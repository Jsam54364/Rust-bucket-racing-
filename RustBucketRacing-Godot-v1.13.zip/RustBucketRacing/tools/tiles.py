"""The pictures on the menus' tiles: crops of the game's own photos (run the game with --photos=<dir>; see
Main.RunPhotos) made into small WebPs in ui/tiles. Usage: python3 tools/tiles.py <photo dir> [name=source ...]
Each tile is 640 x 360 (the tiles show the middle of it, cropped to their own shape)."""
import os
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'ui', 'tiles')

# tile name: (photo, horizontal centre of the crop 0..1)
DEFAULT = {
    'car_rust': ('car_rust', 0.5), 'car_monte': ('car_monte', 0.5), 'car_cts': ('car_cts', 0.5), 'car_civic': ('car_civic', 0.5),
    'garage_cars': ('garage_cars', 0.5), 'garage_paint': ('garage_paint', 0.5), 'garage_tuning': ('garage_tuning', 0.5),
    'garage_setups': ('garage_setups', 0.5), 'play_career': ('play_career', 0.5),
    'map_grid': ('map_grid', 0.5), 'map_spa': ('map_spa', 0.5), 'map_mcr': ('map_mcr_side', 0.5), 'map_compound': ('map_compound', 0.5),
    'map_iroha': ('map_iroha', 0.5),
    'play_freeroam': ('map_iroha_side', 0.5), 'play_timetrial': ('map_spa_side', 0.5), 'play_online': ('map_compound_side', 0.5),
    'play_resume': ('map_grid_side', 0.5),
}


def make(src, cx, dst):
    im = Image.open(src).convert('RGB')
    w, h = im.size
    cw = min(w, int(h * 16 / 9))
    x0 = int(max(0, min(w - cw, cx * w - cw / 2)))
    im = im.crop((x0, 0, x0 + cw, int(cw * 9 / 16))).resize((640, 360), Image.LANCZOS)
    im.save(dst, 'WEBP', quality=80, method=6)
    return os.path.getsize(dst)


def main():
    d = sys.argv[1]
    plan = dict(DEFAULT)
    for a in sys.argv[2:]:
        k, v = a.split('=')
        src, _, cx = v.partition(':')
        plan[k] = (src, float(cx) if cx else 0.5)
    os.makedirs(OUT, exist_ok=True)
    total = 0
    for name, (src, cx) in plan.items():
        p = os.path.join(d, src + '.png')
        if not os.path.exists(p):
            print('missing', p)
            continue
        total += make(p, cx, os.path.join(OUT, name + '.webp'))
    print(f'{len(plan)} tiles, {total / 1024:.0f} kB')


if __name__ == '__main__':
    main()
