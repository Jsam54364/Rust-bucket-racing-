// Menus: camera and menu buttons (top right), the menu, the car setup and controls drawers, and the start /
// help sheet. Everything changes live and is saved.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public interface IGame
    {
        Car Car { get; }
        string CarId { get; }
        string MapId { get; }
        bool SoundOn { get; }
        bool TelemetryOn { get; }
        bool Touch { get; }
        ControlPrefs Prefs { get; }
        int Quality { get; }
        void SetQuality(int q);
        bool Kmh { get; }
        void SetUnits(bool kmh);
        void SwitchCar(string id);
        void SwitchMap(string id);
        void SetGearbox(Gearbox g);
        void ToggleTelemetry();
        void ResetCar(bool toStart);
        void ToGrid();
        void ToggleSound();
        void CycleCamera();
        void ChangeTune(Action<Tune> change);
        void SaveControls();
        void Toast(string s);
        void Go(bool raceTrack);
        void PanelsChanged();
    }

    public sealed class Panels
    {
        readonly IGame g;
        public readonly Control Root;
        IconButton bCam, bMenu;
        PanelContainer menu, tune, controls;
        VBoxContainer menuCol;
        Control help;
        Button[] gfxSeg, unitSeg;
        Button[] carSeg, mapSeg, gbSeg, presetBtns, drvSeg, steerSeg, carPick, mapPick;
        Button mTele, mSound, mTrack, bAbs, bTcs, bAnalog;
        readonly List<(string key, Ui.SliderRow row)> tuneRows = new List<(string, Ui.SliderRow)>();
        Ui.SliderRow cSens, cSpeed, cAssist, cCs, cRec;
        Label touchHint;

        public bool MenuOpen => menu.Visible;
        public bool HelpOpen => help.Visible;
        public bool TuneOpen => tune.Visible;
        public bool ControlsOpen => controls.Visible;
        public bool AnyOpen => menu.Visible || tune.Visible || controls.Visible || help.Visible;

        public Panels(IGame game)
        {
            g = game;
            Root = new Control { Name = "Panels", MouseFilter = Control.MouseFilterEnum.Ignore, Theme = Ui.Theme };
            Root.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            BuildTopRight();
            BuildMenu();
            BuildTune();
            BuildControls();
            BuildHelp();
            Sync();
        }

        static string F(double v, int dp) => v.ToString("F" + dp, System.Globalization.CultureInfo.InvariantCulture);

        /* ---------------- top right ---------------- */
        void BuildTopRight()
        {
            bCam = new IconButton { Icon = 0, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            bMenu = new IconButton { Icon = 1, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            var sb = Ui.Box(Ui.Glass, 16, Ui.Line, 1);
            var sbh = Ui.Box(Ui.Glass, 16, Ui.Amber, 1);
            foreach (var b in new Button[] { bCam, bMenu })
            {
                b.AddThemeStyleboxOverride("normal", sb); b.AddThemeStyleboxOverride("hover", sbh); b.AddThemeStyleboxOverride("pressed", sbh);
                b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            }
            bCam.Pressed += () => g.CycleCamera();
            bMenu.Pressed += () => ShowMenu(!menu.Visible);
            var row = Ui.Row(12);
            row.AddChild(bCam); row.AddChild(bMenu);
            row.SetAnchorsPreset(Control.LayoutPreset.TopRight);
            row.Position = new Vector2(-24 - 76 * 2 - 12, 18);
            row.GrowHorizontal = Control.GrowDirection.Begin;
            row.Name = "TopRight";
            Root.AddChild(row);
            topRow = row;
        }
        HBoxContainer topRow;

        // keep the top-right buttons clear of a notch, and out from under an open drawer on wide screens
        public void Layout(Vector2 size, float safeR)
        {
            float right = 24 + safeR;
            bool drawer = tune.Visible || controls.Visible;
            if (drawer && size.X > 1100) right += DrawerW + 12;
            topRow.Position = new Vector2(size.X - right - 76 * 2 - 12, 18);
            menu.Position = new Vector2(size.X - right - MenuW, 104);
            menu.Size = new Vector2(MenuW, Math.Min(menuCol.GetCombinedMinimumSize().Y + 24, size.Y - 120));
            foreach (var d in new[] { tune, controls })
            {
                d.Position = new Vector2(size.X - DrawerW - safeR, 0);
                d.Size = new Vector2(DrawerW + safeR, size.Y);
            }
        }

        const float MenuW = 400, DrawerW = 460;

        /* ---------------- menu ---------------- */
        void BuildMenu()
        {
            menu = new PanelContainer { Visible = false, Name = "Menu" };
            menu.AddThemeStyleboxOverride("panel", Ui.Box(Ui.Panel, 14, Ui.Line, 1, 10));
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(MenuW - 20, 0) };
            var col = Ui.Col(4);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(col);
            menu.AddChild(scroll);
            menuCol = col;

            col.AddChild(Ui.Heading("Car"));
            col.AddChild(Ui.Seg(new[] { "Rust", "Monte", "CTS-V" }, (i) => { g.SwitchCar(Defs.CarOrder[i]); Sync(); }, out carSeg));
            col.AddChild(Ui.Heading("Map"));
            col.AddChild(Ui.Seg(new[] { "Proving ground", "Spa 1992" }, (i) => { g.SwitchMap(Defs.MapOrder[i]); Sync(); }, out mapSeg));
            col.AddChild(Ui.Sep());
            mTele = MenuItem(col, "Telemetry", () => g.ToggleTelemetry());
            col.AddChild(Ui.Heading("Gearbox"));
            col.AddChild(Ui.Seg(new[] { "Auto", "Semi", "Manual" }, (i) => g.SetGearbox((Gearbox)i), out gbSeg));
            col.AddChild(Ui.Heading("Graphics"));
            col.AddChild(Ui.Seg(new[] { "High", "Medium", "Low" }, (i) => g.SetQuality(i), out gfxSeg));
            col.AddChild(Ui.Heading("Speed units"));
            col.AddChild(Ui.Seg(new[] { "km/h", "mph" }, (i) => g.SetUnits(i == 0), out unitSeg));
            col.AddChild(Ui.Sep());
            MenuItem(col, "Car setup", () => ShowTune(true));
            MenuItem(col, "Controls", () => ShowControls(true));
            MenuItem(col, "Reset car", () => g.ResetCar(false));
            MenuItem(col, "Back to start", () => g.ResetCar(true));
            mTrack = MenuItem(col, "Race track grid", () => g.ToGrid());
            mSound = MenuItem(col, "Sound on", () => g.ToggleSound());
            MenuItem(col, "Controls and map", () => ShowHelp(true));
            MenuItem(col, "Copy debug log", () => { DebugLog.CopyToClipboard(); g.Toast("Debug log copied"); });
            if (!OS.HasFeature("mobile")) MenuItem(col, "Full screen", () =>
            {
                var m = DisplayServer.WindowGetMode();
                DisplayServer.WindowSetMode(m == DisplayServer.WindowMode.Fullscreen ? DisplayServer.WindowMode.Windowed : DisplayServer.WindowMode.Fullscreen);
            });
            Root.AddChild(menu);
        }

        Button MenuItem(VBoxContainer col, string text, Action a)
        {
            var b = Ui.Btn(text, () => { ShowMenu(false); a(); }, false, 56);
            b.Alignment = HorizontalAlignment.Left;
            var flat = Ui.Box(new Color(0, 0, 0, 0), 8, null, 0, 10);
            var hov = Ui.Box(new Color(1, 1, 1, 0.07f), 8, null, 0, 10);
            b.AddThemeStyleboxOverride("normal", flat); b.AddThemeStyleboxOverride("hover", hov); b.AddThemeStyleboxOverride("pressed", hov);
            b.AddThemeColorOverride("font_pressed_color", Ui.Ink);
            col.AddChild(b);
            return b;
        }

        public void ShowMenu(bool on) { menu.Visible = on; g.PanelsChanged(); }

        /* ---------------- car setup drawer ---------------- */
        PanelContainer Drawer(string title, out VBoxContainer body, Action close)
        {
            var d = new PanelContainer { Visible = false };
            d.AddThemeStyleboxOverride("panel", Ui.Box(Ui.Panel, 0, Ui.Line, 1, 0));
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            scroll.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            var col = Ui.Col(8);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            var head = Ui.Row();
            var t = Ui.Text(title.ToUpperInvariant(), Ui.FontBody);
            t.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            head.AddChild(t);
            var cb = Ui.Btn("Close", close, false, 50);
            cb.CustomMinimumSize = new Vector2(110, 50);
            head.AddChild(cb);
            col.AddChild(head);
            scroll.AddChild(Ui.Pad(col, 24, 20, 24, 30));
            d.AddChild(scroll);
            body = col;
            Root.AddChild(d);
            return d;
        }

        void Group(VBoxContainer body, string title, string unit)
        {
            body.AddChild(Ui.Sep());
            var h = Ui.Row();
            var l = Ui.Heading(title); l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            h.AddChild(l);
            if (unit.Length > 0) h.AddChild(Ui.Text(unit, Ui.FontTiny, Ui.Muted));
            body.AddChild(h);
        }

        void TuneSlider(VBoxContainer body, string key, string label, double min, double max, double step, double scale, int dp, string suffix, Action<Tune, double> set)
        {
            var row = Ui.Slider(label, min, max, step, (v) => F(v * scale, dp) + suffix, (v) => g.ChangeTune((t) => set(t, v)));
            body.AddChild(row.Root);
            tuneRows.Add((key, row));
        }

        void BuildTune()
        {
            tune = Drawer("Car setup", out var body, () => ShowTune(false));
            body.AddChild(Ui.Text("Changes apply live. Ride height stays put when you change springs, the same way spring preload works on a coilover.", Ui.FontSmall, Ui.Muted, true));
            body.AddChild(Ui.Seg(new[] { "Comfort", "Street", "Sport", "Race" }, (i) =>
            {
                var name = CarSpec.PresetOrder[i];
                var p = g.Car.Spec.Presets[name];
                g.ChangeTune((t) => t.Apply(p));
                g.Toast(char.ToUpperInvariant(name[0]) + name.Substring(1) + " suspension");
            }, out presetBtns));
            Group(body, "Springs", "kN/m");
            TuneSlider(body, "springF", "Front", 12000, 150000, 500, 0.001, 1, "", (t, v) => t.SpringF = v);
            TuneSlider(body, "springR", "Rear", 12000, 150000, 500, 0.001, 1, "", (t, v) => t.SpringR = v);
            Group(body, "Dampers, bump", "N·s/m");
            TuneSlider(body, "dampF", "Front", 500, 9000, 50, 1, 0, "", (t, v) => t.DampF = v);
            TuneSlider(body, "dampR", "Rear", 500, 9000, 50, 1, 0, "", (t, v) => t.DampR = v);
            TuneSlider(body, "reboundRatio", "Rebound ÷ bump", 1, 2.5, 0.05, 1, 2, "×", (t, v) => t.ReboundRatio = v);
            Group(body, "Anti-roll bars", "kN/m");
            TuneSlider(body, "arbF", "Front", 0, 60000, 500, 0.001, 1, "", (t, v) => t.ArbF = v);
            TuneSlider(body, "arbR", "Rear", 0, 60000, 500, 0.001, 1, "", (t, v) => t.ArbR = v);
            Group(body, "Chassis", "m");
            TuneSlider(body, "comHeight", "Centre of mass height", 0.35, 0.8, 0.01, 1, 2, "", (t, v) => t.ComHeight = v);
            TuneSlider(body, "rollCenter", "Roll centre height", 0, 0.3, 0.01, 1, 2, "", (t, v) => t.RollCenter = v);
            Group(body, "Tyres and brakes", "");
            TuneSlider(body, "grip", "Tyre grip μ", 0.6, 1.8, 0.01, 1, 2, "", (t, v) => t.Grip = v);
            TuneSlider(body, "brakeBias", "Brake bias, front", 0.4, 0.8, 0.01, 100, 0, "%", (t, v) => t.BrakeBias = v);
            Group(body, "Drivetrain", "");
            body.AddChild(Ui.Seg(new[] { "RWD", "FWD", "AWD" }, (i) => { g.ChangeTune((t) => t.Drive = (Drive)i); g.Toast((Drive)i + " drivetrain"); }, out drvSeg));
            Group(body, "Assists", "");
            var tr = Ui.Row();
            bAbs = Ui.Btn("ABS", () => g.ChangeTune((t) => t.Abs = !t.Abs), true);
            bTcs = Ui.Btn("Traction control", () => g.ChangeTune((t) => t.Tcs = !t.Tcs), true);
            bAbs.SizeFlagsHorizontal = bTcs.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            tr.AddChild(bAbs); tr.AddChild(bTcs);
            body.AddChild(tr);
            body.AddChild(Ui.Text("Saved on this device.", Ui.FontTiny, Ui.Muted));
        }

        public void ShowTune(bool on)
        {
            tune.Visible = on;
            if (on) { controls.Visible = false; menu.Visible = false; }
            Sync(); g.PanelsChanged();
        }

        /* ---------------- controls drawer ---------------- */
        void BuildControls()
        {
            controls = Drawer("Controls", out var body, () => ShowControls(false));
            body.AddChild(Ui.Text("How the car answers your hands. Shared by every car and saved on this device.", Ui.FontSmall, Ui.Muted, true));
            Group(body, "Steering", "");
            cSens = Ui.Slider("Sensitivity", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => { g.Prefs.Sens = v; g.SaveControls(); });
            body.AddChild(cSens.Root);
            body.AddChild(Ui.Text("Higher turns more for a small movement of the slider or stick (full lock stays at the end). With buttons or keys, how quickly holding one winds the steering on.", Ui.FontTiny, Ui.Muted, true));
            cSpeed = Ui.Slider("Steering speed", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => g.ChangeTune((t) => t.SteerSpeed = v));
            body.AddChild(cSpeed.Root);
            body.AddChild(Ui.Text("How fast the front wheels can turn, lock to lock. Letting go, they come back to centre almost three times as fast.", Ui.FontTiny, Ui.Muted, true));
            body.AddChild(Ui.Heading("Touch steering"));
            body.AddChild(Ui.Seg(new[] { "Slider", "Buttons" }, (i) =>
            {
                g.Prefs.ButtonSteer = i == 1; g.SaveControls(); Sync();
                g.Toast(i == 1 ? "Touch steering: buttons" : "Touch steering: slider");
            }, out steerSeg));
            Group(body, "Steering assist", "");
            cAssist = Ui.Slider("Assist strength", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + "%" : "Off", (v) => g.ChangeTune((t) => t.SteerAssist = v));
            body.AddChild(cAssist.Root);
            body.AddChild(Ui.Text("Holds full lock back to what the front tyres can use at speed, so stabbing the steering doesn't just scrub them. 0 gives you the whole rack at any speed. Below about 50 km/h both assists stand back while you are steering.", Ui.FontTiny, Ui.Muted, true));
            cCs = Ui.Slider("Counter-steer", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + "%" : "Off", (v) => g.ChangeTune((t) => t.CounterSteer = v));
            body.AddChild(cCs.Root);
            body.AddChild(Ui.Text("When the rear starts to slide, steers into the slide for you to catch it. Higher steps in earlier and harder; lower leaves room for drifts and handbrake turns. The CS light shows when it acts.", Ui.FontTiny, Ui.Muted, true));
            cRec = Ui.Slider("Slide recovery", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + "%" : "Off", (v) => g.ChangeTune((t) => t.Recovery = v));
            body.AddChild(cRec.Root);
            body.AddChild(Ui.Text("How much grip sliding tyres get back when you ease off the throttle and brake, so a slide straightens up. On the pedals (past about half) or the handbrake it stays out of the way. 0 is the raw tyre.", Ui.FontTiny, Ui.Muted, true));
            Group(body, "Pedals", "");
            bAnalog = Ui.Btn("Analogue pedals", () =>
            {
                g.Prefs.AnalogPedals = !g.Prefs.AnalogPedals; g.SaveControls(); Sync();
                g.Toast(g.Prefs.AnalogPedals ? "Analogue pedals on" : "Analogue pedals off: full on when pressed");
            }, true);
            body.AddChild(bAnalog);
            body.AddChild(Ui.Text("On: Gas and Brake press harder the higher you press them, and a tap of the brake gives a light brush. Off: every press is full on.", Ui.FontTiny, Ui.Muted, true));
            var reset = Ui.Btn("Reset controls to defaults", () =>
            {
                g.Prefs.Sens = 1; g.Prefs.ButtonSteer = false; g.Prefs.AnalogPedals = true; g.SaveControls();
                g.ChangeTune((t) => { t.SteerSpeed = 1; t.SteerAssist = 1; t.CounterSteer = 0.5; t.Recovery = 0.75; });
                Sync(); g.Toast("Controls reset");
            });
            reset.AddThemeColorOverride("font_color", Ui.Amber);
            body.AddChild(reset);
        }

        public void ShowControls(bool on)
        {
            controls.Visible = on;
            if (on) { tune.Visible = false; menu.Visible = false; }
            Sync(); g.PanelsChanged();
        }

        /* ---------------- start / help sheet ---------------- */
        void BuildHelp()
        {
            var dim = new ColorRect { Color = new Color(8 / 255f, 10 / 255f, 12 / 255f, 0.45f), MouseFilter = Control.MouseFilterEnum.Stop };
            dim.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            help = dim;
            var center = new CenterContainer { MouseFilter = Control.MouseFilterEnum.Ignore };
            center.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            dim.AddChild(center);
            var card = new PanelContainer();
            card.AddThemeStyleboxOverride("panel", Ui.Box(Ui.Panel, 18, Ui.Line, 1, 0));
            center.AddChild(card);
            // the text scrolls; the Drive / Race track row stays pinned underneath so it is always on screen
            var outer = Ui.Col(0);
            outer.CustomMinimumSize = new Vector2(980, 650);
            card.AddChild(outer);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            outer.AddChild(scroll);
            var col = Ui.Col(12);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(col, 30, 24, 30, 24));

            var title = Ui.Text("RUST BUCKET PROVING GROUND", Ui.FontTitle);
            title.AddThemeFontOverride("font", Ui.Display);
            col.AddChild(title);
            col.AddChild(Ui.Text("Three rear-drive cars, two maps: a flat grid proving ground with its own race track, and Spa-Francorchamps as it was in 1992. Each corner has its own spring, damper and tyre, so the body rolls, pitches and squats for real, and grip follows the weight: brake into a corner to load the front tyres and sharpen the turn-in, feed in throttle to shift it back to the rears.", Ui.FontSmall, new Color(0.76f, 0.8f, 0.83f), true));
            // car pick
            var cars = Ui.Row(10);
            carPick = new Button[Defs.CarOrder.Length];
            for (int i = 0; i < Defs.CarOrder.Length; i++)
            {
                var d = Defs.Cars[Defs.CarOrder[i]];
                string id = d.Id;
                var b = Ui.Btn(d.Title.ToUpperInvariant() + "\n" + d.Sub, () => { g.SwitchCar(id); Sync(); }, true, 84);
                b.Alignment = HorizontalAlignment.Left;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                PickStyle(b);
                carPick[i] = b; cars.AddChild(b);
            }
            col.AddChild(cars);
            var maps = Ui.Row(10);
            mapPick = new Button[Defs.MapOrder.Length];
            for (int i = 0; i < Defs.MapOrder.Length; i++)
            {
                var d = Defs.Maps[Defs.MapOrder[i]];
                string id = d.Id;
                var b = Ui.Btn(d.Name.ToUpperInvariant() + "\n" + d.Sub, () => { g.SwitchMap(id); Sync(); }, true, 84);
                b.Alignment = HorizontalAlignment.Left;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                PickStyle(b);
                mapPick[i] = b; maps.AddChild(b);
            }
            col.AddChild(maps);
            touchHint = Ui.Text("", Ui.FontSmall, new Color(0.83f, 0.86f, 0.88f), true);
            col.AddChild(touchHint);
            // map guide, folded
            var guide = Ui.Text(
                "RACE TRACK  3.2 km circuit around the whole proving ground: 16 corners with four hairpins, two sets of switchbacks and three long straights. Kerbs at every apex, gravel traps outside the slow corners, braking boards before them. Pits and a 10-car grid on the main straight; the lap timer starts when you cross the line.\n" +
                "AHEAD  1.5 km runway with rumble strips on both edges, warning strips at 360 m and a tabletop at 420 m.\n" +
                "LEFT  speed bumps, a one-side articulation strip, moguls, and a gap jump that needs 100 km/h (start about 300 m back).\n" +
                "RIGHT  cone slalom, three kickers, a skid-pad ring, and a 9 m banked bowl.\n" +
                "FAR RIGHT  230 m test strips of dirt, gravel and grass, side by side.\n" +
                "SPA-FRANCORCHAMPS  the 1992 Grand Prix layout, 6.97 km clockwise: La Source, Eau Rouge and Raidillon, Kemmel, Les Combes, Rivage, Pouhon, Stavelot, Blanchimont and the Bus Stop chicane. Guardrails and tyre walls are solid; gravel and grass slow you down. Reset puts you back on the track if you leave it.",
                Ui.FontTiny, new Color(0.79f, 0.82f, 0.85f), true);
            guide.Visible = false;
            var gb = Ui.Btn("MAP GUIDE", () => { guide.Visible = !guide.Visible; }, false, 44);
            gb.Alignment = HorizontalAlignment.Left;
            gb.AddThemeColorOverride("font_color", Ui.Amber);
            gb.AddThemeStyleboxOverride("normal", new StyleBoxEmpty()); gb.AddThemeStyleboxOverride("hover", new StyleBoxEmpty()); gb.AddThemeStyleboxOverride("pressed", new StyleBoxEmpty());
            col.AddChild(gb);
            col.AddChild(guide);
            // actions
            var act = Ui.Row(16);
            var go = Ui.Btn("DRIVE", () => g.Go(false), false, 64);
            go.CustomMinimumSize = new Vector2(220, 64);
            go.AddThemeStyleboxOverride("normal", Ui.Box(Ui.Amber, 12, null, 0, 12));
            go.AddThemeStyleboxOverride("hover", Ui.Box(Ui.Amber.Lightened(0.1f), 12, null, 0, 12));
            go.AddThemeStyleboxOverride("pressed", Ui.Box(Ui.Amber.Darkened(0.1f), 12, null, 0, 12));
            go.AddThemeColorOverride("font_color", Ui.AmberInk); go.AddThemeColorOverride("font_hover_color", Ui.AmberInk);
            go.AddThemeFontSizeOverride("font_size", 28);
            go.AddThemeFontOverride("font", Ui.Display);
            var rt = Ui.Btn("RACE TRACK", () => g.Go(true), false, 64);
            rt.CustomMinimumSize = new Vector2(220, 64);
            rt.AddThemeFontSizeOverride("font_size", 24);
            rt.AddThemeFontOverride("font", Ui.Display);
            act.AddChild(go); act.AddChild(rt);
            var credit = Ui.Text("Cars: \"Lowpoly Abandoned Simple Car Prop\" by Rashad Ibrahimli and \"1987 Chevrolet Monte Carlo SS\" by Randomness. Track and race car: \"Circuit de Spa-Francorchamps 1992 layout\" and \"2004 Cadillac CTS-V race car\" by Dave Love (sketchfab.com/Tyler_Dave). All CC BY 4.0 · Rust Bucket Racing v" + DebugLog.Version, Ui.FontTiny, Ui.Muted, true);
            credit.CustomMinimumSize = new Vector2(380, 0);
            act.AddChild(credit);
            outer.AddChild(Ui.Pad(act, 30, 12, 30, 18));
            Root.AddChild(dim);
        }

        static void PickStyle(Button b)
        {
            b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(Ui.Amber, 0.12f), 10, Ui.Amber, 2, 12));
            b.AddThemeStyleboxOverride("hover_pressed", Ui.Box(new Color(Ui.Amber, 0.16f), 10, Ui.Amber, 2, 12));
            b.AddThemeStyleboxOverride("normal", Ui.Box(new Color(1, 1, 1, 0.05f), 10, Ui.Line, 1, 12));
            b.AddThemeColorOverride("font_pressed_color", Ui.Amber);
            b.AddThemeColorOverride("font_hover_pressed_color", Ui.Amber);
            b.AddThemeFontSizeOverride("font_size", 20);
        }

        public void ShowHelp(bool on)
        {
            help.Visible = on;
            if (on) { menu.Visible = false; tune.Visible = false; controls.Visible = false; }
            Sync(); g.PanelsChanged();
        }

        public void CloseAll() { menu.Visible = false; tune.Visible = false; controls.Visible = false; help.Visible = false; g.PanelsChanged(); }

        // a touch at p lands on an open panel (so the driving controls ignore it)
        public bool Covers(Vector2 p)
        {
            if (help.Visible) return true;
            foreach (Control c in new Control[] { menu, tune, controls, topRow })
                if (c.Visible && c.GetGlobalRect().HasPoint(p)) return true;
            return false;
        }

        public void TapOutside(Vector2 p)
        {
            if (menu.Visible && !menu.GetGlobalRect().HasPoint(p) && !topRow.GetGlobalRect().HasPoint(p)) ShowMenu(false);
        }

        /* ---------------- sync every control to the current state ---------------- */
        public void Sync()
        {
            var car = g.Car;
            if (car == null) return;
            var t = car.Tune;
            Ui.Light(carSeg, Array.IndexOf(Defs.CarOrder, g.CarId));
            Ui.Light(carPick, Array.IndexOf(Defs.CarOrder, g.CarId));
            Ui.Light(mapSeg, Array.IndexOf(Defs.MapOrder, g.MapId));
            Ui.Light(mapPick, Array.IndexOf(Defs.MapOrder, g.MapId));
            Ui.Light(gbSeg, (int)t.Gearbox);
            Ui.Light(gfxSeg, g.Quality);
            Ui.Light(unitSeg, g.Kmh ? 0 : 1);
            mTele.Text = g.TelemetryOn ? "Telemetry  ·  on" : "Telemetry";
            mSound.Text = g.SoundOn ? "Sound on" : "Sound off";
            mTrack.Text = g.MapId == "grid" ? "Race track grid" : "Starting grid";
            int pi = -1;
            for (int i = 0; i < CarSpec.PresetOrder.Length; i++) if (t.Matches(car.Spec.Presets[CarSpec.PresetOrder[i]])) pi = i;
            Ui.Light(presetBtns, pi);
            foreach (var (key, row) in tuneRows) row.Show(TuneValue(t, key));
            Ui.Light(drvSeg, (int)t.Drive);
            bAbs.SetPressedNoSignal(t.Abs); bAbs.Text = t.Abs ? "ABS  ·  on" : "ABS  ·  off";
            bTcs.SetPressedNoSignal(t.Tcs); bTcs.Text = t.Tcs ? "Traction control  ·  on" : "Traction control  ·  off";
            cSens.Show(g.Prefs.Sens); cSpeed.Show(t.SteerSpeed); cAssist.Show(t.SteerAssist); cCs.Show(t.CounterSteer); cRec.Show(t.Recovery);
            Ui.Light(steerSeg, g.Prefs.ButtonSteer ? 1 : 0);
            bAnalog.SetPressedNoSignal(g.Prefs.AnalogPedals); bAnalog.Text = g.Prefs.AnalogPedals ? "Analogue pedals  ·  on" : "Analogue pedals  ·  off";
            touchHint.Text = g.Touch
                ? "Left thumb: slide along the steering pad, and flick the gear slider up or down (or tap its ends) to shift. Right thumb: Gas, Brake and Hand. Gas and Brake are pressure-sensitive: press higher for more, lower (or slide down) to feather. Gearbox (menu): Auto shifts for you and reverses when you hold Brake at a stop; Semi lets you shift but protects the engine; Manual takes any gear. Camera and menu are top right; drag in the orbit camera to fly round the car, pinch to zoom."
                : "W S throttle, brake (tap S to feather)  ·  A D steer  ·  Space handbrake  ·  C camera  ·  G telemetry  ·  T car setup  ·  K controls  ·  Q E shift down, up  ·  M gearbox  ·  V car  ·  N map  ·  L starting grid  ·  R reset (Shift+R start)  ·  H help  ·  drag to look, wheel or + - to zoom. A gamepad works too.";
        }

        static double TuneValue(Tune t, string k)
        {
            switch (k)
            {
                case "springF": return t.SpringF;
                case "springR": return t.SpringR;
                case "dampF": return t.DampF;
                case "dampR": return t.DampR;
                case "reboundRatio": return t.ReboundRatio;
                case "arbF": return t.ArbF;
                case "arbR": return t.ArbR;
                case "comHeight": return t.ComHeight;
                case "rollCenter": return t.RollCenter;
                case "grip": return t.Grip;
                default: return t.BrakeBias;
            }
        }
    }
}
