// Low graphics has no shadow maps; a soft dark footprint stands in for the car's shadow. It lies where the sun
// throws the body onto the ground, so it slides out from under the car as the body rises, grows softer and fades
// over a jump, turns with the car and lies on slopes and banking.
using System;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class BlobShadow
    {
        public readonly MeshInstance3D Node;
        readonly ShaderMaterial mat;
        float halfW = 0.8f, halfL = 2f;

        public BlobShadow()
        {
            mat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/blob.gdshader") };
            Node = new MeshInstance3D
            {
                Name = "BlobShadow", Mesh = new PlaneMesh { Size = Vector2.One }, MaterialOverride = mat,
                CastShadow = GeometryInstance3D.ShadowCastingSetting.Off, Visible = false,
            };
        }

        // footprint from the physics hull (already at the car's size)
        public void SetCar(CarSpec spec)
        {
            halfW = (float)(spec.HullMaxX - spec.HullMinX) * 0.5f * 0.94f;
            halfL = (float)(spec.HullMaxZ - spec.HullMinZ) * 0.5f * 0.96f;
        }

        // toSun: unit vector towards the sun
        public void Update(Car car, TerrainBase terrain, Vector3 toSun)
        {
            V3 c = car.Pos; // centre of mass
            double h = Math.Max(0, c.Y - terrain.HeightVis(c.X, c.Z));
            double k = h / Math.Max(0.2, toSun.Y);
            double sx = c.X - toSun.X * k, sz = c.Z - toSun.Z * k;
            float gy = (float)terrain.HeightVis(sx, sz);
            var N = MeshUtil.V(terrain.Normal(sx, sz)).Normalized();
            var f = MeshUtil.V(car.Forward);
            var F = f - N * f.Dot(N);
            F = F.LengthSquared() > 1e-6f ? F.Normalized() : Vector3.Forward;
            var R = F.Cross(N).Normalized();
            // the higher the body above its ride height, the bigger, softer and fainter
            float air = (float)Math.Max(0, h - car.Tune.ComHeight);
            float grow = 1 + air * 0.25f, soft = 0.3f + air * 0.35f;
            var half = new Vector2(halfW * grow, halfL * grow);
            var ext = half + new Vector2(soft, soft);
            Node.GlobalTransform = new Transform3D(new Basis(R * (2 * ext.X), N, -F * (2 * ext.Y)), new Vector3((float)sx, gy + 0.02f, (float)sz));
            mat.SetShaderParameter("ext", ext);
            mat.SetShaderParameter("half_size", half);
            mat.SetShaderParameter("soft", soft);
            mat.SetShaderParameter("strength", 0.55f * Mathf.Clamp(1 - air / 3.5f, 0.12f, 1f));
        }
    }
}
