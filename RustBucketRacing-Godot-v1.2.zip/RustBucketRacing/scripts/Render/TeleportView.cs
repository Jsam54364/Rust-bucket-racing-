// The glowing pads in the middle of a stage's turning circles: drive onto one to come out at the other end of
// the road (Main.CheckTeleport). Rippling rings on the ground, a glow over them and a sign saying where it goes.
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public static class TeleportView
    {
        public static Node3D Build(StageInfo st)
        {
            var root = new Node3D { Name = "Teleports" };
            var sh = GD.Load<Shader>("res://shaders/teleport.gdshader");
            for (int k = 0; k < st.Ends.Length; k++)
            {
                var e = st.Ends[k];
                var n = new Node3D { Name = "Teleport" + k, Position = new Vector3((float)e.X, (float)e.Y, (float)e.Z) };
                float r = (float)e.Island;
                var disc = new ShaderMaterial { Shader = sh };
                disc.SetShaderParameter("part", 0);
                n.AddChild(new MeshInstance3D
                {
                    Mesh = new PlaneMesh { Size = new Vector2(2 * r, 2 * r), Material = disc },
                    Position = new Vector3(0, 0.05f, 0),
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                });
                const float H = 3f;
                var glow = new ShaderMaterial { Shader = sh };
                glow.SetShaderParameter("part", 1);
                glow.SetShaderParameter("height", H);
                n.AddChild(new MeshInstance3D
                {
                    Mesh = new CylinderMesh { TopRadius = r * 0.97f, BottomRadius = r * 0.97f, Height = H, RadialSegments = 40, Rings = 1, CapTop = false, CapBottom = false, Material = glow },
                    Position = new Vector3(0, H / 2 + 0.05f, 0),
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                });
                n.AddChild(new Label3D
                {
                    Text = k == 0 ? "TELEPORT\nto the top of the stage" : "TELEPORT\nto the bottom of the stage",
                    Billboard = BaseMaterial3D.BillboardModeEnum.Enabled,
                    FontSize = 72, OutlineSize = 14, PixelSize = 0.008f,
                    Modulate = new Color(0.75f, 0.92f, 1f), OutlineModulate = new Color(0.02f, 0.08f, 0.16f, 0.85f),
                    Position = new Vector3(0, H + 0.9f, 0),
                    CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                });
                root.AddChild(n);
            }
            return root;
        }
    }
}
