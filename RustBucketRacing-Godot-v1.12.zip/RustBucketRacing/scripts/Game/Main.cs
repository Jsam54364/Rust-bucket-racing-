// The game: builds the scene in code, steps the 480 Hz simulation, and wires cameras, effects, sound,
// HUD, touch controls and menus together.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Godot;
using RustBucket.Audio;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public partial class Main : Node3D, IGame
    {
        const double DT = 1.0 / 480;
        static readonly V3 SpawnPos = new V3(0, 0, 5);

        // look: tweak these to taste on a device
        const float SunEnergy = 1.45f, AmbientSky = 0.85f, Exposure = 0.95f;
        const float FogGrid = 0.0003f, FogMap = 0.00045f;

        Settings store;
        GridTerrain gridTerrain;
        TerrainBase terrain;
        string mapId = "grid", carId = "rust";
        Car car;
        readonly ControlPrefs prefs = new ControlPrefs();
        DriverInput input;
        readonly CameraRig rig = new CameraRig();
        Cones cones;
        LapTimer lap;
        CourseSet courses;      // a map's other timed courses (the compound's club circuit, oval, drag strip...)
        CourseSet.Entry shownCourse;   // the course whose time the HUD is showing (it stays up a moment after a run)
        MapPack pack;           // the map pack being driven (null on the proving ground)
        StageTimer stage;       // point-to-point maps (Monte Carlo) time stages instead of laps
        bool stageDown;         // the way the stage start puts you: false up from the START gantry, true down from the FINISH
        Effects fx;

        Camera3D cam;
        DirectionalLight3D sun;
        Godot.Environment env;
        ProvingGroundView pgView;
        MeshInstance3D ground;
        ShaderMaterial groundMat;
        sealed class MapEntry { public MapPack Pack; public MeshTerrain Terrain; public MapWorldView View; }
        readonly Dictionary<string, MapEntry> maps = new Dictionary<string, MapEntry>();
        ConesView conesView;
        SkidMarks skids;
        SmokeView smoke;
        BlobShadow blob;
        static readonly Vector3 ToSun = new Vector3(-0.42f, 0.74f, -0.52f).Normalized();
        readonly Dictionary<string, CarView> carViews = new Dictionary<string, CarView>();
        CarView carView;

        AudioOut audioOut;
        EngineAudio audio;
        SfxData sfxData;
        readonly double[] vols = { 1, 1, 1, 1, 1 };   // player volume per kind of sound (EngineAudio.Kind)
        // menus: a short sample of the kind of sound being set (the paused game is otherwise silent)
        int previewKind = -1;
        double previewT, previewDur, previewCool;
        readonly SoundState pv = new SoundState();
        readonly Dictionary<string, EngineData> engineFiles = new Dictionary<string, EngineData>();
        readonly SoundState snd = new SoundState();
        bool soundOn = true;

        Hud hud;
        TouchControls touch;
        Panels panels;
        FrontEnd front;
        MapLibrary lib;
        bool telemetry, touchDevice;
        bool hasSession, wasPaused;     // a drive has been started (the main menu offers to resume it); menus open

        double acc, lapFlash, loadingT;
        bool busy;
        // camera drag / pinch
        readonly Dictionary<int, Vector2> camTouches = new Dictionary<int, Vector2>();
        float pinch;
        bool mouseDrag;
        V3 camPrev, camVel; bool hasCamPrev;
        // graphics quality (fixed; changing the 3D resolution on the fly caused hitches and brightness jumps)
        int quality;
        int warmFrames = 10;
        // performance log: a line every 30 s, and each long frame (up to 40 a run)
        double perfClock, perfSum, perfWorst; int perfFrames, perfLong, longLines, gcSeen0, gcSeen2, gcLine0, gcLine2;
        Vector2 lastSize; float safeL, safeR;
        // start-up marker for the boot screen, and the self-test CI runs (-- --smoke --shots=<dir>)
        bool bootOk, selfTest;
        double bootT, simClock, smokeReal, smokeLog;
        string shotDir = "user://smoke", smokeStep = "";
        int shotN;
        static bool crashHooks;

        public Car Car => car;
        public string CarId => carId;
        public string MapId => mapId;
        public bool SoundOn => soundOn;
        public bool TelemetryOn => telemetry;
        public bool Touch => touchDevice;
        public ControlPrefs Prefs => prefs;
        public int Quality => quality;
        public bool Kmh => hud == null || hud.Kmh;
        public Settings Store => store;
        public MapLibrary Library => lib;
        public bool Busy => busy;
        public bool HasSession => hasSession;
        public bool Paused => front != null && front.IsOpen;

        public void SetUnits(bool kmh)
        {
            hud.Kmh = kmh;
            store.Set("units", kmh ? "kmh" : "mph");
            SyncUi();
            Toast(kmh ? "Speed in km/h" : "Speed in mph");
        }
        string RunState => Paused ? "in the menus" : "driving " + mapId + "/" + carId;
        CarDef Def => Defs.Cars[carId];

        public override void _Ready()
        {
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            DebugLog.Trace("main: start · " + DebugLog.DeviceInfo());
            if (!crashHooks)
            {
                crashHooks = true;
                AppDomain.CurrentDomain.UnhandledException += (s, e) => GD.PrintErr("[crash] unhandled .NET exception: " + e.ExceptionObject);
                TaskScheduler.UnobservedTaskException += (s, e) => { GD.PrintErr("[crash] unobserved task exception: " + e.Exception); e.SetObserved(); };
            }
            var args = OS.GetCmdlineUserArgs();
            selfTest = Array.IndexOf(args, "--smoke") >= 0;
            foreach (var a in args) if (a.StartsWith("--shots=")) shotDir = a.Substring(8);
            GetTree().QuitOnGoBack = false;
            DebugLog.Trace("settings");
            store = new Settings();
            prefs.Sens = store.Num("sens", 1);
            prefs.ButtonSteer = store.Bool("buttonSteer", false);
            prefs.AnalogPedals = store.Bool("analogPedals", true);
            telemetry = store.Bool("telemetry", false);
            soundOn = store.Bool("sound", true);
            stageDown = store.Bool("stageDown", false);
            for (int k = 0; k < vols.Length; k++) vols[k] = Math.Clamp(store.Num(EngineAudio.KindKeys[k], 1), 0, 1);
            // installed maps (downloads): before the menus are built, which list them
            DebugLog.Trace("map library");
            lib = new MapLibrary(this) { CanReplace = (id) => !busy, Replacing = DropMap };
            foreach (var a in args) if (a.StartsWith("--maps=")) lib.FallbackDir = a.Substring(7);
            lib.Changed += () => { panels?.MapsChanged(); front?.MapsChanged(); };

            DebugLog.Trace("scene");
            BuildScene();
            GetViewport().UseOcclusionCulling = false; // on only for maps with occluders (SwitchMap)
            quality = Math.Clamp((int)store.Num("quality", OS.HasFeature("mobile") ? 1 : 0), 0, 2);
            ApplyQuality();

            DebugLog.Trace("proving ground");
            gridTerrain = ProvingGround.BuildGridMap();
            terrain = gridTerrain;
            pgView = new ProvingGroundView(gridTerrain);
            AddChild(pgView.Root);
            groundMat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/surface.gdshader") };
            groundMat.SetShaderParameter("kind", 0);
            ground = new MeshInstance3D { Name = "Ground", Mesh = ProvingGroundView.GroundMesh(28, 250, groundMat), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
            AddChild(ground);
            cones = new Cones(ProvingGround.BuildCones(), terrain);
            conesView = new ConesView(cones.List.Count);
            AddChild(conesView.Node);
            skids = new SkidMarks();
            AddChild(skids.Root);
            smoke = new SmokeView();
            AddChild(smoke.Node);
            blob = new BlobShadow();
            AddChild(blob.Node);
            fx = new Effects(skids, terrain);

            input = new DriverInput(prefs) { OnAction = OnAction };
            string want = store.Str("car", "rust");
            carId = Defs.Cars.ContainsKey(want) ? want : "rust";
            DebugLog.Trace("car model " + carId);
            try { ShowCarView(carId); }
            catch (Exception e)
            {
                GD.PushError("car model: " + e.Message);
                carId = "rust";
                try { ShowCarView(carId); }
                catch (Exception e2) { GD.PushError("car model: " + e2.Message); carView = CarView.Empty(); carViews[carId] = carView; AddChild(carView.Root); }
            }
            DebugLog.Trace("car physics");
            car = new Car(terrain, store.LoadTune(Def.Spec), Def.Spec);
            car.Reset(SpawnPos, 0);
            ApplyCameraDef();
            rig.Snap(car);
            lap = new LapTimer(terrain.Circuit);

            // sound
            DebugLog.Trace("sound");
            audioOut = new AudioOut { Name = "Audio" };
            AddChild(audioOut);
            try
            {
                var sfx = AudioData.Sfx(FileAccess.GetFileAsString("res://data/sfx.json"));
                sfxData = sfx;
                audio = new EngineAudio(audioOut.MixRate, sfx) { Enabled = soundOn };
                for (int k = 0; k < vols.Length; k++) audio.SetVolume((EngineAudio.Kind)k, vols[k]);
                SetEngineSound(carId);
                audioOut.Engine = audio;
            }
            catch (Exception e) { GD.PushError("engine sound: " + e.Message); audio = null; }

            // HUD, touch controls, menus
            DebugLog.Trace("ui");
            var layer = new CanvasLayer { Name = "UI" };
            AddChild(layer);
            hud = new Hud { Name = "Hud", Theme = Ui.Theme, Kmh = store.Str("units", "kmh") == "kmh", Telemetry = telemetry };
            hud.OnUnits = () => SetUnits(!hud.Kmh);
            layer.AddChild(hud);
            touchDevice = DisplayServer.IsTouchscreenAvailable() || OS.HasFeature("mobile") || selfTest;
            touch = new TouchControls { Name = "Touch", Drv = input, Visible = touchDevice };
            layer.AddChild(touch);
            panels = new Panels(this);
            layer.AddChild(panels.Root);
            touch.Blocked = (p) => panels.Covers(p);
            // the front end over everything: the game starts at the main menu, in the garage studio
            DebugLog.Trace("front end");
            front = new FrontEnd(this);
            layer.AddChild(front.Root);
            front.Open(FrontEnd.Page.Main, false);
            DebugLog.Trace("ready");
            if (selfTest) Callable.From(() => RunSmoke()).CallDeferred();
        }

        void BuildScene()
        {
            var sky = new ProceduralSkyMaterial
            {
                SkyTopColor = new Color(0.30f, 0.50f, 0.80f),
                SkyHorizonColor = new Color(0.74f, 0.80f, 0.87f),
                SkyCurve = 0.12f,
                GroundHorizonColor = new Color(0.66f, 0.69f, 0.72f),
                GroundBottomColor = new Color(0.36f, 0.37f, 0.40f),
                SunAngleMax = 25,
                SunCurve = 0.12f,
            };
            env = new Godot.Environment
            {
                BackgroundMode = Godot.Environment.BGMode.Sky,
                Sky = new Sky { SkyMaterial = sky },
                AmbientLightSource = Godot.Environment.AmbientSource.Sky,
                AmbientLightSkyContribution = AmbientSky,
                ReflectedLightSource = Godot.Environment.ReflectionSource.Sky,
                TonemapMode = Godot.Environment.ToneMapper.Aces,
                TonemapExposure = Exposure,
                FogEnabled = true,
                FogLightColor = new Color(0.70f, 0.76f, 0.83f),
                FogDensity = FogGrid,
                FogSkyAffect = 0,
            };
            AddChild(new WorldEnvironment { Name = "Environment", Environment = env });
            sun = new DirectionalLight3D
            {
                Name = "Sun",
                ShadowEnabled = true,
                LightEnergy = SunEnergy,
                LightColor = new Color(1f, 0.95f, 0.87f),
                DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel2Splits,
                DirectionalShadowMaxDistance = 90,
                ShadowBias = 0.04f,
                ShadowNormalBias = 1.2f,
                ShadowBlur = 1.2f,
            };
            AddChild(sun);
            var L = new Vector3(-0.42f, 0.74f, -0.52f).Normalized(); // towards the sun
            sun.LookAtFromPosition(Vector3.Zero, -L, Vector3.Up);
            cam = new Camera3D { Name = "Camera", Near = 0.1f, Far = 6000, Fov = 60, Current = true };
            AddChild(cam);
        }

        /* ---------------- cars ---------------- */
        void ShowCarView(string id)
        {
            var v = EnsureCarView(id);
            foreach (var kv in carViews) kv.Value.SetVisible(kv.Key == id);
            carView = v;
            blob?.SetCar(Defs.Cars[id].Spec);
        }

        // a car's model, made the first time it is wanted (by the game or the garage)
        CarView EnsureCarView(string id)
        {
            if (carViews.TryGetValue(id, out var v)) return v;
            var d = Defs.Cars[id];
            DebugLog.Trace("car model " + id);
            v = d.Pack ? CarView.FromPack(FileAccess.GetFileAsBytes(d.Model)) : CarView.FromScene(d.Model);
            v.ModelScale = d.ModelScale;
            v.AddShadowProxy(d.Spec);
            AddChild(v.Root);
            v.SetVisible(false);
            carViews[id] = v;
            return v;
        }

        public bool HasCarView(string id) => carViews.ContainsKey(id);

        // the garage studio borrows a model for its turntable and gives it back after
        public CarView BorrowCarView(string id)
        {
            try { return EnsureCarView(id); }
            catch (Exception e) { GD.PushError("car model " + id + ": " + e.Message); return null; }
        }

        public void ReturnCarView(string id, CarView v)
        {
            if (v == null) return;
            v.Root.Reparent(this, false);
            v.Root.Transform = Transform3D.Identity;
            v.SetVisible(id == carId);
            if (v == carView && car != null) v.Update(car, Def.SteerRatio);
        }

        void ApplyCameraDef()
        {
            var d = Def;
            rig.ChaseDist = d.Chase; rig.Bumper = d.Bumper; rig.HasCockpit = d.HasCockpit; rig.Cockpit = d.Cockpit;
        }

        void SetEngineSound(string id)
        {
            if (audio == null) return;
            var d = Defs.Cars[id];
            if (!engineFiles.TryGetValue(d.Engine, out var data))
            {
                data = AudioData.Engine(FileAccess.GetFileAsString(d.Engine));
                engineFiles[d.Engine] = data;
            }
            var pf = data.Profile.Clone();
            d.EngineProfile?.Invoke(pf);
            audio.SetEngine(data, pf);
        }

        // driver preferences follow you from car to car; everything else in the setup is per car
        static Tune KeepShared(Tune src, Tune dst)
        {
            dst.Gearbox = src.Gearbox; dst.Abs = src.Abs; dst.Tcs = src.Tcs;
            dst.SteerAssist = src.SteerAssist; dst.CounterSteer = src.CounterSteer; dst.SteerSpeed = src.SteerSpeed; dst.Recovery = src.Recovery;
            return dst;
        }

        // Switch cars in place: the new car drops in where the old one is, facing the same way, at rest.
        public async void SwitchCar(string id)
        {
            if (busy || !Defs.Cars.ContainsKey(id) || (id == carId && carView != null)) return;
            busy = true;
            DebugLog.State("loading car " + id); DebugLog.Trace("loading car " + id);
            try
            {
                if (!carViews.ContainsKey(id)) { SetLoading("Loading car"); await Frames(2); }
                ShowCarView(id);
                store.SaveTune(carId, car.Tune);
                var spec = Defs.Cars[id].Spec;
                var nt = KeepShared(car.Tune, store.LoadTune(spec));
                var next = new Car(terrain, nt, spec);
                V3 f = car.Forward, bas = car.Pos - car.Q.Rotate(car.ComModel);
                next.Reset(new V3(bas.X, 0, bas.Z), Math.Atan2(-f.X, -f.Z), car.Pos.Y);
                if (nt.Gearbox != Gearbox.Auto) next.Engine.Gear = 1;
                car = next; carId = id;
                store.Set("car", id); store.SaveTune(id, car.Tune);
                ApplyCameraDef(); rig.Snap(car);
                bool noInterior = rig.Mode == 4 && !rig.HasCockpit;
                if (noInterior) rig.Mode = 2;
                fx.ResetTrails();
                lap.Reset(); stage?.Reset(); courses?.Reset();
                SetEngineSound(id);
                SyncUi();
                Toast(Defs.Cars[id].Toast + (noInterior ? " · no interior: bumper cam" : ""));
                SetLoading("");
            }
            catch (Exception e) { SetLoading("Car model failed to load: " + e.Message, 5); GD.PushError(e.ToString()); }
            finally { busy = false; SyncUi(); DebugLog.State(RunState); }
        }

        /* ---------------- maps ---------------- */
        public void SwitchMap(string id) => _ = SwitchMapAsync(id);

        async Task SwitchMapAsync(string id)
        {
            if (busy || !Defs.Maps.ContainsKey(id) || id == mapId) return;
            busy = true;
            DebugLog.State("loading map " + id); DebugLog.Trace("loading map " + id);
            var md = Defs.Maps[id];
            try
            {
                MapEntry m = null;
                if (id != "grid")
                {
                    if (!maps.TryGetValue(id, out m))
                    {
                        SetLoading("Loading " + md.Name);
                        await Frames(2); // let the label paint before the heavy lifting
                        if (!FileAccess.FileExists(md.Pack))
                        {
                            SetLoading(md.Name + " isn't installed: get it from Maps in the main menu", 6);
                            return;
                        }
                        var bytes = FileAccess.GetFileAsBytes(md.Pack);
                        if (bytes == null || bytes.Length == 0) throw new Exception("map data missing");
                        var pk = await Task.Run(() => MapPack.Load(bytes));
                        var tr = await Task.Run(() => MapPack.BuildTerrain(pk));
                        m = new MapEntry { Pack = pk, Terrain = tr, View = new MapWorldView(pk, md.Occlude) };
                        AddChild(m.View.Root);
                        maps[id] = m;
                        DebugLog.Trace($"map {id}: {pk.Chunks.Length} chunks, {m.View.LodDraws} draws with LODs, {m.View.Occluders} occluders, {pk.Walls.Length / 6} wall segments");
                    }
                }
                foreach (var kv in maps) kv.Value.View.Root.Visible = kv.Key == id;
                bool grid = id == "grid";
                pgView.Root.Visible = grid;
                terrain = grid ? (TerrainBase)gridTerrain : m.Terrain;
                pack = grid ? null : m.Pack;
                if (pack?.ExtrasError != null) GD.PushWarning($"map {id}: its extras didn't read ({pack.ExtrasError})");
                groundMat.SetShaderParameter("kind", grid ? 0 : 9);
                ground.Position = new Vector3(0, grid ? 0 : m.View.FloorY, 0);
                env.FogDensity = grid ? FogGrid : md.Fog > 0 ? md.Fog : FogMap;
                cam.Far = md.Far;
                // occlusion culling only pays where hills hide most of the map
                GetViewport().UseOcclusionCulling = !grid && md.Occlude && m.View.Occluders > 0;
                mapId = id; store.Set("map", id);
                car.Terrain = terrain;
                lap = new LapTimer(terrain.Circuit);
                stage = terrain.Circuit?.Stage != null ? new StageTimer(terrain.Circuit) : null;
                var coneSpots = grid ? ProvingGround.BuildCones() : pack.Cones;
                cones = new Cones(coneSpots, terrain);
                conesView.Use(coneSpots.Count);
                conesView.Node.Visible = coneSpots.Count > 0;
                courses = pack != null && pack.Courses.Count > 0 ? new CourseSet(pack.Courses) : null;
                shownCourse = null;
                fx.Terrain = terrain;
                if (grid) { car.Reset(SpawnPos, 0); fx.Clear(); rig.Snap(car); rig.ClearTrack(); }
                else ToGrid(0, true);
                SetLoading("");
                Toast(md.Toast);
            }
            catch (Exception e) { SetLoading(md.Name + " failed to load: " + e.Message, 5); GD.PushError(e.ToString()); }
            finally { busy = false; SyncUi(); DebugLog.State(RunState); DebugLog.Trace("map " + mapId + " ready"); }
        }

        // Free Roam from the front end: load the map (the menu stays up meanwhile), put the car at the start
        // picked (test areas or race track; uphill or downhill), and drive.
        public async void StartFreeRoam(string map, int start)
        {
            if (busy || !Defs.Maps.ContainsKey(map)) return;
            if (map != mapId) await SwitchMapAsync(map);
            if (mapId != map)
            {
                front.DriveFailed(hud.Loading.Length > 0 ? hud.Loading : "Couldn't load " + Defs.Maps[map].Name);
                SetLoading("");
                return;
            }
            var md = Defs.Maps[map];
            if (md.Stage && stage != null) StageStart(start == 1, true);
            else if (map == "grid" && start == 0)
            {
                car.Reset(SpawnPos, 0); cones.Reset(); fx.Clear(); lap.Reset(); rig.Snap(car); rig.ClearTrack();
                if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            }
            else if (start > 0 && pack != null && start - 1 < pack.Spots.Count) ToSpot(start - 1, true);
            else ToGrid(0, true);
            hasSession = true;
            front.Close();
            Toast(md.Toast);
            DebugLog.State(RunState);
        }

        // the next map in the order that this build has (a map whose pack comes in its own zip may be missing)
        static bool MapAvailable(string id) => Defs.Maps.TryGetValue(id, out var md) && (id == "grid" || FileAccess.FileExists(md.Pack));

        // a map is about to be removed or replaced by a new version: off it (to the proving ground, which loads at
        // once) and forget its loaded copy
        void DropMap(string id)
        {
            if (mapId == id) { SwitchMap("grid"); DebugLog.Trace("off map " + id + ": now on " + mapId); }
            if (maps.TryGetValue(id, out var m)) { m.View.Root.QueueFree(); maps.Remove(id); }
            DebugLog.Trace("map " + id + " let go");
        }
        string NextMapId()
        {
            int k = Array.IndexOf(Defs.MapOrder, mapId);
            for (int i = 1; i <= Defs.MapOrder.Length; i++)
            {
                string id = Defs.MapOrder[(k + i) % Defs.MapOrder.Length];
                if (MapAvailable(id)) return id;
            }
            return mapId;
        }

        async Task Frames(int n)
        {
            for (int i = 0; i < n; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        }

        void SetLoading(string s, double hold = 0) { hud.Loading = s; loadingT = hold; }

        /* ---------------- resets ---------------- */
        public void ResetCar(bool toStart)
        {
            var c = terrain.Circuit;
            if (toStart && mapId != "grid") { ToGrid(); return; }
            if (toStart) { car.Reset(SpawnPos, 0); cones.Reset(); fx.Clear(); Toast("Back at the start line"); }
            else if (pack != null && pack.Roads.Count > 0)
            {
                // a compound: off every road and pad (or off the edge of the map) puts you on the nearest road
                var h = RoadFinder.Nearest(pack.Roads, car.Pos.X, car.Pos.Y, car.Pos.Z);
                bool off = !h.Found || (h.Dist > h.Half + 5.5 && !RoadFinder.OnPad(pack.Pads, car.Pos.X, car.Pos.Z));
                if (h.Found && (off || terrain.HeightVis(car.Pos.X, car.Pos.Z) <= terrain.Floor)) ToRoad(h);
                else { car.ResetUpright(); Toast("Car reset"); }
            }
            else if (c != null && c.Mesh)
            {
                // a real circuit: off the track (or off the edge of the map) puts you back on the racing line
                var n = c.Path is PolyPath pp ? pp.Nearest(car.Pos.X, car.Pos.Y - 0.5, car.Pos.Z, -1) : c.Path.Nearest(car.Pos.X, car.Pos.Z);
                if (n.Dist > c.Width / 2 + 3 || terrain.HeightVis(car.Pos.X, car.Pos.Z) <= terrain.Floor) ToTrack(n.S);
                else { car.ResetUpright(); Toast("Car reset"); }
            }
            else { car.ResetUpright(); Toast("Car reset"); }
            lap.Reset(); stage?.Reset(); courses?.Reset(); rig.Snap(car);
        }

        // onto a road at a centreline point, facing the way the car was going along it
        void ToRoad(RoadFinder.Hit h)
        {
            var f = car.Forward;
            double hx = h.Hx, hz = h.Hz;
            if (f.X * hx + f.Z * hz < 0) { hx = -hx; hz = -hz; }
            car.Reset(new V3(h.X, 0, h.Z), Math.Atan2(-hx, -hz), h.Y + 1.0);
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.ResetTrails(); rig.ClearTrack();
            Toast("Back on the road");
        }

        /* ---------------- start points (a compound's paddocks, the drag strip, the slalom pad...) ---------------- */
        public string[] Spots
        {
            get
            {
                if (pack == null) return Array.Empty<string>();
                var o = new string[pack.Spots.Count];
                for (int i = 0; i < o.Length; i++) o[i] = pack.Spots[i].Name;
                return o;
            }
        }

        public void ToSpot(int i) => ToSpot(i, false);

        void ToSpot(int i, bool quiet)
        {
            if (pack == null || i < 0 || i >= pack.Spots.Count) return;
            var sp = pack.Spots[i];
            car.Reset(new V3(sp.X, 0, sp.Z), Math.Atan2(-sp.Dx, -sp.Dz));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.Clear(); lap.Reset(); courses?.Reset(); cones.Reset(); rig.Snap(car); rig.ClearTrack();
            if (!quiet) Toast(sp.Name);
        }

        void ToTrack(double s)
        {
            var c = terrain.Circuit;
            var p = c.Path.At(s);
            double hx = Math.Cos(p.H), hz = Math.Sin(p.H);
            // on a stage, keep facing the way you were going (up or down the road), except near either end of the
            // road (it stops at the edge of the map there), where you face back along it
            if (c.Stage != null)
            {
                var f = car.Forward;
                bool back = s > c.Path.Len - 60 || (s >= 60 && f.X * hx + f.Z * hz < 0);
                if (back) { hx = -hx; hz = -hz; }
            }
            car.Reset(new V3(p.X, 0, p.Z), Math.Atan2(-hx, -hz), RoadY(s));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.ResetTrails(); rig.ClearTrack();
            Toast(c.Stage != null ? "Back on the road" : "Back on the track");
        }

        // a little over the road at s, where the pack knows it (the car is put on the ground at or under this)
        double RoadY(double s)
        {
            double y = terrain.Circuit?.Path is PolyPath pp ? pp.Y(s) : double.NaN;
            return double.IsFinite(y) ? y + 1.0 : double.PositiveInfinity;
        }

        public void ToGrid() => ToGrid(0, false);

        // race track: line up in a grid slot (pole by default), facing down the main straight
        void ToGrid(int slot, bool quiet)
        {
            var c = terrain.Circuit;
            if (c != null && c.Stage != null) { StageStart(stageDown, quiet); return; }
            if (c == null || c.Grid.Count == 0) return;
            var gs = c.Grid[Math.Min(slot, c.Grid.Count - 1)];
            var p = c.Path.At(gs.S - 2.6);
            double rx = -Math.Sin(p.H), rz = Math.Cos(p.H);
            car.Reset(new V3(p.X + rx * gs.D, 0, p.Z + rz * gs.D), Math.Atan2(-Math.Cos(p.H), -Math.Sin(p.H)));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.Clear(); lap.Reset(); courses?.Reset(); rig.Snap(car); rig.ClearTrack();
            if (!quiet) Toast("On the grid: the timer starts at the line");
        }

        /* ---------------- stages: start either way ---------------- */
        public bool IsStage => stage != null;
        public bool StageDown => stageDown;
        public void StageStart(bool down) => StageStart(down, false);

        // 12 m short of the line you start from, facing along the road: up from the START gantry, or down from the FINISH
        void StageStart(bool down, bool quiet)
        {
            var c = terrain.Circuit; var st = c.Stage;
            stageDown = down; store.Set("stageDown", down);
            double s = down ? st.Finish + 12 : st.Start - 12;
            var p = c.Path.At(s);
            double hx = Math.Cos(p.H), hz = Math.Sin(p.H);
            if (down) { hx = -hx; hz = -hz; }
            car.Reset(new V3(p.X, 0, p.Z), Math.Atan2(-hx, -hz), RoadY(s));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.Clear(); stage?.Reset(); lap.Reset(); rig.Snap(car); rig.ClearTrack();
            SyncUi();
            var md = Defs.Maps[mapId];
            if (!quiet) Toast(down ? $"Top of the stage: the clock starts at {md.TopLine}, going down" : $"Bottom of the stage: the clock starts at {md.BottomLine}, going up");
        }

        string StageKey(bool down) => mapId + "_" + carId + (down ? "_down" : "_up");

        void OnStage(double t, bool valid, bool down)
        {
            string key = StageKey(down), dir = down ? "downhill" : "uphill";
            double best = store.Best(key);
            bool none = double.IsNaN(best);
            if (valid && (none || t < best)) { store.SetBest(key, t); Toast(none ? $"Stage {dir}: {LapTimer.Fmt(t, 3)}" : $"New best {dir}: {LapTimer.Fmt(t, 3)}"); }
            else Toast(valid ? $"Stage {dir}: {LapTimer.Fmt(t, 3)} (best {LapTimer.Fmt(best, 3)})" : $"Stage {dir}: {LapTimer.Fmt(t, 3)}: not counted, off the road");
            lapFlash = 4;
        }

        /* ---------------- settings from the menus ---------------- */
        public void ChangeTune(Action<Tune> change)
        {
            var t = car.Tune.Clone();
            change(t);
            car.SetTune(t);
            store.SaveTune(carId, car.Tune);
            SyncUi();
        }

        static readonly string[] GearboxName = { "Automatic gearbox", "Semi-automatic gearbox", "Manual gearbox: no protection" };

        public void SetGearbox(Gearbox mode)
        {
            ChangeTune((t) => t.Gearbox = mode);
            if (mode != Gearbox.Auto) store.Set("handMode", mode.ToString());
            if (mode != Gearbox.Manual && car.Engine.Gear == 0 && car.Engine.Shift == null) car.Engine.Gear = 1;
            Toast(GearboxName[(int)mode]);
        }

        public void ToggleTelemetry()
        {
            telemetry = !telemetry; hud.Telemetry = telemetry; store.Set("telemetry", telemetry);
            Toast(telemetry ? "Telemetry on" : "Telemetry off"); SyncUi();
        }

        public void ToggleSound()
        {
            soundOn = !soundOn; store.Set("sound", soundOn);
            if (audio != null) audio.Enabled = soundOn;
            SyncUi();
        }

        void SyncUi() { panels?.Sync(); front?.Sync(); }

        /* ---------------- volumes ---------------- */
        public double Volume(int k) => vols[k];

        public void SetVolume(int k, double v, bool preview = true)
        {
            vols[k] = Math.Clamp(v, 0, 1);
            store.Set(EngineAudio.KindKeys[k], vols[k]);
            audio?.SetVolume((EngineAudio.Kind)k, vols[k]);
            if (preview) PreviewSound(k);
        }

        // a sample of a kind of sound while it is being set: a knock, a gear change, a rev, a short slide
        public void PreviewSound(int k)
        {
            if (audio == null || !soundOn || previewCool > 0) return;
            previewCool = 0.7;
            switch ((EngineAudio.Kind)k)
            {
                case EngineAudio.Kind.Effects: audio.ShiftSound(); break;
                case EngineAudio.Kind.Engine: previewKind = k; previewT = previewDur = 1.7; break;
                case EngineAudio.Kind.Tyres: previewKind = k; previewT = previewDur = 1.1; break;
                default: audio.Impact(7 + GD.Randf() * 5); break;
            }
        }

        // what the preview "drives": a blip of the throttle, or the tyres sliding at 50 km/h, 4 m from the camera
        void PreviewState()
        {
            double t = previewDur - previewT;
            var s = car.Spec;
            pv.CamPos = rig.Pos; pv.CamVel = V3.Zero; pv.CarPos = rig.Pos + new V3(0, 0, -4); pv.CarVel = V3.Zero;
            pv.Gear = car.Engine.Gear; pv.Limiter = false; pv.Shifting = false;
            bool eng = previewKind == (int)EngineAudio.Kind.Engine;
            double peak = s.IdleRpm + (s.Redline - s.IdleRpm) * 0.75;
            if (eng)
            {
                pv.Throttle = t < 0.6 ? 1 : 0;
                pv.Rpm = t < 0.6 ? s.IdleRpm + (peak - s.IdleRpm) * M.Smooth01(t / 0.55) : s.IdleRpm + (peak - s.IdleRpm) * Math.Exp(-(t - 0.6) / 0.3);
                pv.Speed = 0;
            }
            else { pv.Rpm = s.IdleRpm; pv.Throttle = 0; pv.Speed = 14; }
            foreach (var w in pv.Wheels)
            {
                w.Contact = true; w.Surface = Surf.Tarmac; w.Load = 1;
                w.Speed = eng ? 0 : 14; w.Slip = eng || t > previewDur - 0.3 ? 0 : 9;
            }
        }

        public void CycleCamera() => Toast(rig.Cycle());
        // the free camera from the menu (again from the menu, or the camera button, goes back to the chase cam)
        public void FreeCamera()
        {
            if (rig.Mode == CameraRig.Free) { CycleCamera(); return; }
            rig.EnterFree();
            Toast("Free cam: gas and brake fly, steering turns, drag to look · camera button to go back");
        }
        readonly DriveInput parked = new DriveInput();
        public void SaveControls() { store.Set("sens", prefs.Sens); store.Set("buttonSteer", prefs.ButtonSteer); store.Set("analogPedals", prefs.AnalogPedals); }
        public void Toast(string s) { if (!Paused) hud?.Toast(s); }
        public void OpenSettings(int tab) { front.ShowTab(tab); front.Open(FrontEnd.Page.Settings, true); }
        public void OpenHowTo() => front.Open(FrontEnd.Page.HowTo, true);
        public void OpenMainMenu() => front.Open(FrontEnd.Page.Main, true);
        public void OpenMaps() => front.Open(FrontEnd.Page.Maps, true);
        public void PanelsChanged() { if (touch != null && panels != null && panels.AnyOpen) touch.ReleaseAll(); }

        void OnAction(GameAction a)
        {
            if (a == GameAction.Touch)
            {
                if (panels.MenuOpen) panels.ShowMenu(false);
                return;
            }
            switch (a)
            {
                case GameAction.Camera: CycleCamera(); break;
                case GameAction.Reset: ResetCar(false); break;
                case GameAction.ResetStart: ResetCar(true); break;
                case GameAction.Setup: panels.ShowTune(!panels.TuneOpen); break;
                case GameAction.Telemetry: ToggleTelemetry(); break;
                case GameAction.Fullscreen:
                    if (!OS.HasFeature("mobile"))
                        DisplayServer.WindowSetMode(DisplayServer.WindowGetMode() == DisplayServer.WindowMode.Fullscreen ? DisplayServer.WindowMode.Windowed : DisplayServer.WindowMode.Fullscreen);
                    break;
                case GameAction.Help: OpenHowTo(); break;
                case GameAction.Escape: if (panels.AnyOpen) panels.CloseAll(); else OpenMainMenu(); break;
                case GameAction.Controls: OpenSettings(3); break;
                case GameAction.Gearbox: SetGearbox((Gearbox)(((int)car.Tune.Gearbox + 1) % 3)); break;
                case GameAction.Grid: ToGrid(); break;
                case GameAction.NextCar: SwitchCar(Defs.CarOrder[(Array.IndexOf(Defs.CarOrder, carId) + 1) % Defs.CarOrder.Length]); break;
                case GameAction.NextMap: SwitchMap(NextMapId()); break;
                case GameAction.ShiftUp:
                case GameAction.ShiftDown:
                    // shifting by hand in automatic switches to the last hand-shift mode used (semi to start with)
                    if (car.Tune.Gearbox == Gearbox.Auto)
                        SetGearbox(Enum.TryParse<Gearbox>(store.Str("handMode", "Semi"), out var hm) && hm != Gearbox.Auto ? hm : Gearbox.Semi);
                    if (a == GameAction.ShiftUp) input.State.ShiftUp = true; else input.State.ShiftDown = true;
                    break;
            }
        }

        /* ---------------- keys, mouse and camera touches ---------------- */
        public override void _UnhandledInput(InputEvent e)
        {
            // in the menus only Escape does anything here (back a page); the menus take their own touches
            if (Paused)
            {
                if (e is InputEventKey ek && ek.Pressed && !ek.Echo && ek.PhysicalKeycode == Key.Escape) { front.Back(); GetViewport().SetInputAsHandled(); }
                return;
            }
            if (e is InputEventKey k && k.Pressed && !k.Echo)
            {
                var key = k.PhysicalKeycode;
                GameAction a = key switch
                {
                    Key.C => GameAction.Camera,
                    Key.R => k.ShiftPressed ? GameAction.ResetStart : GameAction.Reset,
                    Key.T => GameAction.Setup,
                    Key.G => GameAction.Telemetry,
                    Key.F => GameAction.Fullscreen,
                    Key.H => GameAction.Help,
                    Key.Escape => GameAction.Escape,
                    Key.K => GameAction.Controls,
                    Key.M => GameAction.Gearbox,
                    Key.L => GameAction.Grid,
                    Key.V => GameAction.NextCar,
                    Key.N => GameAction.NextMap,
                    Key.E => GameAction.ShiftUp,
                    Key.Q => GameAction.ShiftDown,
                    _ => GameAction.None,
                };
                if (a != GameAction.None) { OnAction(a); GetViewport().SetInputAsHandled(); }
                return;
            }
            if (e is InputEventMouseButton mb && mb.Device != -1)
            {
                if (mb.ButtonIndex == MouseButton.Left) { mouseDrag = mb.Pressed; rig.Dragging = mouseDrag; if (mb.Pressed && panels.MenuOpen) panels.ShowMenu(false); }
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) rig.Zoom(Math.Exp(-0.1));
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) rig.Zoom(Math.Exp(0.1));
                return;
            }
            if (e is InputEventMouseMotion mm && mm.Device != -1)
            {
                if (mouseDrag) rig.Drag(mm.Relative.X * 0.0035, mm.Relative.Y * 0.003);
                return;
            }
            // touch: in the orbit camera one finger flies round the car, two pinch to zoom
            if (e is InputEventScreenTouch st)
            {
                if (st.Pressed)
                {
                    if (panels.MenuOpen) panels.ShowMenu(false);
                    if (rig.Mode != 1 && rig.Mode != CameraRig.Free) return;
                    camTouches[st.Index] = st.Position;
                    if (camTouches.Count == 2) pinch = Spread();
                }
                else
                {
                    camTouches.Remove(st.Index);
                    if (camTouches.Count < 2) pinch = 0;
                }
                rig.Dragging = camTouches.Count > 0;
                return;
            }
            if (e is InputEventScreenDrag sd && camTouches.ContainsKey(sd.Index))
            {
                camTouches[sd.Index] = sd.Position;
                if (camTouches.Count >= 2)
                {
                    float d = Spread();
                    if (pinch > 0 && d > 0) rig.Zoom(pinch / d);
                    pinch = d;
                }
                else rig.Drag(sd.Relative.X * 0.0035, sd.Relative.Y * 0.003);
            }
        }

        float Spread()
        {
            var e = camTouches.Values.GetEnumerator();
            e.MoveNext(); var a = e.Current; e.MoveNext(); var b = e.Current;
            return a.DistanceTo(b);
        }

        public override void _Notification(int what)
        {
            if (what == NotificationApplicationFocusOut || what == NotificationApplicationPaused)
            {
                if (bootOk) DebugLog.State("paused"); // in the background: Android may close the app, which is not a crash
                touch?.ReleaseAll();
                camTouches.Clear(); rig.Dragging = false; mouseDrag = false;
                store?.Save();
            }
            else if (what == NotificationApplicationFocusIn || what == NotificationApplicationResumed)
            {
                if (bootOk && !busy) DebugLog.State(RunState);
            }
            else if (what == NotificationWMCloseRequest) DebugLog.State("ok");
            else if (what == NotificationWMGoBackRequest)
            {
                if (panels == null || front == null) return;
                if (front.IsOpen) front.Back();
                else if (panels.AnyOpen) panels.CloseAll();
                else OpenMainMenu();
            }
        }

        /* ---------------- frame ---------------- */
        public override void _Process(double delta)
        {
            double raw = delta;
            double dt = Math.Max(0, Math.Min(raw, 0.1));
            if (car == null) return;
            simClock += dt;
            if (!bootOk && (bootT += raw) > 4) { bootOk = true; if (!busy) DebugLog.State(RunState); DebugLog.Trace("running"); }
            if (selfTest) SmokeTick(raw);
            var size = GetViewport().GetVisibleRect().Size;
            if (size != lastSize) { lastSize = size; UpdateSafeArea(size); }
            PerfLog(raw);

            // the menus pause the drive: no simulation, the camera holds still
            bool paused = Paused;
            if (paused != wasPaused) { wasPaused = paused; OnPause(paused); }
            if (!paused)
            {
                var st = input.Update(dt, true);
                if (rig.Mode == CameraRig.Free)
                {
                    // the free camera flies on the driving controls; the car brakes to a stop and waits
                    rig.FlyFwd = st.Throttle - st.Brake; rig.FlyTurn = st.Steer;
                    parked.Brake = car.Tel.Speed > 0.5 ? 1 : 0; parked.Handbrake = 1;
                    st = parked;
                }
                acc += dt;
                int n = 0;
                while (acc >= DT && n < 60) { car.Step(DT, st); cones.Step(DT, car); acc -= DT; n++; }
                if (n >= 60) acc = 0;
                if (!Finite(car.Pos) || !Finite(car.Vel) || !Finite(car.AngVel))
                {
                    // never let a broken simulation reach the renderer: log it and put the car back
                    GD.PrintErr($"[sim] the car's state went non-finite on {mapId}/{carId}; resetting it");
                    acc = 0; ResetCar(true);
                }
                if (car.Engine.Refused != null)
                {
                    Toast(car.Engine.Refused == "overrev" ? "Too fast for that gear" : "Stop the car to change direction");
                    car.Engine.Refused = null;
                }
                if (terrain.Circuit != null && terrain.Circuit.Mesh && car.Pos.Y < terrain.BoundsMinY - 25) ResetCar(false);
                fx.Update(dt, car);
                if (stage != null) stage.Update(dt, car, OnStage);
                else if (courses == null || !courses.HasMain) lap.Update(dt, car, OnLap);   // a map that times its own circuit's configurations
                courses?.Update(dt, car, OnCourse, OnCourseStart);
                lapFlash = Math.Max(0, lapFlash - dt);

                rig.Aspect = size.X / Math.Max(1, size.Y);
                int zk = (Input.IsPhysicalKeyPressed(Key.Minus) || Input.IsPhysicalKeyPressed(Key.KpSubtract) ? 1 : 0) - (Input.IsPhysicalKeyPressed(Key.Equal) || Input.IsPhysicalKeyPressed(Key.KpAdd) ? 1 : 0);
                if (zk != 0) rig.Zoom(Math.Exp(zk * dt * 1.6));
                rig.Update(dt, car, terrain);
            }
            else acc = 0;
            lib.Update();
            front.Update(raw, size);
            UpdateSound(dt);
            UpdateHud(dt);
            // the garage studio draws the menus' backdrop in its own world: the game's 3D is off meanwhile
            bool studio = paused && front.Room.Active;
            var vp = GetViewport();
            if (vp.Disable3D != studio) vp.Disable3D = studio;
            if (!studio) Render();
            store.Tick(dt);
        }

        // into the menus: hide the driving UI, let go of every touch; back out: show it again
        void OnPause(bool on)
        {
            hud.Visible = !on;
            touch.Visible = !on && touchDevice;
            panels.Root.Visible = !on;
            if (on)
            {
                panels.CloseAll();
                touch.ReleaseAll(); input.ClearTouch();
                camTouches.Clear(); rig.Dragging = false; mouseDrag = false; pinch = 0;
            }
            else { previewT = 0; previewKind = -1; }
            acc = 0;
            if (bootOk && !busy) DebugLog.State(RunState);
            DebugLog.Trace(on ? "menus" : "drive");
        }

        void OnLap(double t, bool valid)
        {
            string key = mapId + "_" + carId;
            double best = store.Best(key);
            bool none = double.IsNaN(best);
            if (valid && (none || t < best)) { store.SetBest(key, t); Toast(none ? $"Lap {LapTimer.Fmt(t, 3)}" : $"New best lap {LapTimer.Fmt(t, 3)}"); }
            else Toast(valid ? $"Lap {LapTimer.Fmt(t, 3)} (best {LapTimer.Fmt(best, 3)})" : $"Lap {LapTimer.Fmt(t, 3)}: not counted, cut or off track");
            lapFlash = 3;
        }

        static string CourseLabel(string id) => id switch
        {
            "gp" => "GP", "int" => "INTL", "nat" => "NATL", "enduro" => "ENDURO", "drift" => "DRIFT", "club" => "CLUB", "handling" => "HANDLING",
            "oval" => "OVAL", "drag" => "DRAG", _ => id.StartsWith("slalom") ? "SLALOM" : id.ToUpperInvariant()
        };

        string CourseKey(CourseSet.Entry e) => mapId + "_" + e.Info.Id + "_" + carId;

        // a slalom run starts with every cone back in place
        void OnCourseStart(CourseSet.Entry e)
        {
            if (cones.List.Count > 0 && e.Info.Id.StartsWith("slalom")) cones.Reset();
            shownCourse = e;
        }

        void OnCourse(CourseSet.Entry e, double t, bool valid, double speed)
        {
            string key = CourseKey(e), name = e.Info.Name;
            if (e.Info.Id.StartsWith("slalom"))
            {
                // two seconds for every cone knocked over on the way
                int hit = 0;
                foreach (var c in cones.List) if (c.Loose) hit++;
                t += 2 * hit;
                if (hit > 0) name += $" (+{hit} cone{(hit > 1 ? "s" : "")})";
            }
            double best = store.Best(key);
            bool none = double.IsNaN(best);
            string what = e.Lap != null ? name + " lap" : name;
            string trap = double.IsNaN(speed) ? "" : $" at {speed * 3.6:F0} km/h";
            if (valid && (none || t < best)) { store.SetBest(key, t); Toast(none ? $"{what}: {LapTimer.Fmt(t, 3)}{trap}" : $"New best, {what}: {LapTimer.Fmt(t, 3)}{trap}"); }
            else Toast(valid ? $"{what}: {LapTimer.Fmt(t, 3)}{trap} (best {LapTimer.Fmt(best, 3)})" : $"{what}: {LapTimer.Fmt(t, 3)}: not counted, off the course");
            shownCourse = e; courseFlashT = t; lapFlash = 4;
            smokeCourse = $"{e.Info.Id} {t:F3} {(valid ? "valid" : "void")}" + (double.IsNaN(speed) ? "" : $" {speed * 3.6:F0} km/h");
        }
        string smokeCourse = "";
        double courseFlashT;

        void UpdateSound(double dt)
        {
            V3 cp = rig.Pos;
            if (hasCamPrev && dt > 0)
            {
                V3 v = (cp - camPrev) * (1 / dt);
                double k = 1 - Math.Exp(-dt * 10);
                camVel = new V3(M.Lerp(camVel.X, M.Clamp(v.X, -120, 120), k), M.Lerp(camVel.Y, M.Clamp(v.Y, -120, 120), k), M.Lerp(camVel.Z, M.Clamp(v.Z, -120, 120), k));
            }
            camPrev = cp; hasCamPrev = true;
            if (audio == null) return;
            audio.Enabled = soundOn;
            if (Paused)
            {
                // the paused drive is silent, apart from a sample of the sound being set in the settings
                previewCool -= dt;
                if (previewT > 0)
                {
                    previewT -= dt;
                    PreviewState();
                    audio.Update(dt, pv);
                }
                bool on = previewT > 0;
                audio.SetGates(on && previewKind == (int)EngineAudio.Kind.Engine, on && previewKind == (int)EngineAudio.Kind.Tyres, false);
                return;
            }
            audio.SetGates(true, true, true);
            var e = car.Engine;
            snd.Rpm = e.Rpm; snd.Throttle = e.Load; snd.Limiter = e.LimiterCut;
            snd.Shifting = e.Shift != null && e.Clutch == 0 && !e.Blip;
            snd.Gear = e.Gear; snd.Speed = car.Tel.Speed;
            snd.CamPos = cp; snd.CamVel = camVel; snd.CarPos = car.Pos; snd.CarVel = car.Vel;
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i]; var ws = snd.Wheels[i];
                ws.Contact = w.Contact; ws.Surface = w.Surface; ws.Speed = Math.Abs(w.VLong); ws.Slip = w.SlipVel;
                ws.Load = (w.Contact ? w.Load : w.Fz) / w.StaticLoad;
            }
            audio.Update(dt, snd);
            // collisions: the hardest new hit since last frame, with the same doppler as the engine
            if (car.Impact > 0) { audio.Impact(car.Impact); car.Impact = 0; }
            if (cones.Knock > 0) { audio.ConeHit(cones.Knock); cones.Knock = 0; }
        }

        void UpdateHud(double dt)
        {
            if (loadingT > 0) { loadingT -= dt; if (loadingT <= 0) hud.Loading = ""; }
            hud.Car = car;
            // a course of the map's own (the one started last) wins over the main circuit while it runs
            var ce = courses?.Active;
            if (ce != null) shownCourse = ce;
            else if (lapFlash <= 0 || lap.Running) shownCourse = null;
            bool show = (stage != null ? stage.Running : lap.Running) || ce != null || lapFlash > 0;
            hud.LapShow = show;
            if (show && shownCourse != null)
            {
                hud.LapLabel = CourseLabel(shownCourse.Info.Id);
                hud.LapTime = ce != null ? ce.T : courseFlashT; hud.LapValid = ce != null ? ce.Valid : true;
                hud.LapBest = store.Best(CourseKey(shownCourse));
            }
            else if (show && stage != null) { hud.LapLabel = stage.Down ? "DOWN" : "UP"; hud.LapTime = stage.T; hud.LapValid = stage.Valid; hud.LapBest = store.Best(StageKey(stage.Down)); }
            else if (show) { hud.LapLabel = "LAP"; hud.LapTime = lap.T; hud.LapValid = lap.Valid; hud.LapBest = store.Best(mapId + "_" + carId); }
            var e = car.Engine;
            int gn = e.Shift != null ? e.Shift.To : e.Gear;
            touch.GearText = gn < 0 ? "R" : gn == 0 ? "N" : gn.ToString();
            touch.ModeText = car.Tune.Gearbox == Gearbox.Auto ? "AUTO" : car.Tune.Gearbox == Gearbox.Semi ? "SEMI" : "MAN";
            // the cluster sits in the gap between the thumbs (or above the controls if the gap is too narrow)
            hud.SpeedoKmh = Def.SpeedoKmh; hud.SpeedoMph = Def.SpeedoMph;
            hud.Thr = input.State.Throttle; hud.Brk = input.State.Brake;
            if (touch.Visible) { hud.BandL = touch.RightEdgeOfLeft; hud.BandR = touch.LeftEdgeOfRight; hud.BottomLift = lastSize.Y - touch.TopOfControls + 8; }
            else { hud.BandR = -1; hud.BottomLift = 0; }
            panels.Layout(lastSize, safeR);
            front.Layout(lastSize, safeL, safeR);
        }

        void Render()
        {
            // (not while the garage has the model on its turntable)
            if (carView != null && carView.Root.GetParent() == this) carView.Update(car, Def.SteerRatio);
            blob.Node.Visible = quality == 2;
            if (quality == 2) blob.Update(car, terrain, ToSun);
            carView?.SetInside(rig.Mode == 4, Def.GlassInside);
            if (cones.List.Count > 0) conesView.Update(cones);
            skids.Flush();
            var cp = MeshUtil.V(rig.Pos);
            var ct = MeshUtil.V(rig.Target);
            smoke.Update(fx.Smoke, cp, ct);
            if (warmFrames > 0)
            {
                // draw an invisible skid mark and smoke puff for the first frames so those shaders are compiled
                // up front rather than as a hitch at the first slide
                warmFrames--;
                skids.Warm(warmFrames > 0, ct);
                if (warmFrames > 0) smoke.Warm(ct);
            }
            const float T = 250;
            ground.Position = new Vector3(Mathf.Round(cp.X / T) * T, ground.Position.Y, Mathf.Round(cp.Z / T) * T);
            cam.Fov = (float)(rig.Fov * 180 / Math.PI);
            cam.Near = rig.Mode == 4 || rig.Mode == 2 ? 0.05f : 0.1f;
            var up = MeshUtil.V(rig.Up);
            var dir = ct - cp;
            if (dir.LengthSquared() > 1e-8f)
            {
                if (Mathf.Abs(dir.Normalized().Dot(up.Normalized())) > 0.999f) up = Vector3.Forward;
                cam.LookAtFromPosition(cp, ct, up);
            }
            RenderingServer.GlobalShaderParameterSet("main_cam_pos", cp);
        }

        void UpdateSafeArea(Vector2 size)
        {
            safeL = safeR = 0;
            var win = DisplayServer.WindowGetSize();
            var safe = DisplayServer.GetDisplaySafeArea();
            if (win.X > 0 && safe.Size.X > 0)
            {
                float k = size.X / win.X;
                safeL = Math.Max(0, safe.Position.X) * k;
                safeR = Math.Max(0, win.X - safe.End.X) * k;
            }
            if (touch != null) touch.Safe = Math.Max(safeL, safeR);
        }

        static bool Finite(V3 v) => double.IsFinite(v.X) && double.IsFinite(v.Y) && double.IsFinite(v.Z);

        /* ---------------- graphics quality ---------------- */
        static readonly string[] QualityName = { "Graphics: high", "Graphics: medium", "Graphics: low" };

        public void SetQuality(int q)
        {
            quality = Math.Clamp(q, 0, 2);
            store.Set("quality", quality);
            ApplyQuality();
            SyncUi();
            Toast(QualityName[quality]);
        }

        // high: four shadow splits out to 120 m on a 4096 map; medium: two splits out to 70 m, the first covering the
        // closest 13 m (so the car's own shadow is sharp); low: no shadow maps (a soft mock shadow under the car
        // instead), no MSAA, 70 % resolution. The cars cast through ~150-triangle stand-ins, so splits cost little.
        // Only "low" renders below 100 %: Godot 4.7's GL renderer draws a scene with shadows too bright when the 3D
        // resolution is scaled (that, switching on and off with the frame rate, was the bright / dark flashing).
        void ApplyQuality()
        {
            var vp = GetViewport();
            vp.Scaling3DScale = quality == 2 ? 0.7f : 1f;
            // mesh LODs: how many pixels of error a coarser LOD may show
            vp.MeshLodThreshold = quality == 0 ? 1f : quality == 1 ? 1.6f : 2.5f;
            vp.Msaa3D = quality == 2 ? Viewport.Msaa.Disabled : Viewport.Msaa.Msaa2X;
            sun.ShadowEnabled = quality != 2;
            sun.ShadowBlur = 0.6f;
            sun.DirectionalShadowBlendSplits = true;
            if (quality == 0)
            {
                sun.DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel4Splits;
                sun.DirectionalShadowMaxDistance = 120;
                sun.DirectionalShadowSplit1 = 0.06f; sun.DirectionalShadowSplit2 = 0.16f; sun.DirectionalShadowSplit3 = 0.42f;
            }
            else
            {
                sun.DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel2Splits;
                sun.DirectionalShadowMaxDistance = 70;
                sun.DirectionalShadowSplit1 = 0.18f;
            }
            RenderingServer.DirectionalShadowAtlasSetSize(quality == 0 ? 4096 : 2048, true);
            DebugLog.Trace($"quality {quality}: 3D scale {vp.Scaling3DScale:F2}, msaa {vp.Msaa3D}, shadows {sun.ShadowEnabled}");
        }

        /* ---------------- performance log ---------------- */
        void PerfLog(double raw)
        {
            int g0 = GC.CollectionCount(0), g2 = GC.CollectionCount(2);
            bool gcNow = g0 != gcSeen0, gc2Now = g2 != gcSeen2;
            gcSeen0 = g0; gcSeen2 = g2;
            if (!bootOk) { gcLine0 = g0; gcLine2 = g2; return; }
            perfClock += raw; perfSum += raw; perfFrames++;
            if (raw > perfWorst) perfWorst = raw;
            if (raw > 0.07)
            {
                perfLong++;
                if (longLines < 40)
                {
                    longLines++;
                    GD.Print($"[perf] long frame {raw * 1000:F0} ms · {mapId}/{carId} cam {rig.Mode} · {car.Tel.Speed * 3.6:F0} km/h · " +
                        $"gc this frame: {(gc2Now ? "full" : gcNow ? "minor" : "no")} · puffs {fx.Smoke.Count} · loading {busy}");
                }
            }
            if (perfClock < 30) return;
            GD.Print($"[perf] {perfFrames / perfSum:F0} fps · worst {perfWorst * 1000:F0} ms · {perfLong} frames over 70 ms · " +
                $"gc {g0 - gcLine0} minor / {g2 - gcLine2} full · managed {GC.GetTotalMemory(false) >> 20} MB · engine {OS.GetStaticMemoryUsage() >> 20} MB · " +
                $"video {Performance.GetMonitor(Performance.Monitor.RenderVideoMemUsed) / 1048576:F0} MB · " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalDrawCallsInFrame)} draws " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalPrimitivesInFrame) / 1000}k tris · {mapId}/{carId} · quality {quality}");
            perfClock = perfSum = perfWorst = 0; perfFrames = perfLong = 0; gcLine0 = g0; gcLine2 = g2;
        }

        /* ---------------- self-test: CI runs the game with  -- --smoke --shots=<dir>  ----------------
           Drives every car on both maps, goes through the cameras and menus, and saves screenshots. Prints
           "SMOKE OK" and quits with 0 when it gets to the end; a different exit code says where it stopped. */
        async void RunSmoke()
        {
            try
            {
                GD.Print("[smoke] start · " + DebugLog.DeviceInfo());
                foreach (var id in Defs.CarOrder) GD.Print($"[smoke] {id} on flat tarmac (simulation only): {SimFigures(Defs.Cars[id].Spec)}");
                DirAccess.MakeDirRecursiveAbsolute(shotDir);
                SetQuality(1); // what phones start with
                smokeStep = "main menu"; await Frames(30);
                if (!front.IsOpen || front.Current != FrontEnd.Page.Main) throw new Exception("the game did not start at the main menu");
                if (!front.Room.Active || front.Room.CarId != carId) throw new Exception("the garage studio is not showing the car behind the main menu");
                Shot("main-menu");
                await SmokeFrontEnd();
                // into Free Roam on the proving ground, from the map select
                smokeStep = "free roam";
                front.Go(FrontEnd.Page.FreeRoam); await Frames(6); Shot("free-roam");
                StartFreeRoam("grid", 0);
                await Frames(3);
                if (front.IsOpen || !hasSession) throw new Exception("Free Roam did not start");
                if (carView.Root.GetParent() != this) throw new Exception("the car's model did not come back from the garage");
                if (GetViewport().Disable3D) throw new Exception("the game's 3D is still off after the menus");
                // the touch controls and HUD must fill the screen, and pressing the gas pedal must drive the car
                smokeStep = "touch controls";
                await Frames(3);
                if (touch.Size.X < 100 || hud.Size.X < 100) throw new Exception($"touch controls / HUD have no size ({touch.Size}, {hud.Size})");
                var gp = touch.GasCenter;
                Input.ParseInputEvent(new InputEventScreenTouch { Index = 7, Position = gp, Pressed = true });
                double tg = simClock;
                while (simClock < tg + 1.5) await Frames(1);
                double vg = car.Tel.Speed * 3.6;
                Shot("touch-gas");
                Input.ParseInputEvent(new InputEventScreenTouch { Index = 7, Position = gp, Pressed = false });
                await SmokeDrive(1.5, 0, 0, 1);
                if (vg < 3) throw new Exception($"pressing the touch gas pedal did not move the car ({vg:F1} km/h)");
                GD.Print($"[smoke] touch gas pedal: {vg:F0} km/h after 1.5 s");
                smokeStep = "rust: launch"; await SmokeDrive(3, 1, 0); Shot("rust-chase");
                smokeStep = "rust: turn"; await SmokeDrive(2, 0.7, 0.5); Shot("rust-turn");
                // revs with the clutch out (handbrake): they should hang and fall over a second or two, not snap to idle
                smokeStep = "free revs";
                double fr0 = car.Engine.Rpm, frT = simClock;
                while (simClock < frT + 0.5) { input.ClearTouch(); input.TouchHand = true; await Frames(1); }
                double fr1 = car.Engine.Rpm;
                input.ClearTouch();
                GD.Print($"[smoke] free revs (clutch out): {fr0:F0} -> {fr1:F0} rpm in 0.5 s (idle {car.Spec.IdleRpm:F0})");
                smokeStep = "rust: cameras";
                for (int i = 0; i < 6; i++)
                {
                    CycleCamera();
                    if (rig.Mode == 0) break;
                    await SmokeDrive(0.6, 0.5, 0); Shot("rust-" + Slug(CameraRig.Names[rig.Mode]));
                }
                await SmokeCam(0);
                // the free camera from the menu: it flies on the pedals and steering while the car stops and waits
                smokeStep = "rust: free camera";
                {
                    FreeCamera();
                    V3 fcPos0 = rig.Pos;
                    await SmokeDrive(1.5, 1, 0.4);
                    double fcMoved = (rig.Pos - fcPos0).Length(), fcKmh = Math.Abs(car.Tel.Speed) * 3.6;
                    Shot("rust-free-cam");
                    GD.Print($"[smoke] free camera: flew {fcMoved:F1} m, the car at {fcKmh:F0} km/h" + (rig.Mode != CameraRig.Free || fcMoved < 3 ? "  WARN" : ""));
                    CycleCamera();
                    if (rig.Mode != 0) throw new Exception("the camera button did not bring the chase cam back from the free camera");
                }
                smokeStep = "rust: brake"; await SmokeDrive(1.5, 0, 0, 1);
                await SmokeCrash(20, "72 km/h");
                await SmokeCrash(33, "120 km/h");
                await SmokeGlance(12, 25);
                await SmokeGlance(25, 25);
                smokeStep = "menus";
                panels.ShowMenu(true); await Frames(4); Shot("menu");
                panels.ShowTune(true); await Frames(4); Shot("car-setup");
                panels.CloseAll();
                // settings over the drive: paused, the drive dimmed behind (no studio); Back returns to it
                OpenSettings(3); await Frames(6); Shot("settings-over-the-drive");
                if (!Paused || front.Room.Active) throw new Exception("settings over the drive should pause it, without the studio");
                front.Back(); await Frames(3);
                if (Paused) throw new Exception("Back from settings did not return to the drive");
                // the main menu from the drive (pause), then resume: the car must come back from the turntable
                smokeStep = "pause to the main menu";
                OpenMainMenu(); await Frames(10); Shot("pause-main-menu");
                if (!front.Room.Active) throw new Exception("the main menu from the drive has no studio");
                front.Back(); await Frames(4);
                if (Paused || carView.Root.GetParent() != this) throw new Exception("resuming from the main menu did not give the car back");
                await SmokeDrive(0.5, 0.4, 0); Shot("resumed");
                ToggleTelemetry(); await Frames(4); Shot("telemetry"); ToggleTelemetry();
                SetUnits(false); await Frames(3); Shot("mph"); SetUnits(true);
                smokeStep = "graphics quality";
                SetQuality(2); await SmokeDrive(0.5, 0.3, 0); Shot("quality-low");
                SetQuality(0); await SmokeDrive(0.5, 0.3, 0); Shot("quality-high");
                SetQuality(1); await Frames(3);
                foreach (var id in new[] { "monte", "cts", "civic" })
                {
                    smokeStep = "switch car " + id; SwitchCar(id); await SmokeIdle();
                    if (carId != id) throw new Exception("car " + id + " did not load");
                    smokeStep = id + ": launch";
                    car.Reset(SpawnPos, 0); fx.Clear(); rig.Snap(car); await Frames(2); // a clear run up the runway
                    {
                        // full throttle from a standstill: the automatic should change up cleanly, never hunt 1-2-1
                        int lastG = car.Engine.Gear, downs = 0; string seq = lastG.ToString(); double t0 = simClock;
                        input.TouchGas = 1;
                        while (simClock < t0 + 4)
                        {
                            input.TouchGas = 1; input.TouchBrake = 0; input.TouchSteerActive = false;
                            await Frames(1);
                            int gNow = car.Engine.Gear;
                            if (gNow != lastG) { if (gNow < lastG) downs++; seq += ">" + gNow; lastG = gNow; }
                        }
                        input.ClearTouch();
                        GD.Print($"[smoke] {id} full-throttle start: gears {seq}, {downs} downshifts, {car.Tel.Speed * 3.6:F0} km/h after 4 s" + (downs > 0 ? "  WARN: gear hunting" : ""));
                    }
                    smokeStep = id + ": drive"; await SmokeDrive(1.5, 0.6, -0.5); Shot(id + "-chase");
                    if (rig.HasCockpit) { await SmokeCam(4); await SmokeDrive(0.8, 0.6, 0); Shot(id + "-interior"); }
                    await SmokeCam(2); await Frames(3); Shot(id + "-bumper");
                    await SmokeCam(0);
                }
                await SmokeMapLibrary();
                await SmokeSpa();
                await SmokeMonteCarlo();
                await SmokeIroha();
                await SmokeCompound();
                await SmokeMapRemoval();
                smokeStep = "back to the proving ground"; SwitchMap("grid"); await SmokeIdle();
                if (mapId != "grid") throw new Exception("could not go back to the proving ground");
                await SmokeDrive(1, 0.5, 0); Shot("grid-again");
                GD.Print($"[smoke] SMOKE OK after {smokeReal:F0} s");
                GetTree().Quit(0);
            }
            catch (Exception e)
            {
                GD.PrintErr("[smoke] SMOKE FAILED during " + smokeStep + ": " + e);
                try { Shot("failed"); } catch (Exception) { }
                GetTree().Quit(3);
            }
        }

        // Straight-line figures from the simulation alone (no rendering, flat tarmac, the default setup and the
        // automatic at full throttle from a standstill): 0-100 km/h, the quarter mile and its speed, and top speed
        static string SimFigures(CarSpec spec)
        {
            var c = new Car(new GridTerrain(new List<RustBucket.Sim.Feature>(), new List<SolidBox>()), null, spec);
            c.Reset(V3.Zero, 0);
            var inp = new DriveInput { Throttle = 1 };
            const double h = 1.0 / 480;
            double t = 0, t100 = double.NaN, qm = double.NaN, trap = 0, vmax = 0;
            V3 p0 = c.Pos;
            for (int i = 0; i < 480 * 75; i++)
            {
                c.Step(h, inp); t += h;
                double v = c.Tel.Speed * 3.6;
                vmax = Math.Max(vmax, v);
                if (double.IsNaN(t100) && v >= 100) t100 = t;
                if (double.IsNaN(qm))
                {
                    double dx = c.Pos.X - p0.X, dz = c.Pos.Z - p0.Z;
                    if (dx * dx + dz * dz >= 402.3 * 402.3) { qm = t; trap = v; }
                }
            }
            return $"0-100 km/h {t100:F1} s, quarter mile {qm:F1} s at {trap:F0} km/h, top speed {vmax:F0} km/h (gear {c.Engine.Gear}, {c.Engine.Rpm:F0} rpm)";
        }

        // The front end: the garage (turn the platform, look at each car), every page, each settings tab, and the
        // volumes saved and read back
        async Task SmokeFrontEnd()
        {
            smokeStep = "garage";
            front.Go(FrontEnd.Page.Garage); await Frames(20); Shot("garage");
            front.TestTurn(1.4, 0.35); await Frames(6); Shot("garage-turned");
            front.TestTurn(-0.6, -0.3);
            foreach (var id in new[] { "monte", "cts", "civic" })
            {
                smokeStep = "garage: " + id;
                front.TestInspect(id);
                for (int i = 0; i < 600 && front.Room.CarId != id; i++) await Frames(1);
                if (front.Room.CarId != id) throw new Exception("the garage did not put the " + id + " on the turntable");
                await Frames(10); Shot("garage-" + id);
            }
            front.TestInspect(carId); await Frames(4);
            smokeStep = "front end pages";
            foreach (var p in new[] { FrontEnd.Page.TimeTrial, FrontEnd.Page.Career, FrontEnd.Page.Online, FrontEnd.Page.HowTo, FrontEnd.Page.Credits })
            {
                front.Go(p); await Frames(4); Shot("page-" + Slug(p.ToString()));
            }
            smokeStep = "settings";
            front.Go(FrontEnd.Page.Settings);
            for (int i = 0; i < FrontEnd.TabNames.Length; i++) { front.ShowTab(i); await Frames(4); Shot("settings-" + Slug(FrontEnd.TabNames[i])); }
            front.ShowTab(0);
            double v0 = Volume(1);
            SetVolume(1, 0.5, false);
            if (Math.Abs(store.Num(EngineAudio.KindKeys[1], 1) - 0.5) > 1e-6) throw new Exception("the engine volume was not saved");
            SetVolume(1, v0, false);
            SmokeAudioMix();
            front.Go(FrontEnd.Page.Main); await Frames(4);
            GD.Print("[smoke] front end: main menu, garage, " + FrontEnd.TabNames.Length + " settings tabs and the mode pages all open");
        }

        // The mix, measured: each kind of sound on its own through a separate copy of the audio (the others turned
        // to 0 with the volume controls), as overall level and loudest 100 ms in dB of full scale.
        void SmokeAudioMix()
        {
            if (sfxData == null) { GD.Print("[smoke] audio mix: no sound data"); return; }
            smokeStep = "audio mix";
            var d = Def;
            if (!engineFiles.TryGetValue(d.Engine, out var data)) { data = AudioData.Engine(FileAccess.GetFileAsString(d.Engine)); engineFiles[d.Engine] = data; }
            var pf = data.Profile.Clone();
            d.EngineProfile?.Invoke(pf);
            var sp = car.Spec;
            const int N = 800;
            var buf = new float[N];
            string Run(string name, int only, double secs, Action<SoundState, double> drive, Action<EngineAudio> at = null)
            {
                var a = new EngineAudio(48000, sfxData);
                a.SetEngine(data, pf);
                for (int k = 1; k < 5; k++) a.SetVolume((EngineAudio.Kind)k, only < 1 || k == only ? 1 : 0);
                var s = new SoundState { CamPos = new V3(0, 1.2, 4), CarPos = V3.Zero, Gear = 2, Rpm = sp.IdleRpm };
                foreach (var w in s.Wheels) { w.Contact = true; w.Surface = Surf.Tarmac; w.Load = 1; }
                double sum = 0, loud = -200; int cnt = 0;
                var win = new double[6];
                int frames = (int)(secs * 60) + 30;
                for (int f = 0; f < frames; f++)
                {
                    double t = (f - 30) / 60.0;
                    drive(s, t);
                    a.Update(1.0 / 60, s);
                    if (f == 30) at?.Invoke(a);
                    a.Render(buf, N);
                    if (f < 30) continue;
                    double m = 0;
                    for (int i = 0; i < N; i++) m += buf[i] * (double)buf[i];
                    m /= N; sum += m;
                    win[cnt % 6] = m; cnt++;
                    if (cnt >= 6) { double w6 = 0; foreach (var x in win) w6 += x; loud = Math.Max(loud, 10 * Math.Log10(w6 / 6 + 1e-12)); }
                }
                return $"{name} {10 * Math.Log10(sum / Math.Max(1, cnt) + 1e-12):F1} dB (loudest {loud:F1})";
            }
            void Wheels(SoundState s, double v, double slip, Surf surf)
            {
                s.Speed = v;
                foreach (var w in s.Wheels) { w.Speed = v; w.Slip = slip; w.Surface = surf; }
            }
            double idle = sp.IdleRpm, hi = sp.Redline * 0.85;
            var lines = new List<string>
            {
                Run("engine idle", 1, 2, (s, t) => { s.Rpm = idle; s.Throttle = 0; Wheels(s, 0, 0, Surf.Tarmac); }),
                Run("engine full throttle", 1, 2, (s, t) => { s.Rpm = hi; s.Throttle = 1; s.Gear = 3; Wheels(s, 30, 0.3, Surf.Tarmac); }),
                Run("tyres rolling 100 km/h", 2, 2, (s, t) => Wheels(s, 27.8, 0.2, Surf.Tarmac)),
                Run("tyres sliding", 2, 2, (s, t) => Wheels(s, 12, 9, Surf.Tarmac)),
                Run("gravel 60 km/h", 2, 2, (s, t) => Wheels(s, 16.7, 0.3, Surf.Gravel)),
                Run("crash 70 km/h", 3, 2.5, (s, t) => Wheels(s, 0, 0, Surf.Tarmac), (a) => a.Impact(19.4)),
                Run("crunch 30 km/h", 3, 1.5, (s, t) => Wheels(s, 0, 0, Surf.Tarmac), (a) => a.Impact(8.3)),
                Run("knock 10 km/h", 3, 1, (s, t) => Wheels(s, 0, 0, Surf.Tarmac), (a) => a.Impact(2.8)),
                Run("cone 40 km/h", 3, 1, (s, t) => Wheels(s, 0, 0, Surf.Tarmac), (a) => a.ConeHit(11)),
                Run("gear change", 4, 1, (s, t) => Wheels(s, 0, 0, Surf.Tarmac), (a) => a.ShiftSound()),
                Run("wind 160 km/h", 4, 2, (s, t) => Wheels(s, 44, 0.2, Surf.Tarmac)),
                Run("everything, full throttle at 100 km/h", 0, 2, (s, t) => { s.Rpm = hi; s.Throttle = 1; s.Gear = 3; Wheels(s, 27.8, 0.3, Surf.Tarmac); }),
            };
            GD.Print($"[smoke] audio mix ({carId}), each kind on its own: " + string.Join(" · ", lines));
        }

        // Spa (when installed): the grid, a run, ABS and auto hold, the cameras
        async Task SmokeSpa()
        {
            if (!MapAvailable("spa")) { GD.Print("[smoke] Spa is not installed: skipped"); return; }
            smokeStep = "load Spa"; SwitchMap("spa"); await SmokeIdle();
            if (mapId != "spa") throw new Exception("Spa did not load");
            ToGrid(); await Frames(10); Shot("spa-grid");
            smokeStep = "spa: drive"; await SmokeDrive(5, 1, 0); Shot("spa-chase");
            {
                // stand on the brakes at speed, steering a little: ABS should keep the wheels turning
                smokeStep = "spa: ABS stop";
                double v0 = car.Tel.Speed * 3.6, tb = simClock; int lockedFrames = 0, frames = 0, absFrames = 0;
                while (simClock < tb + 1.2)
                {
                    input.TouchGas = 0; input.TouchBrake = 1; input.TouchSteerActive = true; input.TouchSteerVal = 0.15;
                    await Frames(1); frames++;
                    if (car.Tel.AbsActive) absFrames++;
                    foreach (var w in car.Wheels) if (w.Contact && Math.Abs(w.VLong) > 5 && Math.Abs(w.Omega * w.Rad) < 0.3 * Math.Abs(w.VLong)) { lockedFrames++; break; }
                }
                input.ClearTouch();
                GD.Print($"[smoke] ABS stop: {v0:F0} -> {car.Tel.Speed * 3.6:F0} km/h in 1.2 s, ABS active {absFrames}/{frames} frames, a wheel locked {lockedFrames}/{frames}" + (lockedFrames > frames / 4 ? "  WARN: wheels locking" : ""));
                // come to a stop, let go of everything: auto hold should keep the car still
                smokeStep = "spa: auto hold";
                double ts = simClock;
                while (simClock < ts + 6 && Math.Abs(car.Tel.Speed) > 0.2) { input.TouchBrake = 1; await Frames(1); }
                input.ClearTouch();
                await SmokeDrive(0.5, 0, 0);
                var p0 = car.Pos; await SmokeDrive(2, 0, 0.4); var dp = car.Pos - p0;
                GD.Print($"[smoke] auto hold: moved {Math.Sqrt(dp.X * dp.X + dp.Z * dp.Z):F3} m in 2 s with no pedals" + (Math.Sqrt(dp.X * dp.X + dp.Z * dp.Z) > 0.1 ? "  WARN: car creeping" : ""));
                await SmokeDrive(3, 1, 0);
            }
            if (rig.HasCockpit) { await SmokeCam(4); await Frames(3); Shot("spa-interior"); }
            await SmokeCam(3); await SmokeDrive(1, 0.8, 0); Shot("spa-trackside");
            await SmokeCam(1); await Frames(3); Shot("spa-orbit");
            await SmokeCam(0);
            smokeStep = "spa: rust bucket"; SwitchCar("rust"); await SmokeIdle(); await SmokeDrive(2, 1, 0); Shot("spa-rust");
            smokeStep = "spa: resets"; ResetCar(false); await Frames(3); ResetCar(true); await Frames(3);
        }

        // The map library: the catalogue from the release "maps", every map downloaded and installed (from the
        // folder the build passes with --maps= if a download fails), the Maps page and Free Roam listing them
        async Task SmokeMapLibrary()
        {
            smokeStep = "map library: catalogue";
            lib.Refresh();
            double r0 = smokeReal;
            while (lib.Fetching && smokeReal < r0 + 45) await Frames(1);
            if (lib.Catalogue.Count == 0 && lib.FallbackDir != null && FileAccess.FileExists(lib.FallbackDir.PathJoin("maps.json")))
            {
                GD.Print("[smoke] map catalogue not reachable (" + lib.Status + "): using the build's own list  WARN");
                lib.UseCatalogue(FileAccess.GetFileAsString(lib.FallbackDir.PathJoin("maps.json")));
            }
            var names = new List<string>();
            foreach (var c in lib.Catalogue) names.Add($"{c.Name} ({c.Bytes / 1048576.0:F1} MB)");
            GD.Print($"[smoke] map catalogue: {lib.Status}: " + string.Join(", ", names));
            OpenMaps(); await Frames(8); Shot("maps-page");
            smokeStep = "map library: downloads";
            foreach (var c in lib.Catalogue) if (!lib.IsInstalled(c.Id)) lib.Install(c);
            r0 = smokeReal;
            await Frames(10); Shot("maps-downloading");
            while (lib.AnyDownloading && smokeReal < r0 + 300) await Frames(1);
            await Frames(3);
            foreach (var c in lib.Catalogue)
            {
                if (lib.IsInstalled(c.Id)) { GD.Print($"[smoke] {c.Name}: downloaded and installed in {smokeReal - r0:F0} s"); continue; }
                string why = lib.Error(c.Id) ?? "not finished";
                bool local = lib.FallbackDir != null && lib.InstallLocal(c, lib.FallbackDir);
                await Frames(3);
                GD.Print($"[smoke] {c.Name}: download failed ({why}){(local && lib.IsInstalled(c.Id) ? ", installed from the build's copy" : "")}  WARN");
            }
            Shot("maps-installed");
            front.Go(FrontEnd.Page.FreeRoam); await Frames(6); Shot("free-roam-all-maps");
            front.Close(); await Frames(3);
            GD.Print("[smoke] maps on this phone: " + string.Join(", ", Defs.MapOrder));
        }

        // removing maps: one not in use, then the one being driven (back to the proving ground)
        async Task SmokeMapRemoval()
        {
            smokeStep = "map library: remove";
            if (MapAvailable("spa") && mapId != "spa")
            {
                bool ok = lib.Remove("spa"); await Frames(2);
                bool gone = ok && !Defs.Maps.ContainsKey("spa") && !FileAccess.FileExists(MapLibrary.PackPath("spa")) && Array.IndexOf(Defs.MapOrder, "spa") < 0;
                GD.Print($"[smoke] remove Spa: {(gone ? "gone" : "still there  WARN")}; maps now {string.Join(", ", Defs.MapOrder)}");
            }
            string cur = mapId;
            if (cur != "grid")
            {
                // (v1.11's run stopped responding here, after the map was removed: say how far each part gets)
                GD.Print($"[smoke] removing the map being driven ({cur})");
                bool ok = lib.Remove(cur);
                GD.Print($"[smoke] removed: {ok}, now on {mapId}");
                for (int i = 1; i <= 3; i++) { await Frames(1); GD.Print($"[smoke] frame {i} after the removal"); }
                GD.Print($"[smoke] removing the map being driven ({cur}): now on {mapId}{(mapId == "grid" ? "" : "  WARN")}");
            }
            OpenMaps(); await Frames(6); Shot("maps-after-remove"); front.Close(); await Frames(3);
        }

        // Monte Carlo: load, the stage start both ways (the clock must start at the gantry), views along the road,
        // and both ends of the road (a reset there faces back along it)
        async Task SmokeMonteCarlo()
        {
            if (!MapAvailable("mcr")) { GD.Print("[smoke] Monte Carlo is not installed: skipped"); return; }
            smokeStep = "load Monte Carlo"; SwitchMap("mcr"); await SmokeIdle();
            if (mapId != "mcr" || stage == null) throw new Exception("Monte Carlo did not load as a stage");
            var view = maps["mcr"].View;
            GD.Print($"[smoke] Monte Carlo: {view.LodDraws} draws with LODs, {view.Occluders} occluders, occlusion culling {GetViewport().UseOcclusionCulling}, far {cam.Far:F0} m");
            var c = terrain.Circuit; var st = c.Stage;
            smokeStep = "mcr: uphill start"; StageStart(false); await Frames(10); Shot("mcr-start-uphill");
            await SmokeDrive(3.5, 1, 0);
            GD.Print($"[smoke] uphill start: {car.Tel.Speed * 3.6:F0} km/h, stage clock {(stage.Running ? "running" : "NOT running")} {stage.T:F1} s{(stage.Running && !stage.Down ? "" : "  WARN: the clock did not start at the START gantry")}");
            Shot("mcr-uphill-chase");
            // views along the road: put the car on the road every 900 m, facing up, let the frame settle
            for (double s = 700; s < c.Path.Len - 400; s += 900)
            {
                smokeStep = $"mcr: view at {s:F0} m";
                ToTrack(s); rig.Snap(car);
                await SmokeDrive(0.6, 0.4, 0);
                GD.Print($"[smoke] view at s={s:F0}: {Godot.Engine.GetFramesPerSecond():F0} fps, {RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalObjectsInFrame)} objects, " +
                    $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalDrawCallsInFrame)} draws, {RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalPrimitivesInFrame) / 1000}k tris, car at {car.Pos.Y:F1} m (road {RoadY(s) - 1:F1})");
                Shot($"mcr-road-{s:F0}");
            }
            await SmokeRail(1932, -3.1);
            await SmokeRail(1050, -3.45);
            smokeStep = "mcr: downhill start"; StageStart(true); await Frames(10); Shot("mcr-start-downhill");
            await SmokeDrive(3, 0.8, 0);
            GD.Print($"[smoke] downhill start: {car.Tel.Speed * 3.6:F0} km/h, stage clock {(stage.Running ? "running" : "NOT running")}{(stage.Running && stage.Down ? "" : "  WARN: the clock did not start at the FINISH gantry")}");
            for (int k = 0; k < 2; k++)
            {
                smokeStep = $"mcr: end {k} of the road";
                double se = k == 0 ? 5 : c.Path.Len - 5;
                ToTrack(se); rig.Snap(car); await Frames(4);
                var pe = c.Path.At(k == 0 ? 30 : c.Path.Len - 30);
                double dx = pe.X - car.Pos.X, dz = pe.Z - car.Pos.Z;
                var f = car.Forward;
                bool facesIn = f.X * dx + f.Z * dz > 0;
                GD.Print($"[smoke] reset at end {k} of the road: {(facesIn ? "faces back along it" : "faces off the end  WARN")}");
                Shot($"mcr-road-end-{k}");
            }
            await SmokeCam(1); await Frames(4); Shot("mcr-orbit"); await SmokeCam(0);
        }

        // Irohazaka, when its map pack came with the build: both stage starts, views down the road, a run into
        // the first hairpins at speed.
        // The compound: its extras read (courses, roads, start points, cones), every start point, a drag run to the
        // finish, a slalom run through the cones, the club circuit's lap clock, and a reset from the middle of a field
        async Task SmokeCompound()
        {
            if (!MapAvailable("compound")) { GD.Print("[smoke] the compound is not installed: skipped"); return; }
            smokeStep = "load the compound"; double r0 = smokeReal;
            SwitchMap("compound"); await SmokeIdle();
            if (mapId != "compound" || pack == null) throw new Exception("the compound did not load");
            var view = maps["compound"].View;
            GD.Print($"[smoke] compound: loaded in {smokeReal - r0:F1} s, {pack.Chunks.Length} chunks, {view.LodDraws} draws with LODs, {pack.Walls.Length / 6} wall segments, " +
                $"{courses?.All.Count ?? 0} courses, {pack.Roads.Count} roads, {pack.Pads.Count} pads, {pack.Spots.Count} start points, {cones.List.Count} cones, far {cam.Far:F0} m" +
                (pack.ExtrasError != null ? "  WARN: extras: " + pack.ExtrasError : courses == null || pack.Spots.Count == 0 || cones.List.Count == 0 || pack.Roads.Count == 0 ? "  WARN: extras missing" : ""));
            ToGrid(); await Frames(10); Shot("compound-grid");
            smokeStep = "compound: drive"; await SmokeDrive(5, 1, 0); Shot("compound-chase");
            await SmokeCam(3); await SmokeDrive(1, 0.6, 0); Shot("compound-trackside"); await SmokeCam(0);
            for (int i = 0; i < pack.Spots.Count; i++)
            {
                smokeStep = "compound: go to " + pack.Spots[i].Name;
                ToSpot(i); await Frames(8);
                var sp = pack.Spots[i];
                double d = Math.Sqrt((car.Pos.X - sp.X) * (car.Pos.X - sp.X) + (car.Pos.Z - sp.Z) * (car.Pos.Z - sp.Z));
                GD.Print($"[smoke] compound: {sp.Name}: car {d:F1} m from the spot, {car.Pos.Y:F1} m up" + (d > 3 ? "  WARN: not at the start point" : ""));
                Shot("compound-" + Slug(sp.Name));
            }
            int Spot(string name) => pack.Spots.FindIndex(s => s.Name == name);
            // the drag strip: flat out to the finish
            if (Spot("Drag strip") >= 0)
            {
                smokeStep = "compound: drag run"; smokeCourse = "";
                ToSpot(Spot("Drag strip")); await Frames(3);
                double t0 = simClock; bool shot = false;
                while (simClock < t0 + 35 && !smokeCourse.StartsWith("drag"))
                {
                    input.TouchGas = 1; await Frames(1);
                    if (!shot && simClock > t0 + 6) { Shot("compound-drag-run"); shot = true; }
                }
                input.ClearTouch();
                GD.Print("[smoke] compound: drag strip: " + (smokeCourse.StartsWith("drag") ? smokeCourse : "no time  WARN: the run was not timed"));
                await SmokeDrive(4, 0, 0, 1);
            }
            // the slalom: straight down the cone line (every cone goes, each one costs 2 s)
            if (Spot("Slalom pad") >= 0)
            {
                smokeStep = "compound: slalom run"; smokeCourse = "";
                ToSpot(Spot("Slalom pad")); await Frames(3);
                double t0 = simClock;
                while (simClock < t0 + 60 && !smokeCourse.StartsWith("slalom"))
                {
                    input.TouchGas = car.Tel.Speed < 14 ? 0.7 : 0; await Frames(1);
                }
                input.ClearTouch();
                int loose = 0; foreach (var c in cones.List) if (c.Loose) loose++;
                GD.Print($"[smoke] compound: slalom: {(smokeCourse.Length > 0 ? smokeCourse : "no time  WARN: the run was not timed")}, {loose} cones down");
                Shot("compound-slalom-after");
            }
            // the oval and the GP: onto each one's line from 40 m back, its lap clock should start (the GP's three
            // configurations run together from their shared line; the HUD shows one)
            foreach (var id in new[] { "oval", "gp", "enduro", "drift" })
            {
                var cr = courses?.All.Find(e => e.Info.Id == id);
                if (cr == null || cr.Info.Line == null) continue;
                smokeStep = "compound: " + id + " lap clock";
                var ln = cr.Info.Line; int n = ln.Length / 2, j = n - 20;
                double hx = ln[0] - ln[j * 2], hz = ln[1] - ln[j * 2 + 1], hl = Math.Sqrt(hx * hx + hz * hz);
                double ry = cr.Info.LineY != null ? cr.Info.LineY[j] + 1.0 : double.PositiveInfinity;
                car.Reset(new V3(ln[j * 2], 0, ln[j * 2 + 1]), Math.Atan2(-hx / hl, -hz / hl), ry);
                courses.Reset(); rig.Snap(car);
                await SmokeDrive(5, 0.6, 0);
                var act = courses.Active;
                GD.Print($"[smoke] compound: {cr.Info.Name} lap clock " + (cr.Running ? $"running ({cr.T:F1} s), HUD shows {hud.LapLabel} ({act?.Info.Name ?? "none"})" : "NOT running  WARN"));
                Shot("compound-" + id);
            }
            // reset from the middle of a field: back onto the nearest road
            smokeStep = "compound: reset to the road";
            car.Reset(new V3(-3000, 0, -1500), 0.7); await Frames(5);
            ResetCar(false); await Frames(5);
            var h = RoadFinder.Nearest(pack.Roads, car.Pos.X, car.Pos.Y, car.Pos.Z);
            GD.Print($"[smoke] compound: reset from a field: {h.Dist:F1} m from the road centreline now" + (h.Dist > h.Half + 3 ? "  WARN: not on a road" : ""));
            Shot("compound-reset");
        }

        async Task SmokeIroha()
        {
            if (!MapAvailable("iroha")) { GD.Print("[smoke] Irohazaka is not installed: skipped"); return; }
            smokeStep = "load Irohazaka"; SwitchMap("iroha"); await SmokeIdle();
            if (mapId != "iroha" || stage == null) throw new Exception("Irohazaka did not load as a stage");
            var view = maps["iroha"].View;
            var c = terrain.Circuit;
            GD.Print($"[smoke] Irohazaka: {view.LodDraws} draws with LODs, {view.Occluders} occluders, occlusion culling {GetViewport().UseOcclusionCulling}, " +
                $"far {cam.Far:F0} m, {c.Path.Len:F0} m of road, stage {c.Stage.Start:F0}-{c.Stage.Finish:F0} m, {maps["iroha"].Pack.Walls.Length / 6} wall segments");
            smokeStep = "iroha: downhill start"; StageStart(true); await Frames(10); Shot("iroha-start-downhill");
            await SmokeDrive(4, 0.8, 0);
            GD.Print($"[smoke] Irohazaka downhill start: {car.Tel.Speed * 3.6:F0} km/h, stage clock {(stage.Running ? "running" : "NOT running")} {stage.T:F1} s" +
                (stage.Running && stage.Down ? "" : "  WARN: the clock did not start at the top line"));
            Shot("iroha-downhill-chase");
            for (double s = 300; s < c.Path.Len - 150; s += 700)
            {
                smokeStep = $"iroha: view at {s:F0} m";
                ToTrack(s); rig.Snap(car);
                await SmokeDrive(0.6, 0.4, 0);
                GD.Print($"[smoke] iroha view at s={s:F0}: {Godot.Engine.GetFramesPerSecond():F0} fps, {RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalObjectsInFrame)} objects, " +
                    $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalDrawCallsInFrame)} draws, {RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalPrimitivesInFrame) / 1000}k tris, car at {car.Pos.Y:F1} m (road {RoadY(s) - 1:F1})" +
                    (Math.Abs(car.Pos.Y - (RoadY(s) - 1)) > 2 ? "  WARN: not on the road" : ""));
                Shot($"iroha-road-{s:F0}");
            }
            smokeStep = "iroha: uphill start"; StageStart(false); await Frames(10); Shot("iroha-start-uphill");
            await SmokeDrive(4, 1, 0);
            GD.Print($"[smoke] Irohazaka uphill start: {car.Tel.Speed * 3.6:F0} km/h, stage clock {(stage.Running ? "running" : "NOT running")}" +
                (stage.Running && !stage.Down ? "" : "  WARN: the clock did not start at the bottom line"));
            await SmokeCam(1); await Frames(4); Shot("iroha-orbit"); await SmokeCam(0);
        }

        // Crash test on the proving ground: straight into the front of the garage block, no pedals. The car should
        // stop on the wall and come off it slowly, not be fired back.
        async Task SmokeCrash(double v, string label)
        {
            smokeStep = "crash test " + label;
            car.Reset(new V3(55, 0, 127.5), Math.PI);
            var f = car.Forward;
            car.Vel = f * v;
            foreach (var w in car.Wheels) w.Omega = v / w.Rad;
            fx.Clear(); rig.Snap(car);
            double back = 0, tc = simClock, spin = 0;
            int hits0 = car.ImpactCount;
            while (simClock < tc + 1.6)
            {
                input.ClearTouch(); await Frames(1);
                back = Math.Max(back, -V3.Dot(car.Vel, f));
                spin = Math.Max(spin, car.AngVel.Length());
            }
            GD.Print($"[smoke] crash into a wall at {label}: came back off it at {back * 3.6:F1} km/h, spin up to {spin:F1} rad/s, at z {car.Pos.Z:F1} (wall face 139.5), {car.ImpactCount - hits0} impact sounds" +
                (back * 3.6 > 15 ? "  WARN: bounced hard" : ""));
            Shot("crash-" + label.Replace(" ", "").Replace("/", ""));
            car.Reset(SpawnPos, 0); fx.Clear(); rig.Snap(car);
        }

        // Glancing hit on the proving ground: along the pit lane, angled into the front of the garage block, no
        // pedals. The car should be turned along the wall and keep most of its speed, not stop on it or sink in.
        async Task SmokeGlance(double deg, double v)
        {
            smokeStep = $"glancing hit at {deg:F0} deg";
            double a = deg * Math.PI / 180, hx = Math.Cos(a), hz = Math.Sin(a);
            car.Reset(new V3(-10, 0, 133.5), Math.Atan2(-hx, -hz));
            car.Vel = car.Forward * v;
            foreach (var w in car.Wheels) w.Omega = v / w.Rad;
            fx.Clear(); rig.Snap(car);
            double t0 = simClock, tHit = -1, deep = -9, vAfter = -1, hAfter = 0;
            int hits0 = car.ImpactCount;
            while (simClock < t0 + 3)
            {
                input.ClearTouch(); await Frames(1);
                double mz = -1e9;
                foreach (var hb in car.Spec.Hull) mz = Math.Max(mz, car.ToWorld(hb - car.ComModel).Z);
                deep = Math.Max(deep, mz - 139.5);
                if (tHit < 0 && mz > 139.5 - 0.06) tHit = simClock;
                if (tHit >= 0 && simClock >= tHit + 1)
                {
                    vAfter = car.Vel.Length(); var fw = car.Forward; hAfter = Math.Atan2(fw.Z, fw.X) * 180 / Math.PI;
                    break;
                }
            }
            if (vAfter < 0) GD.Print($"[smoke] glancing hit at {deg:F0} deg: never reached the wall  WARN");
            else
            {
                double pct = vAfter / v * 100;
                GD.Print($"[smoke] glancing hit at {deg:F0} deg, {v * 3.6:F0} km/h: {vAfter * 3.6:F0} km/h a second later ({pct:F0} %), heading {deg:F0} -> {hAfter:F1} deg (along the wall is 0), " +
                    $"deepest hull point {deep * 100:F0} cm into the wall, {car.ImpactCount - hits0} impact sounds" +
                    (pct < 60 ? "  WARN: lost too much speed" : "") + (deep > 0.08 ? "  WARN: sank into the wall" : ""));
            }
            Shot($"glance-{deg:F0}");
            car.Reset(SpawnPos, 0); fx.Clear(); rig.Snap(car);
        }

        // Glancing hit on a guardrail on Monte Carlo (on the -D side, posts behind the rail, face about railD from
        // the line): 15 degrees into it at 100 km/h, no pedals. The car should slide along it, not catch the posts
        // and stop, and the body must stay out of the rail.
        async Task SmokeRail(double s0, double railD)
        {
            smokeStep = $"mcr: guardrail at {s0:F0} m";
            var c = terrain.Circuit;
            const double v = 27.8, a = 15 * Math.PI / 180;
            var p0 = c.Path.At(s0);
            double hx = Math.Cos(p0.H), hz = Math.Sin(p0.H), rx = -Math.Sin(p0.H), rz = Math.Cos(p0.H);
            double dx = hx * Math.Cos(a) - rx * Math.Sin(a), dz = hz * Math.Cos(a) - rz * Math.Sin(a);
            car.Reset(new V3(p0.X - rx * 0.8, 0, p0.Z - rz * 0.8), Math.Atan2(-dx, -dz), RoadY(s0));
            car.Vel = car.Forward * v;
            foreach (var w in car.Wheels) w.Omega = v / w.Rad;
            fx.Clear(); rig.Snap(car);
            double t0 = simClock, tHit = -1, deepD = 9, centreD = 9, vAfter = -1;
            int hits0 = car.ImpactCount;
            while (simClock < t0 + 3)
            {
                input.ClearTouch(); await Frames(1);
                double md = 9;
                foreach (var hb in car.Spec.Hull)
                {
                    if (hb.Y > 0.7) continue; // the body above the rail can lean over it
                    var p = car.ToWorld(hb - car.ComModel);
                    md = Math.Min(md, ((PolyPath)c.Path).Nearest(p.X, p.Y, p.Z, -1).D);
                }
                deepD = Math.Min(deepD, md);
                centreD = Math.Min(centreD, ((PolyPath)c.Path).Nearest(car.Pos.X, car.Pos.Y - 0.5, car.Pos.Z, -1).D);
                if (tHit < 0 && md < railD + 0.05) tHit = simClock;
                if (tHit >= 0 && simClock >= tHit + 1) { vAfter = car.Vel.Length(); break; }
            }
            if (vAfter < 0) GD.Print($"[smoke] guardrail at {s0:F0} m: never reached the rail (closest hull point at D {deepD:F2})  WARN");
            else
            {
                double pct = vAfter / v * 100;
                GD.Print($"[smoke] guardrail at {s0:F0} m, 15 deg, 100 km/h: {vAfter * 3.6:F0} km/h a second later ({pct:F0} %), lowest hull points reached D {deepD:F2} (rail face about {railD:F2}), " +
                    $"car centre {centreD:F2}, {car.ImpactCount - hits0} impact sounds" +
                    (pct < 60 ? "  WARN: lost too much speed" : "") + (deepD < railD - 0.15 ? "  WARN: into the rail" : "") + (centreD < railD + 0.1 ? "  WARN: through the rail" : ""));
            }
            Shot($"mcr-guardrail-{s0:F0}");
        }

        void SmokeTick(double raw)
        {
            smokeReal += raw;
            if (double.IsNaN(car.Pos.X) || double.IsNaN(car.Pos.Y) || double.IsNaN(car.Vel.X))
            {
                GD.PrintErr("[smoke] NaN in the car state during " + smokeStep);
                selfTest = false; GetTree().Quit(4); return;
            }
            if (smokeReal > 900) { GD.PrintErr("[smoke] TIMEOUT during " + smokeStep); selfTest = false; GetTree().Quit(2); return; }
            if (smokeReal - smokeLog < 1) return;
            smokeLog = smokeReal;
            var e = car.Engine;
            GD.Print($"[smoke] {smokeReal,5:F1}s {smokeStep} | {mapId}/{carId} cam {rig.Mode} | pos {car.Pos.X:F1} {car.Pos.Y:F2} {car.Pos.Z:F1} | " +
                $"{car.Tel.Speed * 3.6:F0} km/h {e.Rpm:F0} rpm gear {e.Gear} | {Godot.Engine.GetFramesPerSecond():F0} fps " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalDrawCallsInFrame)} draws " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalPrimitivesInFrame)} tris");
        }

        async Task SmokeDrive(double seconds, double gas, double steer, double brake = 0)
        {
            double end = simClock + seconds;
            while (simClock < end)
            {
                input.TouchGas = gas; input.TouchBrake = brake;
                input.TouchSteerActive = steer != 0; input.TouchSteerVal = steer;
                await Frames(1);
            }
            input.ClearTouch();
        }

        async Task SmokeIdle() { await Frames(1); while (busy) await Frames(1); await Frames(3); }

        async Task SmokeCam(int mode) { for (int i = 0; i < 6 && rig.Mode != mode; i++) rig.Cycle(); await Frames(2); }

        static string Slug(string s) => s.ToLowerInvariant().Replace(' ', '-');

        void Shot(string name)
        {
            var img = GetViewport().GetTexture().GetImage();
            string path = shotDir.PathJoin($"{++shotN:00}-{name}.jpg");
            var err = img.SaveJpg(path, 0.8f);
            GD.Print("[smoke] screenshot " + path + (err == Error.Ok ? "" : " failed: " + err));
        }
    }
}
