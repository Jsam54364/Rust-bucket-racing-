// The in-game menus: camera and menu buttons (top right), the drop-down menu (car, map, resets, starts, and the
// way to settings and the main menu) and the car setup drawer. Everything changes live and is saved. General
// settings live in the front end's settings page.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public interface IGame
    {
        Car Car { get; }
        string CarId { get; }
        string MapId { get; }
        void SwitchCar(string id);
        void SwitchMap(string id);
        void ResetCar(bool toStart);
        void ToGrid();
        void CycleCamera();
        void FreeCamera();
        void ChangeTune(Action<Tune> change);
        void Toast(string s);
        bool IsStage { get; }
        bool StageDown { get; }
        void StageStart(bool down);
        string[] Spots { get; }      // the map's start points (a compound's paddocks, drag strip...), or none
        void ToSpot(int i);
        void PanelsChanged();
        void OpenSettings(int tab);
        void OpenHowTo();
        void OpenMainMenu();
        void OpenMaps();
    }

    public sealed class Panels
    {
        readonly IGame g;
        public readonly Control Root;
        IconButton bCam, bMenu;
        PanelContainer menu, tune;
        VBoxContainer menuCol;
        Button[] carSeg, presetBtns, drvSeg;
        readonly List<Button> mapBtns = new List<Button>();
        string[] mapIds = new string[0];
        VBoxContainer mapBox;
        Button mTrack, mTrackDown, bAbs, bTcs;
        Label spotHead;
        VBoxContainer spotBox;
        string spotSig = "";
        readonly List<(string key, Ui.SliderRow row)> tuneRows = new List<(string, Ui.SliderRow)>();

        public bool MenuOpen => menu.Visible;
        public bool TuneOpen => tune.Visible;
        public bool AnyOpen => menu.Visible || tune.Visible;

        public Panels(IGame game)
        {
            g = game;
            Root = new Control { Name = "Panels", MouseFilter = Control.MouseFilterEnum.Ignore, Theme = Ui.Theme };
            Root.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            BuildTopRight();
            BuildMenu();
            BuildTune();
            Sync();
        }

        static string F(double v, int dp) => v.ToString("F" + dp, System.Globalization.CultureInfo.InvariantCulture);

        /* ---------------- top right ---------------- */
        void BuildTopRight()
        {
            bCam = new IconButton { Icon = 0, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            bMenu = new IconButton { Icon = 1, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            var sb = Ui.Box(Ui.Glass, 16, Ui.Line, 1);
            var sbh = Ui.Box(Ui.Glass, 16, Ui.Amber, 1);
            foreach (var b in new Button[] { bCam, bMenu })
            {
                b.AddThemeStyleboxOverride("normal", sb); b.AddThemeStyleboxOverride("hover", sbh); b.AddThemeStyleboxOverride("pressed", sbh);
                b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            }
            bCam.Pressed += () => g.CycleCamera();
            bMenu.Pressed += () => ShowMenu(!menu.Visible);
            var row = Ui.Row(12);
            row.AddChild(bCam); row.AddChild(bMenu);
            row.SetAnchorsPreset(Control.LayoutPreset.TopRight);
            row.Position = new Vector2(-24 - 76 * 2 - 12, 18);
            row.GrowHorizontal = Control.GrowDirection.Begin;
            row.Name = "TopRight";
            Root.AddChild(row);
            topRow = row;
        }
        HBoxContainer topRow;

        // keep the top-right buttons clear of a notch, and out from under an open drawer on wide screens
        public void Layout(Vector2 size, float safeR)
        {
            float right = 24 + safeR;
            bool drawer = tune.Visible;
            if (drawer && size.X > 1100) right += DrawerW + 12;
            topRow.Position = new Vector2(size.X - right - 76 * 2 - 12, 18);
            menu.Position = new Vector2(size.X - right - MenuW, 104);
            menu.Size = new Vector2(MenuW, Math.Min(menuCol.GetCombinedMinimumSize().Y + 24, size.Y - 120));
            tune.Position = new Vector2(size.X - DrawerW - safeR, 0);
            tune.Size = new Vector2(DrawerW + safeR, size.Y);
        }

        const float MenuW = 400, DrawerW = 460;

        /* ---------------- menu ---------------- */
        void BuildMenu()
        {
            menu = new PanelContainer { Visible = false, Name = "Menu" };
            menu.AddThemeStyleboxOverride("panel", Ui.Box(Ui.Panel, 14, Ui.Line, 1, 10));
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(MenuW - 20, 0) };
            var col = Ui.Col(4);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(col);
            menu.AddChild(scroll);
            menuCol = col;

            var top = Ui.Row(6);
            foreach (var (label, act) in new (string, Action)[] { ("Settings", () => g.OpenSettings(0)), ("Main menu", () => g.OpenMainMenu()) })
            {
                var a = act;
                var b = Ui.Btn(label, () => { ShowMenu(false); a(); }, false, 50);
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                b.AddThemeFontSizeOverride("font_size", Ui.FontSmall);
                top.AddChild(b);
            }
            col.AddChild(top);
            col.AddChild(Ui.Heading("Car"));
            col.AddChild(Ui.Seg(new[] { "Rust", "Monte", "CTS-V", "Civic" }, (i) => { g.SwitchCar(Defs.CarOrder[i]); Sync(); }, out carSeg));
            col.AddChild(Ui.Heading("Map"));
            mapBox = Ui.Col(6);
            col.AddChild(mapBox);
            BuildMapButtons();
            col.AddChild(Ui.Sep());
            MenuItem(col, "Car setup", () => ShowTune(true));
            MenuItem(col, "Free camera", () => g.FreeCamera());
            MenuItem(col, "Reset car", () => g.ResetCar(false));
            MenuItem(col, "Back to start", () => g.ResetCar(true));
            mTrack = MenuItem(col, "Race track grid", () => { if (g.IsStage) g.StageStart(false); else g.ToGrid(); });
            mTrackDown = MenuItem(col, "Stage start: downhill", () => g.StageStart(true));
            // the map's start points, two to a row (only maps that have them)
            spotHead = Ui.Heading("Go to");
            col.AddChild(spotHead);
            spotBox = Ui.Col(6);
            col.AddChild(spotBox);
            MenuItem(col, "How to play", () => g.OpenHowTo());
            Root.AddChild(menu);
        }

        // the installed maps two to a row, and a way to get more at the end
        void BuildMapButtons()
        {
            foreach (var c in mapBox.GetChildren()) { mapBox.RemoveChild(c); c.QueueFree(); }
            mapBtns.Clear();
            mapIds = Defs.MapOrder;
            var labels = new List<string>();
            foreach (var id in mapIds) labels.Add(Defs.Maps[id].Short);
            labels.Add("More maps…");
            var ids = mapIds;
            for (int r = 0; r * 2 < labels.Count; r++)
            {
                int first = r * 2;
                var row = Ui.Seg(labels.GetRange(first, Math.Min(2, labels.Count - first)).ToArray(), (k) =>
                {
                    int i = first + k;
                    if (i < ids.Length) { g.SwitchMap(ids[i]); Sync(); }
                    else { ShowMenu(false); g.OpenMaps(); }
                }, out var bs);
                foreach (var b in bs) mapBtns.Add(b);
                mapBox.AddChild(row);
            }
        }

        public void MapsChanged() { BuildMapButtons(); Sync(); }

        void SyncSpots()
        {
            var spots = g.Spots;
            string sig = g.MapId + ":" + string.Join("|", spots);
            if (sig == spotSig) return;
            spotSig = sig;
            foreach (var c in spotBox.GetChildren()) { spotBox.RemoveChild(c); c.QueueFree(); }
            for (int r = 0; r * 2 < spots.Length; r++)
            {
                int first = r * 2;
                var labels = new List<string>();
                for (int i = first; i < Math.Min(first + 2, spots.Length); i++) labels.Add(spots[i]);
                Button[] bs = null;
                var row = Ui.Seg(labels.ToArray(), (k) => { Ui.Light(bs, -1); ShowMenu(false); g.ToSpot(first + k); }, out bs);
                spotBox.AddChild(row);
            }
            spotHead.Visible = spotBox.Visible = spots.Length > 0;
        }

        Button MenuItem(VBoxContainer col, string text, Action a)
        {
            var b = Ui.Btn(text, () => { ShowMenu(false); a(); }, false, 56);
            b.Alignment = HorizontalAlignment.Left;
            var flat = Ui.Box(new Color(0, 0, 0, 0), 8, null, 0, 10);
            var hov = Ui.Box(new Color(1, 1, 1, 0.07f), 8, null, 0, 10);
            b.AddThemeStyleboxOverride("normal", flat); b.AddThemeStyleboxOverride("hover", hov); b.AddThemeStyleboxOverride("pressed", hov);
            b.AddThemeColorOverride("font_pressed_color", Ui.Ink);
            col.AddChild(b);
            return b;
        }

        public void ShowMenu(bool on) { menu.Visible = on; g.PanelsChanged(); }

        /* ---------------- car setup drawer ---------------- */
        PanelContainer Drawer(string title, out VBoxContainer body, Action close)
        {
            var d = new PanelContainer { Visible = false };
            d.AddThemeStyleboxOverride("panel", Ui.Box(Ui.Panel, 0, Ui.Line, 1, 0));
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            scroll.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            var col = Ui.Col(8);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            var head = Ui.Row();
            var t = Ui.Text(title.ToUpperInvariant(), Ui.FontBody);
            t.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            head.AddChild(t);
            var cb = Ui.Btn("Close", close, false, 50);
            cb.CustomMinimumSize = new Vector2(110, 50);
            head.AddChild(cb);
            col.AddChild(head);
            scroll.AddChild(Ui.Pad(col, 24, 20, 24, 30));
            d.AddChild(scroll);
            body = col;
            Root.AddChild(d);
            return d;
        }

        void Group(VBoxContainer body, string title, string unit)
        {
            body.AddChild(Ui.Sep());
            var h = Ui.Row();
            var l = Ui.Heading(title); l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            h.AddChild(l);
            if (unit.Length > 0) h.AddChild(Ui.Text(unit, Ui.FontTiny, Ui.Muted));
            body.AddChild(h);
        }

        void TuneSlider(VBoxContainer body, string key, string label, double min, double max, double step, double scale, int dp, string suffix, Action<Tune, double> set)
        {
            var row = Ui.Slider(label, min, max, step, (v) => F(v * scale, dp) + suffix, (v) => g.ChangeTune((t) => set(t, v)));
            body.AddChild(row.Root);
            tuneRows.Add((key, row));
        }

        void BuildTune()
        {
            tune = Drawer("Car setup", out var body, () => ShowTune(false));
            body.AddChild(Ui.Text("Changes apply live. Ride height stays put when you change springs, the same way spring preload works on a coilover.", Ui.FontSmall, Ui.Muted, true));
            body.AddChild(Ui.Seg(new[] { "Comfort", "Street", "Sport", "Race" }, (i) =>
            {
                var name = CarSpec.PresetOrder[i];
                var p = g.Car.Spec.Presets[name];
                g.ChangeTune((t) => t.Apply(p));
                g.Toast(char.ToUpperInvariant(name[0]) + name.Substring(1) + " suspension");
            }, out presetBtns));
            Group(body, "Springs", "kN/m");
            TuneSlider(body, "springF", "Front", 12000, 150000, 500, 0.001, 1, "", (t, v) => t.SpringF = v);
            TuneSlider(body, "springR", "Rear", 12000, 150000, 500, 0.001, 1, "", (t, v) => t.SpringR = v);
            Group(body, "Dampers, bump", "N·s/m");
            TuneSlider(body, "dampF", "Front", 500, 9000, 50, 1, 0, "", (t, v) => t.DampF = v);
            TuneSlider(body, "dampR", "Rear", 500, 9000, 50, 1, 0, "", (t, v) => t.DampR = v);
            TuneSlider(body, "reboundRatio", "Rebound ÷ bump", 1, 2.5, 0.05, 1, 2, "×", (t, v) => t.ReboundRatio = v);
            Group(body, "Anti-roll bars", "kN/m");
            TuneSlider(body, "arbF", "Front", 0, 60000, 500, 0.001, 1, "", (t, v) => t.ArbF = v);
            TuneSlider(body, "arbR", "Rear", 0, 60000, 500, 0.001, 1, "", (t, v) => t.ArbR = v);
            Group(body, "Chassis", "m");
            TuneSlider(body, "comHeight", "Centre of mass height", 0.35, 0.8, 0.01, 1, 2, "", (t, v) => t.ComHeight = v);
            TuneSlider(body, "rollCenter", "Roll centre height", 0, 0.3, 0.01, 1, 2, "", (t, v) => t.RollCenter = v);
            Group(body, "Tyres and brakes", "");
            TuneSlider(body, "grip", "Tyre grip μ", 0.6, 1.8, 0.01, 1, 2, "", (t, v) => t.Grip = v);
            TuneSlider(body, "brakeBias", "Brake bias, front", 0.4, 0.8, 0.01, 100, 0, "%", (t, v) => t.BrakeBias = v);
            Group(body, "Drivetrain", "");
            body.AddChild(Ui.Seg(new[] { "RWD", "FWD", "AWD" }, (i) => { g.ChangeTune((t) => t.Drive = (Drive)i); g.Toast((Drive)i + " drivetrain"); }, out drvSeg));
            Group(body, "Assists", "");
            var tr = Ui.Row();
            bAbs = Ui.Btn("ABS", () => g.ChangeTune((t) => t.Abs = !t.Abs), true);
            bTcs = Ui.Btn("Traction control", () => g.ChangeTune((t) => t.Tcs = !t.Tcs), true);
            bAbs.SizeFlagsHorizontal = bTcs.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            tr.AddChild(bAbs); tr.AddChild(bTcs);
            body.AddChild(tr);
            body.AddChild(Ui.Text("Saved on this device.", Ui.FontTiny, Ui.Muted));
        }

        public void ShowTune(bool on)
        {
            tune.Visible = on;
            if (on) menu.Visible = false;
            Sync(); g.PanelsChanged();
        }

        public void CloseAll() { menu.Visible = false; tune.Visible = false; g.PanelsChanged(); }

        // a touch at p lands on an open panel (so the driving controls ignore it)
        public bool Covers(Vector2 p)
        {
            foreach (Control c in new Control[] { menu, tune, topRow })
                if (c.Visible && c.GetGlobalRect().HasPoint(p)) return true;
            return false;
        }

        public void TapOutside(Vector2 p)
        {
            if (menu.Visible && !menu.GetGlobalRect().HasPoint(p) && !topRow.GetGlobalRect().HasPoint(p)) ShowMenu(false);
        }

        /* ---------------- sync every control to the current state ---------------- */
        public void Sync()
        {
            var car = g.Car;
            if (car == null) return;
            var t = car.Tune;
            Ui.Light(carSeg, Array.IndexOf(Defs.CarOrder, g.CarId));
            int mi = Array.IndexOf(mapIds, g.MapId);
            for (int i = 0; i < mapBtns.Count; i++) mapBtns[i].SetPressedNoSignal(i == mi);
            mTrack.Text = g.IsStage ? "Stage start: uphill" : g.MapId == "grid" ? "Race track grid" : "Starting grid";
            mTrackDown.Visible = g.IsStage;
            SyncSpots();
            int pi = -1;
            for (int i = 0; i < CarSpec.PresetOrder.Length; i++) if (t.Matches(car.Spec.Presets[CarSpec.PresetOrder[i]])) pi = i;
            Ui.Light(presetBtns, pi);
            foreach (var (key, row) in tuneRows) row.Show(TuneValue(t, key));
            Ui.Light(drvSeg, (int)t.Drive);
            bAbs.SetPressedNoSignal(t.Abs); bAbs.Text = t.Abs ? "ABS  ·  on" : "ABS  ·  off";
            bTcs.SetPressedNoSignal(t.Tcs); bTcs.Text = t.Tcs ? "Traction control  ·  on" : "Traction control  ·  off";
        }

        static double TuneValue(Tune t, string k)
        {
            switch (k)
            {
                case "springF": return t.SpringF;
                case "springR": return t.SpringR;
                case "dampF": return t.DampF;
                case "dampR": return t.DampR;
                case "reboundRatio": return t.ReboundRatio;
                case "arbF": return t.ArbF;
                case "arbR": return t.ArbR;
                case "comHeight": return t.ComHeight;
                case "rollCenter": return t.RollCenter;
                case "grip": return t.Grip;
                default: return t.BrakeBias;
            }
        }
    }
}
