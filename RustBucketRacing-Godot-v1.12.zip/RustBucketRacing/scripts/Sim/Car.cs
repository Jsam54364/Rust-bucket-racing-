// The vehicle: rigid body on four raycast corners (spring, damper, anti-roll bar, bump stop), a combined-slip
// tyre model with load sensitivity and geometric load transfer, an engine with a torque curve, launch
// converter, clutch slip and limiter, a sequential gearbox (auto / semi / manual), viscous LSD, ABS, TCS,
// speed-sensitive steering assist and counter-steer, aero drag and downforce, and body collision against
// solid boxes, wall segments and the ground. Stepped at 480 Hz.
using System;
using System.Collections.Generic;

namespace RustBucket.Sim
{
    public enum Drive { RWD, FWD, AWD }
    public enum Gearbox { Auto, Semi, Manual }

    public sealed class Preset
    {
        public readonly double SpringF, SpringR, DampF, DampR, ArbF, ArbR, ComHeight;
        public Preset(double springF, double springR, double dampF, double dampR, double arbF, double arbR, double comHeight)
        { SpringF = springF; SpringR = springR; DampF = dampF; DampR = dampR; ArbF = arbF; ArbR = arbR; ComHeight = comHeight; }
    }

    public sealed class Tune
    {
        public double SpringF, SpringR, DampF, DampR, ArbF, ArbR, ComHeight;
        public double ReboundRatio = 1.6, RollCenter = 0.08, Grip = 1.05, BrakeBias = 0.64;
        public Drive Drive = Drive.RWD;
        public bool Abs = true, Tcs = true;
        public Gearbox Gearbox = Gearbox.Auto;
        public double SteerAssist = 1;  // 0..1: how far full lock is held back to the grip limit at speed
        public double CounterSteer = 0.5; // 0..1: how much the assist catches a sliding rear
        public double SteerSpeed = 1;   // multiplier on how fast the front wheels can turn
        public double Recovery = 0.75;  // 0..1: grip a sliding tyre keeps when you are off the throttle and brake

        public Tune Clone() => (Tune)MemberwiseClone();

        public void Apply(Preset p)
        {
            SpringF = p.SpringF; SpringR = p.SpringR; DampF = p.DampF; DampR = p.DampR; ArbF = p.ArbF; ArbR = p.ArbR; ComHeight = p.ComHeight;
        }

        public bool Matches(Preset p) =>
            Math.Abs(SpringF - p.SpringF) < 1e-6 && Math.Abs(SpringR - p.SpringR) < 1e-6 && Math.Abs(DampF - p.DampF) < 1e-6 &&
            Math.Abs(DampR - p.DampR) < 1e-6 && Math.Abs(ArbF - p.ArbF) < 1e-6 && Math.Abs(ArbR - p.ArbR) < 1e-6 && Math.Abs(ComHeight - p.ComHeight) < 1e-6;
    }

    /* Everything the chassis, drivetrain and body collision need, per car (model frame: forward -Z, right +X,
       up +Y, origin on the ground midway between the axles; hubs at static ride height). */
    public sealed class CarSpec
    {
        public string Id, Name;
        public double Mass;
        public V3 Inertia;               // pitch (X), yaw (Y), roll (Z)
        public double ComZ;              // CoM forward/back of the axle midpoint (model frame)
        public double WheelRadius, WheelRadiusF; // WheelRadiusF 0 = same as the rears
        public double WheelWidth, MountAbove;
        public V3[] Hubs;                // FL, FR, RL, RR
        public double WheelInertia, EngineInertia;
        public double[][] Curve;         // rpm, Nm at full throttle
        public double IdleRpm, Redline, Limiter, OverRev, ClutchCap, Stall, EngBrake, Lsd;
        public double[] Gears;
        public double Reverse, FinalDrive, MaxBrake, Handbrake, CdA, ClA;
        public double AeroBalance = double.NaN; // front share of the downforce; NaN = at the CoM
        public V3[] Hull;                // corners of the convex body collider
        public int[][] HullFaces;        // its faces: corner indices, counter-clockwise seen from outside
        public double HullMinX, HullMaxX, HullMinY, HullMaxY, HullMinZ, HullMaxZ;
        public Dictionary<string, Preset> Presets;
        public Tune DefaultTune;
        public double GeomScale = 1;     // the model and every length here scaled by this (saved setups convert to it)

        public static readonly string[] PresetOrder = { "comfort", "street", "sport", "race" };
    }

    public static class Cars
    {
        public const double G = 9.81;

        static V3 P(double x, double y, double z) => new V3(x, y, z);
        static double[][] Curve(params double[] rpmNm)
        {
            var c = new double[rpmNm.Length / 2][];
            for (int i = 0; i < c.Length; i++) c[i] = new[] { rpmNm[i * 2], rpmNm[i * 2 + 1] };
            return c;
        }
        static Dictionary<string, Preset> Presets(Preset comfort, Preset street, Preset sport, Preset race) =>
            new Dictionary<string, Preset> { ["comfort"] = comfort, ["street"] = street, ["sport"] = sport, ["race"] = race };
        static Tune Default(Preset p, double rollCenter, double grip, double brakeBias)
        {
            var t = new Tune { ReboundRatio = 1.6, RollCenter = rollCenter, Grip = grip, Drive = Drive.RWD, BrakeBias = brakeBias, Abs = true, Tcs = true, Gearbox = Gearbox.Auto, SteerAssist = 1, CounterSteer = 0.5, SteerSpeed = 1 };
            t.Apply(p);
            return t;
        }

        // Every length of a car (and its model) times k: inertia goes with k^2 at the same mass, aero areas with k^2.
        static CarSpec Scale(CarSpec s, double k)
        {
            s.GeomScale = k;
            s.Inertia = s.Inertia * (k * k); s.ComZ *= k;
            s.WheelRadius *= k; s.WheelRadiusF *= k; s.WheelWidth *= k; s.MountAbove *= k;
            s.WheelInertia *= k * k;
            for (int i = 0; i < s.Hubs.Length; i++) s.Hubs[i] = s.Hubs[i] * k;
            for (int i = 0; i < s.Hull.Length; i++) s.Hull[i] = s.Hull[i] * k;
            s.HullMinX *= k; s.HullMaxX *= k; s.HullMinY *= k; s.HullMaxY *= k; s.HullMinZ *= k; s.HullMaxZ *= k;
            s.CdA *= k * k; s.ClA *= k * k;
            return s;
        }

        // The Rust Bucket's model came in about 10 % over the size of the small European hatchbacks of the '80s it
        // looks like; at 0.91 it is 3.97 m long, 1.62 m wide and 1.37 m tall on a 2.41 m wheelbase (a VW Golf Mk2
        // is 3.99 x 1.67 x 1.42 m on 2.48 m).
        public const double RustScale = 0.91;

        // Rust Bucket: 1.4 L-class four, 126 Nm at 4200 rpm, ~69 kW (92 hp) at 6000-6200 rpm, 1.25 t, 5-speed
        public static readonly CarSpec Rust = MakeRust();
        static CarSpec MakeRust()
        {
            const double K = RustScale;
            var pr = Presets(
                new Preset(19000, 17000, 1450, 1300, 5000, 1000, 0.56 * K),
                new Preset(26000, 23000, 1900, 1700, 10000, 3500, 0.52 * K),
                new Preset(40000, 36000, 2800, 2500, 18000, 8000, 0.49 * K),
                new Preset(68000, 62000, 4100, 3700, 30000, 14000, 0.45 * K));
            return Scale(new CarSpec
            {
                Id = "rust", Name = "Rust Bucket",
                Mass = 1250, Inertia = P(2130, 2310, 480), ComZ = -0.12,
                WheelRadius = 0.307, WheelWidth = 0.239, MountAbove = 0.13,
                Hubs = new[] { P(-0.7596, 0.3073, -1.3224), P(0.7596, 0.3073, -1.3224), P(-0.7596, 0.3073, 1.3224), P(0.7596, 0.3073, 1.3224) },
                WheelInertia = 1.15, EngineInertia = 0.13,
                Curve = Curve(800, 78, 1500, 92, 2500, 108, 3500, 120, 4200, 126, 5000, 122, 5800, 112, 6200, 106, 6800, 92, 7200, 80),
                IdleRpm = 800, Redline = 6500, Limiter = 6800, OverRev = 9200, ClutchCap = 340, Stall = 2600, EngBrake = 1, Lsd = 45,
                Gears = new[] { 3.55, 2.04, 1.32, 0.97, 0.78 }, Reverse = 3.5, FinalDrive = 4.06,
                MaxBrake = 5600, Handbrake = 2600, CdA = 0.74, ClA = 0.12,
                // convex collider fitted to the body (tools: collider/fit2.py): a low-poly shrink-wrap without the
                // mirrors and aerial, flat underneath at the ground clearance, the front corners swept back
                Hull = new[]
                {
                    P(0.014, 1.475, 1.306), P(-0.479, 0.488, 2.178), P(0.479, 0.488, 2.178), P(0.377, 0.897, -1.892), P(0.767, 0.255, -1.892),
                    P(0.542, 0.483, -2.183), P(-0.542, 0.483, -2.183), P(-0.377, 0.897, -1.892), P(-0.639, 1.398, -0.148), P(-0.779, 0.817, -1.892),
                    P(0.804, 0.25, 0.143), P(-0.805, 0.25, 1.015), P(0.805, 0.25, 1.015), P(0.79, 0.598, 2.178), P(0.828, 0.594, 2.14),
                    P(0.817, 0.637, 2.15), P(0.586, 1.442, 1.306), P(0.491, 0.769, 2.178), P(0.639, 1.398, -0.148), P(0.779, 0.817, -1.892),
                    P(-0.767, 0.255, -1.892), P(-0.879, 0.31, -1.601), P(-0.804, 0.25, 0.143), P(-0.89, 0.588, -1.02), P(-0.873, 0.357, 1.597),
                    P(-0.874, 0.839, 1.015), P(-0.586, 1.442, 1.306), P(-0.491, 0.769, 2.178), P(-0.828, 0.594, 2.14), P(-0.79, 0.598, 2.178),
                    P(-0.817, 0.637, 2.15), P(0.879, 0.31, -1.601), P(0.874, 0.839, 1.015), P(0.873, 0.357, 1.597), P(0.89, 0.588, -1.02),
                },
                HullFaces = new[] { new[] { 16, 0, 17 }, new[] { 0, 8, 26 }, new[] { 19, 34, 31 }, new[] { 19, 31, 4 }, new[] { 0, 26, 27 }, new[] { 0, 27, 17 }, new[] { 9, 7, 6 }, new[] { 8, 9, 23, 25 }, new[] { 7, 9, 8 }, new[] { 9, 6, 20 }, new[] { 16, 18, 0 }, new[] { 0, 18, 8 }, new[] { 18, 16, 32 }, new[] { 18, 32, 34, 19 }, new[] { 19, 4, 5 }, new[] { 17, 13, 15 }, new[] { 16, 17, 15 }, new[] { 15, 13, 14 }, new[] { 32, 15, 14 }, new[] { 16, 15, 32 }, new[] { 25, 23, 24 }, new[] { 26, 8, 25 }, new[] { 25, 24, 28 }, new[] { 21, 20, 22 }, new[] { 23, 21, 24 }, new[] { 23, 9, 21 }, new[] { 9, 20, 21 }, new[] { 18, 19, 3 }, new[] { 3, 19, 5 }, new[] { 31, 33, 12 }, new[] { 32, 14, 33 }, new[] { 34, 33, 31 }, new[] { 32, 33, 34 }, new[] { 31, 10, 4 }, new[] { 31, 12, 10 }, new[] { 21, 22, 11 }, new[] { 24, 21, 11 }, new[] { 27, 30, 29 }, new[] { 26, 30, 27 }, new[] { 30, 28, 29 }, new[] { 26, 25, 30 }, new[] { 25, 28, 30 }, new[] { 6, 5, 4, 20 }, new[] { 18, 3, 7, 8 }, new[] { 7, 3, 5, 6 }, new[] { 29, 28, 24, 1 }, new[] { 4, 10, 12, 11, 22, 20 }, new[] { 12, 33, 24, 11 }, new[] { 17, 27, 29, 1, 2, 13 }, new[] { 33, 2, 1, 24 }, new[] { 14, 13, 2, 33 } },
                HullMinX = -0.89, HullMaxX = 0.89, HullMinY = 0.25, HullMaxY = 1.475, HullMinZ = -2.183, HullMaxZ = 2.178,
                Presets = pr,
                DefaultTune = Default(pr["street"], 0.08 * K, 1.05, 0.64),
            }, K);
        }

        // Monte Carlo SS: a built 5.7 L small-block, 450 Nm at 4000 rpm and ~240 kW (320 hp) at 5800 rpm,
        // 1.55 t, 5-speed with a 3.55 axle.
        public static readonly CarSpec Monte = MakeMonte();
        static CarSpec MakeMonte()
        {
            var pr = Presets(
                new Preset(30000, 26000, 2200, 1900, 9000, 3000, 0.53),
                new Preset(43000, 37500, 3000, 2550, 17000, 7500, 0.5),
                new Preset(60000, 54000, 3900, 3400, 26000, 12000, 0.47),
                new Preset(86000, 78000, 5300, 4700, 38000, 18000, 0.43));
            return new CarSpec
            {
                Id = "monte", Name = "Monte Carlo SS",
                Mass = 1550, Inertia = P(3500, 3800, 620), ComZ = -0.14,
                WheelRadius = 0.3165, WheelWidth = 0.245, MountAbove = 0.13,
                Hubs = new[] { P(-0.7459, 0.3177, -1.3715), P(0.7459, 0.3177, -1.3715), P(-0.7459, 0.3177, 1.3715), P(0.7459, 0.3177, 1.3715) },
                WheelInertia = 1.35, EngineInertia = 0.2,
                Curve = Curve(700, 290, 1500, 360, 2500, 410, 3500, 445, 4000, 450, 4800, 435, 5400, 412, 5800, 392, 6200, 362, 6600, 318, 7000, 270),
                IdleRpm = 780, Redline = 6000, Limiter = 6300, OverRev = 8800, ClutchCap = 640, Stall = 2300, EngBrake = 2.2, Lsd = 130,
                Gears = new[] { 2.95, 1.94, 1.34, 1.0, 0.73 }, Reverse = 2.76, FinalDrive = 3.55,
                MaxBrake = 7400, Handbrake = 3000, CdA = 0.84, ClA = 0.1,
                // convex collider fitted to the body (tools: collider/fit2.py): a low-poly shrink-wrap without the
                // mirrors and aerial, flat underneath at the ground clearance, the front corners swept back
                Hull = new[]
                {
                    P(-0.18, 0.17, 1.456), P(-0.753, 0.89, 2.368), P(0.753, 0.89, 2.368), P(0.075, 0.672, -2.497), P(0.18, 0.17, 1.456),
                    P(0.84, 0.79, -2.193), P(-0.752, 0.218, 0.848), P(-0.489, 1.345, 0.544), P(0.489, 1.345, 0.544), P(-0.938, 0.986, -0.369),
                    P(-0.492, 1.343, -0.065), P(-0.64, 1.29, 1.152), P(0.938, 0.986, -0.369), P(0.492, 1.343, -0.065), P(0.64, 1.29, 1.152),
                    P(-0.799, 0.528, 2.672), P(-0.693, 0.304, 2.672), P(0.693, 0.304, 2.672), P(0.799, 0.528, 2.672), P(-0.075, 0.672, -2.497),
                    P(-0.84, 0.79, -2.193), P(-0.833, 0.253, -2.193), P(-0.919, 0.696, 1.456), P(-0.87, 0.317, 1.152), P(0.919, 0.696, 1.456),
                    P(0.87, 0.317, 1.152), P(0.752, 0.218, 0.848), P(0.833, 0.253, -2.193), P(0.586, 0.253, -2.497), P(-0.586, 0.253, -2.497),
                    P(-0.207, 0.17, -1.281), P(0.207, 0.17, -1.281),
                },
                HullFaces = new[] { new[] { 0, 16, 6 }, new[] { 11, 9, 1 }, new[] { 11, 10, 9 }, new[] { 7, 10, 11 }, new[] { 30, 0, 6 }, new[] { 30, 6, 21 }, new[] { 3, 5, 28 }, new[] { 30, 21, 29 }, new[] { 10, 20, 9 }, new[] { 9, 20, 21 }, new[] { 20, 19, 29 }, new[] { 20, 29, 21 }, new[] { 5, 27, 28 }, new[] { 28, 27, 31 }, new[] { 5, 12, 27 }, new[] { 12, 24, 25, 27 }, new[] { 15, 23, 16 }, new[] { 16, 23, 6 }, new[] { 23, 21, 6 }, new[] { 2, 18, 24 }, new[] { 12, 2, 24 }, new[] { 14, 2, 12 }, new[] { 13, 12, 5 }, new[] { 13, 14, 12 }, new[] { 26, 4, 31 }, new[] { 27, 26, 31 }, new[] { 26, 17, 4 }, new[] { 15, 22, 23 }, new[] { 1, 22, 15 }, new[] { 1, 9, 22 }, new[] { 22, 9, 21, 23 }, new[] { 14, 13, 8 }, new[] { 18, 17, 25 }, new[] { 25, 17, 26 }, new[] { 24, 18, 25 }, new[] { 25, 26, 27 }, new[] { 31, 4, 0, 30 }, new[] { 19, 3, 28, 29 }, new[] { 28, 31, 30, 29 }, new[] { 5, 3, 19, 20 }, new[] { 18, 15, 16, 17 }, new[] { 4, 17, 16, 0 }, new[] { 2, 1, 15, 18 }, new[] { 2, 14, 11, 1 }, new[] { 13, 5, 20, 10 }, new[] { 14, 8, 7, 11 }, new[] { 8, 13, 10, 7 } },
                HullMinX = -0.938, HullMaxX = 0.938, HullMinY = 0.17, HullMaxY = 1.345, HullMinZ = -2.497, HullMaxZ = 2.672,
                Presets = pr,
                DefaultTune = Default(pr["street"], 0.08, 1.12, 0.62),
            };
        }

        // Cadillac CTS-V race car (2004, World Challenge style): race 5.7 L V8, 569 Nm (420 lb-ft) at 5600 rpm,
        // ~375 kW (500+ hp) from 7200 to 7600 rpm, 1.45 t, close-ratio 6-speed, slicks, splitter and wing, big
        // brakes. 1.4-1.6 g sustained cornering, 1.3-1.5 g braking, ~275 km/h. Smaller front tyres than rears.
        public static readonly CarSpec Cts = MakeCts();
        static CarSpec MakeCts()
        {
            var pr = Presets(
                new Preset(55000, 50000, 3600, 3200, 18000, 8000, 0.47),
                new Preset(75000, 68000, 4600, 4100, 26000, 12000, 0.45),
                new Preset(100000, 90000, 5900, 5300, 36000, 17000, 0.44),
                new Preset(130000, 118000, 7300, 6600, 48000, 23000, 0.42));
            return new CarSpec
            {
                Id = "cts", Name = "Cadillac CTS-V race car",
                Mass = 1450, Inertia = P(2900, 3200, 520), ComZ = -0.058,
                WheelRadius = 0.3293, WheelRadiusF = 0.3166, WheelWidth = 0.29, MountAbove = 0.12,
                Hubs = new[] { P(-0.737, 0.3124, -1.44), P(0.737, 0.3124, -1.44), P(-0.7491, 0.3254, 1.44), P(0.7491, 0.3254, 1.44) },
                WheelInertia = 1.2, EngineInertia = 0.17,
                Curve = Curve(1000, 330, 2000, 400, 3000, 455, 4000, 510, 5000, 555, 5600, 569, 6200, 556, 6800, 528, 7200, 500, 7600, 472, 8000, 420, 8400, 360),
                IdleRpm = 1100, Redline = 7600, Limiter = 7800, OverRev = 9600, ClutchCap = 820, Stall = 3200, EngBrake = 2.6, Lsd = 200,
                Gears = new[] { 2.50, 1.93, 1.54, 1.27, 1.06, 0.89 }, Reverse = 2.9, FinalDrive = 3.90,
                MaxBrake = 6900, Handbrake = 3200, CdA = 1.25, ClA = 2.3, AeroBalance = 0.4,
                // convex collider fitted to the body (tools: collider/fit2.py): a low-poly shrink-wrap without the
                // mirrors and aerial, flat underneath at the ground clearance, the front corners swept back
                Hull = new[]
                {
                    P(0.887, 0.12, 1.073), P(-0.887, 0.12, 1.073), P(-0.561, 0.12, -2.442), P(0.561, 0.12, -2.442), P(-0.83, 0.12, -2.149),
                    P(0.83, 0.12, -2.149), P(0.871, 0.919, -0.685), P(-0.549, 0.661, -2.149), P(-0.598, 1.202, -0.099), P(-0.887, 0.686, -1.564),
                    P(-0.871, 0.919, -0.685), P(0.887, 0.686, -1.564), P(0.549, 0.661, -2.149), P(0.598, 1.202, -0.099), P(0.35, 0.325, 2.537),
                    P(-0.35, 0.325, 2.537), P(-0.734, 0.202, 2.244), P(-0.631, 1.178, 2.537), P(-0.152, 1.193, -0.392), P(0.152, 1.193, -0.392),
                    P(-0.892, 0.12, -0.685), P(-0.919, 0.707, 1.366), P(-0.902, 0.325, 1.659), P(0.892, 0.12, -0.685), P(0.902, 0.325, 1.659),
                    P(0.919, 0.707, 1.366), P(0.734, 0.202, 2.244), P(0.631, 1.178, 2.537), P(-0.834, 1.205, 2.244), P(0.834, 1.205, 2.244),
                    P(0, 1.286, 0.487),
                },
                HullFaces = new[] { new[] { 17, 16, 15 }, new[] { 24, 26, 0 }, new[] { 24, 0, 23 }, new[] { 25, 24, 23 }, new[] { 10, 9, 21 }, new[] { 29, 24, 25 }, new[] { 29, 13, 30 }, new[] { 29, 26, 24 }, new[] { 29, 27, 26 }, new[] { 27, 14, 26 }, new[] { 22, 1, 16 }, new[] { 28, 10, 21 }, new[] { 29, 30, 28 }, new[] { 28, 21, 22 }, new[] { 17, 28, 16 }, new[] { 28, 22, 16 }, new[] { 8, 9, 10 }, new[] { 28, 8, 10 }, new[] { 30, 18, 8 }, new[] { 30, 8, 28 }, new[] { 18, 7, 8 }, new[] { 8, 7, 9 }, new[] { 7, 2, 4 }, new[] { 9, 7, 4 }, new[] { 13, 12, 19 }, new[] { 30, 19, 18 }, new[] { 13, 19, 30 }, new[] { 12, 11, 5 }, new[] { 13, 11, 12 }, new[] { 11, 23, 5 }, new[] { 11, 25, 23 }, new[] { 12, 5, 3 }, new[] { 9, 4, 20 }, new[] { 21, 9, 20 }, new[] { 21, 20, 22 }, new[] { 22, 20, 1 }, new[] { 13, 29, 6 }, new[] { 13, 6, 11 }, new[] { 29, 25, 6 }, new[] { 6, 25, 11 }, new[] { 0, 26, 16, 1 }, new[] { 26, 14, 15, 16 }, new[] { 27, 17, 15, 14 }, new[] { 27, 29, 28, 17 }, new[] { 19, 12, 7, 18 }, new[] { 7, 12, 3, 2 }, new[] { 3, 5, 23, 0, 1, 20, 4, 2 } },
                HullMinX = -0.919, HullMaxX = 0.919, HullMinY = 0.12, HullMaxY = 1.286, HullMinZ = -2.442, HullMaxZ = 2.537,
                Presets = pr,
                DefaultTune = Default(pr["race"], 0.09, 1.58, 0.6),
            };
        }

        // Honda Civic Type R (EK9, 2000): B16B 1.6 L DOHC VTEC four, 160 Nm (118 lb-ft) at 7500 rpm and 136 kW
        // (182 hp / 185 PS) at 8200 rpm on a 10.8:1 compression ratio, 8400 rpm redline (the cut just over it); close-ratio 5-speed with a
        // helical LSD on the front axle; 1.07 t, 61 % on the front wheels; 195/55 R15 tyres; 262 mm vented front and
        // 239 mm solid rear discs. 0-100 km/h in about 7 s, the quarter mile in about 15.3 s, ~230 km/h flat out.
        // VTEC changes to the high-lift cams at about 5800 rpm: the curve flattens before it and climbs after.
        public static readonly CarSpec Civic = MakeCivic();
        static CarSpec MakeCivic()
        {
            var pr = Presets(
                new Preset(23500, 17300, 1660, 1140, 6000, 5000, 0.53),
                new Preset(35000, 25300, 2160, 1470, 9000, 9000, 0.5),
                new Preset(51500, 36400, 2790, 1875, 14000, 15000, 0.48),
                new Preset(87000, 60200, 3835, 2554, 20000, 24000, 0.45));
            var tune = Default(pr["street"], 0.08, 1.10, 0.66);
            tune.Drive = Drive.FWD;
            return new CarSpec
            {
                Id = "civic", Name = "Honda Civic Type R",
                Mass = 1070, Inertia = P(1680, 1820, 380), ComZ = -0.288,
                WheelRadius = 0.3022, WheelWidth = 0.232, MountAbove = 0.13,
                Hubs = new[] { P(-0.7277, 0.3021, -1.31), P(0.7277, 0.3021, -1.31), P(-0.7277, 0.3021, 1.31), P(0.7277, 0.3021, 1.31) },
                WheelInertia = 0.9, EngineInertia = 0.08,
                Curve = Curve(1000, 105, 2000, 118, 3000, 128, 4000, 137, 5000, 141, 5600, 139, 6000, 148, 6500, 154, 7000, 158, 7500, 160, 8200, 158, 8400, 153, 8800, 140, 9200, 125),
                IdleRpm = 900, Redline = 8400, Limiter = 8700, OverRev = 10400, ClutchCap = 330, Stall = 4200, EngBrake = 1.1, Lsd = 90,
                Gears = new[] { 3.230, 2.105, 1.458, 1.107, 0.848 }, Reverse = 3.0, FinalDrive = 4.40,
                MaxBrake = 5000, Handbrake = 2300, CdA = 0.66, ClA = 0.08,
                // convex collider fitted to the body (tools: collider/fit2.py): a low-poly shrink-wrap without the
                // mirrors, flat underneath at the ground clearance, the front corners swept back
                Hull = new[]
                {
                    P(-0.487, 1.331, 1.405), P(-0.773, 0.855, 1.701), P(-0.617, 0.565, 1.998), P(-0.807, 0.174, 0.811), P(-0.393, 0.196, 1.998),
                    P(0.617, 0.565, 1.998), P(0.393, 0.196, 1.998), P(0.807, 0.174, 0.811), P(0.797, 0.171, -0.969), P(-0.797, 0.171, -0.969),
                    P(0.492, 0.178, -2.156), P(-0.492, 0.178, -2.156), P(0.487, 1.331, 1.405), P(0.773, 0.855, 1.701), P(-0.559, 1.259, -0.079),
                    P(-0.387, 1.339, 0.811), P(0, 1.309, -0.079), P(0.387, 1.339, 0.811), P(0.482, 0.491, -2.156), P(-0.578, 0.684, -1.859),
                    P(-0.482, 0.491, -2.156), P(0.559, 1.259, -0.079), P(0.578, 0.684, -1.859), P(-0.831, 0.828, 0.811), P(0.831, 0.828, 0.811),
                    P(-0.855, 0.499, 0.514), P(-0.84, 0.605, -1.563), P(-0.854, 0.31, 1.405), P(0.855, 0.499, 0.514), P(0.84, 0.605, -1.563),
                    P(0.854, 0.31, 1.405),
                },
                HullFaces = new[] { new[] { 23, 26, 25 }, new[] { 14, 26, 23 }, new[] { 15, 14, 0 }, new[] { 0, 14, 23 }, new[] { 26, 11, 9 }, new[] { 29, 8, 10 }, new[] { 21, 24, 29 }, new[] { 24, 28, 29 }, new[] { 14, 19, 26 }, new[] { 21, 12, 24 }, new[] { 12, 13, 24 }, new[] { 30, 6, 7 }, new[] { 24, 30, 28 }, new[] { 24, 13, 30 }, new[] { 30, 7, 8 }, new[] { 29, 28, 30 }, new[] { 29, 30, 8 }, new[] { 27, 9, 3 }, new[] { 25, 26, 27 }, new[] { 26, 9, 27 }, new[] { 23, 25, 27 }, new[] { 27, 3, 4 }, new[] { 2, 27, 4 }, new[] { 21, 29, 22 }, new[] { 26, 20, 11 }, new[] { 26, 19, 20 }, new[] { 0, 23, 1 }, new[] { 0, 1, 2 }, new[] { 1, 23, 27 }, new[] { 1, 27, 2 }, new[] { 12, 21, 17 }, new[] { 12, 5, 13 }, new[] { 13, 5, 30 }, new[] { 5, 6, 30 }, new[] { 16, 19, 14 }, new[] { 22, 19, 16 }, new[] { 21, 22, 16 }, new[] { 16, 14, 15 }, new[] { 17, 21, 16 }, new[] { 17, 16, 15 }, new[] { 18, 29, 10 }, new[] { 22, 29, 18 }, new[] { 10, 8, 9, 11 }, new[] { 7, 6, 4, 3 }, new[] { 8, 7, 3, 9 }, new[] { 12, 17, 15, 0 }, new[] { 12, 0, 2, 5 }, new[] { 5, 2, 4, 6 }, new[] { 20, 18, 10, 11 }, new[] { 19, 22, 18, 20 } },
                HullMinX = -0.855, HullMaxX = 0.855, HullMinY = 0.171, HullMaxY = 1.339, HullMinZ = -2.156, HullMaxZ = 1.998,
                Presets = pr,
                DefaultTune = tune,
            };
        }

        public static CarSpec ById(string id) => id == "monte" ? Monte : id == "cts" ? Cts : id == "civic" ? Civic : Rust;

        // full-throttle torque curve lookup
        public static double TorqueAt(double[][] c, double rpm)
        {
            if (rpm <= c[0][0]) return c[0][1];
            for (int i = 1; i < c.Length; i++)
                if (rpm <= c[i][0])
                {
                    double t = (rpm - c[i - 1][0]) / (c[i][0] - c[i - 1][0]);
                    return M.Lerp(c[i - 1][1], c[i][1], t);
                }
            return c[c.Length - 1][1];
        }

        // Normalised tyre curve: rises to 1 at rho = 1 (peak slip), falls to `slide` beyond.
        public static double TyreCurve(double rho, double slide)
        {
            if (rho < 1) return rho * (2 - rho);
            return 1 - (1 - slide) * (1 - Math.Exp(-(rho - 1) / 1.1));
        }
    }

    public sealed class DriveInput
    {
        public double Throttle, Brake, Steer, Handbrake;
        public bool ShiftUp, ShiftDown;
    }

    public sealed class Wheel
    {
        public string Id;
        public bool Front, Left, Driven;
        public V3 HubModel, MountModel, MountBody;
        public double Rad;
        public double X, XPrev, Fz, Load, Omega, Spin, Steer, DVis = 0.2;
        public double SlipRatio, SlipAngle, SlipVel, Grip, Fx, Fy, Cap, Sliding, VLong, Geo;
        public double Kp; // peak slip ratio on the current surface (0 until the first contact)
        public double AbsP = 1; // ABS: share of the brake pressure let through to this wheel
        public bool Contact, AbsActive, HasFw;
        public V3 ContactPt, Normal = V3.UnitY, Head, Mount, Fw;
        public Surf Surface = Surf.Tarmac;
        public double K, CBump, CReb, StaticLoad, L0;
        public double KpOr => Kp != 0 ? Kp : 0.11;
    }

    public sealed class ShiftState { public int From, To; public double T, Sel, Total; public bool Down; }

    public sealed class EngineState
    {
        public double Rpm, ShiftT, Clutch = 1, TcsCut = 1, RevTimer, Load;
        public double UpHold, LimT; // automatic: no kickdown just after changing up; time spent near the limiter
        public int Gear = 1, Queued;
        public bool LimiterCut, Blip, OverRev;
        public ShiftState Shift;
        public string Refused; // "speed" | "overrev" | null
    }

    public sealed class Telemetry
    {
        public double GLat, GLong, Roll, Pitch, Speed, WheelRpm;
        public bool AbsActive, TcsActive, CsActive;
        public bool HasLoad; public double FrontLoad, LoadCx, LoadCz;
    }

    public sealed class Car
    {
        const double G = Cars.G;
        static readonly double[] UF = { -0.7, -0.35, 0, 0.35, 0.7 };

        public TerrainBase Terrain;
        public readonly CarSpec Spec;
        public Tune Tune;
        public readonly double Mass;
        public readonly V3 I;
        public readonly Wheel[] Wheels; // FL, FR, RL, RR
        public readonly EngineState Engine = new EngineState();
        public readonly Telemetry Tel = new Telemetry();
        double recSm; // slide recovery, eased in and out
        public readonly double[] ShiftRpm;
        public V3 Pos, Vel, AngVel, PrevVel;
        public Q4 Q = Q4.Identity;
        public double SteerSm, Cs, AssistW = 1, HitWall, HitGround;
        // impacts for the sound: the hardest new hit (closing speed, m/s) since the game last read it
        public double Impact;
        public int ImpactCount;
        double impactCool, impactLast;
        V3[] hullBody, hp;
        readonly double[] driveT = new double[4], arbF = new double[4];
        V3 fAcc, tAcc;

        public Car(TerrainBase terrain, Tune tune, CarSpec spec)
        {
            Terrain = terrain; Spec = spec;
            var S = spec;
            Tune = (tune ?? S.DefaultTune).Clone();
            Mass = S.Mass; I = S.Inertia;
            string[] ids = { "FL", "FR", "RL", "RR" };
            Wheels = new Wheel[4];
            for (int i = 0; i < 4; i++)
            {
                bool front = ids[i][0] == 'F';
                Wheels[i] = new Wheel
                {
                    Id = ids[i], Front = front, Left = ids[i][1] == 'L', HubModel = S.Hubs[i],
                    Rad = front && S.WheelRadiusF > 0 ? S.WheelRadiusF : S.WheelRadius,
                };
            }
            Engine.Rpm = S.IdleRpm;
            // automatic under power: change up where the next gear pulls harder at the wheels, which for these
            // engines is right up at the limiter (it changes 60 rpm short of the cut)
            ShiftRpm = new double[S.Gears.Length];
            for (int i = 0; i < S.Gears.Length; i++)
            {
                if (i == S.Gears.Length - 1) { ShiftRpm[i] = S.Limiter; continue; }
                double g = S.Gears[i], g2 = S.Gears[i + 1];
                double found = S.Limiter - 60;
                for (double r = S.Redline * 0.85; r <= S.Limiter - 60; r += 20)
                    if (Cars.TorqueAt(S.Curve, r) * g <= Cars.TorqueAt(S.Curve, (r * g2) / g) * g2) { found = r; break; }
                ShiftRpm[i] = found;
            }
            hp = new V3[S.Hull.Length];
            lastWallN = new V3[S.Hull.Length];
            Recompute();
            Reset(V3.Zero, 0);
        }

        // CoM in model frame
        public V3 ComModel => new V3(0, Tune.ComHeight, Spec.ComZ);

        // new setup values; the visual body stays put when the CoM moves
        public void SetTune(Tune t)
        {
            V3 oldCom = ComModel;
            Tune = t.Clone();
            Recompute();
            V3 d = ComModel - oldCom;
            Pos = Pos + Q.Rotate(d);
        }

        void Recompute()
        {
            var S = Spec; var t = Tune; V3 com = ComModel;
            double wb = S.Hubs[2].Z - S.Hubs[0].Z;
            double frontShare = (S.Hubs[2].Z - com.Z) / wb;
            foreach (var w in Wheels)
            {
                w.K = w.Front ? t.SpringF : t.SpringR;
                w.CBump = w.Front ? t.DampF : t.DampR;
                w.CReb = w.CBump * t.ReboundRatio;
                double load = (Mass * G * (w.Front ? frontShare : 1 - frontShare)) / 2;
                w.StaticLoad = load;
                w.L0 = S.MountAbove + load / w.K; // preload keeps ride height constant
                w.MountModel = new V3(w.HubModel.X, w.HubModel.Y + S.MountAbove, w.HubModel.Z);
                w.MountBody = w.MountModel - com;
                w.Driven = t.Drive == Drive.AWD || (t.Drive == Drive.RWD ? !w.Front : w.Front);
            }
            hullBody = new V3[S.Hull.Length];
            for (int i = 0; i < S.Hull.Length; i++) hullBody[i] = S.Hull[i] - com;
            // the collider's faces in the body frame: outward normal and offset (inside: n . x <= d)
            int nf = S.HullFaces?.Length ?? 0;
            faceN = new V3[nf]; faceD = new double[nf];
            for (int f = 0; f < nf; f++)
            {
                var fi = S.HullFaces[f];
                V3 a = hullBody[fi[0]], b = hullBody[fi[1]], c = hullBody[fi[2]];
                V3 n = V3.Cross(b - a, c - a).Normalized();
                faceN[f] = n; faceD[f] = V3.Dot(n, a);
            }
        }

        public void Reset(V3 pos, double yaw) => Reset(pos, yaw, double.PositiveInfinity);

        // yHint: put the car on the ground at or just above this height (on the road, not on a rock hanging over it)
        public void Reset(V3 pos, double yaw, double yHint)
        {
            var S = Spec;
            V3 com = ComModel;
            double gy = double.IsFinite(yHint) ? Terrain.HeightAt(pos.X, pos.Z, yHint) : Terrain.Height(pos.X, pos.Z);
            if (gy <= Terrain.Floor && double.IsFinite(yHint)) gy = Terrain.Height(pos.X, pos.Z);
            Q = Q4.Axis(V3.UnitY, yaw);
            Pos = new V3(pos.X, gy, pos.Z) + Q.Rotate(com);
            Vel = V3.Zero; AngVel = V3.Zero; PrevVel = V3.Zero;
            foreach (var w in Wheels) { w.Omega = 0; w.X = w.L0 - S.MountAbove; w.XPrev = w.X; w.DVis = S.MountAbove; }
            var e = Engine;
            e.Gear = Tune.Gearbox == Gearbox.Auto ? 1 : (e.Gear != 0 ? e.Gear : 1);
            e.Rpm = S.IdleRpm;
            e.ShiftT = 0; e.Shift = null; e.Queued = 0; e.Blip = false;
            Cs = 0; SteerSm = 0;
            Impact = 0; impactCool = 0; impactLast = 0;
            Array.Clear(lastWallN, 0, lastWallN.Length);
        }

        public void ResetUpright()
        {
            V3 f = Q.Rotate(V3.Fwd);
            double yaw = Math.Atan2(-f.X, -f.Z);
            V3 c = Q.Rotate(ComModel);
            Reset(new V3(Pos.X - c.X, 0, Pos.Z - c.Z), yaw, Pos.Y);
            Pos = new V3(Pos.X, Pos.Y + 0.25, Pos.Z);
        }

        public V3 Forward => Q.Rotate(V3.Fwd);
        public V3 Up => Q.Rotate(V3.UnitY);
        public V3 Right => Q.Rotate(V3.UnitX);
        public V3 PointVel(V3 p) => Vel + V3.Cross(AngVel, p - Pos);
        public V3 ToWorld(V3 pb) => Pos + Q.Rotate(pb);
        public double Yaw { get { V3 f = Forward; return Math.Atan2(-f.X, -f.Z); } }

        // Sequential gearbox with an automatic clutch.
        // Upshift ~0.26 s: clutch out with an ignition cut, gear in at 0.09 s, clutch closes progressively.
        // Downshift ~0.46 s: clutch out while the throttle blips to the lower gear's revs, gear in at 0.24 s.
        void StartShift(int to)
        {
            var e = Engine;
            bool down = to < e.Gear && to > 0;
            e.Shift = new ShiftState { From = e.Gear, To = to, T = 0, Sel = down ? 0.24 : 0.09, Total = down ? 0.46 : 0.26, Down = down };
            e.ShiftT = e.Shift.Total;
        }

        double DrivenOmega()
        {
            double s = 0; int n = 0;
            foreach (var w in Wheels) if (w.Driven) { s += w.Omega; n++; }
            return n > 0 ? s / n : 0;
        }

        // Driver or auto-logic request. Automatic and semi skip neutral (1 <-> R); every mode refuses reverse while
        // rolling; semi-auto also refuses downshifts that would over-rev. Manual takes any gear: an over-speed
        // downshift slips the clutch, spins the engine past its limit and drags the wheels.
        // Returns false when refused (reason in Engine.Refused).
        public bool Shift(int dir)
        {
            var e = Engine; var S = Spec;
            if (e.Shift != null) { e.Queued = M.ClampI(e.Queued + dir, -4, 4); return true; } // quick flicks stack up
            bool manual = Tune.Gearbox == Gearbox.Manual;
            int ng = M.ClampI(e.Gear + dir, -1, S.Gears.Length);
            if (ng == 0 && !manual) ng = dir > 0 ? 1 : -1; // only manual stops in neutral
            if (ng == e.Gear) return false;
            double vF = V3.Dot(Vel, Q.Rotate(V3.Fwd));
            if ((ng < 0 && vF > 1.5) || (e.Gear < 0 && ng > 0 && vF < -1.5)) { e.Refused = "speed"; return false; }
            if (Tune.Gearbox == Gearbox.Semi && ng > 0 && ng < e.Gear)
            {
                double rpmAfter = Math.Abs(DrivenOmega() * GearRatio(ng) * 60 / (2 * Math.PI));
                if (rpmAfter > S.Limiter - 100) { e.Refused = "overrev"; return false; }
            }
            StartShift(ng);
            return true;
        }

        // Engine turning freely (clutch out): drive torque against friction on the engine's own inertia, so the revs
        // rise quickly and fall back over a second or two. Part throttle settles at part revs; full throttle runs to
        // the limiter. Idle control holds the idle speed.
        double FreeRev(EngineState e, double thr, double dt)
        {
            const double TO_RPM = 60 / (2 * Math.PI);
            var S = Spec;
            double rpm = e.Rpm;
            double want = S.IdleRpm + Math.Pow(M.Clamp(thr, 0, 1), 0.8) * (S.Limiter + 120 - S.IdleRpm);
            double fric = Math.Max(S.EngBrake, 1.5) * (10 + 0.0045 * rpm) + (rpm > S.Limiter ? 0.05 * (rpm - S.Limiter) : 0);
            if (rpm < want && !e.LimiterCut)
            {
                double drv = Cars.TorqueAt(S.Curve, rpm) * Math.Max(thr, 0.12);
                return Math.Min(want, rpm + Math.Max(0, (drv - fric) / S.EngineInertia) * dt * TO_RPM);
            }
            // coming down: settle on the part-throttle speed from above, or fall freely while the limiter cuts
            double down = rpm - (fric / S.EngineInertia) * dt * TO_RPM;
            return rpm > want ? Math.Max(want, down) : Math.Max(S.IdleRpm, down);
        }

        public double GearRatio(int g)
        {
            var S = Spec;
            if (g == 0) return 0;
            if (g < 0) return -S.Reverse * S.FinalDrive;
            return S.Gears[g - 1] * S.FinalDrive;
        }

        void ApplyAt(V3 f, V3 p)
        {
            fAcc = fAcc + f;
            V3 r = p - Pos;
            tAcc = tAcc + V3.Cross(r, f);
        }

        // Body contacts (walls, boxes, the ground under the hull) are collected during the step and solved after
        // the forces as impulses on the velocities: each hull point that is in stops going in, all at once, so the
        // body never sinks into a guardrail (a spring soft enough not to fire the car back let it sink in 30-70 cm
        // and catch the posts behind the rail, which stopped it dead). What comes back out is a small, fixed share
        // of the speed it went in at (restitution: a quarter for a bump, a twentieth for a big hit), and friction
        // along the surface is a share of that same impulse: low on walls, so a glancing hit takes the speed going
        // into the wall and leaves the speed along it, and the car is turned away along the wall. Whatever depth is
        // left after the move is taken out by moving the car (not by giving it speed).
        const int MaxC = 160;
        readonly V3[] cP = new V3[MaxC], cN = new V3[MaxC], cJt = new V3[MaxC], cRb = new V3[MaxC];
        readonly double[] cD = new double[MaxC], cMu = new double[MaxC], cE = new double[MaxC], cK = new double[MaxC],
            cTgt = new double[MaxC], cJn = new double[MaxC], cCorr = new double[MaxC];
        readonly int[] cH = new int[MaxC];
        readonly bool[] cWall = new bool[MaxC], cSeg = new bool[MaxC];
        int nC;
        V3[] lastWallN;                  // per hull point: the wall face it was against last step (zero: none)
        V3[] faceN; double[] faceD;      // collider faces in the body frame
        // a collision turns the car about its vertical axis as if it were half as heavy again to turn: closer to
        // what tyres gripping the road do in the moment of a hit, so a car that glances off a wall or a post is
        // set back along it a little turned away, instead of being spun round on its nose
        const double ContactYawK = 1.5;
        readonly double[] edgeSeen = new double[256];
        public int ContactCount;         // body contacts in the last step (for the self-test)

        void AddContact(int h, V3 p, V3 n, double depth, double mu, double rest, bool wall, bool seg = false)
        {
            if (nC >= MaxC) return;
            cH[nC] = h; cP[nC] = p; cN[nC] = n; cD[nC] = depth; cMu[nC] = mu; cE[nC] = rest; cWall[nC] = wall; cSeg[nC] = seg;
            cRb[nC] = h >= 0 ? hullBody[h] : V3.Zero;
            nC++;
        }

        // A vertical edge (the end of a wall, a corner of a post or of a box) at (ex, ez) from y0 up to y1, against
        // the collider: where it passes through the body, the car is pushed out through the nearest face. This is
        // what makes the bevelled corners work: a post that meets a swept-back corner pushes it sideways along
        // the bevel, not straight back.
        void EdgeContact(double ex, double ez, double y0, double y1, V3 pos, Q4 q, Q4 qi, double mu)
        {
            int nf = faceN.Length;
            if (nf == 0 || nC >= MaxC) return;
            V3 a = qi.Rotate(new V3(ex - pos.X, y0 - pos.Y, ez - pos.Z)), b = qi.Rotate(new V3(ex - pos.X, y1 - pos.Y, ez - pos.Z));
            V3 d = b - a;
            double t0 = 0, t1 = 1;
            for (int f = 0; f < nf; f++)
            {
                double na = V3.Dot(faceN[f], a) - faceD[f], nd = V3.Dot(faceN[f], d);
                if (Math.Abs(nd) < 1e-12) { if (na > 0) return; continue; }
                double t = -na / nd;
                if (nd > 0) { if (t < t1) t1 = t; } else if (t > t0) t0 = t;
                if (t0 >= t1) return;
            }
            V3 x = a + d * ((t0 + t1) / 2);
            int best = -1; double bd = double.PositiveInfinity;
            for (int f = 0; f < nf; f++) { double dep = faceD[f] - V3.Dot(faceN[f], x); if (dep < bd) { bd = dep; best = f; } }
            if (best < 0 || bd <= 0) return;
            AddContact(-1, pos + q.Rotate(x), q.Rotate(faceN[best]) * -1, bd, mu, 1, true);
            cRb[nC - 1] = x;
        }

        // each wall end once a step (pieces of a wall share their ends)
        int edgeN;
        bool EdgeSeenBefore(double x, double z)
        {
            for (int i = 0; i < edgeN; i += 2) if (Math.Abs(edgeSeen[i] - x) < 0.01 && Math.Abs(edgeSeen[i + 1] - z) < 0.01) return true;
            if (edgeN < edgeSeen.Length) { edgeSeen[edgeN++] = x; edgeSeen[edgeN++] = z; }
            return false;
        }

        // world inverse inertia times a vector: the inertia is diagonal along the body axes ibx, iby, ibz
        V3 ibx, iby, ibz;
        V3 InvI(V3 v) => ibx * (V3.Dot(ibx, v) / I.X) + iby * (V3.Dot(iby, v) / (I.Y * ContactYawK)) + ibz * (V3.Dot(ibz, v) / I.Z);

        // 1 / (how much the point's speed along d changes per unit impulse along d)
        double EffMass(V3 r, V3 d) => 1 / (1 / Mass + V3.Dot(d, V3.Cross(InvI(V3.Cross(r, d)), r)));

        void Impulse(V3 j, V3 r)
        {
            Vel = Vel + j * (1 / Mass);
            AngVel = AngVel + InvI(V3.Cross(r, j));
        }

        void SolveContacts(Q4 q)
        {
            ibx = q.Rotate(V3.UnitX); iby = q.Rotate(V3.UnitY); ibz = q.Rotate(new V3(0, 0, 1));
            for (int i = 0; i < nC; i++)
            {
                V3 r = cP[i] - Pos, n = cN[i];
                cK[i] = EffMass(r, n);
                double vn0 = V3.Dot(Vel + V3.Cross(AngVel, r), n);
                if (cWall[i]) HitWall = Math.Max(HitWall, -vn0); else HitGround = Math.Max(HitGround, -vn0);
                // restitution: none for resting or slow contact, a quarter at a bump, a twentieth at 30 m/s
                double e = vn0 < -1.0 ? M.Clamp(0.25 - 0.0067 * -vn0, 0.05, 0.25) * cE[i] : 0;
                cTgt[i] = vn0 < 0 ? -e * vn0 : 0;
                cJn[i] = 0; cJt[i] = V3.Zero;
            }
            for (int it = 0; it < 8; it++)
                for (int ii = 0; ii < nC; ii++)
                {
                    int i = (it & 1) == 0 ? ii : nC - 1 - ii; // sweep both ways, so no contact gets more than its share
                    V3 r = cP[i] - Pos, n = cN[i];
                    V3 v = Vel + V3.Cross(AngVel, r);
                    double dj = (cTgt[i] - V3.Dot(v, n)) * cK[i];
                    double jn = Math.Max(cJn[i] + dj, 0);
                    dj = jn - cJn[i]; cJn[i] = jn;
                    if (dj != 0) Impulse(n * dj, r);
                    if (jn <= 0 || cMu[i] <= 0) continue;
                    v = Vel + V3.Cross(AngVel, r);
                    V3 vt = v - n * V3.Dot(v, n);
                    double vtl = vt.Length();
                    if (vtl < 1e-6) continue;
                    V3 tdir = vt * (1 / vtl);
                    V3 jt = cJt[i] - tdir * (vtl * EffMass(r, tdir));
                    double lim = cMu[i] * jn, jl = jt.Length();
                    if (jl > lim) jt = jt * (lim / jl);
                    V3 djt = jt - cJt[i]; cJt[i] = jt;
                    Impulse(djt, r);
                }
        }

        // after the move: push the car out of whatever depth is left (part of it each step; positions only)
        void Depenetrate()
        {
            const double Slop = 0.004, Beta = 0.4;
            for (int i = 0; i < nC; i++)
            {
                V3 p1 = Pos + Q.Rotate(cRb[i]);
                double d = cD[i] - V3.Dot(p1 - cP[i], cN[i]); // the surface is flat at this scale
                cCorr[i] = d > Slop ? (d - Slop) * Beta : 0;
            }
            V3 dP = V3.Zero;
            for (int it = 0; it < 4; it++)
                for (int i = 0; i < nC; i++)
                {
                    double s = cCorr[i] - V3.Dot(dP, cN[i]);
                    if (s > 0) dP = dP + cN[i] * s;
                }
            double l = dP.Length();
            if (l > 0.08) dP = dP * (0.08 / l);
            Pos = Pos + dP;
        }

        // The strut pushes the body along the ground normal, but never more than ~32 degrees off the body's own
        // up: a wheel that runs into a rock face or a steep bank lifts the car rather than kicking it sideways.
        static V3 StrutDir(V3 n, V3 up)
        {
            double cu = V3.Dot(n, up);
            if (cu >= 0.85) return n;
            V3 tan = n - up * cu;
            double tl = tan.Length();
            return tl > 1e-6 ? up * 0.85 + tan * (0.527 / tl) : up;
        }

        /* ---------------- one fixed physics step ---------------- */
        public void Step(double dt, DriveInput inp)
        {
            var t = Tune; var e = Engine; var W = Wheels; var T = Terrain; var S = Spec;
            Q4 q = Q;
            V3 up = q.Rotate(V3.UnitY);
            V3 down = up * -1;
            V3 fwdB = q.Rotate(V3.Fwd);
            V3 rgtB = q.Rotate(V3.UnitX);
            double vFwd = V3.Dot(Vel, fwdB);
            double speed = Vel.Length();
            V3 pos = Pos;

            fAcc = new V3(0, -G * Mass, 0);
            tAcc = V3.Zero;
            HitWall = 0; HitGround = 0;
            nC = 0;

            // ----- gearbox: automatic logic and reverse handling -----
            bool auto = t.Gearbox == Gearbox.Auto, semi = t.Gearbox == Gearbox.Semi, manual = t.Gearbox == Gearbox.Manual;
            double throttle = inp.Throttle, brake = inp.Brake;
            if (e.Gear < 0 && auto) { throttle = inp.Brake; brake = inp.Throttle; } // automatic: hold brake to reverse
            if (auto)
            {
                if (e.Gear >= 1 && vFwd < 0.6 && inp.Brake > 0.5 && inp.Throttle < 0.1)
                {
                    e.RevTimer += dt; if (e.RevTimer > 0.3 && e.Shift == null) { StartShift(-1); e.RevTimer = 0; }
                }
                else if (e.Gear < 0 && vFwd > -0.6 && inp.Throttle > 0.5 && inp.Brake < 0.1)
                {
                    e.RevTimer += dt; if (e.RevTimer > 0.15 && e.Shift == null) { StartShift(1); e.RevTimer = 0; }
                }
                else e.RevTimer = 0;
                if (e.Gear == 0 && e.Shift == null) e.Gear = 1;
            }
            if (inp.ShiftUp) Shift(1);
            if (inp.ShiftDown) Shift(-1);
            inp.ShiftUp = inp.ShiftDown = false;

            // ----- steering: rate-limited rack, speed-sensitive assist, counter-steer, Ackermann -----
            double target = M.Clamp(inp.Steer, -1, 1);
            double sp = M.Clamp(t.SteerSpeed != 0 ? t.SteerSpeed : 1, 0.2, 4);
            // turning in at 3.2/s x steering speed; coming back towards centre (or across) at 9/s x steering speed
            double rate = (Math.Abs(target) > Math.Abs(SteerSm) && M.Sgn(target) == M.Sgn(SteerSm) ? 3.2 : 9) * sp;
            SteerSm += M.Clamp(target - SteerSm, -rate * dt, rate * dt);
            double vAbs = Math.Abs(vFwd);
            // assist: full lock tracks the grip limit (kinematic angle for ~1 g plus peak slip), with a little margin.
            // At low speed both assists stand back while you are steering: fully yours below ~35 km/h, back to full
            // assistance by ~65 km/h. Hands off, they work at any speed.
            double steering = M.Smooth01((Math.Abs(target) - 0.08) / 0.17);
            double assistW = 1 - steering * (1 - M.Smooth01((vAbs * 3.6 - 35) / 30));
            AssistW = assistW;
            var Sf = Surfaces.Of(W[0].Surface);
            double assistLock = M.Clamp(1.15 * ((26 * Sf.Mu) / (vAbs * vAbs + 1) + 0.035 * Sf.Ap), 0.06, 0.58);
            double maxLock = M.Lerp(0.58, assistLock, M.Clamp(t.SteerAssist, 0, 1) * assistW);
            double delta = SteerSm * maxLock;
            // Counter-steer: once the rear axle is sliding, steer the fronts toward where they are actually
            // travelling. It only ever adds opposite lock: if you are already countersteering harder, your input wins.
            double csWant = 0;
            if (t.CounterSteer > 0 && vFwd > 4)
            {
                V3 com = ComModel;
                V3 vr = PointVel(ToWorld(new V3(0, 0, S.Hubs[2].Z - com.Z)));
                V3 vf = PointVel(ToWorld(new V3(0, 0, S.Hubs[0].Z - com.Z)));
                double aRear = Math.Atan2(V3.Dot(vr, rgtB), Math.Max(1, V3.Dot(vr, fwdB)));
                double align = -Math.Atan2(V3.Dot(vf, rgtB), Math.Max(1, V3.Dot(vf, fwdB))) * 0.9; // wheel angle along the front's path (+ = left)
                var Sr = Surfaces.Of(W[2].Surface);
                double cs = M.Clamp(t.CounterSteer, 0, 1), gain = 1 - (1 - cs) * (1 - cs), lo = (0.1 - 0.05 * cs) * Sr.Ap;
                double wgt = M.Smooth01((Math.Abs(aRear) - lo) / (0.1 * Sr.Ap)) * gain * assistW;
                double c = M.Sgn(align);
                if (wgt > 0 && c != 0 && c == -M.Sgn(aRear) && delta * c < align * c) csWant = (align - delta) * wgt;
            }
            Cs = Cs + (csWant - Cs) * (1 - Math.Exp(-dt * 18 * sp));
            delta = M.Clamp(delta + Cs, -0.58, 0.58);
            Tel.CsActive = Math.Abs(Cs) > 0.02;
            double wb = S.Hubs[2].Z - S.Hubs[0].Z, track = S.Hubs[1].X - S.Hubs[0].X;
            foreach (var w in W)
            {
                if (!w.Front) { w.Steer = 0; continue; }
                if (Math.Abs(delta) < 1e-4) { w.Steer = delta; continue; }
                double R = wb / Math.Tan(Math.Abs(delta));
                bool inner = (delta > 0) == w.Left; // turning left: left wheel is inner
                w.Steer = M.Sgn(delta) * Math.Atan(wb / (R + (inner ? -track / 2 : track / 2)));
            }

            // ----- suspension geometry: multi-ray tyre footprint vs ground -----
            foreach (var w in W)
            {
                V3 Mw = pos + q.Rotate(w.MountBody);
                V3 head = q.Rotate(new V3(-Math.Sin(w.Steer), 0, -Math.Cos(w.Steer)));
                double best = double.PositiveInfinity; bool hit = false; V3 bestPt = V3.Zero;
                for (int k = 0; k < UF.Length; k++)
                {
                    double u = UF[k] * w.Rad, c = Math.Sqrt(w.Rad * w.Rad - u * u);
                    V3 o = Mw + head * u;
                    double tHit = T.Raycast(o, down, w.L0 + c + 0.02);
                    if (tHit < 0) continue;
                    double d = tHit - c;
                    if (d < best) { best = d; bestPt = o + down * tHit; hit = true; }
                }
                w.Head = head; w.Mount = Mw;
                V3 nHit = hit && best < w.L0 ? T.NormalAt(bestPt.X, bestPt.Z, bestPt.Y, 0.05) : V3.UnitY;
                // a near-vertical face (a wall, a rock face) is for the body to hit, not for the tyre to stand on
                if (hit && best < w.L0 && V3.Dot(nHit, up) > 0.34)
                {
                    w.Contact = true;
                    w.X = w.L0 - best;
                    w.ContactPt = bestPt;
                    w.Normal = nHit;
                    w.Surface = T.SurfaceAt(bestPt.X, bestPt.Z, bestPt.Y, 0.05);
                }
                else { w.Contact = false; w.X = 0; }
            }

            // ----- drivetrain -----
            // shift sequence: phase 1 = clutch out, phase 2 = clutch closing on the new gear
            var sh = e.Shift;
            int phase = 0; double clutchC = 1;
            if (sh != null)
            {
                sh.T += dt;
                if (sh.T >= sh.Sel && e.Gear != sh.To) e.Gear = sh.To;
                if (sh.T < sh.Sel) { phase = 1; clutchC = 0; }
                else if (sh.T < sh.Total) { phase = 2; clutchC = (sh.T - sh.Sel) / (sh.Total - sh.Sel); }
                else
                {
                    e.Shift = null;
                    if (e.Queued != 0) { int qd = Math.Sign(e.Queued); e.Queued -= qd; if (!Shift(qd)) e.Queued = 0; }
                }
                e.ShiftT = e.Shift != null ? e.Shift.Total - e.Shift.T : 0;
            }
            e.Blip = phase == 1 && sh.Down;
            double ratio = GearRatio(e.Gear);
            double avgOmega = 0; int nDriven = 0;
            foreach (var w in W) if (w.Driven) { avgOmega += w.Omega; nDriven++; }
            avgOmega /= nDriven;
            double wheelRpm = avgOmega * ratio * 60 / (2 * Math.PI);
            bool shifting = phase > 0;
            // the revs the engine would turn at with the driven wheels rolling at road speed (not spinning, not locked)
            double rDriven = 0; foreach (var w in W) if (w.Driven) rDriven += w.Rad;
            rDriven /= nDriven;
            double roadRpm = Math.Abs(vFwd) / rDriven * Math.Abs(ratio) * 60 / (2 * Math.PI);
            e.UpHold = Math.Max(0, e.UpHold - dt);
            e.LimT = e.Rpm > S.Limiter - 400 ? e.LimT + dt : 0;

            // semi-automatic: the driver picks gears, but it drops a gear rather than bog below ~1000 rpm
            if (semi && e.Shift == null && e.Gear > 1 && roadRpm < 1000) StartShift(e.Gear - 1);

            if (auto && e.Gear >= 1 && !shifting && e.Shift == null)
            {
                // Decisions go on road speed, so wheelspin off the line doesn't change up early (and straight back
                // down once the tyres bite). Accelerating (a third of the pedal or more) it holds each gear to the top,
                // or changes up anyway if the wheels sit spinning on the limiter; floored at low revs it kicks down,
                // but not in the first moments after changing up. Gently on the pedal it changes up early so it
                // cruises in a sensible gear. Slowing down it changes down early: braking from ~72 % of the redline,
                // lifting off from 42 % of it.
                bool slowing = brake > 0.2 || (throttle < 0.25 && Tel.GLong < -0.05);
                bool pulling = throttle >= 0.35 && brake <= 0.2;
                double coastDown = 0.42 * S.Redline;
                int ngears = S.Gears.Length;
                double late = ShiftRpm[e.Gear - 1];
                double upR = e.Gear < ngears ? S.Gears[e.Gear] / S.Gears[e.Gear - 1] : 0;
                double dnR = e.Gear > 1 ? S.Gears[e.Gear - 2] / S.Gears[e.Gear - 1] : 0;
                double higher = roadRpm * upR;
                double lower = Math.Max(roadRpm, Math.Abs(wheelRpm)) * dnR; // the higher of the two: never over-rev
                double cruiseUp = S.Redline * (0.5 + 0.47 * M.Clamp(throttle / 0.35, 0, 1));
                bool grip = false;
                foreach (var w in W) if (w.Driven && w.Contact) grip = true;
                bool spinningOnLimiter = e.LimT > 0.35;
                bool changedUp = false;
                if (pulling && e.Gear < ngears && grip && ((e.Rpm > late - 100 && roadRpm > late - 700) || spinningOnLimiter)) changedUp = Shift(1);
                else if (!pulling && e.Gear < ngears && e.Rpm > S.Limiter - 60 && roadRpm > S.Limiter - 700 && grip) changedUp = Shift(1);
                else if (!pulling && !slowing && throttle > 0.02 && e.Gear < ngears && roadRpm > cruiseUp && higher > coastDown + 500 && grip) changedUp = Shift(1);
                else if (e.Gear > 1)
                {
                    bool hold = e.UpHold > 0 && brake <= 0.2 && roadRpm > 1300;
                    if (!hold && throttle > 0.85 && e.Rpm < 0.62 * S.Redline && lower < 0.86 * ShiftRpm[e.Gear - 2]) Shift(-1); // kickdown
                    else if (!hold)
                    {
                        double downAt = brake > 0.2 ? 0.72 * S.Redline : slowing ? coastDown : 2200;
                        if (roadRpm < downAt && lower < S.Redline - 350) Shift(-1);
                    }
                }
                if (changedUp) e.UpHold = 1.6;
            }

            // TCS: cut torque when a driven tyre is past its peak (combined slip) while it is driving
            bool over = false;
            double rs = M.Sgn(ratio != 0 ? ratio : 1);
            foreach (var w in W)
                if (w.Driven && w.Contact && w.SlipRatio * rs > 0.03 && (w.Grip > 1.06 || w.SlipRatio * rs > 1.2 * w.KpOr)) over = true;
            bool tcsActive = t.Tcs && throttle > 0.05 && over && vAbs > 0.5;
            e.TcsCut = tcsActive ? Math.Max(0.15, e.TcsCut - dt * 6) : Math.Min(1, e.TcsCut + dt * 2.5);
            double thr = throttle * (t.Tcs ? e.TcsCut : 1);

            // automatic clutch / torque converter
            double stall = S.IdleRpm + S.Stall * thr;
            bool free = e.Gear == 0 || inp.Handbrake > 0.5;
            double engineRpm;
            bool locked = false, clutchOpen = phase == 1 || free;
            // Clutch slip: when the gearbox side is turning much faster or slower than the engine with the clutch
            // biting (a manual clutch dump into a lower gear), or faster than the engine can physically spin,
            // friction torque spins the engine up and pulls the driven wheels down, hard enough to lock them.
            double mismatch = wheelRpm - e.Rpm;
            bool slipping = !clutchOpen && ((manual && phase == 2 && mismatch > 450) || wheelRpm > S.OverRev);
            double slipT = 0;
            const double TO_RPM = 60 / (2 * Math.PI);
            if (slipping)
            {
                double cap = S.ClutchCap * (phase == 2 ? Math.Max(0.2, clutchC) : 1);
                slipT = M.Sgn(mismatch) * cap; // on the crank; the gearbox gets the reaction
                double fric = -S.EngBrake * (10 + 0.0045 * e.Rpm) - (e.Rpm > S.Limiter ? 0.05 * (e.Rpm - S.Limiter) : 0);
                double drv = !e.LimiterCut ? Cars.TorqueAt(S.Curve, e.Rpm) * thr : 0;
                engineRpm = e.Rpm + ((slipT + fric + drv) / S.EngineInertia) * dt * TO_RPM;
                if (M.Sgn(wheelRpm - engineRpm) != M.Sgn(mismatch)) engineRpm = wheelRpm; // synced this step
                engineRpm = Math.Min(engineRpm, S.OverRev);
            }
            else if (phase == 1)
            {
                // clutch out: blip to the lower gear's revs on a downshift; on an upshift the revs run down on the
                // flywheel's own momentum (never below the new gear's speed) and the clutch brings them the rest of the way
                double tgt = Math.Abs(avgOmega * GearRatio(sh.To) * TO_RPM);
                if (sh.Down) engineRpm = M.Lerp(e.Rpm, M.Clamp(tgt * 1.02, S.IdleRpm, S.Limiter - 50), 1 - Math.Exp(-dt * 16));
                else engineRpm = Math.Max(FreeRev(e, 0, dt), Math.Max(S.IdleRpm, Math.Min(tgt, e.Rpm)));
            }
            else if (free)
            {
                // neutral, or the clutch held out by the handbrake: the engine spins on its own momentum
                engineRpm = FreeRev(e, thr, dt);
            }
            else if (phase == 2)
            {
                // clutch closing: engine and gearbox speeds converge as the clutch bites
                engineRpm = M.Lerp(e.Rpm, Math.Max(Math.Abs(wheelRpm), S.IdleRpm), 1 - Math.Exp(-dt * (6 + 30 * clutchC)));
            }
            else if (Math.Abs(wheelRpm) >= stall - 50)
            {
                engineRpm = Math.Abs(wheelRpm); locked = true;
            }
            else
            {
                engineRpm = M.Lerp(e.Rpm, Math.Max(stall, Math.Abs(wheelRpm)), 1 - Math.Exp(-dt * 10));
            }
            if (engineRpm > S.Limiter) e.LimiterCut = true;
            if (engineRpm < S.Limiter - 350) e.LimiterCut = false;
            e.Rpm = M.Clamp(engineRpm, 600, S.OverRev);
            e.OverRev = e.Rpm > S.Limiter + 150;
            double engT = 0;
            if (slipping)
            {
                engT = -slipT; // clutch friction reaches the gearbox: negative = dragging the wheels
            }
            else if (!clutchOpen)
            {
                if (thr > 0.01 && !e.LimiterCut) engT = Cars.TorqueAt(S.Curve, e.Rpm) * thr;
                // engine braking, much stronger when the wheels force the engine past its limiter
                else if (locked) engT = -S.EngBrake * (10 + 0.0045 * e.Rpm) - (e.Rpm > S.Limiter ? 0.05 * (e.Rpm - S.Limiter) : 0);
                if (!locked && thr > 0.01 && phase == 0)
                {
                    double slip = 1 - Math.Abs(wheelRpm) / Math.Max(stall, 1);
                    engT *= 1 + 0.7 * M.Clamp(slip, 0, 1); // converter torque multiplication
                }
                if (phase == 2) engT *= clutchC;
            }
            e.Load = phase == 1 ? (sh.Down ? 0.7 : 0) : thr;
            e.Clutch = clutchOpen ? 0 : phase == 2 ? clutchC : locked ? 1 : 0.5;
            double axleT = engT * ratio * 0.9;
            double engInertiaShare = locked ? S.EngineInertia * ratio * ratio / nDriven : 0;

            // torque split + viscous LSD per axle, centre coupling for AWD
            Array.Clear(driveT, 0, 4);
            if (t.Drive == Drive.AWD)
            {
                double fAvg = (W[0].Omega + W[1].Omega) / 2, rAvg = (W[2].Omega + W[3].Omega) / 2;
                double cc = 60 * (fAvg - rAvg);
                AxleSplit(axleT * 0.4 - cc, 0, 1);
                AxleSplit(axleT * 0.6 + cc, 2, 3);
            }
            else if (t.Drive == Drive.RWD) AxleSplit(axleT, 2, 3);
            else AxleSplit(axleT, 0, 1);

            // ----- suspension + tyre forces -----
            const double absMinSpeed = 2.5;
            bool absAny = false;
            { double d = W[0].X - W[1].X; arbF[0] = t.ArbF * d; arbF[1] = -t.ArbF * d; }
            { double d = W[2].X - W[3].X; arbF[2] = t.ArbR * d; arbF[3] = -t.ArbR * d; }

            // Geometric (link) load transfer: tyre forces reach the body at roll-centre height through the links, so
            // the springs only react the moment above that height. The rest goes straight onto the tyre loads: more on
            // the outside wheels in a corner, on the fronts under braking, on the rears under power. It nets to zero
            // force and moment on the body. Uses last step's tyre forces.
            double fLong = 0, fLatF = 0, fLatR = 0;
            foreach (var w in W)
                if (w.Contact && w.HasFw)
                {
                    fLong += V3.Dot(w.Fw, fwdB);
                    if (w.Front) fLatF += V3.Dot(w.Fw, rgtB); else fLatR += V3.Dot(w.Fw, rgtB);
                }
            foreach (var w in W)
                w.Geo = (w.Left ? 1 : -1) * (w.Front ? fLatF : fLatR) * t.RollCenter / track // cornering: onto the outside wheels
                      + (w.Front ? -1 : 1) * fLong * t.RollCenter / wb / 2;                // braking: onto the fronts; power: rears

            // slide recovery: full off the throttle and brake, fading out as either goes past about half; never on
            // the handbrake (that is how you start a slide on purpose)
            double recWant = M.Clamp(t.Recovery, 0, 1) * (1 - M.Smooth01((throttle - 0.2) / 0.4)) * (1 - M.Smooth01((brake - 0.25) / 0.4))
                * (inp.Handbrake > 0.1 ? 0 : 1);
            recSm += (recWant - recSm) * (1 - Math.Exp(-dt * 5));
            // auto hold: stopped (or all but) with neither pedal pressed, steering aside, the brakes hold the car
            // where it is; any throttle or brake lets go at once
            double holdK = inp.Throttle < 0.02 && inp.Brake < 0.02 && inp.Handbrake < 0.1 ? 1 - M.Smooth01((speed - 0.25) / 0.5) : 0;

            for (int i = 0; i < 4; i++)
            {
                var w = W[i];
                double kTyre = 0, Fx = 0;
                if (w.Contact)
                {
                    double xdot = (w.X - w.XPrev) / dt;
                    double Fs = w.K * w.X;
                    double bs = w.X - (w.L0 - 0.03);
                    if (bs > 0) Fs += 150000 * bs + 4e6 * bs * bs;
                    double Fd = xdot > 0 ? w.CBump * xdot : w.CReb * xdot;
                    Fd = M.Clamp(Fd, -4 * w.StaticLoad, 6 * w.StaticLoad);
                    double Fz = Fs + Fd + arbF[i];
                    Fz = M.Clamp(Fz, 0, 60000);
                    w.Fz = Fz;                                // through the spring/damper/bar: acts on the body
                    double Fl = M.Clamp(Fz + w.Geo, 0, 60000); // what the tyre is pressed into the ground with
                    w.Load = Fl;

                    V3 n = w.Normal;
                    V3 fw = (w.Head - n * V3.Dot(w.Head, n)).Normalized();
                    V3 side = V3.Cross(fw, n); // points right
                    V3 vc = PointVel(w.ContactPt);
                    double vLong = V3.Dot(vc, fw), vLat = V3.Dot(vc, side);
                    double vRef = Math.Max(Math.Abs(vLong), 3);
                    double slipV = w.Omega * w.Rad - vLong;
                    double kappa = slipV / vRef;
                    double alpha = Math.Atan2(vLat, Math.Max(Math.Abs(vLong), 1));
                    var si = Surfaces.Of(w.Surface);
                    double KP = 0.11 * si.Kp, AP = 0.13 * si.Ap;
                    w.Kp = KP;
                    double sx = kappa / KP, sy = alpha / AP;
                    double rho = M.Hypot(sx, sy);
                    // grip follows load: a tyre pressed harder grips harder, slightly less than in proportion
                    double loadRatio = Fl / w.StaticLoad;
                    double mu = t.Grip * si.Mu * M.Clamp(1 - 0.09 * (loadRatio - 1), 0.75, 1.15);
                    w.Cap = mu * Fl;                          // peak force this tyre can make right now
                    // off the pedals a sliding tyre keeps nearly all of its peak grip, so a slide straightens up
                    double slide = si.Slide < 0.97 ? M.Lerp(si.Slide, 0.97, recSm) : si.Slide;
                    double Ft = w.Cap * Cars.TyreCurve(rho, slide);
                    double Fy = 0;
                    if (rho > 1e-6) { Fx = Ft * sx / rho; Fy = -Ft * sy / rho; }
                    w.SlipRatio = kappa; w.SlipAngle = alpha; w.Grip = rho; w.Fx = Fx; w.Fy = Fy;
                    w.SlipVel = M.Hypot(slipV, vLat);
                    w.Sliding = rho > 1.15 ? M.Clamp((w.SlipVel - 1.5) / 6, 0, 1) : 0;
                    kTyre = mu * Fl * 2 / KP * w.Rad * w.Rad / vRef;

                    double rr = -si.Roll * Fl * Math.Tanh(vLong * 2);
                    V3 pApp = w.ContactPt + up * t.RollCenter;
                    ApplyAt(StrutDir(n, up) * Fz, w.ContactPt);
                    w.Fw = fw * Fx + side * Fy; w.HasFw = true;
                    ApplyAt(w.Fw + fw * rr, pApp);
                    w.VLong = vLong;
                }
                else
                {
                    w.Fz = 0; w.Load = 0; w.Cap = 0; w.HasFw = false; w.Fx = 0; w.Fy = 0; w.Grip = 0; w.SlipVel = 0; w.Sliding = 0; w.SlipRatio = 0; w.SlipAngle = 0;
                }
                w.XPrev = w.X;

                // ----- wheel spin (implicit in the tyre stiffness so it stays stable) -----
                double Ieff = S.WheelInertia + (w.Driven ? engInertiaShare : 0);
                double denom = Ieff + dt * kTyre;
                double om = w.Omega + dt * ((w.Driven ? driveT[i] : 0) - Fx * w.Rad) / denom;
                double bT = brake * S.MaxBrake * (w.Front ? t.BrakeBias : 1 - t.BrakeBias) / 2;
                // ABS: modulates each wheel's pressure to hold its tyre just under the peak, counting the cornering it
                // is doing as well (combined slip), so the car still steers when you stand on the brakes at any
                // speed. Past the peak it lets the pressure go fast; under it, builds it back over a fraction of a second.
                bool absOn = t.Abs && brake > 0.05 && w.Contact && Math.Abs(w.VLong) > absMinSpeed && inp.Handbrake < 0.5;
                if (absOn)
                {
                    bool past = w.SlipRatio < -0.35 * w.KpOr && (w.Grip > 0.98 || w.SlipRatio < -1.05 * w.KpOr);
                    w.AbsP = past ? Math.Max(0.08, w.AbsP - dt * 22) : Math.Min(1, w.AbsP + dt * 8);
                }
                else w.AbsP = Math.Min(1, w.AbsP + dt * 10);
                bT *= w.AbsP;
                w.AbsActive = absOn && w.AbsP < 0.96;
                if (w.AbsActive) absAny = true;
                if (!w.Front) bT += inp.Handbrake * S.Handbrake;
                bT += holdK * S.MaxBrake * 0.08; // auto hold
                double db = dt * bT / denom;
                if (om > db) om -= db; else if (om < -db) om += db; else om = 0;
                w.Omega = M.Clamp(om, -400, 400);
                w.Spin = (w.Spin + w.Omega * dt) % (Math.PI * 2);
                // visual hub position (droops smoothly when airborne)
                double targetD = w.Contact ? M.Clamp(w.L0 - w.X, 0, w.L0) : w.L0;
                w.DVis = w.Contact ? targetD : M.Lerp(w.DVis, targetD, 1 - Math.Exp(-dt * 25));
            }

            // ----- aero -----
            if (speed > 0.1)
            {
                ApplyAt(Vel * (-0.5 * 1.2 * S.CdA * speed), pos);
                // downforce grows with the square of speed; AeroBalance (front share) puts it where the wings are
                double zc = !double.IsNaN(S.AeroBalance) ? S.Hubs[0].Z * S.AeroBalance + S.Hubs[2].Z * (1 - S.AeroBalance) - ComModel.Z : 0;
                ApplyAt(up * (-0.5 * 1.2 * S.ClA * vFwd * vFwd), zc != 0 ? ToWorld(new V3(0, 0, zc)) : pos);
            }

            // ----- body vs solid boxes (pit wall, garages): pushed out through the nearest side -----
            Q4 qInv = q.Conj();
            var solids = T.Solids;
            for (int si2 = 0; si2 < solids.Count; si2++)
            {
                var sb = solids[si2];
                if (pos.X < sb.MinX - 4 || pos.X > sb.MaxX + 4 || pos.Z < sb.MinZ - 4 || pos.Z > sb.MaxZ + 4) continue;
                for (int cu = -1; cu <= 1; cu += 2)
                    for (int cv = -1; cv <= 1; cv += 2)
                        EdgeContact(sb.Cx + sb.AxX * sb.Hx * cu + sb.AzX * sb.Hz * cv, sb.Cz + sb.AxZ * sb.Hx * cu + sb.AzZ * sb.Hz * cv,
                            sb.H - 50, sb.H, pos, q, qInv, 0.15);
                for (int h = 0; h < hullBody.Length; h++)
                {
                    V3 p = pos + q.Rotate(hullBody[h]);
                    if (p.Y > sb.H) continue;
                    double rx = p.X - sb.Cx, rz = p.Z - sb.Cz;
                    double u = rx * sb.AxX + rz * sb.AxZ, v = rx * sb.AzX + rz * sb.AzZ;
                    double pu = sb.Hx - Math.Abs(u), pv = sb.Hz - Math.Abs(v);
                    if (pu <= 0 || pv <= 0) continue;
                    double pt = sb.H - p.Y;
                    V3 n; double pen;
                    if (pt < Math.Min(pu, pv) && pt < 0.25) { n = V3.UnitY; pen = pt; } // resting on top
                    else if (pu < pv) { double sg = u != 0 ? M.Sgn(u) : 1; n = new V3(sb.AxX * sg, 0, sb.AxZ * sg); pen = pu; }
                    else { double sg = v != 0 ? M.Sgn(v) : 1; n = new V3(sb.AzX * sg, 0, sb.AzZ * sg); pen = pv; }
                    AddContact(h, p, n, pen, 0.15, 1, true);
                }
            }

            // ----- body vs wall segments (mesh maps: guardrails, tyre walls, fences, buildings) -----
            // Each wall pushes hull points back to the side the car's centre is on, so a point that got through
            // between two steps is still pushed back out the way it came. A segment counts from 2 cm in from
            // either end: the end of the next block of a wall, or a guardrail post, starts flush with (or just
            // behind) the face the car is sliding along, and the body rides 5 cm off that face, so it slides past
            // the joint instead of catching on the end. A point counts up to 15 cm over the top of a wall (the
            // body is solid between its points: a corner a little higher than a guardrail can't ride over the
            // beam and catch the posts behind it). And a point meets a wall only by coming in through its face,
            // or by staying against the same face: one that finds itself behind the line of a short piece from
            // the side (the face of a post, seen end on) is not inside it.
            if (T.WallSeg != null)
            {
                int nW = T.WallsNear(pos.X, pos.Z, 3.4);
                if (nW > 0)
                {
                    var WS = T.WallSeg; var ids = T.WNear;
                    for (int h = 0; h < hullBody.Length; h++) hp[h] = pos + q.Rotate(hullBody[h]);
                    // the ends of the pieces, as edges against the body
                    edgeN = 0;
                    for (int k = 0; k < nW; k++)
                    {
                        int o = ids[k] * 6;
                        for (int ee = 0; ee <= 2; ee += 2)
                            if (!EdgeSeenBefore(WS[o + ee], WS[o + ee + 1])) EdgeContact(WS[o + ee], WS[o + ee + 1], WS[o + 4], WS[o + 5], pos, q, qInv, 0.15);
                    }
                    for (int k = 0; k < nW; k++)
                    {
                        int o = ids[k] * 6;
                        double ax = WS[o], az = WS[o + 1], ex = WS[o + 2] - ax, ez = WS[o + 3] - az, y0 = WS[o + 4], y1 = WS[o + 5];
                        double L = M.Hypot(ex, ez);
                        if (L < 0.35) continue; // posts and other short pieces count by their corners only (above)
                        double nx = -ez / L, nz = ex / L, side = (pos.X - ax) * nx + (pos.Z - az) * nz >= 0 ? 1 : -1;
                        V3 Nw = new V3(nx * side, 0, nz * side);
                        for (int h = 0; h < hp.Length; h++)
                        {
                            V3 p = hp[h];
                            if (p.Y < y0 - 0.6 || p.Y > y1 + 0.15) continue;
                            double u = ((p.X - ax) * ex + (p.Z - az) * ez) / (L * L);
                            if (u < 0.02 / L || u > 1 - 0.02 / L) continue;
                            double pen = 0.05 - ((p.X - ax) * nx + (p.Z - az) * nz) * side;
                            if (pen <= 0 || pen > 1.2) continue;
                            V3 pv = PointVel(p);
                            double vIn = -(pv.X * nx + pv.Z * nz) * side;     // speed into the wall
                            bool crossed = pen - vIn * dt <= 0;                 // was in front of the face last step
                            V3 ln = lastWallN[h];
                            bool same = ln.X * Nw.X + ln.Z * Nw.Z > 0.85;       // against this face (or the next piece of it)
                            if (!crossed && !same && !(pen <= 0.08 && vIn < 3)) continue;
                            AddContact(h, p, Nw, pen, 0.15, 1, true, true);
                        }
                    }
                }
            }

            // ----- body vs ground (rollovers, bottoming out) -----
            for (int h = 0; h < hullBody.Length; h++)
            {
                V3 p = pos + q.Rotate(hullBody[h]);
                double gh = T.HeightAt(p.X, p.Z, p.Y);
                double pen = gh - p.Y;
                if (pen <= 0) continue;
                V3 n = T.NormalAt(p.X, p.Z, p.Y);
                // pen is measured straight down; the depth across a slope is less (on a steep face, much less).
                // The body scrapes along the ground; a steep face (a rock bank) is slippery like a wall.
                bool steep = n.Y < 0.5;
                AddContact(h, p, n, pen * Math.Max(n.Y, 0.05), steep ? 0.2 : 0.5, steep ? 1 : 0.6, steep);
            }

            // ----- integrate rigid body (semi-implicit Euler), with the body contacts solved on the new velocities -----
            Vel = Vel + fAcc * (dt / Mass);
            Q4 qi = q.Conj();
            V3 wl = qi.Rotate(AngVel);
            V3 tl = qi.Rotate(tAcc);
            V3 Iw = new V3(I.X * wl.X, I.Y * wl.Y, I.Z * wl.Z);
            V3 gyro = V3.Cross(wl, Iw);
            wl = new V3(wl.X + dt * (tl.X - gyro.X) / I.X, wl.Y + dt * (tl.Y - gyro.Y) / I.Y, wl.Z + dt * (tl.Z - gyro.Z) / I.Z);
            AngVel = q.Rotate(wl);
            ContactCount = nC;
            if (nC > 0) SolveContacts(q);
            Pos = Pos + Vel * dt;
            var wq = new Q4(AngVel.X, AngVel.Y, AngVel.Z, 0);
            Q4 dq = Q4.Mul(wq, q);
            Q = new Q4(q.X + 0.5 * dt * dq.X, q.Y + 0.5 * dt * dq.Y, q.Z + 0.5 * dt * dq.Z, q.W + 0.5 * dt * dq.W).Normalized();
            if (nC > 0) Depenetrate();
            Array.Clear(lastWallN, 0, lastWallN.Length);
            for (int i = 0; i < nC; i++) if (cSeg[i]) lastWallN[cH[i]] = cN[i];

            // ----- impacts, for the sound: a new hit, or a much harder one, after a short quiet spell. The body
            // landing on the ground only counts once it comes down hard (scraping over a crest doesn't). -----
            impactCool -= dt;
            double hitNow = Math.Max(HitWall, HitGround - 2.0);
            if (hitNow > 1.0 && (impactCool <= 0 || hitNow > impactLast * 1.8))
            {
                Impact = Math.Max(Impact, hitNow); impactLast = hitNow; impactCool = 0.22; ImpactCount++;
            }
            if (impactCool <= 0) impactLast = 0;

            // ----- telemetry -----
            var tel = Tel;
            V3 acc = (Vel - PrevVel) * (1 / dt);
            PrevVel = Vel;
            V3 rgt = Q.Rotate(V3.UnitX);
            double a = 1 - Math.Exp(-dt * 8);
            tel.GLat = M.Lerp(tel.GLat, V3.Dot(acc, rgt) / G, a);
            tel.GLong = M.Lerp(tel.GLong, V3.Dot(acc, fwdB) / G, a);
            double xl = (W[0].X + W[2].X) / 2, xr = (W[1].X + W[3].X) / 2;
            double xf = (W[0].X + W[1].X) / 2, xrr = (W[2].X + W[3].X) / 2;
            bool allDown = W[0].Contact && W[1].Contact && W[2].Contact && W[3].Contact;
            // suspension roll/pitch: body attitude relative to the tyre contact plane
            tel.Roll = allDown ? Math.Atan2(xr - xl, track) : Math.Asin(M.Clamp(-rgt.Y, -1, 1));
            tel.Pitch = allDown ? Math.Atan2(xrr - xf, wb) : Math.Asin(M.Clamp(fwdB.Y, -1, 1));
            tel.Speed = vFwd;
            // where the weight sits: share on the front axle, and the load centre over the wheelbase/track
            double lt = 0, lf = 0, lx = 0, lz = 0;
            foreach (var w in W) { double l = w.Load; lt += l; if (w.Front) lf += l; lx += l * w.HubModel.X; lz += l * w.HubModel.Z; }
            if (lt > 1) { tel.HasLoad = true; tel.FrontLoad = lf / lt; tel.LoadCx = lx / lt; tel.LoadCz = lz / lt; }
            else tel.HasLoad = false;
            tel.AbsActive = absAny;
            tel.TcsActive = tcsActive;
            tel.WheelRpm = wheelRpm;

            if (!double.IsFinite(Pos.X + Pos.Y + Pos.Z + Q.W))
            {
                if (T.HasSpawn) Reset(T.SpawnPos, T.SpawnYaw); else Reset(V3.Zero, 0);
            }
        }

        void AxleSplit(double part, int a, int b)
        {
            double lsd = Spec.Lsd * (Wheels[a].Omega - Wheels[b].Omega);
            driveT[a] = part / 2 - lsd; driveT[b] = part / 2 + lsd;
        }
    }
}
