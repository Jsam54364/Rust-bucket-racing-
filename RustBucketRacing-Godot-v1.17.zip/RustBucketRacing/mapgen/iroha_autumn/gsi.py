"""GSI Japan's map tiles (地理院タイル, 出典：国土地理院), fetched once and cached: road centrelines (experimental_rdcl,
z16 GeoJSON), elevation (dem5a_png laser / dem5b_png photogrammetry 5 m, z15; dem10b_png 10 m, z14 and coarser) and
aerial photos (seamlessphoto, JPEG). Cache: $HARUNA_GSI (default ./gsi next to this file)."""
import glob, io, json, math, os, time, urllib.request, urllib.error
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.environ.get('IROHA_GSI', os.path.join(HERE, 'gsi'))
BASE = 'https://cyberjapandata.gsi.go.jp/xyz/'


def tile_xy(lat, lon, z):
    """fractional tile coordinates (Web Mercator); lat, lon may be arrays"""
    n = 2.0 ** z
    lat = np.asarray(lat, np.float64); lon = np.asarray(lon, np.float64)
    r = np.radians(lat)
    return (lon + 180) / 360 * n, (1 - np.log(np.tan(r) + 1 / np.cos(r)) / np.pi) / 2 * n


def tile_ll(x, y, z):
    n = 2.0 ** z
    return np.degrees(np.arctan(np.sinh(np.pi * (1 - 2 * np.asarray(y, np.float64) / n)))), np.asarray(x, np.float64) / n * 360 - 180


def fetch(layer, z, x, y, ext):
    p = os.path.join(CACHE, layer, str(z), f'{x}_{y}.{ext}')
    if os.path.exists(p): return p
    os.makedirs(os.path.dirname(p), exist_ok=True)
    try:
        with urllib.request.urlopen(f'{BASE}{layer}/{z}/{x}/{y}.{ext}', timeout=30) as r: b = r.read()
    except urllib.error.HTTPError as e:
        if e.code != 404: raise
        b = b''                                     # no tile there (an empty file remembers it)
    open(p, 'wb').write(b); time.sleep(0.03)
    return p


def tiles(layer, z, ext, lat0, lon0, lat1, lon1):
    fx0, fy1 = tile_xy(lat0, lon0, z); fx1, fy0 = tile_xy(lat1, lon1, z)
    x0, y0, x1, y1 = int(fx0), int(fy0), int(fx1), int(fy1)
    for ty in range(y0, y1 + 1):
        for tx in range(x0, x1 + 1): fetch(layer, z, tx, ty, ext)
    return x0, y0, x1, y1


def dem_decode(b):
    if not b: return np.full((256, 256), np.nan, np.float32)
    a = np.asarray(Image.open(io.BytesIO(b)).convert('RGB')).astype(np.int64)
    v = (a[..., 0] << 16) + (a[..., 1] << 8) + a[..., 2]
    na = (a[..., 0] == 128) & (a[..., 1] == 0) & (a[..., 2] == 0)
    v = np.where(v >= 2 ** 23, v - 2 ** 24, v).astype(np.float32) * 0.01
    v[na] = np.nan
    return v


def photo_decode(b):
    if not b: return np.zeros((256, 256, 3), np.uint8)
    return np.asarray(Image.open(io.BytesIO(b)).convert('RGB'))


class Mosaic:
    """the tiles of one layer over a box as one array, with pixel <-> lat/lon (pixel centres at +0.5)"""
    def __init__(self, layer, z, ext, lat0, lon0, lat1, lon1):
        self.z = z
        self.x0, self.y0, x1, y1 = tiles(layer, z, ext, lat0, lon0, lat1, lon1)
        dec = dem_decode if ext == 'png' else photo_decode
        rows = []
        for ty in range(self.y0, y1 + 1):
            row = []
            for tx in range(self.x0, x1 + 1):
                p = os.path.join(CACHE, layer, str(z), f'{tx}_{ty}.{ext}')
                row.append(dec(open(p, 'rb').read()))
            rows.append(np.concatenate(row, 1))
        self.a = np.concatenate(rows, 0)

    def px(self, lat, lon):
        x, y = tile_xy(lat, lon, self.z)
        return (x - self.x0) * 256, (y - self.y0) * 256

    def ll(self, px, py):
        return tile_ll(np.asarray(px) / 256 + self.x0, np.asarray(py) / 256 + self.y0, self.z)


def roads(lat0, lon0, lat1, lon1):
    """road centrelines (properties, [[lon, lat], ...]) touching a box"""
    tiles('experimental_rdcl', 16, 'geojson', lat0, lon0, lat1, lon1)
    out = []
    for p in glob.glob(os.path.join(CACHE, 'experimental_rdcl', '16', '*.geojson')):
        s = open(p, 'rb').read()
        if not s: continue
        for f in json.loads(s)['features']:
            if f['geometry']['type'] != 'LineString': continue
            c = f['geometry']['coordinates']
            if all(not (lat0 <= q[1] <= lat1 and lon0 <= q[0] <= lon1) for q in c): continue
            out.append((f['properties'], c))
    return out


def buildings(lat0, lon0, lat1, lon1):
    """building outlines (基盤地図情報, experimental_fgd z18: BldL) over a box: the tiles cut each outline into pieces,
    so the pieces are joined end to end again; [(type, [[lon, lat], ...] closed ring), ...]"""
    x0, y0, x1, y1 = tiles('experimental_fgd', 18, 'geojson', lat0, lon0, lat1, lon1)
    lines = []
    for ty in range(y0, y1 + 1):
        for tx in range(x0, x1 + 1):
            s = open(os.path.join(CACHE, 'experimental_fgd', '18', f'{tx}_{ty}.geojson'), 'rb').read()
            if not s: continue
            for f in json.loads(s)['features']:
                if f['properties'].get('class') != 'BldL' or f['geometry']['type'] != 'LineString': continue
                lines.append((f['properties'].get('type', ''), [tuple(q) for q in f['geometry']['coordinates']]))
    key = lambda q: (round(q[0], 7), round(q[1], 7))
    out, open_ = [], []
    for t, c in lines:
        if key(c[0]) == key(c[-1]) and len(c) >= 4: out.append((t, c))
        else: open_.append([t, c])
    # join the open pieces: by their ends
    ends = {}
    for i, (t, c) in enumerate(open_):
        ends.setdefault(key(c[0]), []).append(i); ends.setdefault(key(c[-1]), []).append(i)
    used = [False] * len(open_)
    for i in range(len(open_)):
        if used[i]: continue
        used[i] = True
        t, ring = open_[i][0], list(open_[i][1])
        for _ in range(64):
            if key(ring[0]) == key(ring[-1]): break
            nxt = [j for j in ends.get(key(ring[-1]), []) if not used[j]]
            if not nxt: break
            j = nxt[0]; used[j] = True
            c = open_[j][1]
            ring += c[1:] if key(c[0]) == key(ring[-1]) else c[::-1][1:]
        if key(ring[0]) == key(ring[-1]) and len(ring) >= 4: out.append((t, ring))
    return out
