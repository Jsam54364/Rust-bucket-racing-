"""Land cover maps for the shaders, on the local plane (x east, z south): what GSI's aerial photo (出典：国土地理院)
shows at each spot, as one image per area:

  R  conifers (the photo's dark green)        G  bare ground (scree, rock, roads, buildings)
  B  water (Lake Chuzenji)                    A  the photo's brightness (a little variation for the canopy)

  tex/cover_near.png   the road's box plus 700 m, 2 m a pixel (photos at zoom 17)
  tex/cover_far.png    12 km square round the middle, 8 m a pixel (zoom 14)
  tex/cover.json       where each lies
"""
import json, os, sys
import numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates, gaussian_filter
import source as S
import gsi
from geo import forest_classes

OUT = os.path.join(S.HERE, 'tex')


def cover(name, x0, z0, x1, z1, res, zoom):
    lat_a, lon_a = S.to_ll(x0, z1); lat_b, lon_b = S.to_ll(x1, z0)
    M = gsi.Mosaic('seamlessphoto', zoom, 'jpg', float(min(lat_a, lat_b)) - 0.001, float(min(lon_a, lon_b)) - 0.001,
                   float(max(lat_a, lat_b)) + 0.001, float(max(lon_a, lon_b)) + 0.001)
    cls = forest_classes(M)
    nx, nz = int(round((x1 - x0) / res)), int(round((z1 - z0) / res))
    X, Z = np.meshgrid(x0 + (np.arange(nx) + 0.5) * res, z0 + (np.arange(nz) + 0.5) * res)
    lat, lon = S.to_ll(X, Z); px, py = M.px(lat, lon)
    out = np.zeros((nz, nx, 4), np.float32)
    for ch, k in enumerate((1, 2, 3)):
        m = (cls == k).astype(np.float32)
        out[..., ch] = map_coordinates(m, [py - 0.5, px - 0.5], order=1)
    L = M.a.astype(np.float32).mean(-1) / 255
    out[..., 3] = map_coordinates(L, [py - 0.5, px - 0.5], order=1)
    # water only where the ground model is the lake's flat surface (shaded slopes look blue in the photos too)
    h = S.ground(X, Z)
    gz_, gx_ = np.gradient(h, res)
    lake = (np.abs(h - 1269.5) < 2.0) & (np.hypot(gx_, gz_) < 0.03)
    out[..., 2] = lake.astype(np.float32)
    out[..., 0] *= 1 - out[..., 2]; out[..., 1] *= 1 - out[..., 2]
    for ch in range(3): out[..., ch] = gaussian_filter(out[..., ch], 0.6)
    # (image rows run north to south = z growing, so the picture's top is z0: v = 1 - (z - z0) / (z1 - z0) in Blender)
    Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), 'RGBA').save(os.path.join(OUT, f'cover_{name}.png'))
    print(f'cover_{name}: {nx}x{nz} at {res} m; conifer {out[..., 0].mean():.2f}, bare {out[..., 1].mean():.2f}, water {out[..., 2].mean():.2f}')
    return dict(x0=x0, z0=z0, x1=x1, z1=z1)


if __name__ == '__main__':
    lo = S.line.min(0) - 700; hi = S.line.max(0) + 700
    lo = np.floor(lo / 100) * 100; hi = np.ceil(hi / 100) * 100
    box = {'near': cover('near', float(lo[0]), float(lo[1]), float(hi[0]), float(hi[1]), 2.0, 17),
           'far': cover('far', -6000.0, -6000.0, 6000.0, 6000.0, 8.0, 14)}
    json.dump(box, open(os.path.join(OUT, 'cover.json'), 'w'), indent=1)
