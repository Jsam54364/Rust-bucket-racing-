"""Textures and materials for Irohazaka Autumn: all drawn for this map (tex.py: asphalt, kikko masonry, concrete,
the autumn forest floor, a straw verge, rock, the bend signs, chevrons, the speed limit; here: the guardrail, the
reflectors, the ground seen from afar in its autumn colours from the land cover maps, cover.py). Nothing from
other games or mods."""
import io, os, json
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import map_coordinates, gaussian_filter

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, 'tex')


def load(name, rgba=False):
    im = Image.open(os.path.join(TEX, name + '.png')); im.load()
    return im.convert('RGBA' if rgba else 'RGB')


def tinted(name, gain=1.0, tint=(1, 1, 1)):
    a = np.asarray(load(name), np.float32) * gain * np.array(tint, np.float32)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def tex_guardrail():
    """a Japanese guardrail seen from the road: a white W-beam on white posts, 4 m to the picture (two posts),
    1 m tall (v 0 at the top), clear round it; an orange reflector on every other post"""
    W, H = 512, 128
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    px = lambda m: int(round(m / 4.0 * W))
    py = lambda m: int(round((1.0 - m) * H))
    for x0 in (0.15, 2.15):
        d.rectangle([px(x0), py(0.9), px(x0 + 0.14), py(0.0)], fill=(226, 228, 226, 255))
        d.rectangle([px(x0 + 0.1), py(0.9), px(x0 + 0.14), py(0.0)], fill=(186, 188, 186, 255))
    for y0, y1, c in ((0.60, 0.65, 200), (0.65, 0.72, 242), (0.72, 0.76, 205), (0.76, 0.80, 225), (0.80, 0.87, 246), (0.87, 0.92, 205)):
        d.rectangle([0, py(y1), W - 1, py(y0)], fill=(c, c, c - 3, 255))
    for x0 in (0.15, 2.15):
        for yb in (0.68, 0.84):
            d.ellipse([px(x0) - 2, py(yb) - 2, px(x0) + 6, py(yb) + 6], fill=(150, 150, 150, 255))
    d.ellipse([px(0.10), py(0.99), px(0.29), py(0.90)], fill=(236, 112, 24, 255))
    a = np.asarray(im, np.float32)
    a[..., :3] *= 0.92 + 0.08 * np.random.default_rng(2).random((H, W, 1))
    return Image.fromarray(a.clip(0, 255).astype(np.uint8), 'RGBA')


# ---------------------------------------------------------------- the ground seen from afar
LAYER, MARGIN = 512, 16
COVER = json.load(open(os.path.join(TEX, 'cover.json')))
_cov = {}


def cover_at(x, z):
    """(conifer, bare, water, photo brightness) at map points, from the near map inside its box, else the far one"""
    out = np.zeros(x.shape + (4,), np.float32)
    out[..., 3] = 0.4
    done = np.zeros(x.shape, bool)
    for key in ('near', 'far'):
        if key not in _cov: _cov[key] = np.asarray(Image.open(os.path.join(TEX, f'cover_{key}.png'))).astype(np.float32) / 255
        a = _cov[key]; b = COVER[key]
        res = (b['x1'] - b['x0']) / a.shape[1]
        cx = (x - b['x0']) / res - 0.5; cz = (z - b['z0']) / res - 0.5
        ins = (~done) & (cx >= 0) & (cz >= 0) & (cx <= a.shape[1] - 1) & (cz <= a.shape[0] - 1)
        for ch in range(4):
            out[..., ch][ins] = map_coordinates(a[..., ch], [cz[ins], cx[ins]], order=1)
        done |= ins
    out[..., 0][~done] = 0.25
    return out


# autumn crowns (sRGB): crimson, scarlet, orange, ochre, yellow, the last greens
AUTUMN = np.array([(96, 44, 32), (118, 58, 34), (128, 82, 42), (122, 100, 52), (112, 106, 58), (82, 88, 48)], np.float32)


def autumn_ground(X, Z, res):
    """the colour of the land from afar: crowns in autumn colours (cells of ~8 m, a few colours to a hillside),
    the conifers dark, scree and rock grey, the lake dark; X, Z a grid of map points res metres apart"""
    c = cover_at(X, Z)
    r = np.random.default_rng(int(abs(X[0, 0]) + abs(Z[0, 0])) % 2 ** 31)
    n = X.shape[0]
    # (crowns: noise at a few metres, patches at ~60 m, hillsides at ~400 m; finer than a texel is left out)
    def noise(scale_m):
        s = max(scale_m / res, 0.6)
        g = gaussian_filter(r.normal(size=X.shape), s, mode='wrap')
        return (g - g.mean()) / (g.std() + 1e-9)
    pick = np.clip(0.5 + 0.16 * noise(60) + 0.08 * noise(400) + 0.12 * noise(8), 0, 0.999)
    k = pick * (len(AUTUMN) - 1); i0 = np.floor(k).astype(int); f = (k - i0)[..., None]
    broad = AUTUMN[i0] * (1 - f) + AUTUMN[np.minimum(i0 + 1, len(AUTUMN) - 1)] * f
    crown = np.clip(1 + 0.18 * noise(5), 0.6, 1.4)[..., None]
    conif = np.array([40, 56, 36], np.float32)[None, None] * np.clip(1 + 0.15 * noise(6), 0.7, 1.3)[..., None]
    bare = np.array([128, 122, 110], np.float32)[None, None] * np.clip(0.9 + 0.5 * (c[..., 3:4] - 0.45), 0.7, 1.2)
    water = np.array([24, 38, 46], np.float32)[None, None]
    col = broad * crown
    col = col * (1 - c[..., 0:1]) + conif * c[..., 0:1]
    col = col * (1 - c[..., 1:2]) + bare * c[..., 1:2]
    col = col * (1 - c[..., 2:3]) + water * c[..., 2:3]
    return np.clip(col, 0, 255).astype(np.uint8)


class Drape:
    """the autumn ground over a square of the map's plane, in layers of LAYER px at `res` metres a pixel"""
    def __init__(self, name, x0, z0, nx, nz, res):
        self.name, self.x0, self.z0, self.nx, self.nz, self.res = name, x0, z0, nx, nz, res
        self.span = (LAYER - 2 * MARGIN) * res

    def key(self, i, j): return f'{self.name}_{i}_{j}'
    def keys(self): return [self.key(i, j) for j in range(self.nz) for i in range(self.nx)]

    def cell(self, x, z):
        i = np.clip(np.floor((np.asarray(x) - self.x0) / self.span).astype(int), 0, self.nx - 1)
        j = np.clip(np.floor((np.asarray(z) - self.z0) / self.span).astype(int), 0, self.nz - 1)
        return i, j

    def uv(self, i, j, x, z):
        ox = self.x0 + i * self.span - MARGIN * self.res; oz = self.z0 + j * self.span - MARGIN * self.res
        return np.c_[(np.asarray(x) - ox) / (LAYER * self.res), (np.asarray(z) - oz) / (LAYER * self.res)]

    def image(self, i, j):
        ox = self.x0 + i * self.span - MARGIN * self.res; oz = self.z0 + j * self.span - MARGIN * self.res
        c = (np.arange(LAYER) + 0.5) * self.res
        X, Z = np.meshgrid(ox + c, oz + c)
        return Image.fromarray(autumn_ground(X, Z, self.res))


TEXTURES = {
    'asphalt': lambda: tinted('asphalt', 0.92), 'kikko': lambda: load('kikko'), 'concrete': lambda: load('concrete'),
    'gutter': lambda: tinted('concrete', 0.8),
    'litter': lambda: tinted('litter', 0.9), 'grass': lambda: load('grass'), 'rock': lambda: tinted('rock', 0.85),
    'guardrail': tex_guardrail, 'chevron': lambda: load('chevron'), 'limit40': lambda: load('limit40', True),
}
for _n in range(21, 49): TEXTURES[f'sign_{_n}'] = (lambda n: lambda: load(f'sign_{n}'))(_n)


def bleed(img):
    a = np.array(img, dtype=np.float32)
    rgb, al = a[:, :, :3], a[:, :, 3]
    known = al > 8
    if known.all() or not known.any(): return img
    out = np.where(known[:, :, None], rgb, 0); filled = known.copy()
    for _ in range(64):
        if filled.all(): break
        s = sum(np.roll(np.roll(out * filled[:, :, None], dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        w = sum(np.roll(np.roll(filled.astype(np.float32), dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        new = (~filled) & (w > 0)
        out[new] = s[new] / w[new][:, None]; filled |= new
    out[~filled] = rgb[known].mean(0)
    return Image.fromarray(np.dstack([out, al]).clip(0, 255).astype(np.uint8), 'RGBA')


def webp(img, q=82):
    has_a = img.mode == 'RGBA' and (np.asarray(img)[..., 3] < 250).any()
    img = img.convert('RGBA' if has_a else 'RGB')
    if has_a: img = bleed(img)
    w, h = img.size
    sc = min(1.0, 512 / max(w, h))
    if sc < 1: img = img.resize((max(4, int(w * sc)), max(4, int(h * sc))), Image.LANCZOS)
    bio = io.BytesIO(); img.save(bio, 'WEBP', quality=q, method=6)
    return bio.getvalue()


def M(tex, cat, surf=0, mode=0, fade=0, shadow=False, layer=0, spec=0.1, color=(1, 1, 1, 1), fog=True):
    d = dict(tex=tex, cat=cat, surf=surf, mode=mode, fade=fade, shadow=shadow, layer=layer, spec=spec, color=list(color))
    if not fog: d['fog'] = False
    return d


# material key -> settings (surf: 1 tarmac, 2 kerb, 3 gravel, 4 grass, 0 none)
MATERIALS = {
    'road':       M('asphalt', 'ground', 1, spec=0.25),
    'gutter':     M('gutter', 'ground', 1, spec=0.12),
    'paint':      M(None, 'ground', 1, layer=1, spec=0.2, color=(0.86, 0.86, 0.84, 1)),
    'verge':      M('grass', 'ground', 4, spec=0.03),
    'fill':       M('grass', 'ground', 4, spec=0.03),
    'forest':     M('litter', 'ground', 4, spec=0.03),
    'cut':        M('rock', 'wall', shadow=True, spec=0.05),
    'wall':       M('kikko', 'wall', shadow=True, spec=0.08),
    'concrete':   M('concrete', 'wall', shadow=True, spec=0.1),
    'guardrail':  M('guardrail', 'small', mode=1, fade=900, shadow=True, spec=0.45),
    'post':       M(None, 'small', fade=300, spec=0.3, color=(0.6, 0.61, 0.63, 1)),
    'rail_brown': M(None, 'small', fade=500, spec=0.3, color=(0.16, 0.11, 0.08, 1)),
    'sign_back':  M(None, 'small', fade=450, spec=0.2, color=(0.55, 0.56, 0.57, 1)),
    'chevron':    M('chevron', 'small', fade=500, spec=0.2),
    'limit40':    M('limit40', 'small', mode=1, fade=450, spec=0.2),
}
for _n in range(21, 49): MATERIALS[f'sign_{_n}'] = M(f'sign_{_n}', 'small', fade=500, spec=0.2)


def add_drape(d, cat):
    for k in d.keys():
        TEXTURES[k] = (lambda d, k: lambda: d.image(*map(int, k.rsplit('_', 2)[1:])))(d, k)
        MATERIALS[k] = M(k, cat, 4 if d.name == 'near' else 0, spec=0.02)


def build_tables(used):
    tex_keys, mats, mat_index = [], [], {}
    for k in sorted(used, key=lambda k: list(MATERIALS).index(k)):
        m = dict(MATERIALS[k]); t = m.pop('tex')
        if t is not None:
            if t not in tex_keys: tex_keys.append(t)
            m['tex'] = tex_keys.index(t)
        m['name'] = k
        mat_index[k] = len(mats); mats.append(m)
    images = [webp(TEXTURES[t](), q=78 if t.startswith(('near_', 'mid_', 'far_')) else 82) for t in tex_keys]
    return mats, mat_index, images
