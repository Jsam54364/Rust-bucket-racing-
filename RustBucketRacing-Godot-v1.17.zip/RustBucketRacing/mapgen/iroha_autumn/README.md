# The Irohazaka Autumn generator

Builds `iroha_autumn.bin`, an installable map. Its description is `maps/iroha_autumn.json`, which ships next to the pack in the map zip.

The map is the First Irohazaka (第一いろは坂), National Route 120's one-way descent from Lake Chuzenji to Umagaeshi at Nikko:
- 7.1 km of road, with the stage lines 45 m in from each end
- 458 m lower at the bottom line than at the top line
- 28 hairpins, from な (21) to ん (48)
- the mid-October colours

It is rebuilt from GSI Japan's open map data (出典：国土地理院). Everything is drawn here or comes from the LOLIPOP foliage packs (CC BY 4.0). Nothing comes from other games or mods.

This folder is not part of the game build: `mapgen/.gdignore` keeps Godot out of it.

The geometry is the same as the Blender build's (`iroha_blender`: its scenes, lightmaps and renders). Here it goes into the game's pack instead, and the game's own baker lights it.

## Requirements

- Python 3 with numpy, scipy, matplotlib and Pillow (webp).
- Godot 4.7 for the LODs: set `GODOT` to its binary.
- Internet access to cyberjapandata.gsi.go.jp the first time. The tiles are cached in `gsi/`.
- LOLIPOP's foliage packs. Set `FOLIAGE` to the folder that holds them, as for Mt. Haruna.

## Steps

    python3 tex.py hairpins.json && python3 cover.py && python3 geo.py      # textures, land cover, geo.npz (~30 s)
    GODOT=/path/to/godot python3 gen.py iroha_autumn.bin                    # the pack (~5 min)
    python3 ../haruna/check_phys.py iroha_autumn.bin                        # holes and steps in the drive surface
    python3 -I ../bake/bake_light.py iroha_autumn.bin --sky qwantani_afternoon_puresky

## Files

- `source.py`, `gsi.py`: the road's line and heights, the bridges, and the elevation grids, all from GSI tiles.
- `geo.py`: the road (crowned and banked, widened in the hairpins), its paint and the ground. It also works out:
  - the retaining walls where the hill rises
  - the gutters, bridges and snow shed
  - where the guardrails go
  - the 28 hairpins
  - the trees, placed where the aerial photo shows forest
- `tex.py`: the textures:
  - asphalt, kikko masonry, concrete, autumn leaf litter, straw verge and rock
  - the bend signs, in our own design: the kana and "n/48"
  - the chevrons and the 40 km/h sign
- `cover.py`: the land cover (conifers, bare ground, the lake), read from the aerial photo.
- `assets.py`: materials, and the land seen from afar in autumn colours, drawn from the land cover.
- `foliage_autumn.py`: Mt. Haruna's foliage module with autumn leaves. Each broadleaf impostor comes in a few colours; the firs are dark green, the bushes red, the grass straw.
- `gen.py`: the pack:
  - the surfaces and the far ground
  - guardrails and collisions
  - signs and the snow shed
  - the forest as impostors
  - grass, bushes and young trees by the road
  - the line, running up the hill: the bottom line is the stage's start
