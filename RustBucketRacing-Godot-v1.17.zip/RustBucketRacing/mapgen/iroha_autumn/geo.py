"""The First Irohazaka's geometry, worked out in numpy for the Blender build (build.py):

  * the road: stations along the centreline (1 m in the bends, 2 m between), a 7.2 m carriageway widened round the
    hairpins, crowned and banked; its paint (white edge lines, the lane line dashed, solid through the bends)
  * the ground: one triangulation, dense rows beside the road and retaining walls where the hillside rises at the
    road's edge (a battered face from a concrete gutter to a bench on top), then coarser out to REACH and beyond it
    to 12 km; never over the road; bridges left standing over their gullies
  * guardrails where the ground drops away; the 28 hairpins (な to ん, the Iroha poem's last 28 letters: the descent
    finishes the poem the ascent began); trees where the aerial photos show forest

Writes geo.npz. Same frame as source.py: x east, z south, y up; build.py turns it to Blender's (x, -z, y)."""
import sys, os, time
import numpy as np
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d, median_filter
from scipy.spatial import cKDTree, Delaunay
from PIL import Image, ImageDraw
import source as S
import gsi

log = S.log
rng = np.random.default_rng(120)
HALF = 3.6                          # half the carriageway: two 3.25 m lanes and their edge strips
FAR_R = 12000.0


# ---------------------------------------------------------------- the road
def stations():
    P = S.line; s0 = S.sl
    t, _ = S.normals(P)
    ang = np.unwrap(np.arctan2(t[:, 1], t[:, 0]))
    kap = np.abs(np.gradient(gaussian_filter1d(ang, 2), s0))
    s, out = 0.0, [0.0]
    while s < s0[-1] - 0.5:
        s += 1.0 if np.interp(s, s0, kap) > 1 / 45 else 2.0
        out.append(min(s, s0[-1]))
    s = np.array(out)
    Q = np.c_[np.interp(s, s0, P[:, 0]), np.interp(s, s0, P[:, 1])]
    return s, Q, np.interp(s, s0, S.ly)


ST_S, ST_P, ST_Y = stations()
ST_T, ST_N = S.normals(ST_P)
NS = len(ST_P)
_ang = np.unwrap(np.arctan2(ST_T[:, 1], ST_T[:, 0]))
ST_K = np.gradient(gaussian_filter1d(_ang, 3), ST_S)          # curvature, + turning towards +normal
ST_R = 1 / np.maximum(np.abs(ST_K), 1e-4)
_near = np.clip(np.searchsorted(S.sl, ST_S), 0, len(S.sl) - 1)
BRIDGE = ndimage.binary_dilation(S.BRIDGE[_near], iterations=2)
SHED = S.STATE_AT[_near] == '雪覆い'
log(f'road: {NS} stations over {ST_S[-1]:.0f} m; {int((ST_R < 25).sum())} in bends under 25 m; {int(BRIDGE.sum())} on bridges')


def road_edges():
    widen = np.clip(30.0 / ST_R - 0.35, 0, 2.8)
    widen = gaussian_filter1d(ndimage.maximum_filter1d(widen, 9), 4, mode='nearest')
    hi = HALF + widen * (ST_K > 0); lo = -HALF - widen * (ST_K < 0)
    hi = gaussian_filter1d(hi, 3, mode='nearest'); lo = gaussian_filter1d(lo, 3, mode='nearest')
    inner_hi = ST_K > 0
    lim = 0.92 * ST_R
    for it in range(3):
        hi = np.where(inner_hi, np.minimum(hi, lim), hi); lo = np.where(~inner_hi, np.maximum(lo, -lim), lo)
        if it < 2: hi = gaussian_filter1d(hi, 3, mode='nearest'); lo = gaussian_filter1d(lo, 3, mode='nearest')
    hi = np.maximum(hi, 2.8); lo = np.minimum(lo, -2.8)
    for side, E in ((1, hi), (-1, lo)):
        for it in range(60):
            e = ST_P + ST_N * E[:, None]
            fwd = np.einsum('ij,ij->i', np.diff(e, axis=0), (ST_T[:-1] + ST_T[1:]) / 2)
            bad = np.nonzero(fwd < 0.25 * np.diff(ST_S))[0]
            if not len(bad): break
            for b in bad:
                for j in (b, b + 1):
                    if abs(E[j]) > 2.0: E[j] -= side * 0.15
            E[:] = np.where(side > 0, np.maximum(gaussian_filter1d(E, 1.0, mode='nearest'), 2.0), np.minimum(gaussian_filter1d(E, 1.0, mode='nearest'), -2.0))
    log(f'road width: median {np.median(hi - lo):.2f} m, {np.percentile(hi - lo, 5):.1f}-{np.max(hi - lo):.1f} m')
    return lo, hi


ED_LO, ED_HI = road_edges()
FRAC = np.array([-1.0, -2 / 3, -1 / 3, 0.0, 1 / 3, 2 / 3, 1.0])


def offsets_of(idx=slice(None)):
    return np.where(FRAC[None, :] < 0, -FRAC[None, :] * ED_LO[idx, None], FRAC[None, :] * ED_HI[idx, None])


def grid_tris(nu, nv):
    a = np.arange(nu - 1)[:, None] * nv + np.arange(nv - 1)[None, :]
    a = a.ravel()
    return np.concatenate([np.c_[a, a + nv, a + nv + 1], np.c_[a, a + nv + 1, a + 1]])


def up_tris(P, I):
    up = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])[:, 1]
    return np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)


MESH = {}          # name -> list of (P, UV, I)


def add(name, P, UV, I):
    MESH.setdefault(name, []).append((np.asarray(P, np.float64), np.asarray(UV, np.float64), np.asarray(I, np.int64)))


def road_mesh():
    """the surface: a 2 % crown, one slope across in the bends (up to 6 %, the inside low); UV in metres (u across
    from the left edge, v along)"""
    off = offsets_of()
    bank = np.clip(2.6 / ST_R, 0, 0.06)
    b = np.clip((bank - 0.015) / 0.015, 0, 1)
    crown = -0.02 * np.abs(off)
    banked = -bank[:, None] * np.sign(ST_K)[:, None] * off
    dy = (1 - b[:, None]) * crown + b[:, None] * banked
    dy = gaussian_filter1d(dy, 6, axis=0, mode='nearest')
    xz = ST_P[:, None, :] + ST_N[:, None, :] * off[..., None]
    P = np.dstack([xz[..., 0], ST_Y[:, None] + dy, xz[..., 1]])
    UV = np.dstack([off - ED_LO[:, None], np.repeat(ST_S[:, None], len(FRAC), 1)])
    I = up_tris(P.reshape(-1, 3), grid_tris(NS, len(FRAC)))
    add('road', P.reshape(-1, 3), UV.reshape(-1, 2), I)
    log(f'road surface: {len(I)} triangles, banked up to {100 * bank.max():.0f} %')
    return P


ROAD_P = road_mesh()
EY_LO, EY_HI = ROAD_P[:, 0, 1], ROAD_P[:, -1, 1]


def road_y(idx, d):
    off = offsets_of(idx)
    return np.array([np.interp(d[k], off[k], ROAD_P[i, :, 1]) for k, i in enumerate(idx)])


def runs_of(flags, min_len=1):
    out, i = [], 0
    while i < len(flags):
        if flags[i]:
            j = i
            while j + 1 < len(flags) and flags[j + 1]: j += 1
            if j - i + 1 >= min_len: out.append((i, j))
            i = j + 1
        else: i += 1
    return out


def band(name, idx, d0, d1, lift=0.006):
    if len(idx) < 2: return
    d0 = np.broadcast_to(d0, len(idx)).astype(float); d1 = np.broadcast_to(d1, len(idx)).astype(float)
    def at(d):
        xz = ST_P[idx] + ST_N[idx] * d[:, None]
        return np.c_[xz[:, 0], road_y(idx, d) + lift, xz[:, 1]]
    P = np.stack([at(d0), at(d1)], 1).reshape(-1, 3)
    s = ST_S[idx]
    UV = np.stack([np.c_[np.zeros(len(idx)), s], np.c_[np.ones(len(idx)), s]], 1).reshape(-1, 2)
    add(name, P, UV, up_tris(P, grid_tris(len(idx), 2)))


def paint():
    """white edge lines 15 cm wide, 30 cm in from the edges; the lane line between the lanes: 5 m dashes with 5 m
    gaps on the open road, solid through the bends (no changing lanes in a hairpin)"""
    allidx = np.arange(NS)
    for E, sgn in ((ED_LO, 1), (ED_HI, -1)):
        band('paint_white', allidx, E + sgn * 0.30, E + sgn * 0.45)
    mid = (ED_LO + ED_HI) / 2
    solid = ndimage.binary_dilation(ST_R < 60, iterations=15)
    for i0, i1 in runs_of(solid):
        idx = np.arange(i0, i1 + 1); band('paint_white', idx, mid[idx] - 0.075, mid[idx] + 0.075)
    dash = (~solid) & (np.mod(ST_S, 10.0) < 5.0)
    for i0, i1 in runs_of(dash):
        if i1 > i0:
            idx = np.arange(i0, i1 + 1); band('paint_white', idx, mid[idx] - 0.075, mid[idx] + 0.075)


# ---------------------------------------------------------------- the ground
OFFS = np.array([0.5, 0.9, 1.4, 2.0, 2.8, 3.8, 5.0, 6.5, 8.5, 11.0, 14.0, 18.0])
GUTTER_W = 0.45                     # the concrete side ditch along the uphill side and the walls


def corridor_mask(R=0.25):
    E0 = ST_P + ST_N * ED_LO[:, None]; E1 = ST_P + ST_N * ED_HI[:, None]
    allp = np.vstack([E0, E1])
    x0, z0 = allp.min(0) - 30; x1, z1 = allp.max(0) + 30
    W_, H_ = int((x1 - x0) / R) + 1, int((z1 - z0) / R) + 1
    im = Image.new('L', (W_, H_), 0); d = ImageDraw.Draw(im)
    for i in range(NS - 1):
        poly = [E0[i], E1[i], E1[i + 1], E0[i + 1]]
        d.polygon([((p[0] - x0) / R, (p[1] - z0) / R) for p in poly], fill=255)
    return dict(m=np.array(im) > 0, x0=x0, z0=z0, R=R)


def in_corridor(C, xz, shrink=0):
    m = C['m']
    if shrink: m = ndimage.binary_erosion(m, iterations=shrink)
    c = ((xz[:, 0] - C['x0']) / C['R']).astype(int); r = ((xz[:, 1] - C['z0']) / C['R']).astype(int)
    ok = (c >= 0) & (r >= 0) & (c < m.shape[1]) & (r < m.shape[0])
    out = np.zeros(len(xz), bool)
    out[ok] = m[r[ok], c[ok]]
    return out


EDGE_TREE = cKDTree(np.vstack([ST_P + ST_N * ED_LO[:, None], ST_P + ST_N * ED_HI[:, None]]))
EDGE_Y = np.r_[EY_LO, EY_HI]


def edge_dist(xz):
    return EDGE_TREE.query(xz)


_bias = gaussian_filter1d(ST_Y - S.dem(ST_P[:, 0], ST_P[:, 1]), 5, mode='nearest')


def ground_y(xz, stn=None, dR=None):
    """the ground model, with the road's offset from it carried onto the ground near the road (full within 6 m of
    an edge, none past 20 m) so the rows meet the road whatever the model makes of the road's bench"""
    y = S.ground(xz[:, 0], xz[:, 1])
    if dR is None or stn is None:
        dR, j = edge_dist(xz); stn = j % NS
    w = np.clip((20.0 - dR) / 14.0, 0, 1)
    return y + np.where(BRIDGE[stn], 0.0, _bias[stn]) * w


def walls():
    """retaining walls where the hillside rises at the road's edge: per side and station, the wall's height (0: no
    wall) from how far the ground model stands above the road 3-5 m out; runs of at least 12 m, smoothed, eased
    in at their ends"""
    WH = {}
    for side, E, EY in ((-1, ED_LO, EY_LO), (1, ED_HI, EY_HI)):
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        smp = np.array([1.5, 3.0, 4.5])
        xz = (edge[:, None, :] + o[:, None, :] * smp[None, :, None]).reshape(-1, 2)
        y = S.ground(xz[:, 0], xz[:, 1]).reshape(NS, 3)
        rise = (y - EY[:, None]).max(1)
        inner = (ST_K * side) > 0
        want = (rise > 1.6) & ~BRIDGE & ~(inner & (ST_R < 14))
        want = ndimage.binary_closing(want, structure=np.ones(7)) & ~BRIDGE
        want = ndimage.binary_opening(want, structure=np.ones(7))
        H = np.where(want, np.clip(rise + 0.4, 1.4, 9.0), 0.0)
        H = gaussian_filter1d(median_filter(H, 9, mode='nearest'), 2.0, mode='nearest') * want
        # (the ends ease down over ~6 m)
        for i0, i1 in runs_of(want):
            n = i1 - i0 + 1; r = min(4, n // 3)
            if r > 0:
                H[i0:i0 + r] *= np.linspace(0.45, 1, r); H[i1 - r + 1:i1 + 1] *= np.linspace(1, 0.45, r)
        H[want] = np.maximum(H[want], 0.9)
        WH[side] = H
        log(f'walls, side {side:+d}: {sum(ST_S[b] - ST_S[a] for a, b in runs_of(want)):.0f} m in {len(runs_of(want))} runs, up to {H.max():.1f} m')
    return WH


WH = walls()
BATTER = 0.25                       # (a wall leans back 1 in 4)


def wall_geom(side, i):
    """foot and top of the wall at station i on a side: (offset of the foot, of the top, height of the top)"""
    E = ED_LO if side < 0 else ED_HI
    EY = EY_LO if side < 0 else EY_HI
    h = WH[side][i]
    foot = GUTTER_W + 0.14
    return foot, foot + BATTER * h, EY[i] + h


def ground_points(C):
    """kind: 0 road edge, 1 gutter row, 2 rows, 3 detail, 4 far, 5 wall foot, 6 wall top"""
    pts, kind, stn, side_of = [], [], [], []
    for side, E in ((-1, ED_LO), (+1, ED_HI)):
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        EY = EY_LO if side < 0 else EY_HI
        on = ~BRIDGE
        pts.append(np.c_[edge[on, 0], EY[on], edge[on, 1]]); kind.append(np.zeros(on.sum(), int))
        stn.append(np.nonzero(on)[0]); side_of.append(np.full(on.sum(), side))
        inner = (ST_K * side) > 0
        room = np.where(inner, ST_R - np.abs(E), 1e9)
        wall = WH[side] > 0
        foot, top_off, top_y = wall_geom(side, np.arange(NS))
        # the gutter row everywhere off the bridges
        sel = on & (OFFS[0] < 0.7 * room)
        xz = edge[sel] + o[sel] * GUTTER_W
        pts.append(np.c_[xz[:, 0], EY[sel] - 0.15, xz[:, 1]]); kind.append(np.full(sel.sum(), 1))
        stn.append(np.nonzero(sel)[0]); side_of.append(np.full(sel.sum(), side))
        # the walls: foot and top rows
        sel = wall & on
        for off, y, k in ((foot, EY - 0.12, 5), (top_off, top_y, 6)):
            off_ = np.broadcast_to(off, NS)
            xz = edge[sel] + o[sel] * off_[sel, None]
            pts.append(np.c_[xz[:, 0], y[sel], xz[:, 1]]); kind.append(np.full(sel.sum(), k))
            stn.append(np.nonzero(sel)[0]); side_of.append(np.full(sel.sum(), side))
        for k in OFFS[1:]:
            sel = on & (k < 0.7 * room) & (~inner | (ST_R > 15) | (k > 1.0))
            sel &= ~(wall & (k <= top_off + 0.6))                # (behind a wall, the rows start past its top)
            if k > 3.0: sel &= (np.arange(NS) % (2 if k < 9 else 4)) == 0
            xz = edge[sel] + o[sel] * k
            pts.append(np.c_[xz[:, 0], np.full(sel.sum(), np.nan), xz[:, 1]]); kind.append(np.full(sel.sum(), 2))
            stn.append(np.nonzero(sel)[0]); side_of.append(np.full(sel.sum(), side))
    # beyond the rows: jittered grids, coarser with distance from the road, out to REACH; then the far ground
    m = C['m']; step = 8
    dist = ndimage.distance_transform_edt(~m[::step, ::step]) * C['R'] * step
    line_tree = cKDTree(ST_P[::2])
    def road_dist(Q):
        c = ((Q[:, 0] - C['x0']) / (C['R'] * step)).astype(int); r = ((Q[:, 1] - C['z0']) / (C['R'] * step)).astype(int)
        ins = (c >= 0) & (r >= 0) & (c < dist.shape[1]) & (r < dist.shape[0])
        dd = np.full(len(Q), 1e9); dd[ins] = dist[r[ins], c[ins]]
        far = ~ins
        if far.any(): dd[far] = line_tree.query(Q[far])[0]
        return dd
    lo_, hi_ = ST_P.min(0) - S.REACH - 40, ST_P.max(0) + S.REACH + 40
    det = []
    for d0, d1, sp in ((18, 40, 2.5), (40, 100, 4.5), (100, 180, 7.0), (180, S.REACH, 10.0)):
        gx, gz = np.meshgrid(np.arange(lo_[0], hi_[0], sp), np.arange(lo_[1], hi_[1], sp))
        Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.35, 0.35, (gx.size, 2)) * sp
        dd = road_dist(Q)
        det.append(Q[(dd >= d0) & (dd < d1)])
    D = np.vstack(det)
    pts.append(np.c_[D[:, 0], np.full(len(D), np.nan), D[:, 1]]); kind.append(np.full(len(D), 3)); stn.append(np.full(len(D), -1)); side_of.append(np.zeros(len(D), int))
    far = []
    for d0, d1, sp in ((S.REACH, 700, 22.0), (700, 1600, 45.0), (1600, 4000, 100.0), (4000, 1e9, 220.0)):
        lim = FAR_R
        gx, gz = np.meshgrid(np.arange(-lim, lim, sp), np.arange(-lim, lim, sp))
        Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.3, 0.3, (gx.size, 2)) * sp
        Q = Q[np.hypot(Q[:, 0], Q[:, 1]) < FAR_R]
        dd = road_dist(Q)
        far.append(Q[(dd >= d0) & (dd < d1)])
    a = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    far.append(np.c_[FAR_R * np.cos(a), FAR_R * np.sin(a)])
    F = np.vstack(far)
    pts.append(np.c_[F[:, 0], np.full(len(F), np.nan), F[:, 1]]); kind.append(np.full(len(F), 4)); stn.append(np.full(len(F), -1)); side_of.append(np.zeros(len(F), int))
    P = np.concatenate(pts); K = np.concatenate(kind); STN = np.concatenate(stn); SD = np.concatenate(side_of)
    log(f'ground points: {int(((K <= 2) | (K >= 5)).sum())} by the road, {int((K == 3).sum())} within {S.REACH:.0f} m, {int((K == 4).sum())} beyond')
    return P, K, STN, SD


def road_samples():
    fr = np.linspace(0, 1, 15)
    lo, hi = ED_LO + 0.05, ED_HI - 0.05
    d = lo[:, None] + (hi - lo)[:, None] * fr[None, :]
    off = offsets_of()
    y = np.stack([np.interp(d[i], off[i], ROAD_P[i, :, 1]) for i in range(NS)])
    xz = ST_P[:, None, :] + ST_N[:, None, :] * d[..., None]
    keep = ~BRIDGE
    return xz[keep].reshape(-1, 2), y[keep].ravel()


def no_ground_over_road(P, tri, K):
    import matplotlib.tri as mtri
    xz, ry = road_samples()
    for it in range(3):
        T = mtri.Triangulation(P[:, 0], P[:, 2], tri)
        t = T.get_trifinder()(xz[:, 0], xz[:, 1])
        hit = t >= 0
        gy = mtri.LinearTriInterpolator(T, P[:, 1])(xz[hit, 0], xz[hit, 1]).filled(-1e9)
        over = np.zeros(len(xz), bool); over[np.nonzero(hit)[0][gy > ry[hit] + 0.02]] = True
        bad = np.unique(t[over])
        if not len(bad):
            log('  ground over the road: none' + (f' (after {it} passes)' if it else ''))
            return tri
        if it == 2:
            keep = np.ones(len(tri), bool); keep[bad] = False
            log(f'  ground over the road: {len(bad)} triangles still above it: taken out')
            return tri[keep]
        v = np.unique(tri[bad].ravel())
        d, j = EDGE_TREE.query(P[v][:, [0, 2]])
        near = (d < 3.0) & (K[v] != 0)
        P[v[near], 1] = np.minimum(P[v[near], 1], EDGE_Y[j[near]] - 0.15)
    return tri


def build_ground(C):
    P, K, STN, SD = ground_points(C)
    dR, j = edge_dist(P[:, [0, 2]])
    # inside a hairpin two legs of the road face each other across the island: a row stops where the other leg's
    # edge is nearer than its own (past the middle), else the two legs' rows interleave at their two heights
    own = np.maximum(STN, 0)
    other = (K == 2) & (STN >= 0) & (np.abs(ST_S[j % NS] - ST_S[own]) > 25.0)
    P, K, STN, SD, dR, j = P[~other], K[~other], STN[~other], SD[~other], dR[~other], j[~other]
    log(f'  rows past the middle of a hairpin island: {int(other.sum())} dropped')
    need = np.isnan(P[:, 1])
    stn_use = np.where((K == 2) & (STN >= 0), STN, j % NS)
    P[need, 1] = ground_y(P[need][:, [0, 2]], stn_use[need], dR[need])
    # behind a wall the ground comes no lower than the wall's top for the first few metres
    for side in (-1, 1):
        sel = np.nonzero((K == 2) & (SD == side) & (STN >= 0))[0]
        h = WH[side][STN[sel]]
        w = h > 0
        if w.any():
            _, _, ty = wall_geom(side, STN[sel[w]])
            P[sel[w], 1] = np.maximum(P[sel[w], 1], ty - 0.3)
    inside = in_corridor(C, P[:, [0, 2]], shrink=1) & (K != 0)
    P, K, STN, SD = P[~inside], K[~inside], STN[~inside], SD[~inside]
    tree = cKDTree(P[:, [0, 2]])
    pairs = tree.query_pairs(0.07, output_type='ndarray')
    drop = np.zeros(len(P), bool)
    pri = np.array([0, 1, 4, 5, 6, 2, 3])[K]            # (which of two points too close goes: rows before walls)
    for a, b in pairs:
        if drop[a] or drop[b]: continue
        drop[b if pri[b] >= pri[a] else a] = True
    P, K, STN, SD = P[~drop], K[~drop], STN[~drop], SD[~drop]
    tri = Delaunay(P[:, [0, 2]]).simplices
    T = P[tri]
    cen = T.mean(1)
    keep = ~in_corridor(C, cen[:, [0, 2]])
    longest = np.max([np.hypot(*(T[:, a, [0, 2]] - T[:, b, [0, 2]]).T) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    dRc = edge_dist(cen[:, [0, 2]])[0]
    keep &= np.where(dRc < S.REACH, longest < 40, longest < 600)
    tri = tri[keep]
    tri = no_ground_over_road(P, tri, K)
    T = P[tri]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    flip = fn[:, 1] < 0
    tri[flip] = tri[flip][:, [0, 2, 1]]; fn[flip] *= -1
    area = np.linalg.norm(fn, axis=1) / 2
    fu = fn / np.maximum(2 * area, 1e-9)[:, None]
    cen = P[tri].mean(1)
    dR, jj = edge_dist(cen[:, [0, 2]])
    Kt = K[tri]
    st3 = STN[tri]
    same = (np.ptp(st3, axis=1) <= 3) & (np.ptp(SD[tri], axis=1) == 0)
    gutter = np.all((Kt <= 1) | (Kt == 5), axis=1) & same & (Kt == 1).any(1)
    wallf = np.all((Kt == 5) | (Kt == 6), axis=1) & same
    # the slope's kind by each triangle's neighbours too (a bank all one thing, not a chequer)
    upy = fu[:, 1].copy()
    nearR = np.nonzero(dR < 30)[0]
    if len(nearR):
        _, nb = cKDTree(cen[nearR][:, [0, 2]]).query(cen[nearR][:, [0, 2]], k=min(10, len(nearR)))
        ar = area[nearR]
        upy[nearR] = (fu[nearR][nb][:, :, 1] * ar[nb]).sum(1) / np.maximum(ar[nb].sum(1), 1e-9)
    above = cen[:, 1] > EDGE_Y[jj] + 0.3
    mat = np.full(len(tri), 'forest', object)
    mat[dR < 6] = 'verge'
    mat[(dR < 25) & (upy < 0.62) & above] = 'cut'                # (the cut faces above the walls: rock and moss)
    mat[(dR < 25) & (upy < 0.62) & ~above] = 'fill'              # (the fill slopes below the road: scrub on soil)
    mat[dR >= S.REACH * 0.98] = 'far'
    mat[gutter] = 'gutter'
    mat[wallf] = 'wall'
    # per vertex: (x, z) for the ground; (along the road, height over its edge) for walls; (along, across) for gutters
    st = np.maximum(STN, 0)
    ey = np.where(SD > 0, EY_HI[st], EY_LO[st])
    uv_wall = np.c_[ST_S[st], P[:, 1] - ey]
    uv_gut = np.c_[ST_S[st], np.where(K == 0, 0.0, 1.0)]
    uv_xz = np.c_[P[:, 0], P[:, 2]]
    for mname in sorted(set(mat)):
        sel = np.nonzero(mat == mname)[0]
        I = tri[sel]
        used, inv = np.unique(I.ravel(), return_inverse=True)
        UV = {'wall': uv_wall, 'gutter': uv_gut}.get(mname, uv_xz)[used]
        if mname in ('wall', 'gutter'):
            # (these own their vertices: their UVs don't continue onto the ground)
            add('g_' + mname, P[I].reshape(-1, 3), {'wall': uv_wall, 'gutter': uv_gut}[mname][I].reshape(-1, 2), np.arange(3 * len(I)).reshape(-1, 3))
        else:
            add('g_' + mname, P[used], UV, inv.reshape(-1, 3))
    log(f'ground: {len(tri)} triangles; ' + ', '.join(f'{k} {int((mat == k).sum())}' for k in sorted(set(mat))))
    import matplotlib.tri as mtri
    TT = mtri.Triangulation(P[:, 0], P[:, 2], tri)
    return mtri.LinearTriInterpolator(TT, P[:, 1])


# ---------------------------------------------------------------- bridges, the snow shed
def bridges():
    """each bridge: the deck (the road's own surface over it), a slab under it, concrete parapets with a rail on top,
    girders, and piers down to the gully every ~25 m"""
    out = []
    for i0, i1 in runs_of(BRIDGE):
        idx = np.arange(max(i0 - 1, 0), min(i1 + 2, NS))
        out.append(idx)
        for side, E in ((-1, ED_LO), (1, ED_HI)):
            EY = EY_LO if side < 0 else EY_HI
            edge = ST_P[idx] + ST_N[idx] * E[idx, None]
            o = ST_N[idx] * side
            # the slab's edge and underside
            for a, b in (((0.0, 0.0), (0.45, 0.0)), ((0.45, 0.0), (0.45, -1.1))):
                p0 = edge + o * a[0]; p1 = edge + o * b[0]
                Pq = np.stack([np.c_[p0[:, 0], EY[idx] + a[1], p0[:, 1]], np.c_[p1[:, 0], EY[idx] + b[1], p1[:, 1]]], 1).reshape(-1, 3)
                UV = np.stack([np.c_[ST_S[idx], np.zeros(len(idx))], np.c_[ST_S[idx], np.ones(len(idx))]], 1).reshape(-1, 2)
                add('concrete', Pq, UV, grid_tris(len(idx), 2))
            # parapet: 0.25 m thick, 0.75 m tall, its top 1 m over the deck
            for (a0, a1, y0, y1) in ((0.05, 0.05, 0.0, 0.8), (0.05, 0.30, 0.8, 0.8), (0.30, 0.30, 0.8, -0.1)):
                p0 = edge + o * a0; p1 = edge + o * a1
                Pq = np.stack([np.c_[p0[:, 0], EY[idx] + y0, p0[:, 1]], np.c_[p1[:, 0], EY[idx] + y1, p1[:, 1]]], 1).reshape(-1, 3)
                UV = np.stack([np.c_[ST_S[idx], np.full(len(idx), y0)], np.c_[ST_S[idx], np.full(len(idx), y1)]], 1).reshape(-1, 2)
                add('concrete', Pq, UV, grid_tris(len(idx), 2))
        # the soffit under the road
        left = ST_P[idx] + ST_N[idx] * (ED_LO[idx, None] - 0.45); right = ST_P[idx] + ST_N[idx] * (ED_HI[idx, None] + 0.45)
        Pq = np.stack([np.c_[left[:, 0], EY_LO[idx] - 1.1, left[:, 1]], np.c_[right[:, 0], EY_HI[idx] - 1.1, right[:, 1]]], 1).reshape(-1, 3)
        UV = np.stack([np.c_[ST_S[idx], np.zeros(len(idx))], np.c_[ST_S[idx], np.full(len(idx), 8.0)]], 1).reshape(-1, 2)
        I = grid_tris(len(idx), 2)
        I = np.where((np.cross(Pq[I[:, 1]] - Pq[I[:, 0]], Pq[I[:, 2]] - Pq[I[:, 0]])[:, 1] > 0)[:, None], I[:, [0, 2, 1]], I)
        add('concrete', Pq, UV, I)
    log(f'bridges: {len(out)}, {sum(ST_S[i[-1]] - ST_S[i[0]] for i in out):.0f} m')
    return [np.array([ST_S[i[0]], ST_S[i[-1]]]) for i in out]


def snow_shed():
    """the covered gallery: a roof slab on a hillside wall and a row of columns on the valley side"""
    out = []
    for i0, i1 in runs_of(SHED):
        idx = np.arange(max(i0 - 2, 0), min(i1 + 3, NS))
        # which side is the valley: the side where the ground is lower
        lo_y = S.ground(*(ST_P[idx] + ST_N[idx] * (ED_LO[idx, None] - 6)).T).mean()
        hi_y = S.ground(*(ST_P[idx] + ST_N[idx] * (ED_HI[idx, None] + 6)).T).mean()
        valley = -1 if lo_y < hi_y else 1
        out.append(dict(i0=int(idx[0]), i1=int(idx[-1]), valley=valley))
    log(f'snow sheds: {len(out)}')
    return out


# ---------------------------------------------------------------- guardrails, hairpins, signs
def rails(gy):
    """W-beam guardrail where the ground falls away from the edge (or round the outside of a tight bend over any
    drop); not on the bridges (their parapets) nor where a wall stands"""
    R = {}
    for side, E in ((-1, ED_LO), (1, ED_HI)):
        EY = EY_LO if side < 0 else EY_HI
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        smp = np.array([1.2, 2.0, 3.0])
        xz = (edge[:, None, :] + o[:, None, :] * smp[None, :, None]).reshape(-1, 2)
        y = gy(xz[:, 0], xz[:, 1])
        y = np.asarray(y.filled(np.nan) if hasattr(y, 'filled') else y).reshape(NS, 3)
        y = np.where(np.isfinite(y), y, S.ground(xz[:, 0], xz[:, 1]).reshape(NS, 3))
        dy = y - EY[:, None]
        outside = (ST_K * side) < 0
        drop = (dy.min(1) < -0.8) | (outside & (ST_R < 40) & (dy.min(1) < -0.25))
        drop &= ~BRIDGE & ~(WH[side] > 0)
        drop = ndimage.binary_closing(drop, structure=np.ones(9)) & ~BRIDGE & ~(WH[side] > 0)
        drop = ndimage.binary_opening(drop, structure=np.ones(5))
        R[side] = drop
        log(f'guardrail, side {side:+d}: {sum(ST_S[b] - ST_S[a] for a, b in runs_of(drop)):.0f} m')
    return R


IROHA = 'いろはにほへとちりぬるをわかよたれそつねならむうゐのおくやまけふこえてあさきゆめみしゑひもせすん'


def hairpins():
    """the 28 curves of the descent, in order from the top: the bends that turn furthest (over 90 degrees within
    60 m), the 28 sharpest if there are more; each with its apex station and which way it turns"""
    turn = np.abs(gaussian_filter1d(_ang, 1)[np.minimum(np.searchsorted(ST_S, ST_S + 30), NS - 1)] - gaussian_filter1d(_ang, 1)[np.maximum(np.searchsorted(ST_S, ST_S - 30), 0)])
    cand = []
    i = 0
    while i < NS:
        if turn[i] > np.radians(95):
            j = i
            while j + 1 < NS and turn[j + 1] > np.radians(95): j += 1
            seg = np.arange(i, j + 1)
            apex = seg[np.argmax(np.abs(ST_K[seg]))]
            cand.append((apex, float(turn[seg].max())))
            i = j + 1
        else: i += 1
    if len(cand) > 28:
        best = sorted(cand, key=lambda c: -c[1])[:28]
        cand = sorted(best)
    names = list(IROHA[20:48])
    out = [dict(i=int(a), kana=names[k] if k < 28 else '', n=21 + k, turn=float(np.degrees(t)), sign=int(np.sign(ST_K[a]))) for k, (a, t) in enumerate(cand)]
    log(f'hairpins: {len(cand)} (' + ''.join(h['kana'] for h in out) + ')')
    return out


# ---------------------------------------------------------------- trees: where the photos show forest
def photo_mosaic():
    lat0, lon0 = S.to_ll(ST_P[:, 0].max() + S.REACH + 60, ST_P[:, 1].max() + S.REACH + 60)
    lat1, lon1 = S.to_ll(ST_P[:, 0].min() - S.REACH - 60, ST_P[:, 1].min() - S.REACH - 60)
    la0, la1 = min(lat0, lat1), max(lat0, lat1); lo0, lo1 = min(lon0, lon1), max(lon0, lon1)
    return gsi.Mosaic('seamlessphoto', 17, 'jpg', float(la0), float(lo0), float(la1), float(lo1))


def forest_classes(M):
    """what the photo shows, per pixel: 0 deciduous forest (leaf-off brown in this photo), 1 conifers (dark green),
    2 bare (scree, rock, road, buildings), 3 water"""
    from scipy.ndimage import uniform_filter, binary_opening
    a = uniform_filter(M.a.astype(np.float32) / 255, size=(5, 5, 1))
    L = a.mean(-1); mx = a.max(-1); mn = a.min(-1); sat = (mx - mn) / np.maximum(mx, 1e-3)
    g = a[..., 1] - np.maximum(a[..., 0], a[..., 2])
    cls = np.zeros(L.shape, np.uint8)
    cls[(g > 0.0) & (L < 0.36)] = 1
    cls[((L > 0.50) & (sat < 0.18)) | (L > 0.62)] = 2
    cls[(a[..., 2] > a[..., 0] + 0.03) & (a[..., 2] > a[..., 1]) & (L < 0.45)] = 3
    for k in (1, 2, 3):                                   # (no single-pixel specks)
        m = cls == k; cls[m & ~binary_opening(m, iterations=2)] = 0
    return cls


def trees(gy, rails_, C):
    """the forest within REACH of the road: a jittered 5 m grid kept where the photo shows forest, thick by the road
    and thinning with distance (a clear strip of 4.5 m beside it, small trees nearest it); not on cliffs, nor in the
    gullies under the bridges. Columns: x, y, z, kind (0 oak, 1 maple, 2 fir, 3 bush), size (0 small, 1 medium,
    2 large), a random number (picks the model and its colour), the turn (radians), the scale"""
    M = photo_mosaic()
    cls = forest_classes(M)
    from scipy.ndimage import map_coordinates
    lo_, hi_ = ST_P.min(0) - S.REACH, ST_P.max(0) + S.REACH
    sp = 5.0
    gx, gz = np.meshgrid(np.arange(lo_[0], hi_[0], sp), np.arange(lo_[1], hi_[1], sp))
    Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.45, 0.45, (gx.size, 2)) * sp
    dR = edge_dist(Q)[0]
    Q, dR = Q[dR < S.REACH], dR[dR < S.REACH]
    lat, lon = S.to_ll(Q[:, 0], Q[:, 1]); px, py = M.px(lat, lon)
    c = map_coordinates(cls, [py - 0.5, px - 0.5], order=0)
    dens = np.clip(1.0 - (dR - 30) / 400, 0.45, 1.0) * (dR > 4.5)
    keep = (c < 2) & (rng.random(len(Q)) < dens) & ~in_corridor(C, Q)
    # (the gullies under the bridges: nothing tall)
    bi = np.flatnonzero(BRIDGE)
    if len(bi):
        bd = cKDTree(ST_P[bi]).query(Q)[0]
        keep &= bd > 18
    Q, dR, c = Q[keep], dR[keep], c[keep]
    y = gy(Q[:, 0], Q[:, 1]); y = np.asarray(y.filled(np.nan) if hasattr(y, 'filled') else y)
    sl = np.hypot(S.ground(Q[:, 0] + 1.5, Q[:, 1]) - S.ground(Q[:, 0] - 1.5, Q[:, 1]),
                  S.ground(Q[:, 0], Q[:, 1] + 1.5) - S.ground(Q[:, 0], Q[:, 1] - 1.5)) / 3.0
    ok = np.isfinite(y) & (sl < 1.3)
    Q, y, dR, c = Q[ok], y[ok], dR[ok], c[ok]
    n = len(Q)
    kind = np.where(c == 1, 2, np.where(rng.random(n) < 0.32, 1, 0))
    # (a few conifers in the broadleaf woods, a few broadleaves among the conifers)
    flip = rng.random(n)
    kind = np.where((kind != 2) & (flip < 0.08), 2, kind)
    kind = np.where((kind == 2) & (c == 1) & (flip < 0.15), 0, kind)
    u = rng.random(n)
    # (by the road small and medium trees, whose crowns don't close over it; the big ones further back)
    size = np.where(dR < 7, np.where(u < 0.7, 0, 1), np.where(dR < 16, np.where(u < 0.15, 0, 1), np.where(u < 0.35, 1, 2)))
    T = np.c_[Q[:, 0], y, Q[:, 1], kind, size, rng.random(n), rng.uniform(0, 2 * np.pi, n), rng.uniform(0.8, 1.15, n)]
    # past REACH out to 650 m: big trees only, 11 m apart (the canopy as seen from the road's views and from above),
    # their kind from the land cover map (cover.py)
    cov = os.path.join(S.HERE, 'tex', 'cover_near.png')
    if os.path.exists(cov):
        import json
        cb = json.load(open(os.path.join(S.HERE, 'tex', 'cover.json')))['near']
        cm = np.asarray(Image.open(cov)).astype(np.float32) / 255
        sp2 = 11.0
        lo2, hi2 = ST_P.min(0) - 650, ST_P.max(0) + 650
        gx, gz = np.meshgrid(np.arange(lo2[0], hi2[0], sp2), np.arange(lo2[1], hi2[1], sp2))
        F = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.45, 0.45, (gx.size, 2)) * sp2
        fd = edge_dist(F)[0]
        F = F[(fd >= S.REACH) & (fd < 650)]
        res = (cb['x1'] - cb['x0']) / cm.shape[1]
        px = np.clip(((F[:, 0] - cb['x0']) / res).astype(int), 0, cm.shape[1] - 1)
        py = np.clip(((F[:, 1] - cb['z0']) / res).astype(int), 0, cm.shape[0] - 1)
        c3 = cm[py, px]
        ok = (c3[:, 1] < 0.5) & (c3[:, 2] < 0.3)
        F, c3 = F[ok], c3[ok]
        fy = gy(F[:, 0], F[:, 1]); fy = np.asarray(fy.filled(np.nan) if hasattr(fy, 'filled') else fy)
        ok = np.isfinite(fy)
        F, c3, fy = F[ok], c3[ok], fy[ok]
        m = len(F)
        fk = np.where(c3[:, 0] > 0.5, 2, np.where(rng.random(m) < 0.32, 1, 0))
        T = np.vstack([T, np.c_[F[:, 0], fy, F[:, 1], fk, np.full(m, 2), rng.random(m), rng.uniform(0, 2 * np.pi, m), rng.uniform(0.85, 1.2, m)]])
        log(f'trees past REACH: {m}')
    # bushes: the forest's edge by the road, and under the trees near it
    m = int(S.REACH * 0)
    B = lo_ + rng.random((int((hi_ - lo_).prod() / 30), 2)) * (hi_ - lo_)
    bR = edge_dist(B)[0]
    B, bR = B[(bR > 2.2) & (bR < 40)], bR[(bR > 2.2) & (bR < 40)]
    lat, lon = S.to_ll(B[:, 0], B[:, 1]); px, py = M.px(lat, lon)
    bc = map_coordinates(cls, [py - 0.5, px - 0.5], order=0)
    keep = (bc < 2) & (rng.random(len(B)) < np.clip(1.2 - bR / 30, 0.15, 1)) & ~in_corridor(C, B)
    B = B[keep]
    by = gy(B[:, 0], B[:, 1]); by = np.asarray(by.filled(np.nan) if hasattr(by, 'filled') else by)
    B, by = B[np.isfinite(by)], by[np.isfinite(by)]
    nb = len(B)
    Bt = np.c_[B[:, 0], by, B[:, 1], np.full(nb, 3), rng.integers(0, 3, nb), rng.random(nb), rng.uniform(0, 2 * np.pi, nb), rng.uniform(0.8, 1.4, nb)]
    log(f'trees: {n} ({(kind == 0).sum()} oak, {(kind == 1).sum()} maple, {(kind == 2).sum()} fir), {nb} bushes; '
        f'photo: ' + ', '.join(f'{k} {100 * (cls == i).mean():.0f}%' for i, k in enumerate(('broadleaf', 'conifer', 'bare', 'water'))))
    return np.vstack([T, Bt]).astype(np.float32), cls, M


def main(out):
    t0 = time.time()
    paint()
    C = corridor_mask()
    gy = build_ground(C)
    br = bridges()
    sh = snow_shed()
    R = rails(gy)
    hp = hairpins()
    TP, CLS, PM = trees(gy, R, C)
    arrays = {}
    for name, L in MESH.items():
        P = np.concatenate([l[0] for l in L]); UV = np.concatenate([l[1] for l in L])
        o = np.cumsum([0] + [len(l[0]) for l in L])[:-1]
        I = np.concatenate([l[2] + oo for l, oo in zip(L, o)])
        arrays[f'm_{name}_P'] = P.astype(np.float32); arrays[f'm_{name}_UV'] = UV.astype(np.float32); arrays[f'm_{name}_I'] = I.astype(np.int32)
    np.savez_compressed(out, ST_S=ST_S, ST_P=ST_P, ST_Y=ST_Y, ST_N=ST_N, ST_T=ST_T, ST_K=ST_K, ED_LO=ED_LO, ED_HI=ED_HI,
                        EY_LO=EY_LO, EY_HI=EY_HI, BRIDGE=BRIDGE, SHED=SHED, WH_lo=WH[-1], WH_hi=WH[1],
                        RAIL_lo=R[-1], RAIL_hi=R[1], TREES=TP.astype(np.float32),
                        HP=np.array([[h['i'], h['n'], h['sign']] for h in hp], np.int32),
                        HP_KANA=np.array([h['kana'] for h in hp]),
                        SHEDS=np.array([[d['i0'], d['i1'], d['valley']] for d in sh], np.int32).reshape(-1, 3),
                        **arrays)
    log(f'wrote {out}: ' + ', '.join(f'{k} {sum(len(l[2]) for l in L)}' for k, L in MESH.items()) + f' triangles ({time.time() - t0:.0f} s)')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(S.HERE, 'geo.npz'))
