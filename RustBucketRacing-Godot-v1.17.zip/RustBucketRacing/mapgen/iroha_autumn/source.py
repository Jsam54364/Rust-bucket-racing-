"""Where the Irohazaka map comes from: GSI Japan's open map data (gsi.py; 出典：国土地理院).

  * the road: the First Irohazaka (第一いろは坂), National Route 120's one-way descent from Lake Chuzenji to
    Umagaeshi, traced along GSI's national-road centrelines; smoothed; metres on a local plane (x east, z south, y up)
  * its heights: the 5 m elevation model (airborne laser), smoothed along the road
  * the ground: the 5 m model round the road, 10 m from 30 m cells out to 12 km (Mt. Nantai and the ridges)
  * the area of full detail: everything within REACH m of the road

Importing it does the work (a few seconds once the tiles are cached)."""
import heapq, math, os, time
import numpy as np
from scipy.ndimage import gaussian_filter1d, median_filter, map_coordinates
import gsi

HERE = os.path.dirname(os.path.abspath(__file__))
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)

TOP = (36.73958, 139.50320)            # where the descent leaves the lakeside road at Chuzenji
BOTTOM = (36.73920, 139.53600)         # Umagaeshi, where it meets the Second Irohazaka's foot
SEARCH = (36.725, 139.49, 36.755, 139.565)
LAT0, LON0 = 36.7420, 139.5180         # the local plane's origin (the middle of the route)
REACH = 260.0                          # metres of full detail either side of the road
_p = math.radians(LAT0)
M_LAT = 111132.954 - 559.822 * math.cos(2 * _p) + 1.175 * math.cos(4 * _p)
M_LON = 111412.84 * math.cos(_p) - 93.5 * math.cos(3 * _p)


def to_xz(lat, lon):
    return (np.asarray(lon) - LON0) * M_LON, -(np.asarray(lat) - LAT0) * M_LAT


def to_ll(x, z):
    return LAT0 - np.asarray(z) / M_LAT, LON0 + np.asarray(x) / M_LON


# ---------------------------------------------------------------- the road's line
STATE = {}


def _route():
    """national-road centrelines from the top to Umagaeshi: the shortest path that goes by the north side of the
    gorge (the Second Irohazaka, the way up, is on the south side and is kept out by a toll on going south of it)"""
    key = lambda q: (round(q[1], 6), round(q[0], 6))
    g = {}
    for p, c in gsi.roads(*SEARCH):
        if p['rdCtg'] != '国道': continue
        pts = [key(q) for q in c]
        for a, b in zip(pts, pts[1:]):
            if a == b: continue
            STATE[(a, b)] = STATE[(b, a)] = p['state']
            d = float(np.hypot((a[0] - b[0]) * M_LAT, (a[1] - b[1]) * M_LON))
            # (the north side: the descent never goes below 36.7375 between the two ends)
            if min(a[0], b[0]) < 36.7375 and 139.505 < a[1] < 139.534: d *= 50
            g.setdefault(a, []).append((b, d)); g.setdefault(b, []).append((a, d))
    dist = lambda a, b: float(np.hypot((a[0] - b[0]) * M_LAT, (a[1] - b[1]) * M_LON))
    near = lambda p: min(g, key=lambda a: dist(a, p))
    s, t = near(TOP), near(BOTTOM)
    q = [(0.0, s)]; prev = {s: None}; best = {s: 0.0}
    while q:
        d, a = heapq.heappop(q)
        if a == t: break
        if d > best[a]: continue
        for b, l in g[a]:
            if d + l < best.get(b, 1e18): best[b] = d + l; prev[b] = a; heapq.heappush(q, (d + l, b))
    path = [t]
    while prev[path[-1]] is not None: path.append(prev[path[-1]])
    path = path[::-1]
    return np.array(path), [STATE.get((a, b), '通常部') for a, b in zip(path, path[1:])]   # (lat, lon), top first


def _resample(P, step):
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
    u = np.arange(0, s[-1] + 1e-9, step)
    return np.c_[np.interp(u, s, P[:, 0]), np.interp(u, s, P[:, 1])]


def normals(line):
    t = np.gradient(line, axis=0); t /= np.linalg.norm(t, axis=1, keepdims=True)
    return t, np.stack([-t[:, 1], t[:, 0]], 1)


# ---------------------------------------------------------------- elevation
class Grid:
    """heights on a square grid of the local plane (cell centres at x0 + (i + 0.5) res); bilinear"""
    def __init__(self, x0, z0, res, h):
        self.x0, self.z0, self.res, self.h = x0, z0, res, h.astype(np.float32)
        self.nz, self.nx = h.shape
        self.x1 = x0 + self.nx * res; self.z1 = z0 + self.nz * res

    def __call__(self, x, z):
        x = np.asarray(x, np.float64); z = np.asarray(z, np.float64)
        c = (x - self.x0) / self.res - 0.5; r = (z - self.z0) / self.res - 0.5
        return map_coordinates(self.h, [r.ravel(), c.ravel()], order=1, mode='nearest').reshape(x.shape)

    def inside(self, x, z, margin=0.0):
        return (x >= self.x0 + margin) & (x <= self.x1 - margin) & (z >= self.z0 + margin) & (z <= self.z1 - margin)


def _grid(name, x0, z0, x1, z1, res, sources):
    cache = os.path.join(gsi.CACHE, f'grid_{name}.npz')
    if os.path.exists(cache):
        c = np.load(cache)
        if c['spec'].tolist() == [x0, z0, x1, z1, res]: return Grid(x0, z0, res, c['h'])
    nx, nz = int(round((x1 - x0) / res)), int(round((z1 - z0) / res))
    X, Z = np.meshgrid(x0 + (np.arange(nx) + 0.5) * res, z0 + (np.arange(nz) + 0.5) * res)
    lat, lon = to_ll(X, Z)
    h = np.full(X.shape, np.nan)
    for layer, z in sources:
        todo = np.isnan(h)
        if not todo.any(): break
        m = gsi.Mosaic(layer, z, 'png', float(lat[todo].min()) - 0.002, float(lon[todo].min()) - 0.002,
                       float(lat[todo].max()) + 0.002, float(lon[todo].max()) + 0.002)
        px, py = m.px(lat[todo], lon[todo])
        v = map_coordinates(m.a, [py - 0.5, px - 0.5], order=1, mode='nearest', cval=np.nan)
        h[todo] = v
        log(f'  {name}: {layer} z{z}: {np.isfinite(v).sum()} of {todo.sum()} points')
    if np.isnan(h).any():
        from scipy.ndimage import distance_transform_edt
        idx = distance_transform_edt(np.isnan(h), return_distances=False, return_indices=True)
        h = h[tuple(idx)]
    os.makedirs(gsi.CACHE, exist_ok=True)
    np.savez(cache, h=h.astype(np.float32), spec=np.array([x0, z0, x1, z1, res]))
    return Grid(x0, z0, res, h)


# ---------------------------------------------------------------- build
RAW, RAW_STATE = _route()
_x, _z = to_xz(RAW[:, 0], RAW[:, 1])
_P = _resample(np.c_[_x, _z], 1.0)
_P = np.c_[gaussian_filter1d(_P[:, 0], 3.0, mode='nearest'), gaussian_filter1d(_P[:, 1], 3.0, mode='nearest')]
line = _resample(_P, 2.0)                                 # the road's centreline, top first, 2 m steps
line_len = float(np.hypot(*np.diff(line, axis=0).T).sum())
sl = np.r_[0, np.cumsum(np.hypot(*np.diff(line, axis=0).T))]


def _states():
    """what GSI says each station of the line is on: 通常部 (the ground), 橋・高架 (a bridge), トンネル ..."""
    mid = np.c_[(_x[1:] + _x[:-1]) / 2, (_z[1:] + _z[:-1]) / 2]
    from scipy.spatial import cKDTree
    _, k = cKDTree(mid).query(line)
    return np.array(RAW_STATE)[k]
STATE_AT = _states()
BRIDGE = STATE_AT == '橋・高架'

_bx0, _bz0 = line.min(0) - 700; _bx1, _bz1 = line.max(0) + 700
_bx0, _bz0, _bx1, _bz1 = [float(np.floor(v / 50) * 50) for v in (_bx0, _bz0)] + [float(np.ceil(v / 50) * 50) for v in (_bx1, _bz1)]
dem = _grid('near', _bx0, _bz0, _bx1, _bz1, 5.0, [('dem5a_png', 15), ('dem5b_png', 15), ('dem10b_png', 14), ('dem_png', 14)])
dem_far = _grid('far', -12000.0, -12000.0, 12000.0, 12000.0, 30.0, [('dem_png', 13), ('dem_png', 12)])
log(f'elevation: near {dem.nx}x{dem.nz} at {dem.res:.0f} m ({dem.h.min():.0f}-{dem.h.max():.0f} m), far {dem_far.nx}x{dem_far.nz} '
    f'at {dem_far.res:.0f} m ({dem_far.h.min():.0f}-{dem_far.h.max():.0f} m)')


def ground(x, z):
    x = np.asarray(x, np.float64); z = np.asarray(z, np.float64)
    out = dem_far(x, z)
    ins = dem.inside(x, z, 10.0)
    if np.any(ins): out = np.where(ins, dem(np.where(ins, x, dem.x0 + 20), np.where(ins, z, dem.z0 + 20)), out)
    return out


def _heights():
    """the road's height: a smooth line through the ground model along the road, fitted so that points it can't
    follow gently (where the 1:25,000 centreline strays a few metres onto the slope beside the road, the model
    there is the slope, not the road's bench) count less and less (reweighted least squares, a curvature penalty);
    then no grade over 12 %"""
    import scipy.sparse as sp
    from scipy.sparse.linalg import spsolve
    t, n = normals(line)
    h = np.median(np.stack([dem(line[:, 0] + n[:, 0] * o, line[:, 1] + n[:, 1] * o) for o in (-2, -1, 0, 1, 2)]), 0)
    N = len(h)
    D = sp.diags([1, -2, 1], [0, 1, 2], shape=(N - 2, N))
    lam = 4000.0
    w = np.where(BRIDGE, 0.0, 1.0)                               # (on a bridge the model is the gully under it)
    w0 = w.copy()
    for _ in range(8):
        W = sp.diags(w)
        f = spsolve((W + lam * (D.T @ D)).tocsc(), w * h)
        r = np.abs(h - f)
        w = w0 * np.where(r < 0.5, 1.0, 0.5 / r) ** 2            # (Huber-like, squared: the strays fade fast)
    # grades over 12 % pulled back, both ways round, then smoothed a little
    g = np.clip(np.diff(f) / np.diff(sl), -0.12, 0.12)
    f2 = np.r_[f[0], f[0] + np.cumsum(g * np.diff(sl))]
    f2 += np.interp(sl, [sl[0], sl[-1]], [0, (f[-1] - f2[-1])])  # (spread what the clamp lost over the length)
    f2 = gaussian_filter1d(f2, 3, mode='nearest')
    return f2, dem(line[:, 0], line[:, 1])
ly, ly_raw = _heights()

_g = np.gradient(ly, sl)
_b = np.flatnonzero(np.diff(np.r_[0, BRIDGE.astype(int), 0]))
log(f'bridges: ' + ', '.join(f'{sl[a]:.0f}-{sl[min(b, len(sl) - 1)]:.0f} m' for a, b in zip(_b[::2], _b[1::2])))
log(f'road: {line_len:.0f} m, {len(line)} points, {ly[0]:.0f} m to {ly[-1]:.0f} m ({ly[0] - ly[-1]:.0f} m drop), steepest '
    f'{100 * np.abs(_g).max():.1f} %; road vs ground model at its middle: {np.abs(ly - ly_raw).mean():.2f} m mean')
