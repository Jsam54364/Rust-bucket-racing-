"""Textures drawn here for the Irohazaka build (all our own; written to tex/):

  asphalt     worn dark asphalt, its aggregate showing (4 m square, tiling)
  kikko       a kikko-zumi (tortoise-shell) masonry retaining wall: hexagonal dressed stones, deep mortar joints
              (3 m square, tiling), and its height (for the bump)
  concrete    board-marked concrete (2 m square, tiling)
  litter      the forest floor in autumn: fallen leaves over dark soil and twigs (2 m square, tiling)
  grass       a roadside verge gone straw-coloured in autumn (2 m square, tiling)
  rock        weathered andesite with lichen (3 m square, tiling)
  sign_<n>    the hairpin signs: one letter of the Iroha poem and the bend's number (our own design)
  chevron     a curve's chevron board; limit40 the speed limit sign
  susuki_plume  a plume of susuki (Japanese silver grass), with alpha
"""
import os, sys, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy.ndimage import gaussian_filter, map_coordinates

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'tex')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)
FONT = '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'


def noise(n, sigma, seed=None):
    r = np.random.default_rng(seed) if seed is not None else rng
    a = gaussian_filter(r.normal(size=(n, n)), sigma, mode='wrap')
    return (a - a.mean()) / (a.std() + 1e-9)


def fbm(n, sigmas, weights, seed=0):
    return sum(w * noise(n, s, seed + k) for k, (s, w) in enumerate(zip(sigmas, weights)))


def save(name, a, mode='RGB'):
    a = np.clip(a, 0, 1)
    if a.ndim == 2: Image.fromarray((a * 255).astype(np.uint8), 'L').save(os.path.join(OUT, name + '.png'))
    else: Image.fromarray((a * 255).astype(np.uint8), mode).save(os.path.join(OUT, name + '.png'))


def srgb(c):
    return np.array(c, np.float32) / 255


# ---------------------------------------------------------------- asphalt
def asphalt(n=1024):
    base = srgb((74, 74, 76))
    big = fbm(n, (60, 20), (0.6, 0.4), 1) * 0.06
    fine = noise(n, 0.7, 3) * 0.05
    # aggregate: small stones, a few light, a few dark
    agg = np.zeros((n, n), np.float32)
    k = int(n * n * 0.012)
    ys, xs = rng.integers(0, n, k), rng.integers(0, n, k)
    agg[ys, xs] = rng.choice([-1.0, 1.0, 1.6], k, p=[0.45, 0.45, 0.10])
    agg = gaussian_filter(agg, 0.9, mode='wrap') * 1.4
    L = 1 + big + fine + agg * 0.22
    a = base[None, None, :] * L[..., None]
    a[..., 2] *= 1.02
    save('asphalt', a)
    rough = 0.82 + 0.08 * noise(n, 8, 9) - 0.10 * np.clip(agg, 0, None)
    save('asphalt_rough', rough)


# ---------------------------------------------------------------- kikko masonry
def kikko(n=1024, stones=5):
    """hexagonal stones (pointy-top), `stones` across the tile, tiling: each pixel's nearest stone centre on a
    hex lattice (wrapped); a joint where the two nearest are nearly as near"""
    s = n / stones                     # stone spacing in pixels along x
    h = s * math.sqrt(3) / 2
    rows = int(round(n / h))
    h = n / rows                       # (rows fit the tile exactly; the lattice squashes a hair to tile)
    centres = []
    for r in range(rows):
        for c in range(stones):
            centres.append(((c + 0.5 * (r % 2)) * s, r * h))
    C = np.array(centres) + rng.normal(0, s * 0.05, (len(centres), 2))
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32)
    # the two nearest centres, with wrap
    from scipy.spatial import cKDTree
    W = []
    for dx in (-n, 0, n):
        for dy in (-n, 0, n): W.append(C + [dx, dy])
    Cw = np.vstack(W); ids = np.tile(np.arange(len(C)), 9)
    d, k = cKDTree(Cw).query(np.c_[xx.ravel(), yy.ravel()], k=2)
    gap = (d[:, 1] - d[:, 0]).reshape(n, n)
    sid = ids[k[:, 0]].reshape(n, n)
    tone = rng.normal(0, 1, len(C))
    warm = rng.normal(0, 1, len(C))
    edge = np.clip(gap / (s * 0.07), 0, 1)                 # 0 at the joint, 1 well inside a stone
    face = np.sqrt(edge)
    base = srgb((128, 126, 118))
    L = 1 + 0.10 * tone[sid] + 0.07 * fbm(n, (6, 1.2), (0.6, 0.4), 11)
    a = base[None, None, :] * L[..., None]
    a[..., 0] *= 1 + 0.03 * warm[sid]; a[..., 2] *= 1 - 0.03 * warm[sid]
    mortar = srgb((88, 86, 80))
    a = a * face[..., None] + mortar[None, None, :] * (1 - face[..., None]) * (0.7 + 0.3 * edge[..., None])
    # pitting, lichen spots
    lich = np.clip(fbm(n, (14, 4), (0.7, 0.3), 21) - 1.1, 0, 1)
    a = a * (1 - 0.5 * lich[..., None]) + srgb((150, 150, 120))[None, None, :] * 0.5 * lich[..., None]
    save('kikko', a)
    height = face * (0.85 + 0.15 * (0.5 + 0.2 * tone[sid])) + 0.03 * noise(n, 1.5, 31)
    save('kikko_h', (height - height.min()) / np.ptp(height))


# ---------------------------------------------------------------- concrete
def concrete(n=1024):
    base = srgb((150, 148, 142))
    L = 1 + 0.06 * fbm(n, (40, 8, 1.5), (0.5, 0.3, 0.2), 41)
    # board marks: faint horizontal bands every 0.3 m of a 2 m tile
    y = np.arange(n)[:, None] / n * 2.0
    L += 0.025 * np.cos(y / 0.3 * 2 * np.pi)[..., 0:1] if False else 0.02 * np.sin(np.arange(n) / n * 2 * np.pi * 6.67)[:, None]
    # tie holes
    a = base[None, None, :] * L[..., None]
    for yy in (0.25, 0.75):
        for xx in (0.25, 0.75):
            cy, cx = int(yy * n), int(xx * n)
            Y, X = np.ogrid[-cy:n - cy, -cx:n - cx]
            m = (X * X + Y * Y) < (n * 0.008) ** 2
            a[m] *= 0.55
    save('concrete', a)


# ---------------------------------------------------------------- forest floor in autumn
def litter(n=1024, leaves=9000):
    soil = srgb((58, 44, 32))
    im = Image.new('RGB', (n * 2, n * 2), tuple(int(c * 255) for c in soil))
    d = ImageDraw.Draw(im)
    pal = [(150, 74, 30), (178, 102, 40), (120, 56, 30), (196, 140, 58), (104, 70, 40), (86, 60, 36), (160, 48, 30),
           (140, 112, 60)]
    for k in range(leaves):
        cx, cy = rng.uniform(0, 2 * n, 2)
        L = rng.uniform(10, 26); W = L * rng.uniform(0.35, 0.6)
        ang = rng.uniform(0, math.pi)
        col = np.array(pal[rng.integers(len(pal))]) * rng.uniform(0.75, 1.1)
        pts = [(cx + L * math.cos(ang + t) * (math.cos(t) if False else 1) * 0 + (L * math.cos(t)) * math.cos(ang) - (W * math.sin(t)) * math.sin(ang),
                cy + (L * math.cos(t)) * math.sin(ang) + (W * math.sin(t)) * math.cos(ang)) for t in np.linspace(0, 2 * math.pi, 9)]
        d.polygon(pts, fill=tuple(int(min(255, c)) for c in col))
    # twigs
    for k in range(300):
        x0, y0 = rng.uniform(0, 2 * n, 2); a_ = rng.uniform(0, math.pi); L = rng.uniform(20, 70)
        d.line([(x0, y0), (x0 + L * math.cos(a_), y0 + L * math.sin(a_))], fill=(70, 52, 36), width=int(rng.integers(2, 4)))
    im = im.resize((n, n), Image.LANCZOS)
    a = np.asarray(im, np.float32) / 255
    # (tile: blend the image with itself shifted half a tile across a soft seam)
    a2 = np.roll(np.roll(a, n // 2, 0), n // 2, 1)
    yy, xx = np.mgrid[0:n, 0:n] / n
    w = (np.minimum(np.minimum(xx, 1 - xx), np.minimum(yy, 1 - yy)) * 2)
    w = np.clip(w * 3, 0, 1)[..., None]
    a = a * w + a2 * (1 - w)
    a *= (1 + 0.12 * fbm(n, (30, 6), (0.6, 0.4), 51))[..., None]
    save('litter', a)


def grass(n=1024, blades=26000):
    soil = srgb((84, 72, 52))
    im = Image.new('RGB', (n * 2, n * 2), tuple(int(c * 255) for c in soil))
    d = ImageDraw.Draw(im)
    pal = [(170, 150, 96), (150, 128, 80), (190, 170, 110), (120, 116, 70), (104, 110, 60), (140, 122, 74)]
    for k in range(blades):
        x0, y0 = rng.uniform(0, 2 * n, 2); a_ = rng.uniform(0, 2 * math.pi); L = rng.uniform(14, 40)
        col = np.array(pal[rng.integers(len(pal))]) * rng.uniform(0.7, 1.1)
        d.line([(x0, y0), (x0 + L * math.cos(a_), y0 + L * math.sin(a_))], fill=tuple(int(min(255, c)) for c in col), width=2)
    im = im.resize((n, n), Image.LANCZOS)
    a = np.asarray(im, np.float32) / 255
    a2 = np.roll(np.roll(a, n // 2, 0), n // 2, 1)
    yy, xx = np.mgrid[0:n, 0:n] / n
    w = np.clip(np.minimum(np.minimum(xx, 1 - xx), np.minimum(yy, 1 - yy)) * 6, 0, 1)[..., None]
    a = a * w + a2 * (1 - w)
    a *= (1 + 0.10 * fbm(n, (40, 8), (0.6, 0.4), 61))[..., None]
    save('grass', a)


def rock(n=1024):
    base = srgb((112, 108, 100))
    f = fbm(n, (48, 16, 5, 1.2), (0.45, 0.3, 0.17, 0.08), 71)
    cracks = np.abs(fbm(n, (10, 3), (0.7, 0.3), 81))
    L = 1 + 0.16 * f - 0.25 * np.clip(0.25 - cracks, 0, None) * 4
    a = base[None, None, :] * L[..., None]
    lich = np.clip(fbm(n, (12, 3), (0.7, 0.3), 91) - 0.9, 0, 1)
    moss = np.clip(fbm(n, (30, 8), (0.7, 0.3), 92) - 0.6, 0, 1)
    a = a * (1 - 0.6 * lich[..., None]) + srgb((168, 166, 140))[None, None, :] * 0.6 * lich[..., None]
    a = a * (1 - 0.7 * moss[..., None]) + srgb((70, 82, 44))[None, None, :] * 0.7 * moss[..., None]
    save('rock', a)
    save('rock_h', (f - f.min()) / np.ptp(f))


# ---------------------------------------------------------------- signs
def font(size):
    return ImageFont.truetype(FONT, size, index=0)


def hairpin_signs(kana_list):
    """our own design: a white board with a dark green border, the bend's letter large in a circle and its number
    under it (n of 48)"""
    for k, (kana, num) in enumerate(kana_list):
        W, H = 384, 512
        im = Image.new('RGB', (W, H), (246, 246, 240))
        d = ImageDraw.Draw(im)
        d.rectangle([6, 6, W - 7, H - 7], outline=(24, 90, 60), width=16)
        d.ellipse([52, 42, W - 52, 42 + W - 104], outline=(24, 90, 60), width=12)
        f = font(210)
        bb = d.textbbox((0, 0), kana, font=f)
        d.text((W / 2 - (bb[0] + bb[2]) / 2, 42 + (W - 104) / 2 - (bb[1] + bb[3]) / 2), kana, font=f, fill=(20, 30, 28))
        f2 = font(64)
        t = f'{num}/48'
        bb = d.textbbox((0, 0), t, font=f2)
        d.text((W / 2 - (bb[0] + bb[2]) / 2, 400 - (bb[1] + bb[3]) / 2 + 20), t, font=f2, fill=(24, 90, 60))
        im.save(os.path.join(OUT, f'sign_{num}.png'))


def chevron():
    W, H = 256, 384
    im = Image.new('RGB', (W, H), (232, 196, 34))
    d = ImageDraw.Draw(im)
    d.polygon([(70, 40), (190, 192), (70, 344), (120, 344), (230, 192), (120, 40)], fill=(20, 20, 20))
    d.rectangle([4, 4, W - 5, H - 5], outline=(20, 20, 20), width=8)
    im.save(os.path.join(OUT, 'chevron.png'))


def limit40():
    n = 512
    im = Image.new('RGBA', (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse([4, 4, n - 4, n - 4], fill=(250, 250, 250, 255))
    d.ellipse([20, 20, n - 20, n - 20], outline=(206, 30, 36, 255), width=62)
    f = font(250)
    bb = d.textbbox((0, 0), '40', font=f)
    d.text((n / 2 - (bb[0] + bb[2]) / 2, n / 2 - (bb[1] + bb[3]) / 2), '40', font=f, fill=(24, 60, 140, 255))
    im.save(os.path.join(OUT, 'limit40.png'))


def plume_png(path):
    """a susuki plume: a nodding stem with a dozen fine branches, each feathered with silky hairs; RGBA"""
    W, H = 256, 1024
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    r = np.random.default_rng(5)
    cx = W / 2
    for b in range(16):
        y0 = 40 + b * 45 + r.uniform(-10, 10)
        side = -1 if b % 2 else 1
        L = r.uniform(380, 620) * (1 - b / 40)
        ang = math.radians(r.uniform(4, 12)) * side
        pts = []
        for t in np.linspace(0, 1, 30):
            x = cx + math.sin(ang) * L * t + side * 8 * t ** 2
            y = y0 + math.cos(ang) * L * t
            pts.append((x, y))
        for k, (x, y) in enumerate(pts):
            for _ in range(10):
                hl = r.uniform(12, 34) * (1 - k / 40)
                a = math.radians(r.uniform(-50, 50)) + (0.4 * side)
                x2, y2 = x + math.sin(a) * hl, y + abs(math.cos(a)) * hl * 0.7
                c = int(r.uniform(205, 245))
                tint = r.uniform(0, 1)
                col = (c, int(c * (0.88 + 0.06 * tint)), int(c * (0.80 + 0.08 * tint)), int(r.uniform(150, 240)))
                d.line([(x, y), (x2, y2)], fill=col, width=1)
        d.line(pts, fill=(150, 120, 95, 255), width=2)
    d.line([(cx, 0), (cx, 60)], fill=(140, 120, 90, 255), width=3)
    im = im.filter(ImageFilter.GaussianBlur(0.6))
    im.save(path)


if __name__ == '__main__':
    import time; t = time.time()
    asphalt(); kikko(); concrete(); litter(); grass(); rock(); chevron(); limit40()
    plume_png(os.path.join(OUT, 'susuki_plume.png'))
    if len(sys.argv) > 1:
        import json
        kl = json.loads(open(sys.argv[1]).read())
        hairpin_signs([(k, n) for k, n in kl])
    print(f'textures in {time.time() - t:.0f} s:', sorted(os.listdir(OUT)))
