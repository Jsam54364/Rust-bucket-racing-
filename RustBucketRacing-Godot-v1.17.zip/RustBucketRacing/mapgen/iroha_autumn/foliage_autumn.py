"""The foliage packs (LOLIPOP, CC BY 4.0: oak, maple, fir, bush, grass) in autumn, through Mt. Haruna's foliage
module (../haruna/foliage.py: the packs' billboards taken apart into impostors, real meshes by the road): each
broadleaf impostor made in a few autumn colours (its leaf pixels brought to that colour, a little mottled), the firs
a dark green, the bushes red, the grass gone to straw."""
import os, sys
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(HERE, '..', 'haruna'))           # (last: this folder's own modules come first)
import foliage as FOL

# leaf colours (sRGB means the leaf pixels are brought to)
# (the game lights leaves brighter than a photo sees them: held a little short of full saturation)
TINT = {'y': (158, 132, 60), 'o': (164, 94, 48), 'r': (132, 46, 34), 'u': (124, 80, 48), 'v': (108, 110, 54),
        'g': (58, 78, 46), 'b': (136, 58, 40), 's': (146, 128, 84)}
CURRENT = {'tint': None}

FOL.TREES = {}
for k, (pk, m) in {'oak_big1': ('oak', 'Big_oak_tree__001'), 'oak_big3': ('oak', 'Big_oak_tree__003'),
                   'oak_large1': ('oak', 'Large_oak_tree_001'), 'oak_large2': ('oak', 'Large_oak_tree_002'),
                   'oak_med2': ('oak', 'Medium_oak_tree__002')}.items():
    for t in 'youv': FOL.TREES[f'{k}_{t}'] = (pk, m)
for k, (pk, m) in {'maple_large1': ('maple', 'Acer_large_1'), 'maple_large3': ('maple', 'Acer_large_3'),
                   'maple_med1': ('maple', 'Acer_medium_1')}.items():
    for t in 'roy': FOL.TREES[f'{k}_{t}'] = (pk, m)
for k, (pk, m) in {'fir1': ('fir', 'Christmas tree'), 'fir3': ('fir', 'Christmas tree_3'), 'fir6': ('fir', 'Christmas tree_6')}.items():
    FOL.TREES[f'{k}_g'] = (pk, m)
for k, (pk, m) in {'bush_big1': ('bush', 'Bush_big_001'), 'bush_big3': ('bush', 'Bush_big_003')}.items():
    for t in 'bo': FOL.TREES[f'{k}_{t}'] = (pk, m)

# by the road: grass clumps (straw), small bushes (red), young oaks and maples
PACK_TINT = {'grass': 's', 'bush': 'b', 'oak': 'o', 'maple': 'r', 'fir': 'g'}
_haruna_grade = FOL.grade


def grade(im, packname, contrast=1.6):
    """the leaf pixels brought to an autumn colour (the impostor being made, else the pack's own), mottled with
    a second colour near it so a crown isn't one flat hue"""
    t = CURRENT['tint'] or PACK_TINT.get(packname)
    if t is None: return _haruna_grade(im, packname)
    a = np.asarray(im, np.float32)
    rgb, al = a[..., :3], a[..., 3]
    leaf = (al > 128) & (rgb[..., 1] >= 0.95 * rgb[..., 0]) & (rgb[..., 1] >= rgb[..., 2])
    if not leaf.any(): return im
    target = np.array(TINT[t], np.float32)
    mean = rgb[leaf].mean(0)
    gain = target / np.maximum(mean, 1)
    out = rgb[leaf] * gain
    lum = out.mean(1, keepdims=True); lm = float(lum.mean())
    out = out * ((lum - lm) * contrast + lm) / np.maximum(lum, 1)
    if t in 'youbrv':
        # mottling: patches a step warmer or cooler (red <-> orange <-> yellow)
        from scipy.ndimage import gaussian_filter
        r = np.random.default_rng(sum(map(ord, t)))
        n = gaussian_filter(r.normal(size=al.shape), 6.0); n = (n - n.mean()) / (n.std() + 1e-9)
        shift = np.clip(n[leaf], -1.5, 1.5)[:, None]
        warm = np.array([1.06, 0.86, 0.88], np.float32); cool = np.array([0.96, 1.08, 1.04], np.float32)
        f = np.where(shift > 0, 1 + (warm - 1) * shift, 1 + (cool - 1) * -shift)
        out = out * f
    rgb = rgb.copy(); rgb[leaf] = out
    return Image.fromarray(np.dstack([np.clip(rgb, 0, 255), al]).astype(np.uint8), 'RGBA')


FOL.grade = grade


def load():
    """the impostors (each in its colour) and the meshes"""
    for k, (pk, m) in FOL.TREES.items():
        CURRENT['tint'] = k.rsplit('_', 1)[1]
        FOL.IMPOSTORS[k] = FOL.Impostor(k, pk, m)
    CURRENT['tint'] = None
    for k, (pk, m, lod) in FOL.MESHES.items(): FOL.MODELS[k] = FOL.Model(k, pk, m, lod)
    return FOL.IMPOSTORS, FOL.MODELS
