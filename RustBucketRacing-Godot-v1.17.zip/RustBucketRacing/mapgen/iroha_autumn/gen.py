"""Build the Irohazaka Autumn map: the First Irohazaka (第一いろは坂), National Route 120's one-way descent from Lake
Chuzenji to Umagaeshi at Nikko, 7.1 km, 28 hairpins (な 21 to ん 48), in mid-October colour. Made from GSI Japan's
open data (出典：国土地理院) with the Blender build's geometry (geo.py: the road, its paint, walls, gutters, bridges,
the ground, guardrail runs, hairpins, the forest's trees from the aerial photos) and textures drawn for it (tex.py,
cover.py, assets.py); nothing from other games or mods.

    python3 tex.py hairpins.json && python3 cover.py && python3 geo.py     # (geo.npz, tex/: ~30 s)
    GODOT=/path/to/godot python3 gen.py iroha_autumn.bin                  # (~2 min)
    python3 -I ../bake/bake_light.py iroha_autumn.bin --sky qwantani_afternoon_puresky

The pack's line runs up the hill (the game's stages: the bottom line is the start, the top line the finish; the
downhill start puts the car above the top line facing down)."""
import os, sys, time, json
import numpy as np
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d, median_filter
from scipy.spatial import cKDTree

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(1, os.path.join(HERE, '..', 'compound'))
import assets as AS
import foliage_autumn as FA
FOL = FA.FOL
from geom import Mesh, strip, grid_tris, quad

OUT = next((a for a in sys.argv[1:] if not a.startswith('--')), 'iroha_autumn.bin')
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)
rng = np.random.default_rng(48)

G = dict(np.load(os.path.join(HERE, 'geo.npz')))
ST_S, ST_P, ST_N, ST_T, ST_K, ST_Y = G['ST_S'], G['ST_P'], G['ST_N'], G['ST_T'], G['ST_K'], G['ST_Y']
ED = {-1: G['ED_LO'], 1: G['ED_HI']}; EY = {-1: G['EY_LO'], 1: G['EY_HI']}
WH = {-1: G['WH_lo'], 1: G['WH_hi']}; RAILF = {-1: G['RAIL_lo'], 1: G['RAIL_hi']}
BRIDGE = G['BRIDGE']; NS = len(ST_S); L = float(ST_S[-1])
ST_R = 1 / np.maximum(np.abs(ST_K), 1e-4)
EDGE_TREE = cKDTree(np.vstack([ST_P + ST_N * ED[-1][:, None], ST_P + ST_N * ED[1][:, None]]))
GUTTER_W = 0.45
END_IN = 45.0            # the stage's lines this far in from either end of the road


def m(name):
    return G[f'm_{name}_P'].astype(np.float64), G[f'm_{name}_UV'].astype(np.float64), G[f'm_{name}_I'].astype(np.int64)


def runs(flags, min_len=1):
    out, i = [], 0
    while i < len(flags):
        if flags[i]:
            j = i
            while j + 1 < len(flags) and flags[j + 1]: j += 1
            if j - i + 1 >= min_len: out.append((i, j))
            i = j + 1
        else: i += 1
    return out


def face_normals(P, I):
    fn = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])
    return fn / np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-12)


def vertex_normals(P, I):
    fn = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])
    N = np.zeros_like(P)
    for k in range(3): np.add.at(N, I[:, k], fn)
    return N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-12)


# ---------------------------------------------------------------- road, paint, ground, walls, bridges
_st_tree = cKDTree(ST_P)


def over_road(C):
    """ground triangles (centroids C) lying on the road's own footprint at about its height: at the bridges'
    ends the ground model can reach over the deck (geo.py keeps the ground off the road everywhere else)"""
    _, i = _st_tree.query(C[:, [0, 2]])
    d = C[:, [0, 2]] - ST_P[i]
    lat = np.einsum('ij,ij->i', d, ST_N[i]); lon = np.einsum('ij,ij->i', d, ST_T[i])
    return (np.abs(lon) < 2.5) & (lat > ED[-1][i] - 0.1) & (lat < ED[1][i] + 0.1) & (C[:, 1] > ST_Y[i] - 1.5)


def covers_road(P, I):
    """ground triangles over any point of the road (13 across it at every station) at or above its surface"""
    import matplotlib.tri as mtri
    RP = G['m_road_P'].reshape(NS, -1, 3).astype(np.float64)
    fr = np.linspace(0, 1, 13)
    Q = (RP[:, :1] + (RP[:, -1:] - RP[:, :1]) * fr[None, :, None]).reshape(-1, 3)
    used, inv = np.unique(I.ravel(), return_inverse=True)
    TT = mtri.Triangulation(P[used, 0], P[used, 2], inv.reshape(-1, 3))
    t = TT.get_trifinder()(Q[:, 0], Q[:, 2])
    hit = t >= 0
    bad = np.zeros(len(I), bool)
    if hit.any():
        y = mtri.LinearTriInterpolator(TT, P[used, 1])(Q[hit, 0], Q[hit, 2])
        y = np.asarray(y.filled(-1e9) if hasattr(y, 'filled') else y)
        over = y > Q[hit, 1] - 0.02
        bad[t[hit][over]] = True
    if bad.any(): log(f'  {int(bad.sum())} ground triangles over the road taken out')
    return bad
def surfaces(mesh):
    P, UV, I = m('road')
    mesh.add('road', P, UV / 4.0, I, phys=True)                      # (asphalt: 4 m to the picture)
    P, UV, I = m('paint_white')
    P = P.copy(); P[:, 1] += 0.006                                   # (12 mm over the road all told)
    mesh.add('paint', P, UV, I, N=np.tile([0.0, 1.0, 0.0], (len(P), 1)), phys=True)
    # the ground within REACH: one mesh per kind (shared vertices: smooth normals)
    for key, mat, tile in (('g_verge', 'verge', 2.0), ('g_fill', 'fill', 2.0), ('g_forest', 'forest', 2.0)):
        P, UV, I = m(key)
        I = I[~over_road(P[I].mean(1)) & ~covers_road(P, I)]
        fu = face_normals(P, I)
        mesh.add(mat, P, UV / tile, I, phys=fu[:, 1] > 0.45)
    # the cut faces: rock, mapped on the side they face (3 m to the picture)
    P, UV, I = m('g_cut')
    fu = face_normals(P, I)
    C3 = P[I].reshape(-1, 3)
    fx = np.repeat(np.abs(fu[:, 0]) > np.abs(fu[:, 2]), 3)
    U3 = np.c_[np.where(fx, C3[:, 2], C3[:, 0]) / 3.0, -C3[:, 1] / 3.0]
    VN = vertex_normals(P, I)
    mesh.add('cut', C3, U3, np.arange(len(C3)).reshape(-1, 3), N=VN[I].reshape(-1, 3), phys=np.repeat(False, len(I)))
    P, UV, I = m('g_wall')                                            # (kikko stones ~0.4 m: 5 to 2 m)
    mesh.add('wall', P, UV / 2.0, I, N=np.repeat(face_normals(P, I), 3, 0) if len(P) == 3 * len(I) else None, phys=False)
    P, UV, I = m('g_gutter')
    mesh.add('gutter', P, np.c_[UV[:, 0] / 2.0, UV[:, 1]], I, phys=True)
    P, UV, I = m('concrete')
    mesh.add('concrete', P, UV / 2.0, I, N=None, phys=False)
    log('road, paint, ground, walls, gutters, bridges')


def far_ground(mesh):
    """past REACH: the land in its autumn colours (drawn from the land cover maps) at 4 m a texel round the road,
    25 m out to 6 km, 52 m beyond; the coarse part (triangles over 130 m) in the backdrop's own chunk"""
    P, UV, I = m('g_far')
    VN = vertex_normals(P, I)
    lo = ST_P.min(0) - 800; hi = ST_P.max(0) + 800
    span = 480 * 4.0
    near = AS.Drape('near', float(lo[0]), float(lo[1]), int(np.ceil((hi[0] - lo[0]) / span)), int(np.ceil((hi[1] - lo[1]) / span)), 4.0)
    mid = AS.Drape('mid', -6000.0, -6000.0, 1, 1, 12000.0 / 480)
    far = AS.Drape('far', -12600.0, -12600.0, 1, 1, 25200.0 / 480)
    for d in (near, mid, far): AS.add_drape(d, 'ground')
    T = P[I]; cen = T.mean(1)
    longest = np.max([np.hypot(*(T[:, a, [0, 2]] - T[:, b, [0, 2]]).T) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    coarse = longest > 130
    n = 0
    for sel_all, cat in ((~coarse, 'ground'), (coarse, 'far')):
        for d in (near, mid, far):
            ok = (cen[:, 0] >= d.x0) & (cen[:, 0] < d.x0 + d.nx * d.span) & (cen[:, 2] >= d.z0) & (cen[:, 2] < d.z0 + d.nz * d.span)
            sel = np.nonzero(sel_all & ok)[0]
            sel_all = sel_all & ~ok
            if not len(sel): continue
            ci, cj = d.cell(cen[sel, 0], cen[sel, 2])
            for key in sorted(set(zip(ci.tolist(), cj.tolist()))):
                ss = sel[(ci == key[0]) & (cj == key[1])]
                Ii = I[ss]; C3 = P[Ii].reshape(-1, 3)
                name = d.key(*key) + ('' if cat == 'ground' else '_f')
                if name not in AS.MATERIALS: AS.MATERIALS[name] = AS.M(d.key(*key), cat, 0, spec=0.02)
                if cat == 'far': C3 = C3.copy(); C3[:, 1] -= 0.4
                mesh.add(name, C3, d.uv(key[0], key[1], C3[:, 0], C3[:, 2]), np.arange(len(C3)).reshape(-1, 3),
                         N=VN[Ii].reshape(-1, 3), phys=False)
                n += len(ss)
    log(f'far ground: {n} triangles ({int(coarse.sum())} coarse), {len(near.keys())} near layers')


# ---------------------------------------------------------------- the ground's height (for what stands on it)
def ground_interp():
    import matplotlib.tri as mtri
    Ps, Is, n0 = [], [], 0
    for key in ('g_verge', 'g_fill', 'g_forest', 'g_cut', 'g_gutter', 'g_far'):
        P, UV, I = m(key)
        Ps.append(P); Is.append(I + n0); n0 += len(P)
    P = np.vstack(Ps); I = np.vstack(Is)
    # (one vertex per spot, the higher where two meet: walls' and gutters' vertices repeat)
    key = np.round(P[:, [0, 2]] / 0.02).astype(np.int64)
    uk, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = inv.ravel()
    Y = np.full(len(uk), -1e9); np.maximum.at(Y, inv, P[:, 1])
    I2 = inv[I]
    good = (I2[:, 0] != I2[:, 1]) & (I2[:, 1] != I2[:, 2]) & (I2[:, 0] != I2[:, 2])
    TT = mtri.Triangulation(P[first, 0], P[first, 2], I2[good])
    f = mtri.LinearTriInterpolator(TT, Y)
    def at(x, z):
        v = f(np.asarray(x, float), np.asarray(z, float))
        return np.asarray(v.filled(np.nan) if hasattr(v, 'filled') else v, float)
    return at


# ---------------------------------------------------------------- guardrails and collisions
def barriers(mesh, gy):
    """guardrails where geo.py put them (drops, the outside of tight bends); collisions along them, along the walls'
    feet, over level verges where the ground rises or 5 m out, along the bridges' parapets, across both ends"""
    total = 0.0
    for side in (-1, 1):
        o = ST_N * side
        edge = ST_P + ST_N * ED[side][:, None]
        ey = EY[side]
        rail = RAILF[side]
        for i0, i1 in runs(rail, 2):
            idx = np.arange(i0, i1 + 1)
            pts = edge[idx] + o[idx] * 0.62
            base = ey[idx] - 0.02
            strip(mesh, 'guardrail', pts, base, base + 1.0, 4.0, face=-o[idx], tilt=0.15)
            mesh.wall_line(pts, base - 0.6, base + 1.2)
            total += float(np.hypot(*np.diff(pts, axis=0).T).sum())
        wall = WH[side] > 0
        for i0, i1 in runs(wall, 2):
            idx = np.arange(i0, i1 + 1)
            mesh.wall_line(edge[idx] + o[idx] * (GUTTER_W + 0.14), ey[idx] - 0.6, ey[idx] + WH[side][idx] + 0.4)
        # bridges: the parapets
        for i0, i1 in runs(BRIDGE, 2):
            idx = np.arange(max(i0 - 1, 0), min(i1 + 2, NS))
            mesh.wall_line(edge[idx] + o[idx] * 0.15, ey[idx] - 0.5, ey[idx] + 1.4)
            # the brown steel railing along the parapet's top
            strip(mesh, 'rail_brown', edge[idx] + o[idx] * 0.17, ey[idx] + 1.0, ey[idx] + 1.32, 2.0, face=-o[idx], tilt=0.1)
        # the rest: where the ground rises within 5 m, at the rise; else 5 m out
        rest = ~ndimage.binary_dilation(rail | wall | BRIDGE, structure=np.ones(3))
        samples = np.array([1.2, 2.0, 3.0, 4.0, 5.0])
        xz = (edge[:, None, :] + o[:, None, :] * samples[None, :, None]).reshape(-1, 2)
        y = gy(xz[:, 0], xz[:, 1]).reshape(NS, len(samples))
        rise_at = np.full(NS, 5.0)
        for i in range(NS):
            k = np.nonzero(np.nan_to_num(y[i] - ey[i], nan=0.0) > 0.6)[0]
            if len(k): rise_at[i] = samples[k[0]]
        off = gaussian_filter1d(median_filter(rise_at, 7, mode='nearest'), 1.5, mode='nearest')
        for i0, i1 in runs(rest, 2):
            idx = np.arange(max(i0 - 1, 0), min(i1 + 2, NS))
            mesh.wall_line(edge[idx] + o[idx] * off[idx, None], ey[idx] - 1.0, ey[idx] + 3.0)
    for i in (0, NS - 1):
        a = ST_P[i] + ST_N[i] * (ED[-1][i] - 6); b = ST_P[i] + ST_N[i] * (ED[1][i] + 6)
        mesh.wall(a, b, ST_Y[i] - 2, ST_Y[i] + 4)
    log(f'guardrail {total / 1000:.2f} km; {len(mesh.walls)} wall segments')


# ---------------------------------------------------------------- signs, the snow shed
def board(mesh, mat, p, y, face, w, h, top, flip=False, pole=True):
    """a board w x h with its top `top` m above y, facing `face` (unit x, z), on a pole; a grey back"""
    fx, fz = face; rx, rz = fz, -fx
    c = np.array([p[0], p[1]])
    A = (c[0] - rx * w / 2, y + top - h, c[1] - rz * w / 2); B = (c[0] + rx * w / 2, y + top - h, c[1] + rz * w / 2)
    Cc = (B[0], y + top, B[2]); D = (A[0], y + top, A[2])
    u0, u1 = (1, 0) if flip else (0, 1)
    quad(mesh, mat, A, B, Cc, D, uv=((u0, 1), (u1, 1), (u1, 0), (u0, 0)), split=None)
    bk = lambda q: (q[0] - fx * 0.02, q[1], q[2] - fz * 0.02)
    quad(mesh, 'sign_back', bk(B), bk(A), bk(D), bk(Cc), split=None)
    if pole:
        r = 0.035
        x, z = c[0] - fx * 0.05, c[1] - fz * 0.05
        for a in (0, np.pi / 2):
            cs, sn = np.cos(a) * r, np.sin(a) * r
            quad(mesh, 'post', (x - cs, y - 0.6, z - sn), (x + cs, y - 0.6, z + sn), (x + cs, y + top - h, z + sn), (x - cs, y + top - h, z - sn), split=None)


def signs(mesh, gy):
    """each bend's sign (its kana and n/48, our design) 35 m before it on the left; five chevrons round its
    outside (not where a wall or bridge is); the 40 km/h limit at the top"""
    HP = G['HP']; n = 0
    for i, num, sgn in HP:
        j = int(np.searchsorted(ST_S, ST_S[i] - 35.0))
        p = ST_P[j] + ST_N[j] * (ED[-1][j] - 1.0)
        yb = gy(p[0:1], p[1:2])[0]
        yb = EY[-1][j] if not np.isfinite(yb) else min(yb, EY[-1][j] + 0.5)
        board(mesh, f'sign_{num}', p, yb, -ST_T[j], 0.6, 0.8, 2.3 + (EY[-1][j] - yb))
        n += 1
        out_side = -int(sgn) if sgn != 0 else 1
        for d in (-24, -12, 0, 12, 24):
            k = int(np.clip(np.searchsorted(ST_S, ST_S[i] + d), 0, NS - 1))
            if BRIDGE[k] or WH[out_side][max(k - 3, 0):k + 4].max() > 0: continue
            p = ST_P[k] + ST_N[k] * (ED[out_side][k] + out_side * 0.95)
            ey = EY[out_side][k]
            face = -ST_T[k] + ST_N[k] * (-out_side) * 0.35; face = face / np.linalg.norm(face)
            board(mesh, 'chevron', p, ey, face, 0.45, 0.68, 1.39, flip=(sgn < 0))
            n += 1
    j = 20
    p = ST_P[j] + ST_N[j] * (ED[-1][j] - 1.0)
    board(mesh, 'limit40', p, EY[-1][j], -ST_T[j], 0.6, 0.6, 2.5)
    log(f'signs: {n + 1}')


def snow_shed(mesh):
    """the covered gallery: a roof over the road from the hillside, on columns along the valley side"""
    for i0, i1, valley in G['SHEDS']:
        idx = np.arange(max(i0 - 2, 0), min(i1 + 3, NS))
        hill = -valley
        h = 5.2
        a = ST_P[idx] + ST_N[idx] * (ED[valley][idx] + valley * 1.0)[:, None]
        b = ST_P[idx] + ST_N[idx] * (ED[hill][idx] + hill * 1.2)[:, None]
        y = np.maximum(EY[-1][idx], EY[1][idx]) + h
        for k in range(len(idx) - 1):
            A = (a[k][0], y[k], a[k][1]); B = (a[k + 1][0], y[k + 1], a[k + 1][1]); Cc = (b[k + 1][0], y[k + 1], b[k + 1][1]); D = (b[k][0], y[k], b[k][1])
            up = np.cross(np.subtract(B, A), np.subtract(D, A))[1] > 0
            quad(mesh, 'concrete', *((A, B, Cc, D) if up else (A, D, Cc, B)), split=None)             # (the top)
            Ab, Bb, Cb, Db = ((q[0], q[1] - 0.6, q[2]) for q in (A, B, Cc, D))
            quad(mesh, 'concrete', *((Ab, Db, Cb, Bb) if up else (Ab, Bb, Cb, Db)), split=None)        # (underneath)
        s = ST_S[idx]
        for d in np.arange(0.0, s[-1] - s[0], 5.0):
            k = int(np.searchsorted(s - s[0], d))
            c = ST_P[idx[k]] + ST_N[idx[k]] * (ED[valley][idx[k]] + valley * 0.6)
            y0 = EY[valley][idx[k]] - 0.4
            r = 0.25
            corners = [(c[0] - r, c[1] - r), (c[0] + r, c[1] - r), (c[0] + r, c[1] + r), (c[0] - r, c[1] + r)]
            for q in range(4):
                p0, p1 = corners[q], corners[(q + 1) % 4]
                quad(mesh, 'concrete', (p0[0], y0, p0[1]), (p1[0], y0, p1[1]), (p1[0], y[k] - 0.6, p1[1]), (p0[0], y[k] - 0.6, p0[1]), split=None)
            mesh.wall((c[0] - r, c[1]), (c[0] + r, c[1]), y0, y[k])
    log(f'snow sheds: {len(G["SHEDS"])}')


# ---------------------------------------------------------------- the forest
OAKS = ['oak_large1', 'oak_large2', 'oak_big1', 'oak_big3']
MAPLES = ['maple_large1', 'maple_large3']
FIRS = ['fir1', 'fir3', 'fir6']


def trees(mesh, gy):
    """geo.py's trees (where the photos show forest): all within 40 m of the road, fewer further out; each an
    impostor in an autumn colour, sized by its class, never reaching over the road"""
    T = G['TREES']
    X, Y, Z = T[:, 0].astype(float), T[:, 1].astype(float), T[:, 2].astype(float)
    kind, size, rnd, turn, sc = T[:, 3].astype(int), T[:, 4].astype(int), T[:, 5], T[:, 6], T[:, 7]
    dd = EDGE_TREE.query(np.c_[X, Z])[0]
    keep = rng.random(len(T)) < np.where(dd < 40, 1.0, np.where(dd < 150, 0.55, 0.32))
    keep &= (kind < 3)
    log(f'trees: {int(keep.sum())} of {int((kind < 3).sum())}')
    target_h = {0: (5.5, 10.0, 18.0), 1: (6.0, 11.0, 17.0), 2: (5.0, 12.0, 22.0)}
    n_t = n_small = 0
    for k in (0, 1, 2):
        for s in (0, 1, 2):
            q = np.nonzero(keep & (kind == k) & (size == s))[0]
            if not len(q): continue
            if k == 0: names = OAKS if s == 2 else ['oak_med2']; cols = ('y', 'o', 'u', 'v'); cp = (0.36, 0.3, 0.2, 0.14)
            elif k == 1: names = MAPLES if s == 2 else ['maple_med1']; cols = ('r', 'o', 'y'); cp = (0.5, 0.3, 0.2)
            else: names = FIRS; cols = ('g',); cp = (1.0,)
            nm_pick = np.minimum((rnd[q] * len(names)).astype(int), len(names) - 1)
            col_pick = np.searchsorted(np.cumsum(cp), np.mod(rnd[q] * 7.31, 1.0))
            col_pick = np.minimum(col_pick, len(cols) - 1)
            for a, nm in enumerate(names):
                for b, c in enumerate(cols):
                    qq = q[(nm_pick == a) & (col_pick == b)]
                    if not len(qq): continue
                    imp = FOL.IMPOSTORS[f'{nm}_{c}']
                    S_ = target_h[k][s] / imp.height * sc[qq]
                    lim = (dd[qq] - 1.0) / imp.half_width
                    n_small += int((S_ > lim).sum())
                    S_ = np.minimum(S_, lim)
                    ok = S_ >= 0.3 * target_h[k][s] / imp.height
                    qq, S_ = qq[ok], S_[ok]
                    imp.add(mesh, X[qq], Y[qq] - 0.3, Z[qq], S_, turn[qq], np.zeros(len(qq), bool))
                    n_t += len(qq)
    # bushes at the edge of the woods (impostors)
    q = np.nonzero(kind == 3)[0]
    pick = rng.integers(0, 4, len(q))
    for a, nm in enumerate(['bush_big1_b', 'bush_big1_o', 'bush_big3_b', 'bush_big3_o']):
        qq = q[pick == a]
        FOL.IMPOSTORS[nm].add(mesh, X[qq], Y[qq] - 0.1, Z[qq], 0.9 * sc[qq] * (1 + size[qq] * 0.4), turn[qq], np.zeros(len(qq), bool))
    log(f'trees: {n_t} impostors ({n_small} made smaller to keep clear of the road), {len(q)} big bushes')


def verges(mesh, gy):
    """real meshes by the road: grass clumps gone to straw on the verges, small bushes, young oaks and maples"""
    def along(step, lo, hi, jitter, p_keep):
        out = []
        for side in (-1, 1):
            ok = ~BRIDGE & (WH[side] <= 0)
            s = np.arange(0, L, step) + rng.uniform(-jitter, jitter, int(np.ceil(L / step)))
            i = np.clip(np.searchsorted(ST_S, s), 0, NS - 1)
            i = i[ok[i] & (rng.random(len(i)) < p_keep)]
            o = rng.uniform(lo, hi, len(i))
            o = np.where(RAILF[side][i], np.maximum(o, 1.05), o)
            xz = ST_P[i] + ST_N[i] * (ED[side][i] + side * o)[:, None]
            y = gy(xz[:, 0], xz[:, 1])
            good = np.isfinite(y) & (np.abs(y - EY[side][i]) < 4.0)
            out.append(np.c_[xz[good, 0], y[good], xz[good, 1]])
        return np.vstack(out)
    def place(models, X, scale, sink=0.05):
        pick = rng.integers(0, len(models), len(X))
        for i_, name in enumerate(models):
            q = np.nonzero(pick == i_)[0]
            if len(q): FOL.MODELS[name].add(mesh, X[q, 0], X[q, 1] - sink, X[q, 2], rng.uniform(*scale, len(q)), rng.uniform(0, 2 * np.pi, len(q)))
        return len(X)
    ng = place(['grass_l1', 'grass_l2', 'grass_l3', 'grass_m1', 'grass_m3'], along(1.0, 0.75, 3.5, 0.45, 0.8), (1.1, 2.0))
    nb = place(['bush_m1', 'bush_m2', 'bush_m3', 'bush_s1', 'bush_s3'], along(14.0, 2.0, 6.0, 6.0, 0.6), (1.0, 1.8))
    ny = place(['oak_small1', 'oak_small2', 'oak_small3', 'maple_sap2', 'maple_small3', 'oak_sap1', 'oak_sap2'], along(30.0, 4.5, 9.0, 12.0, 0.6), (0.9, 1.4))
    log(f'by the road: {ng} grass clumps, {nb} bushes, {ny} young trees')


def main():
    import writer as W
    mesh = Mesh()
    surfaces(mesh)
    far_ground(mesh)
    gy = ground_interp()
    barriers(mesh, gy)
    signs(mesh, gy)
    snow_shed(mesh)
    FA.load()
    trees(mesh, gy)
    verges(mesh, gy)
    st = mesh.stats()
    log(f'mesh: {sum(v for v, _ in st.values())} vertices, {sum(t for _, t in st.values())} triangles, {len(mesh.walls)} walls')
    for k, (v, t) in sorted(st.items(), key=lambda kv: -kv[1][1])[:14]: print(f'    {k:22s} {t:8d} tris')
    ftex, fmats = FOL.textures_and_materials(AS.M)
    AS.TEXTURES.update(ftex); AS.MATERIALS.update(fmats)
    mats, mat_index, images = AS.build_tables(set(mesh.parts))
    # the line up the hill: Umagaeshi first
    line = ST_P[::-1].astype(np.float32); lineY = ST_Y[::-1].astype(np.float32)
    stage = dict(start=round(END_IN, 2), finish=round(L - END_IN, 2))
    meta = dict(width=round(float(np.median(ED[1] - ED[-1])), 2), loop=False, merge=True, stage=stage,
                credit='The First Irohazaka (Route 120) for Rust Bucket Racing from GSI Japan open data (出典：国土地理院: '
                       'road centrelines, 5 m elevation, aerial photos); trees, bushes and grass from LOLIPOP\'s oak, maple, '
                       'fir, bush and grass packs (CC BY 4.0); textures and signs drawn for the map')
    info = W.write_pack(OUT, mesh, mats, mat_index, images, line, lineY, meta, 'Irohazaka Autumn', L)
    yt = float(np.interp(END_IN, ST_S, ST_Y)); yb = float(np.interp(L - END_IN, ST_S, ST_Y))
    log(f'stage: {L - 2 * END_IN:.0f} m between the lines, {yt - yb:.0f} m drop; done', info)


if __name__ == '__main__':
    main()
