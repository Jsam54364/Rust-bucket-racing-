// The skies the cars see in their paint, glass and chrome (shaders/car.gdshaderinc): a map's HDRI panorama made
// small (512 x 256, half floats) with mip levels standing in for the blur of rougher finishes, as mobile games do it
// (one static environment, prefiltered once; CSR Racing 2 and the like). Below the horizon the photo's flat grey is
// replaced by the ground as it looks under this sun and sky, with a soft band of distant trees and hills along the
// horizon (the dark line along a car's flank that makes it read as standing somewhere). The garage gets the studio
// panorama: soft boxes in a dark cove over a dark floor.
using System;
using Godot;

namespace RustBucket.Render
{
    public static class CarEnv
    {
        public const int W = 512, H = 256;
        const float MaxMip = 7;      // 4 x 2 texels: a fully rough finish

        static string mapSky;
        static ImageTexture mapTex, studioTex;

        // the panorama's texels (linear RGB, row by row from the top), decoded from the game's .sky files (RGB9E5)
        public static float[] Decode(byte[] rgba, int w, int h)
        {
            var o = new float[w * h * 3];
            for (int i = 0; i < w * h; i++)
            {
                uint v = (uint)(rgba[i * 4] | rgba[i * 4 + 1] << 8 | rgba[i * 4 + 2] << 16 | rgba[i * 4 + 3] << 24);
                float s = MathF.Pow(2, (int)(v >> 27) - 15 - 9);
                o[i * 3] = (v & 0x1ff) * s; o[i * 3 + 1] = ((v >> 9) & 0x1ff) * s; o[i * 3 + 2] = ((v >> 18) & 0x1ff) * s;
            }
            return o;
        }

        // halved to W x H (2 x 2 averages, as often as needed), then each texel through fix(elevation in degrees, colour)
        static ImageTexture Build(float[] src, int sw, int sh, Func<float, Vector3, Vector3> fix)
        {
            while (sw > W)
            {
                int nw = sw / 2, nh = sh / 2;
                var d = new float[nw * nh * 3];
                for (int y = 0; y < nh; y++)
                    for (int x = 0; x < nw; x++)
                        for (int c = 0; c < 3; c++)
                        {
                            int a = ((2 * y) * sw + 2 * x) * 3 + c, b = ((2 * y + 1) * sw + 2 * x) * 3 + c;
                            d[(y * nw + x) * 3 + c] = 0.25f * (src[a] + src[a + 3] + src[b] + src[b + 3]);
                        }
                src = d; sw = nw; sh = nh;
            }
            var bytes = new byte[sw * sh * 12];
            for (int y = 0; y < sh; y++)
            {
                float el = 90f - (y + 0.5f) / sh * 180f;
                for (int x = 0; x < sw; x++)
                {
                    int i = (y * sw + x) * 3;
                    var c = fix(el, new Vector3(src[i], src[i + 1], src[i + 2]));
                    BitConverter.TryWriteBytes(new Span<byte>(bytes, i * 4, 4), c.X);
                    BitConverter.TryWriteBytes(new Span<byte>(bytes, i * 4 + 4, 4), c.Y);
                    BitConverter.TryWriteBytes(new Span<byte>(bytes, i * 4 + 8, 4), c.Z);
                }
            }
            var img = Image.CreateFromData(sw, sh, false, Image.Format.Rgbf, bytes);
            img.Convert(Image.Format.Rgbh);
            img.GenerateMipmaps();
            return ImageTexture.CreateFromImage(img);
        }

        static float Smooth(float a, float b, float x) { float t = Math.Clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); }

        // the map's sky: rotation and strength as the panorama is drawn; ground = how the ground below the horizon
        // looks (screen units)
        public static void SetMap(SkyInfo s, float rotation, float energy, Vector3 ground)
        {
            if (s == null) { RenderingServer.GlobalShaderParameterSet("car_env_cfg", new Vector4(0, 1, 0, 0)); return; }
            if (s.Name != mapSky || mapTex == null)
            {
                var px = Skies.Pixels(s);
                if (px == null) { RenderingServer.GlobalShaderParameterSet("car_env_cfg", new Vector4(0, 1, 0, 0)); return; }
                // the sky just above the horizon (its haze), for the far trees and the ground's sheen at grazing angles
                var hz = Vector3.Zero; int n = 0;
                for (int y = (int)(s.H * 0.47f); y < s.H / 2; y++)
                    for (int x = 0; x < s.W; x += 4) { int i = (y * s.W + x) * 3; hz += new Vector3(px[i], px[i + 1], px[i + 2]); n++; }
                hz /= Math.Max(n, 1);
                var g = ground / Math.Max(energy, 1e-3f);
                var trees = g * 0.55f + hz * 0.3f;
                mapTex = Build(px, s.W, s.H, (el, c) =>
                {
                    if (el <= 0) return g.Lerp(hz * 0.7f, 0.45f * MathF.Exp(el / 3f));
                    float w = 0.6f * (1 - Smooth(0, 7, el));
                    return c.Lerp(trees, w);
                });
                mapSky = s.Name;
            }
            RenderingServer.GlobalShaderParameterSet("car_env", mapTex);
            RenderingServer.GlobalShaderParameterSet("car_env_cfg", new Vector4(rotation, energy, MaxMip, H));
        }

        // the garage: the studio panorama's soft boxes, its walls darkened to the cove's, a dark floor
        public static void SetStudio(float energy)
        {
            if (studioTex == null)
            {
                var s = Skies.Get(Skies.Studio);
                var px = s != null && s.Name == Skies.Studio ? Skies.Pixels(s) : null;
                if (px == null) return;
                float floor = 0.03f / energy;
                studioTex = Build(px, s.W, s.H, (el, c) =>
                {
                    if (el <= 0) return new Vector3(floor, floor, floor * 1.08f).Lerp(c * 0.12f, 0.5f * MathF.Exp(el / 2f));
                    float lum = c.Dot(new Vector3(0.2126f, 0.7152f, 0.0722f));
                    return c * Mathf.Lerp(0.16f, 1f, Smooth(0.7f, 1.2f, lum));
                });
            }
            RenderingServer.GlobalShaderParameterSet("car_studio_env", studioTex);
            RenderingServer.GlobalShaderParameterSet("car_studio_cfg", new Vector4(0, energy, MaxMip, H));
        }
    }
}
