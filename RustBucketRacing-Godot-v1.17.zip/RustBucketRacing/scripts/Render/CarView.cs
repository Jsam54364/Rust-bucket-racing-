// A car model: body, four wheels, optional non-spinning hubs (callipers) and steering wheel, posed every frame
// from the simulation. Monte Carlo and CTS-V come from multi-material car packs (tools/convert_*.py, the same
// files the web version embeds); the Rust Bucket is an imported GLB.
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    // how a car is painted in the garage: its colour (or the factory's), a second colour for the livery, the finish,
    // how dark the windows are and the livery
    public sealed class CarLook
    {
        public static readonly string[] FinishNames = { "Factory", "Gloss", "Metallic", "Pearl", "Matte" };
        public static readonly string[] TintNames = { "Factory", "Light", "Medium", "Dark", "Limo" };
        public static readonly string[] LiveryNames = { "Factory", "Plain", "Twin stripes", "Side stripe", "Two-tone", "Centre stripe" };
        // metallic, roughness, clear coat, its roughness
        static readonly Vector4[] Finishes = { new Vector4(-1, 0, 0, 0), new Vector4(0, 0.12f, 1, 0.03f), new Vector4(0.7f, 0.3f, 1, 0.03f), new Vector4(0.35f, 0.2f, 1, 0.02f), new Vector4(0, 0.62f, 0, 0.3f) };
        static readonly float[] TintAlpha = { 0, 0.45f, 0.65f, 0.82f, 0.93f };

        public bool Custom;                                  // a colour of your own (otherwise the factory's)
        public Color Paint = new Color(0.78f, 0.08f, 0.07f);
        public Color Paint2 = new Color(0.95f, 0.95f, 0.95f);
        public int Finish, Tint, Livery;

        public CarLook Clone() => (CarLook)MemberwiseClone();
        public static Vector4 FinishOf(int i) => Finishes[Math.Clamp(i, 0, Finishes.Length - 1)];
        public static float TintAlphaOf(int i) => TintAlpha[Math.Clamp(i, 0, TintAlpha.Length - 1)];
    }

    // which parts of a model are paint and glass, and what its factory paint is
    public sealed class PaintDef
    {
        public string[] Mats = Array.Empty<string>();      // the painted materials, by name
        public string[] Parts;                             // only on these parts (null: on any)
        public int Mode = 1;                               // car.gdshaderinc paint_mode for a plain repaint
        public Color Factory = new Color(0.8f, 0.8f, 0.8f); // the factory colour (sRGB)
        public Vector3 RefHsv; public float RefLum = 0.5f; // modes 2 and 3: the factory paint as the texture has it
        public bool FactoryLivery;                         // the factory paint is a printed livery (its texture)
        public string[] Windows = Array.Empty<string>();   // the window glass, by name (the lamps' lenses are not)
    }

    public sealed class CarView
    {
        public static readonly string[] WheelNames = { "wheel_FL", "wheel_FR", "wheel_RL", "wheel_RR" };

        public readonly Node3D Root = new Node3D { Name = "Car" };
        Node3D body, steer;
        readonly Node3D[] wheels = new Node3D[4], hubs = new Node3D[4];
        bool hasSteer;
        Vector3 steerPivot, steerAxis = Vector3.Forward;
        // glass: as the model came, and as it is now (window tint)
        sealed class Glass
        {
            public ShaderMaterial M; public string Name; public bool Mix;
            public float Alpha0, Spec; public Color Lin0; public Texture2D Tex0;
            public float Alpha; public Color Lin;
        }
        readonly List<Glass> glass = new List<Glass>();
        // every material of the model: the car shaders (car.gdshaderinc), made from the model's own materials
        readonly List<ShaderMaterial> all = new List<ShaderMaterial>();
        // the painted ones: copies of those on the painted parts, made when the car is first shown
        readonly List<ShaderMaterial> paints = new List<ShaderMaterial>();
        readonly List<bool> paintTex = new List<bool>();
        PaintDef paintDef;
        static Shader opaqueShader, cutShader, glassShader, glassMixShader;
        bool studio;
        // the visual layer of a car's meshes: the garage's fill lights leave it out (the studio's panorama does that)
        public const uint Layer = 2;
        bool inside;
        float insideAlpha = 0.04f;
        float scale = 1; Basis scaleB = Basis.Identity;

        // the model drawn at this size about its origin (on the ground, midway between the axles)
        public float ModelScale
        {
            get => scale;
            set { scale = value; scaleB = Basis.Identity.Scaled(new Vector3(value, value, value)); }
        }

        Node3D Part(string name)
        {
            var n = new Node3D { Name = name };
            Root.AddChild(n);
            return n;
        }

        /* ---------------- car pack: 'RBCP' | u32 json length | json | blob ---------------- */
        public static CarView FromPack(byte[] buf)
        {
            if (buf.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 0, 4)) != 0x50434252) throw new Exception("not a car pack");
            int jl = (int)BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 4, 4));
            int bas = 8 + jl;
            var cv = new CarView();
            using var doc = JsonDocument.Parse(new ReadOnlyMemory<byte>(buf, 8, jl));
            var h = doc.RootElement;
            // gzipped geometry (gz = [offset, length, raw length]): primitive buffers index the unpacked block
            byte[] gbuf = buf; int gbase = bas;
            if (h.TryGetProperty("gz", out var gz) && gz.ValueKind == JsonValueKind.Array)
            {
                var g = Nums(gz);
                using var ms = new MemoryStream(buf, bas + (int)g[0], (int)g[1]);
                using var zs = new GZipStream(ms, CompressionMode.Decompress);
                using var outMs = new MemoryStream((int)g[2]);
                zs.CopyTo(outMs);
                gbuf = outMs.ToArray(); gbase = 0;
            }
            // textures
            var texList = new List<Texture2D>();
            foreach (var im in h.GetProperty("images").EnumerateArray())
            {
                var a = Nums(im, 2);
                string mime = "image/webp";
                int k = 0;
                foreach (var e in im.EnumerateArray()) { if (k == 2 && e.ValueKind == JsonValueKind.String) mime = e.GetString(); k++; }
                var bytes = new byte[(int)a[1]];
                Buffer.BlockCopy(buf, bas + (int)a[0], bytes, 0, bytes.Length);
                Texture2D t = null;
                try { t = MeshUtil.LoadImage(bytes, mime); } catch (Exception ex) { GD.PushWarning("car texture: " + ex.Message); }
                texList.Add(t);
            }
            // materials
            var mats = new List<StandardMaterial3D>();
            var noShadow = new List<bool>();
            var glassOf = new List<int>();
            foreach (var m in h.GetProperty("materials").EnumerateArray())
            {
                var col = m.TryGetProperty("color", out var c) ? Nums(c) : new double[] { 1, 1, 1 };
                double alpha = Num(m, "alpha", 1);
                int mode = (int)Num(m, "mode", 0);
                int tex = m.TryGetProperty("tex", out var tx) && tx.ValueKind == JsonValueKind.Number ? (int)Math.Round(tx.GetDouble()) : -1;
                int mr = m.TryGetProperty("mr", out var mx) && mx.ValueKind == JsonValueKind.Number ? (int)Math.Round(mx.GetDouble()) : -1;
                var lin = new Color((float)col[0], (float)col[1], (float)col[2], 1f);
                var sm = new StandardMaterial3D
                {
                    ResourceName = m.TryGetProperty("name", out var mn) && mn.ValueKind == JsonValueKind.String ? mn.GetString() : "",
                    // pack colours are linear (glTF factors); albedo_color is sRGB
                    AlbedoColor = lin.LinearToSrgb(),
                    Metallic = (float)Num(m, "metal", 0),
                    Roughness = (float)Math.Clamp(Num(m, "rough", 0.8), 0.06, 1.0),
                    // how strongly a non-metal reflects head-on (0.5 = 4 %, plain plastic; car paint under its clear coat more)
                    MetallicSpecular = (float)Math.Clamp(Num(m, "spec", 0.5), 0, 1),
                    CullMode = BaseMaterial3D.CullModeEnum.Disabled,
                    TextureFilter = BaseMaterial3D.TextureFilterEnum.LinearWithMipmapsAnisotropic,
                };
                // a metal/rough map (red: metallic, green: roughness) scaling the two factors: chrome reflectors and
                // coloured lenses sharing one lamp texture
                if (mr >= 0 && mr < texList.Count && texList[mr] != null)
                {
                    sm.MetallicTexture = texList[mr]; sm.MetallicTextureChannel = BaseMaterial3D.TextureChannel.Red;
                    sm.RoughnessTexture = texList[mr]; sm.RoughnessTextureChannel = BaseMaterial3D.TextureChannel.Green;
                }
                var ac = sm.AlbedoColor; ac.A = (float)alpha; sm.AlbedoColor = ac;
                if (tex >= 0 && tex < texList.Count && texList[tex] != null) sm.AlbedoTexture = texList[tex];
                double cc = Num(m, "cc", 0);
                if (cc > 0) { sm.ClearcoatEnabled = true; sm.Clearcoat = (float)cc; sm.ClearcoatRoughness = (float)Math.Clamp(Num(m, "ccRough", 0.03), 0.03, 1.0); }
                if (mode == 1) { sm.Transparency = BaseMaterial3D.TransparencyEnum.AlphaScissor; sm.AlphaScissorThreshold = 0.5f; }
                else if (mode == 2)
                {
                    // glass and lenses: tinted and blended with premultiplied alpha, so the reflections stay at full
                    // strength however clear the glass is, as on a real window (its own colour is scaled by how
                    // opaque it is here; glass textures come premultiplied)
                    // ("blend": "mix" keeps the plain blend, reflections dimmed with the colour: plastic race windows)
                    bool mix = m.TryGetProperty("blend", out var bl) && bl.ValueKind == JsonValueKind.String && bl.GetString() == "mix";
                    sm.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
                    if (!mix) sm.BlendMode = BaseMaterial3D.BlendModeEnum.PremultAlpha;
                    sm.Roughness = Math.Min(sm.Roughness, 0.08f);
                    float gs = (float)Math.Clamp(Num(m, "spec", 0.6), 0, 1);
                    sm.MetallicSpecular = gs;
                    if (!mix) sm.AlbedoColor = Premul(lin, (float)alpha);
                    cv.glass.Add(new Glass { M = null, Name = sm.ResourceName, Mix = mix, Alpha0 = (float)alpha, Alpha = (float)alpha, Spec = gs, Lin0 = lin, Lin = lin, Tex0 = sm.AlbedoTexture });
                    glassOf.Add(mats.Count);
                }
                mats.Add(sm);
                noShadow.Add(m.TryGetProperty("noShadow", out var ns) && ns.ValueKind == JsonValueKind.True);
            }
            // all as the car shaders
            var smats = new List<ShaderMaterial>();
            foreach (var sm in mats) smats.Add(cv.Own(ToShader(sm)));
            for (int i = 0; i < cv.glass.Count; i++) cv.glass[i].M = smats[glassOf[i]];
            // parts: each becomes a node with up to two mesh instances (shadow casters and the rest)
            foreach (var part in h.GetProperty("parts").EnumerateObject())
            {
                var meshCast = new ArrayMesh(); var meshNo = new ArrayMesh();
                foreach (var pr in part.Value.GetProperty("prims").EnumerateArray())
                {
                    int mat = (int)Num(pr, "mat", 0);
                    var posRef = Nums(pr.GetProperty("pos"));
                    var lo = Nums(pr.GetProperty("posLo")); var rng = Nums(pr.GetProperty("posRng"));
                    int nv = (int)posRef[1] / 6;
                    var pos = new Vector3[nv];
                    for (int i = 0; i < nv; i++)
                    {
                        int o = gbase + (int)posRef[0] + i * 6;
                        pos[i] = new Vector3(
                            (float)(lo[0] + U16(gbuf, o) / 65535.0 * rng[0]),
                            (float)(lo[1] + U16(gbuf, o + 2) / 65535.0 * rng[1]),
                            (float)(lo[2] + U16(gbuf, o + 4) / 65535.0 * rng[2]));
                    }
                    var norRef = Nums(pr.GetProperty("nor"));
                    var nrm = new Vector3[nv];
                    for (int i = 0; i < nv; i++)
                    {
                        int o = gbase + (int)norRef[0] + i * 3;
                        var n = new Vector3((sbyte)gbuf[o] / 127f, (sbyte)gbuf[o + 1] / 127f, (sbyte)gbuf[o + 2] / 127f);
                        nrm[i] = n.LengthSquared() > 1e-8f ? n.Normalized() : Vector3.Up;
                    }
                    Vector2[] uv = null;
                    if (pr.TryGetProperty("uv", out var uvp) && uvp.ValueKind == JsonValueKind.Array)
                    {
                        var uvRef = Nums(uvp);
                        var ulo = Nums(pr.GetProperty("uvLo")); var urng = Nums(pr.GetProperty("uvRng"));
                        uv = new Vector2[nv];
                        for (int i = 0; i < nv; i++)
                        {
                            int o = gbase + (int)uvRef[0] + i * 4;
                            uv[i] = new Vector2((float)(ulo[0] + U16(gbuf, o) / 65535.0 * urng[0]), (float)(ulo[1] + U16(gbuf, o + 2) / 65535.0 * urng[1]));
                        }
                    }
                    var idxRef = Nums(pr.GetProperty("idx"));
                    bool i32 = pr.TryGetProperty("idx32", out var b32) && b32.ValueKind == JsonValueKind.True;
                    int ni = i32 ? (int)idxRef[1] / 4 : (int)idxRef[1] / 2;
                    var idx = new int[ni];
                    for (int i = 0; i < ni; i++)
                    {
                        int o = gbase + (int)idxRef[0] + i * (i32 ? 4 : 2);
                        idx[i] = i32 ? (int)BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(gbuf, o, 4)) : U16(gbuf, o);
                    }
                    if (nv == 0 || ni < 3) continue;
                    MeshUtil.Reverse(idx);
                    bool ns = mat >= 0 && mat < noShadow.Count && noShadow[mat];
                    var target = ns ? meshNo : meshCast;
                    target.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, MeshUtil.Arrays(pos, nrm, uv, null, idx));
                    if (mat >= 0 && mat < smats.Count) target.SurfaceSetMaterial(target.GetSurfaceCount() - 1, smats[mat]);
                }
                var node = cv.Part(part.Name);
                if (meshCast.GetSurfaceCount() > 0) node.AddChild(new MeshInstance3D { Mesh = meshCast, Layers = Layer });
                if (meshNo.GetSurfaceCount() > 0) node.AddChild(new MeshInstance3D { Mesh = meshNo, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off, Layers = Layer });
                cv.Assign(part.Name, node);
            }
            // steering wheel pivot
            if (h.TryGetProperty("meta", out var meta) && meta.TryGetProperty("steer", out var st))
            {
                var pv = Nums(st.GetProperty("pivot")); var ax = Nums(st.GetProperty("axis"));
                cv.steerPivot = new Vector3((float)pv[0], (float)pv[1], (float)pv[2]);
                var axis = new Vector3((float)ax[0], (float)ax[1], (float)ax[2]);
                cv.steerAxis = axis.LengthSquared() > 1e-8f ? axis.Normalized() : Vector3.Back;
                cv.hasSteer = cv.steer != null;
            }
            return cv;
        }

        /* ---------------- imported GLB (Rust Bucket): nodes body, wheel_FL, ... ---------------- */
        public static CarView FromScene(string resPath)
        {
            var cv = new CarView();
            var made = new Dictionary<Material, ShaderMaterial>();
            Material Conv(Material m)
            {
                if (!(m is StandardMaterial3D sm)) return m;
                if (!made.TryGetValue(m, out var s)) made[m] = s = cv.Own(ToShader(sm));
                return s;
            }
            var ps = GD.Load<PackedScene>(resPath);
            if (ps == null) throw new Exception("car model missing: " + resPath);
            var inst = ps.Instantiate<Node3D>();
            foreach (var name in new[] { "body", "wheel_FL", "wheel_FR", "wheel_RL", "wheel_RR" })
            {
                var src = Find(inst, name);
                if (src == null) continue;
                var node = cv.Part(name);
                var mi = new MeshInstance3D { Mesh = src.Mesh, Layers = Layer };
                for (int i = 0; i < src.Mesh.GetSurfaceCount(); i++)
                {
                    var om = src.MaterialOverride ?? src.GetSurfaceOverrideMaterial(i) ?? src.Mesh.SurfaceGetMaterial(i);
                    if (om != null) mi.SetSurfaceOverrideMaterial(i, Conv(om));
                }
                node.AddChild(mi);
                cv.Assign(name, node);
            }
            inst.QueueFree();
            if (cv.body == null) throw new Exception("car model has no body");
            return cv;
        }

        static MeshInstance3D Find(Node n, string name)
        {
            if (n is MeshInstance3D mi && (n.Name == name || ((string)n.Name).StartsWith(name))) return mi;
            foreach (var c in n.GetChildren())
            {
                var r = Find(c, name);
                if (r != null) return r;
            }
            return null;
        }

        void Assign(string name, Node3D node)
        {
            if (name == "body") body = node;
            else if (name == "steer") { steer = node; hasSteer = true; }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    if (name == WheelNames[i]) wheels[i] = node;
                    if (name == "hub_" + WheelNames[i].Substring(6)) hubs[i] = node;
                }
            }
        }

        static double Num(JsonElement e, string k, double def) =>
            e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : def;

        static double[] Nums(JsonElement e, int max = int.MaxValue)
        {
            var o = new List<double>();
            foreach (var x in e.EnumerateArray()) { if (o.Count >= max) break; o.Add(x.ValueKind == JsonValueKind.Number ? x.GetDouble() : 0); }
            return o.ToArray();
        }

        static int U16(byte[] b, int o) => b[o] | (b[o + 1] << 8);

        // a linear colour scaled by its opacity, as sRGB with that opacity (premultiplied alpha blending)
        static Color Premul(Color lin, float a)
        {
            var c = new Color(lin.R * a, lin.G * a, lin.B * a, 1f).LinearToSrgb();
            c.A = a;
            return c;
        }

        public static Transform3D CarMatrix(Car car)
        {
            var q = car.Q;
            var basis = new Basis(new Quaternion((float)q.X, (float)q.Y, (float)q.Z, (float)q.W).Normalized());
            var t = new Transform3D(basis, MeshUtil.V(car.Pos));
            return t * new Transform3D(Basis.Identity, -MeshUtil.V(car.ComModel));
        }

        // pose every part from the simulation; steerRatio turns the steering wheel with the front wheels
        public void Update(Car car, double steerRatio)
        {
            var carM = CarMatrix(car);
            if (body != null) body.Transform = carM * new Transform3D(scaleB, Vector3.Zero);
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i];
                var hub = MeshUtil.V(w.MountModel.X, w.MountModel.Y - w.DVis, w.MountModel.Z);
                var steerB = new Basis(Vector3.Up, (float)w.Steer);
                if (wheels[i] != null) wheels[i].Transform = carM * new Transform3D(steerB * new Basis(Vector3.Right, (float)-w.Spin) * scaleB, hub);
                // callipers steer with the wheel but don't spin
                if (hubs[i] != null) hubs[i].Transform = carM * new Transform3D(steerB * scaleB, hub);
            }
            if (hasSteer && steer != null)
            {
                double ang = (car.Wheels[0].Steer + car.Wheels[1].Steer) / 2 * steerRatio;
                steer.Transform = carM * new Transform3D(scaleB, Vector3.Zero) * new Transform3D(new Basis(new Quaternion(steerAxis, (float)ang)), steerPivot);
            }
        }

        // From the cabin the windows are close to clear: hardly any tint and only a faint reflection
        public void SetInside(bool on, float insideAlpha)
        {
            if (on == inside) return;
            inside = on; this.insideAlpha = insideAlpha;
            foreach (var gl in glass) ShowGlass(gl);
        }

        void ShowGlass(Glass gl)
        {
            float a = inside ? Math.Min(gl.Alpha, insideAlpha) : gl.Alpha;
            Color c;
            if (gl.Mix) { c = gl.Lin.LinearToSrgb(); c.A = a; }   // plain blend
            else c = Premul(gl.Lin, a);
            gl.M.SetShaderParameter("albedo", c);
            gl.M.SetShaderParameter("specular", inside ? 0.05f : gl.Spec);
        }

        // the garage's studio light (its panorama for the sky) or the map's
        public void SetStudio(bool on)
        {
            if (on == studio) return;
            studio = on;
            foreach (var m in all) m.SetShaderParameter("studio", on);
        }

        ShaderMaterial Own(ShaderMaterial m)
        {
            all.Add(m);
            if (studio) m.SetShaderParameter("studio", true);
            return m;
        }

        /* ---------------- paint, windows, livery (the garage) ---------------- */
        // the painted materials get copies of their own on the painted parts (once): the same look until painted
        public void PreparePaint(PaintDef def)
        {
            if (paintDef != null || def == null) return;
            paintDef = def;
            var made = new Dictionary<Material, ShaderMaterial>();
            foreach (var ch in Root.GetChildren())
            {
                if (!(ch is Node3D part)) continue;
                if (def.Parts != null && Array.IndexOf(def.Parts, (string)part.Name) < 0) continue;
                foreach (var c in part.GetChildren())
                {
                    if (!(c is MeshInstance3D mi) || mi.Mesh == null || mi.CastShadow == GeometryInstance3D.ShadowCastingSetting.ShadowsOnly) continue;
                    for (int i = 0; i < mi.Mesh.GetSurfaceCount(); i++)
                    {
                        var m = mi.GetSurfaceOverrideMaterial(i) ?? mi.MaterialOverride ?? mi.Mesh.SurfaceGetMaterial(i);
                        if (!(m is ShaderMaterial sm) || Array.IndexOf(def.Mats, sm.ResourceName) < 0) continue;
                        if (!made.TryGetValue(m, out var pm))
                        {
                            pm = Own((ShaderMaterial)sm.Duplicate());
                            made[m] = pm;
                            paints.Add(pm); paintTex.Add((bool)sm.GetShaderParameter("has_tex"));
                        }
                        mi.SetSurfaceOverrideMaterial(i, pm);
                    }
                }
            }
        }

        static Vector4 Channel(BaseMaterial3D.TextureChannel c) => c switch
        {
            BaseMaterial3D.TextureChannel.Red => new Vector4(1, 0, 0, 0),
            BaseMaterial3D.TextureChannel.Green => new Vector4(0, 1, 0, 0),
            BaseMaterial3D.TextureChannel.Blue => new Vector4(0, 0, 1, 0),
            BaseMaterial3D.TextureChannel.Alpha => new Vector4(0, 0, 0, 1),
            _ => new Vector4(1 / 3f, 1 / 3f, 1 / 3f, 0),
        };

        // a model's material as a car shader: opaque, alpha-tested, or glass (premultiplied or plain blend)
        static ShaderMaterial ToShader(StandardMaterial3D sm)
        {
            Shader sh;
            if (sm.Transparency == BaseMaterial3D.TransparencyEnum.AlphaScissor || sm.Transparency == BaseMaterial3D.TransparencyEnum.AlphaHash)
                sh = cutShader ??= GD.Load<Shader>("res://shaders/car_cut.gdshader");
            else if (sm.Transparency != BaseMaterial3D.TransparencyEnum.Disabled)
                sh = sm.BlendMode == BaseMaterial3D.BlendModeEnum.PremultAlpha
                    ? glassShader ??= GD.Load<Shader>("res://shaders/car_glass.gdshader")
                    : glassMixShader ??= GD.Load<Shader>("res://shaders/car_glass_mix.gdshader");
            else sh = opaqueShader ??= GD.Load<Shader>("res://shaders/car_paint.gdshader");
            var p = new ShaderMaterial { Shader = sh, ResourceName = sm.ResourceName };
            p.SetShaderParameter("albedo", sm.AlbedoColor);
            if (sm.AlbedoTexture != null) { p.SetShaderParameter("albedo_tex", sm.AlbedoTexture); p.SetShaderParameter("has_tex", true); }
            p.SetShaderParameter("metallic", sm.Metallic);
            p.SetShaderParameter("roughness", sm.Roughness);
            p.SetShaderParameter("specular", sm.MetallicSpecular);
            if (sm.MetallicTexture != null) { p.SetShaderParameter("metal_tex", sm.MetallicTexture); p.SetShaderParameter("metal_ch", Channel(sm.MetallicTextureChannel)); }
            if (sm.RoughnessTexture != null) { p.SetShaderParameter("rough_tex", sm.RoughnessTexture); p.SetShaderParameter("rough_ch", Channel(sm.RoughnessTextureChannel)); }
            if (sm.NormalEnabled && sm.NormalTexture != null)
            {
                p.SetShaderParameter("normal_tex", sm.NormalTexture); p.SetShaderParameter("has_normal", true); p.SetShaderParameter("normal_scale", sm.NormalScale);
            }
            if (sm.AOEnabled && sm.AOTexture != null)
            {
                p.SetShaderParameter("ao_tex", sm.AOTexture); p.SetShaderParameter("ao_ch", Channel(sm.AOTextureChannel)); p.SetShaderParameter("ao_affect", sm.AOLightAffect);
            }
            if (sm.ClearcoatEnabled) { p.SetShaderParameter("clearcoat", sm.Clearcoat); p.SetShaderParameter("clearcoat_rough", sm.ClearcoatRoughness); }
            if (sm.Transparency != BaseMaterial3D.TransparencyEnum.Disabled) p.RenderPriority = sm.RenderPriority;
            return p;
        }

        public bool HasWindows => paintDef != null && glass.Exists((g) => Array.IndexOf(paintDef.Windows, g.Name) >= 0);
        public bool CanPaint => paints.Count > 0;

        // the garage's paint, windows and livery on this model (bodyLo/Hi: the body's extents in the model's frame)
        public void ApplyLook(CarLook k, Vector3 bodyLo, Vector3 bodyHi)
        {
            var d = paintDef;
            if (d == null || k == null) return;
            bool pattern = k.Livery >= 2;
            bool plain = d.FactoryLivery && k.Livery >= 1;              // the printed livery taken off
            bool on = k.Custom || pattern || plain || k.Finish > 0;
            Color col = k.Custom ? k.Paint : d.Factory;
            for (int i = 0; i < paints.Count; i++)
            {
                var p = paints[i];
                int mode = !on ? 0 : plain ? 1 : d.FactoryLivery ? 3 : d.Mode;
                p.SetShaderParameter("paint_mode", mode);
                p.SetShaderParameter("has_tex", paintTex[i] && mode != 1);
                p.SetShaderParameter("paint", col);
                p.SetShaderParameter("paint2", k.Paint2);
                p.SetShaderParameter("ref_hsv", d.RefHsv);
                p.SetShaderParameter("ref_lum", d.RefLum);
                p.SetShaderParameter("livery", pattern ? k.Livery : 0);
                p.SetShaderParameter("box_lo", bodyLo); p.SetShaderParameter("box_hi", bodyHi);
                p.SetShaderParameter("finish", CarLook.FinishOf(k.Finish));
            }
            // windows: darker glass, one colour (no texture) once tinted
            foreach (var gl in glass)
            {
                if (Array.IndexOf(d.Windows, gl.Name) < 0) continue;
                if (k.Tint <= 0) { gl.Alpha = gl.Alpha0; gl.Lin = gl.Lin0; gl.M.SetShaderParameter("has_tex", gl.Tex0 != null); }
                else { gl.Alpha = Math.Max(gl.Alpha0, CarLook.TintAlphaOf(k.Tint)); gl.Lin = new Color(0.012f, 0.014f, 0.017f); gl.M.SetShaderParameter("has_tex", false); }
                ShowGlass(gl);
            }
        }

        public void SetVisible(bool v) => Root.Visible = v;

        /* ---------------- shadow stand-in ----------------
           The real models are hundreds of thousands of triangles; drawing them a second time into the shadow map
           was most of the cost of shadows. They no longer cast shadows; a stand-in of about 150 triangles does:
           the body as a box to the waist, a roof on four pillars (so sunlight still comes in through the windows),
           and an eight-sided disc per wheel that turns and steers with it. It is a little inside the real body, so
           the body is not shaded by it on the sides the sun reaches. Sizes come from the physics hull (car frame,
           unscaled), so mirrors and aerials don't stretch it. */
        public void AddShadowProxy(CarSpec spec)
        {
            NoShadows(Root);
            double k = spec.GeomScale > 0 ? spec.GeomScale : 1; // the hull is in scaled metres; the model is unscaled here
            float x0 = (float)(spec.HullMinX / k), x1 = (float)(spec.HullMaxX / k), y0 = (float)(spec.HullMinY / k), y1 = (float)(spec.HullMaxY / k);
            float z0 = (float)(spec.HullMinZ / k), z1 = (float)(spec.HullMaxZ / k);
            float w = (x1 - x0) * 0.47f, len = z1 - z0, zc = (z0 + z1) / 2, belt = y0 + (y1 - y0) * 0.48f;
            var st = new SurfaceTool();
            st.Begin(Mesh.PrimitiveType.Triangles);
            // lower body to the waist, lower and narrower towards the bumpers (a box's corners and top edge stuck out
            // through the rounded nose and tail and the sloping bonnet and boot, and their shadows striped the paint)
            float yb = y0 + 0.04f, zf = z0 + len * 0.22f, zr = z1 - len * 0.17f;
            float tf = yb + (belt - yb) * 0.72f, tr = yb + (belt - yb) * 0.8f;
            Segment(st, z0 + len * 0.03f, w * 0.78f, tf, zf, w, belt, yb);
            Segment(st, zf, w, belt, zr, w, belt, yb);
            Segment(st, zr, w, belt, z1 - len * 0.03f, w * 0.82f, tr, yb);
            // roof slab and pillars: cabin from about 30 % to 78 % of the length (front to back), roof a little shorter
            float cz0 = z0 + len * 0.30f, cz1 = z0 + len * 0.78f, rw = w * 0.86f, ry0 = y1 - 0.07f * (y1 - y0), ry1 = y1 - 0.02f * (y1 - y0);
            Box(st, new Vector3(-rw, ry0, cz0 + len * 0.06f), new Vector3(rw, ry1, cz1 - len * 0.03f));
            float pw = 0.07f;
            foreach (float px in new[] { -rw, rw - pw })
            {
                Slant(st, px, pw, cz0, belt, cz0 + len * 0.06f, ry0);       // A-pillar, raked back
                Slant(st, px, pw, cz1, belt, cz1 - len * 0.03f, ry0);       // C-pillar
            }
            st.GenerateNormals();
            var proxy = new MeshInstance3D { Name = "ShadowProxy", Mesh = st.Commit(), CastShadow = GeometryInstance3D.ShadowCastingSetting.ShadowsOnly, Layers = Layer };
            if (body != null) body.AddChild(proxy);
            // wheels: an eight-sided disc each
            for (int i = 0; i < 4; i++)
            {
                if (wheels[i] == null) continue;
                bool front = i < 2;
                float r = (float)((front && spec.WheelRadiusF > 0 ? spec.WheelRadiusF : spec.WheelRadius) / k) * 0.97f;
                float hw = (float)(spec.WheelWidth / k) * 0.5f;
                var ws = new SurfaceTool();
                ws.Begin(Mesh.PrimitiveType.Triangles);
                Disc(ws, r, hw, 8);
                ws.GenerateNormals();
                wheels[i].AddChild(new MeshInstance3D { Name = "ShadowProxy", Mesh = ws.Commit(), CastShadow = GeometryInstance3D.ShadowCastingSetting.ShadowsOnly, Layers = Layer });
            }
        }

        static void NoShadows(Node n)
        {
            if (n is GeometryInstance3D g) g.CastShadow = GeometryInstance3D.ShadowCastingSetting.Off;
            foreach (var c in n.GetChildren()) NoShadows(c);
        }

        static void Quad(SurfaceTool st, Vector3 a, Vector3 b, Vector3 c, Vector3 d)
        {
            st.AddVertex(a); st.AddVertex(b); st.AddVertex(c);
            st.AddVertex(a); st.AddVertex(c); st.AddVertex(d);
        }

        static void Box(SurfaceTool st, Vector3 lo, Vector3 hi) => Hexa(st,
            new Vector3(lo.X, lo.Y, lo.Z), new Vector3(hi.X, lo.Y, lo.Z), new Vector3(hi.X, lo.Y, hi.Z), new Vector3(lo.X, lo.Y, hi.Z),
            new Vector3(lo.X, hi.Y, lo.Z), new Vector3(hi.X, hi.Y, lo.Z), new Vector3(hi.X, hi.Y, hi.Z), new Vector3(lo.X, hi.Y, hi.Z));

        // a length of the lower body from za to zb: half-width and top height at each end, the bottom at yb
        static void Segment(SurfaceTool st, float za, float wa, float ta, float zb, float wb, float tb, float yb) => Hexa(st,
            new Vector3(-wa, yb, za), new Vector3(wa, yb, za), new Vector3(wb, yb, zb), new Vector3(-wb, yb, zb),
            new Vector3(-wa, ta, za), new Vector3(wa, ta, za), new Vector3(wb, tb, zb), new Vector3(-wb, tb, zb));

        // a pillar: a thin slab from (z at the waist) up to (z at the roof)
        static void Slant(SurfaceTool st, float x, float w, float zBottom, float yBottom, float zTop, float yTop)
        {
            const float d = 0.06f;
            Hexa(st,
                new Vector3(x, yBottom, zBottom - d), new Vector3(x + w, yBottom, zBottom - d), new Vector3(x + w, yBottom, zBottom + d), new Vector3(x, yBottom, zBottom + d),
                new Vector3(x, yTop, zTop - d), new Vector3(x + w, yTop, zTop - d), new Vector3(x + w, yTop, zTop + d), new Vector3(x, yTop, zTop + d));
        }

        // eight corners: bottom face 0-3, top face 4-7 (same order); faces both ways, so winding doesn't matter
        static void Hexa(SurfaceTool st, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4, Vector3 p5, Vector3 p6, Vector3 p7)
        {
            Vector3[] v = { p0, p1, p2, p3, p4, p5, p6, p7 };
            int[,] f = { { 0, 1, 2, 3 }, { 4, 7, 6, 5 }, { 0, 4, 5, 1 }, { 1, 5, 6, 2 }, { 2, 6, 7, 3 }, { 3, 7, 4, 0 } };
            for (int i = 0; i < 6; i++)
            {
                Quad(st, v[f[i, 0]], v[f[i, 1]], v[f[i, 2]], v[f[i, 3]]);
                Quad(st, v[f[i, 3]], v[f[i, 2]], v[f[i, 1]], v[f[i, 0]]);
            }
        }

        // a disc around the X axis (the axle), n sides
        static void Disc(SurfaceTool st, float r, float hw, int n)
        {
            for (int i = 0; i < n; i++)
            {
                float a0 = Mathf.Tau * i / n, a1 = Mathf.Tau * (i + 1) / n;
                var p0 = new Vector3(0, Mathf.Cos(a0) * r, Mathf.Sin(a0) * r);
                var p1 = new Vector3(0, Mathf.Cos(a1) * r, Mathf.Sin(a1) * r);
                var L = new Vector3(-hw, 0, 0); var R = new Vector3(hw, 0, 0);
                Quad(st, p0 + L, p1 + L, p1 + R, p0 + R);
                Quad(st, p0 + R, p1 + R, p1 + L, p0 + L);
                st.AddVertex(L); st.AddVertex(p0 + L); st.AddVertex(p1 + L);
                st.AddVertex(L); st.AddVertex(p1 + L); st.AddVertex(p0 + L);
                st.AddVertex(R); st.AddVertex(p0 + R); st.AddVertex(p1 + R);
                st.AddVertex(R); st.AddVertex(p1 + R); st.AddVertex(p0 + R);
            }
        }

        // nothing to draw (the model failed to load): the game still runs
        public static CarView Empty() => new CarView();
    }
}
