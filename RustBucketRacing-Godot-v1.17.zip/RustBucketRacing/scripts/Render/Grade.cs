// The picture's last step: the tone mapping and colour grade, as one 3D table for Godot's post pass.
//
// The renderer's own tone mappers each had a fault for this game: ACES (as before) clips everything a little over
// white (the sky's clouds and the sun on the paint burn out) and turns bright reds orange; AgX rolls the highlights
// off beautifully but turns saturated reds orange at any brightness (a red car came out orange). So the post pass
// runs with no tone mapping of its own and this table does it: a gentle contrast on brightness only (about mid-grey),
// a touch more saturation, then Khronos PBR Neutral (made for showing cars and products true to their colour: hues
// stay where they are, only the top of the range is compressed), softened to start lower and desaturate later, so
// sunlit red paint stays red and a bright sky stays blue instead of turning white. Mid-grey and the shadows come out
// about where ACES had them, so the maps keep the brightness they were made for.
//
// The table's input is the picture as the post pass hands it over: sRGB-encoded and clamped to 1 (measured: with
// linear tone mapping and the adjustments' brightness, contrast and saturation at 1 it comes through unchanged; a
// brightness below 1, to fit more over white, crushed the shadows to black). So the scene is drawn at SceneExposure
// (half the exposure), which keeps everything up to twice white for the table, and the table multiplies it by Gain
// before grading: highlights up to 3.2 times white roll off, and the rest is near white. Its texels sit at
// (i + 0.5) / N.
using System;
using Godot;

namespace RustBucket.Render
{
    public static class Grade
    {
        public const int N = 48;
        public const float Exposure = 1.6f, SceneExposure = 0.5f, Gain = Exposure / SceneExposure;
        public const float Contrast = 1.05f, Saturation = 1.06f;
        const float Start = 0.6f, Desat = 0.06f, Toe = 0.02f;    // PBR Neutral's: 0.76, 0.15 and 0.04

        static ImageTexture3D lut;

        static float Lum(Vector3 c) => 0.2126f * c.X + 0.7152f * c.Y + 0.0722f * c.Z;

        // Khronos PBR Neutral (https://github.com/KhronosGroup/ToneMapping), with its start and desaturation softened
        // and half its toe (the shade under trees and cars keeps its detail, about as dark as it was under ACES)
        static Vector3 Neutral(Vector3 c)
        {
            float x = Math.Min(c.X, Math.Min(c.Y, c.Z));
            float off = x < 2 * Toe ? x - x * x / (4 * Toe) : Toe;
            c -= new Vector3(off, off, off);
            float peak = Math.Max(c.X, Math.Max(c.Y, c.Z));
            if (peak < Start) return c;
            float d = 1 - Start;
            float np = 1 - d * d / (peak + d - Start);
            c *= np / peak;
            float g = 1 - 1 / (Desat * (peak - np) + 1);
            return c.Lerp(new Vector3(np, np, np), g);
        }

        // scene light (linear, after the exposure) to the colour shown (linear)
        public static Vector3 Apply(Vector3 L)
        {
            L = new Vector3(Math.Max(L.X, 0), Math.Max(L.Y, 0), Math.Max(L.Z, 0));
            float y = Math.Max(Lum(L), 1e-6f);
            float y2 = 0.18f * MathF.Pow(y / 0.18f, Contrast);
            L *= y2 / y;
            L = new Vector3(y2, y2, y2) + (L - new Vector3(y2, y2, y2)) * Saturation;
            return Neutral(new Vector3(Math.Max(L.X, 0), Math.Max(L.Y, 0), Math.Max(L.Z, 0)));
        }

        static float Srgb(float x) => x <= 0.0031308f ? 12.92f * x : 1.055f * MathF.Pow(x, 1 / 2.4f) - 0.055f;

        public static ImageTexture3D Table()
        {
            if (lut != null) return lut;
            var layers = new Godot.Collections.Array<Image>();
            var v = new float[N];
            for (int i = 0; i < N; i++)
            {
                // the scene light at texel i: sRGB undone, times the gain
                float s = (i + 0.5f) / N;
                v[i] = (s <= 0.04045f ? s / 12.92f : MathF.Pow((s + 0.055f) / 1.055f, 2.4f)) * Gain;
            }
            for (int b = 0; b < N; b++)
            {
                var d = new byte[N * N * 3];
                for (int g = 0; g < N; g++)
                    for (int r = 0; r < N; r++)
                    {
                        var o = Apply(new Vector3(v[r], v[g], v[b]));
                        int k = (g * N + r) * 3;
                        d[k] = (byte)Math.Clamp((int)MathF.Round(Srgb(Math.Clamp(o.X, 0, 1)) * 255), 0, 255);
                        d[k + 1] = (byte)Math.Clamp((int)MathF.Round(Srgb(Math.Clamp(o.Y, 0, 1)) * 255), 0, 255);
                        d[k + 2] = (byte)Math.Clamp((int)MathF.Round(Srgb(Math.Clamp(o.Z, 0, 1)) * 255), 0, 255);
                    }
                layers.Add(Image.CreateFromData(N, N, false, Image.Format.Rgb8, d));
            }
            lut = new ImageTexture3D();
            lut.Create(Image.Format.Rgb8, N, N, N, false, layers);
            return lut;
        }
    }
}
