"""read meshes, materials and images out of a .glb (glTF 2.0 binary): mesh-local geometry, no node transforms"""
import json, struct, numpy as np
CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}

def load(path):
    b = open(path, 'rb').read()
    cl = struct.unpack('<I', b[12:16])[0]; j = json.loads(b[20:20 + cl])
    off = 20 + cl; bl = struct.unpack('<I', b[off:off + 4])[0]; bin_ = b[off + 8: off + 8 + bl]
    def acc(i):
        a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
        dt = np.dtype(CT[a['componentType']]); n = NC[a['type']]
        start = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        stride = bv.get('byteStride', 0) or dt.itemsize * n
        raw = np.frombuffer(bin_, np.uint8, count=stride * (a['count'] - 1) + dt.itemsize * n, offset=start)
        out = np.lib.stride_tricks.as_strided(raw, (a['count'], n * dt.itemsize), (stride, 1)).copy().view(dt).reshape(a['count'], n)
        return out if n > 1 else out[:, 0]
    meshes = {}
    for m in j['meshes']:
        parts = []
        for p in m['primitives']:
            at = p['attributes']
            P = acc(at['POSITION']).astype(np.float64)
            N = acc(at['NORMAL']).astype(np.float64) if 'NORMAL' in at else None
            U = acc(at['TEXCOORD_0']).astype(np.float64) if 'TEXCOORD_0' in at else np.zeros((len(P), 2))
            I = acc(p['indices']).astype(np.int64).reshape(-1, 3) if 'indices' in p else np.arange(len(P)).reshape(-1, 3)
            parts.append(dict(P=P, N=N, U=U, I=I, mat=p.get('material', -1)))
        meshes[m['name']] = parts
    images = []
    for im in j.get('images', []):
        bv = j['bufferViews'][im['bufferView']]
        images.append(bin_[bv.get('byteOffset', 0): bv.get('byteOffset', 0) + bv['byteLength']])
    mats = []
    for mt in j.get('materials', []):
        pbr = mt.get('pbrMetallicRoughness', {})
        t = pbr.get('baseColorTexture', {}).get('index')
        mats.append(dict(name=mt['name'], image=j['textures'][t]['source'] if t is not None else None,
                         color=pbr.get('baseColorFactor', [1, 1, 1, 1]), alpha=mt.get('alphaMode', 'OPAQUE')))
    return dict(meshes=meshes, images=images, materials=mats, json=j)
