"""camera poses for previews: driver's eye on each course, a few views from above"""
import sys, numpy as np, layout as LY, terrain as TR
L = LY.build(); H0, roads, pads = TR.build(L)
out = []
def eye(name, k, s, look=60.0, h=1.3, side=0.0):
    rd = roads[k]; n = len(rd.P); j = int(s) % n; j2 = int(s + look) % n
    o = side
    p = rd.P[j] + rd.n[j] * o; q = rd.P[j2] + rd.n[j2] * o
    y1 = float(rd.surface(j, o)); y2 = float(rd.surface(j2, o))
    out.append(f'{name} {p[0]:.2f} {y1 + h:.2f} {p[1]:.2f} {q[0]:.2f} {y2 + h * 0.6:.2f} {q[1]:.2f}')
def at(name, p, q): out.append(f'{name} ' + ' '.join(f'{v:.2f}' for v in (*p, *q)))
gp = roads['gp']
eye('gp_start', 'gp', 30, 120, side=-2.9)
for i, s in enumerate(np.linspace(400, gp.L - 600, 12)): eye(f'gp_{i:02d}', 'gp', s, 70)
eye('int_a', 'int_link', 200, 70); eye('int_b', 'int_link', 600, 70)
eye('nat_a', 'nat_link', 400, 80); eye('nat_b', 'nat_link', 1000, 80)
eye('pit', 'pit', 300, 60)
ov = roads['oval']
eye('oval_a', 'oval', 60, 150, side=ov.out * 3); eye('oval_turn', 'oval', 700, 120, side=ov.out * 3); eye('oval_back', 'oval', 1100, 120, side=ov.out * 3)
eye('infield_rd', 'infield', 1500, 80); eye('infield_bridge', 'infield', 500, 120); eye('oval_gate', 'infield', roads['infield'].L - 90, 80)
eye('gate_bridge', 'gate', 250, 150); eye('gate_mid', 'gate', 1500, 100)
en = roads['enduro']
for i, s in enumerate(np.linspace(300, en.L - 1000, 8)): eye(f'en_{i}', 'enduro', s, 90)
eye('drift_a', 'drift', 20, 60); eye('drift_b', 'drift', 900, 60)
eye('drag', 'drag', 900, 300)
f = pads['paddock'][1]
at('paddock', (-450, f + 3, 640), (300, f, 700))
at('haulers', (100, f + 2.5, 690), (300, f + 1, 650))
at('grandstand', (200, f + 9, 520), (100, f + 2, 560))
s = pads['slalom'][1]; at('slalom', (-1270, s + 4, 690), (-950, s, 820))
at('oval_infield', (-150, 6, 100), (100, 0, -20))
at('air_center', (1500, 900, 2400), (200, 0, 0))
at('air_oval', (900, 260, 900), (0, 0, 0))
at('air_hill', (1400, 420, -400), (200, 40, -1200))
at('air_bridge', (1250, 60, -40), (880, 15, -100))
at('horizon', (0, 30, -3000), (0, 30, -9000))
open(sys.argv[1], 'w').write('\n'.join(out) + '\n')
print(len(out), 'cams')
