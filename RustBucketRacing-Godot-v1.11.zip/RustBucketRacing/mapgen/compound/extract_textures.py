"""the textures the compound borrows: every image of the Spa, Monte Carlo and Irohazaka packs, as tex_src/<pack>_<n>.png
usage: python3 extract_textures.py <folder with spa.bin, mcr.bin, iroha.bin>"""
import io, os, sys
from PIL import Image
import packread
src = sys.argv[1] if len(sys.argv) > 1 else '.'
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tex_src'); os.makedirs(out, exist_ok=True)
for pk in ('spa', 'mcr', 'iroha'):
    p = packread.load(os.path.join(src, pk + '.bin'))
    for i, b in enumerate(p['imgs']):
        Image.open(io.BytesIO(b)).save(os.path.join(out, f'{pk}_{i:03d}.png'))
    print(pk, len(p['imgs']), 'images')
