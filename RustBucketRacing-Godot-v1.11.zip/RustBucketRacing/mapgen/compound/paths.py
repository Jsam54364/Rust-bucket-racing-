"""Paths for the compound: polylines whose corners are filleted with given radii (straights joined by circular
arcs), lightly smoothed so the curvature ramps in and out, resampled at an even spacing."""
import numpy as np
from scipy.ndimage import gaussian_filter1d


def fillet(verts, closed, step=1.0):
    """verts: [(x, z, R)] corner points with fillet radius (R ignored at the ends of an open path).
    Returns points every `step` m along straights and arcs."""
    V = np.array([(v[0], v[1]) for v in verts], float)
    R = [v[2] if len(v) > 2 else 0 for v in verts]
    n = len(V)
    pts = []
    idx = range(n) if closed else range(1, n - 1)
    corners = {}
    for i in idx:
        a, b, c = V[(i - 1) % n], V[i], V[(i + 1) % n]
        u = (a - b) / np.linalg.norm(a - b); w = (c - b) / np.linalg.norm(c - b)
        ang = np.arccos(np.clip(u @ w, -1, 1))            # interior angle
        r = R[i]
        if r <= 0 or ang > np.pi - 1e-3: corners[i] = None; continue
        t = r / np.tan(ang / 2)
        ta, tc = b + u * t, b + w * t
        bis = (u + w) / np.linalg.norm(u + w)
        cen = b + bis * r / np.sin(ang / 2)
        corners[i] = (ta, tc, cen, r, t)
    # check the tangent lengths fit
    for i in idx:
        j = (i + 1) % n
        if not closed and j == n - 1: tj = 0
        else: tj = corners[j][4] if corners.get(j) else 0
        ti = corners[i][4] if corners.get(i) else 0
        L = np.linalg.norm(V[j] - V[i])
        if ti + tj > L + 1e-6: raise ValueError(f'corners {i} and {j}: fillets need {ti + tj:.0f} m, the side is {L:.0f} m')
    def arc(ta, tc, cen, r):
        a0 = np.arctan2(*(ta - cen)[::-1]); a1 = np.arctan2(*(tc - cen)[::-1])
        d = (a1 - a0 + np.pi) % (2 * np.pi) - np.pi
        k = max(2, int(abs(d) * r / step) + 1)
        th = a0 + d * np.linspace(0, 1, k)
        return cen + r * np.stack([np.cos(th), np.sin(th)], 1)
    seq = list(idx)
    if not closed: pts.append(V[0][None])
    for i in seq:
        cr = corners.get(i)
        if cr is None: pts.append(V[i][None]); continue
        ta, tc, cen, r, t = cr
        pts.append(arc(ta, tc, cen, r))
    if not closed: pts.append(V[-1][None])
    P = np.concatenate(pts)
    if closed: P = np.vstack([P, P[:1]])
    return resample(P, step, closed=False)[:-1] if closed else resample(P, step)


def resample(P, step, closed=False):
    if closed: P = np.vstack([P, P[:1]])
    d = np.hypot(*np.diff(P, axis=0).T); s = np.concatenate([[0], np.cumsum(d)])
    keep = np.r_[True, d > 1e-9]; P, s = P[keep], s[keep]
    n = max(2, int(round(s[-1] / step)))
    u = np.linspace(0, s[-1], n + 1)
    Q = np.stack([np.interp(u, s, P[:, 0]), np.interp(u, s, P[:, 1])], 1)
    return Q[:-1] if closed else Q


def smooth(P, sigma_m, closed, step=1.0):
    s = sigma_m / step
    mode = 'wrap' if closed else 'nearest'
    Q = np.stack([gaussian_filter1d(P[:, 0], s, mode=mode), gaussian_filter1d(P[:, 1], s, mode=mode)], 1)
    if not closed: Q[0], Q[-1] = P[0], P[-1]
    return resample(Q, step, closed)


def frame(P, closed):
    """tangent, left normal (x-z, z down: normal = tangent turned toward +... (-tz, tx)), signed curvature"""
    if closed:
        E = np.vstack([P[-2:], P, P[:2]]); t = np.gradient(E, axis=0)[2:-2]
    else:
        t = np.gradient(P, axis=0)
    t /= np.linalg.norm(t, axis=1, keepdims=True)
    nrm = np.stack([-t[:, 1], t[:, 0]], 1)
    ang = np.unwrap(np.arctan2(t[:, 1], t[:, 0]))
    ds = np.hypot(*np.gradient(P, axis=0).T)
    k = np.gradient(ang) / np.maximum(ds, 1e-9)
    k = gaussian_filter1d(k, 3, mode='wrap' if closed else 'nearest')
    return t, nrm, k


def length(P, closed):
    d = np.hypot(*np.diff(P, axis=0).T).sum()
    return d + (np.hypot(*(P[0] - P[-1])) if closed else 0)


def min_gap(P, Q, skip=0):
    """closest approach between two paths (or a path and itself away from neighbours when Q is P)"""
    from scipy.spatial import cKDTree
    t = cKDTree(Q)
    if Q is P:
        d, j = t.query(P, k=60)
        i = np.arange(len(P))[:, None]
        far = np.abs((j - i + len(P) // 2) % len(P) - len(P) // 2) > skip
        d = np.where(far, d, np.inf)
        return d.min(1)
    return t.query(P)[0]
