"""The race track assets pack ("Race Track Assets Pack" by Cherk, CC BY 4.0), cut down for the compound: each mesh
simplified with Godot's simplifier to a small triangle budget, textures to 512 px. kit.place() drops a copy into a
geom.Mesh at a position and heading."""
import os, io, struct, subprocess, tempfile, shutil, json
import numpy as np
from PIL import Image
import glb

HERE = os.path.dirname(os.path.abspath(__file__))
GLB = os.environ.get('ASSET_GLB', os.path.join(HERE, 'race_track_assets_pack.glb'))
CACHE = os.path.join(HERE, 'kit_cache.npz')
GODOT = os.environ.get('GODOT', '/home/claude/tools/Godot_v4.7.2-stable_linux.x86_64')
LODGEN = os.path.join(HERE, 'lodgen.gd')

# key -> (mesh name in the pack, triangle budget, material key in assets.MATERIALS)
PARTS = {
    'concrete':  ('barrier_concrete_barrier_concrete_0', 120, 'kit_concrete'),
    'srail':     ('s_rail_s_rail_0', 90, 'kit_srail'),
    'mast':      ('lighting_mast_lighting_mast_0', 440, 'kit_mast'),
    'lights':    ('lights_lights_0', 160, 'kit_lights'),
    'lights_gl': ('lights_lights_glass_0', 40, 'kit_glass'),
    'board50':   ('brake_tablet_50_brake_tablet_0', 12, 'kit_boards'),
    'board100':  ('brake_tablet_100_brake_tablet_0', 12, 'kit_boards'),
    'board150':  ('brake_tablet_150_brake_tablet_0', 12, 'kit_boards'),
    'board200':  ('brake_tablet_200_brake_tablet_0', 12, 'kit_boards'),
    'limit60':   ('speed_limit_60_speed_limit_0', 12, 'kit_signs'),
    'limit80':   ('speed_limit_80_speed_limit_0', 12, 'kit_signs'),
    'limit100':  ('speed_limit_100_speed_limit_0', 12, 'kit_signs'),
    'post':      ('post_clear_post_clear_0', 140, 'kit_post'),
}
TEX = {'kit_concrete': 'barrier_concrete', 'kit_srail': 's_rail', 'kit_mast': 'lighting_mast',
       'kit_lights': 'lights', 'kit_boards': 'brake_tablet', 'kit_signs': 'speed_limit', 'kit_post': 'post_clear'}
# the tyre barrier (170k triangles for 5 m) as pictures: orthographic albedo renders of its front and top
# (bake.gd), drawn on a three-sided strip
BAKED = {'kit_tyres_front': ('barrier_tyre', 'front', (512, 128)), 'kit_tyres_top': ('barrier_tyre', 'top', (512, 200)),
         'kit_conc_front': ('barrier_concrete_barrier_concrete_0', 'front', (512, 160)),
         'kit_conc_top': ('barrier_concrete_barrier_concrete_0', 'top', (512, 64)),
         'kit_rail_front': ('s_rail_s_rail_0', 'front', (512, 160)), 'kit_rail_back': ('s_rail_s_rail_0', 'back', (512, 160))}


def _bake(node, prefix):
    tmp = tempfile.mkdtemp(prefix='kitbake')
    open(os.path.join(tmp, 'project.godot'), 'w').write('config_version=5\n[application]\nconfig/name="kitbake"\n')
    shutil.copy(os.path.join(HERE, 'bake.gd'), os.path.join(tmp, 'bake.gd'))
    r = subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 1600x1200x24', GODOT, '--path', tmp, '--script', 'res://bake.gd', '--', GLB, node,
                        os.path.join(tmp, prefix), '200'], capture_output=True, text=True, timeout=600)
    out = {v: Image.open(os.path.join(tmp, f'{prefix}_{v}.png')).convert('RGBA') for v in ('front', 'top', 'back')}
    shutil.rmtree(tmp)
    return out


def _simplify(meshes):
    """LOD index lists for each (P, N, U, I) from Godot's simplifier (tools/lodgen.gd)"""
    tmp = tempfile.mkdtemp(prefix='kitlod')
    with open(os.path.join(tmp, 'in.bin'), 'wb') as fo:
        fo.write(b'LODI' + struct.pack('<I', len(meshes)))
        for P, N, U, I in meshes:
            fo.write(struct.pack('<II', len(P), I.size))
            fo.write(P.astype('<f4').tobytes()); fo.write(N.astype('<f4').tobytes()); fo.write(U.astype('<f4').tobytes()); fo.write(I.astype('<u4').tobytes())
    open(os.path.join(tmp, 'project.godot'), 'w').write('config_version=5\n[application]\nconfig/name="kitlod"\n')
    shutil.copy(LODGEN, os.path.join(tmp, 'lodgen.gd'))
    r = subprocess.run([GODOT, '--headless', '--path', tmp, '--script', 'res://lodgen.gd', '--', os.path.join(tmp, 'in.bin'), os.path.join(tmp, 'out.bin')],
                       capture_output=True, text=True, timeout=1800)
    if r.returncode != 0: print(r.stdout[-2000:], r.stderr[-2000:]); raise SystemExit('kit: simplifier failed')
    out = []
    with open(os.path.join(tmp, 'out.bin'), 'rb') as fi:
        assert fi.read(4) == b'LODO'
        (cnt,) = struct.unpack('<I', fi.read(4))
        for _ in range(cnt):
            (nl,) = struct.unpack('<I', fi.read(4)); lods = []
            for _ in range(nl):
                size, n = struct.unpack('<fI', fi.read(8))
                lods.append((size, np.frombuffer(fi.read(n * 4), '<u4').astype(np.int64).reshape(-1, 3)))
            out.append(lods)
    shutil.rmtree(tmp)
    return out


def _weld(P, N, U, I):
    """merge duplicate vertices (same position, normal and uv) so the simplifier sees connected surfaces"""
    k = np.c_[np.round(P * 2000), np.round(N * 50), np.round(U * 4000)].astype(np.int64)
    _, first, inv = np.unique(k, axis=0, return_index=True, return_inverse=True)
    return P[first], N[first], U[first], inv.ravel()[I]


def build_cache():
    g = glb.load(GLB)
    src, keys = [], []
    for key, (name, budget, mat) in PARTS.items():
        p = g['meshes'][name][0]
        N = p['N'] if p['N'] is not None else np.tile([0, 1, 0], (len(p['P']), 1))
        P, N, U, I = _weld(p['P'], N, p['U'], p['I'])
        src.append((P, N, U, I)); keys.append(key)
    lods = _simplify(src)
    data = {}
    for key, (P, N, U, I), L in zip(keys, src, lods):
        budget = PARTS[key][1]
        best = I
        for size, li in L:                       # the most detailed level within the budget
            if len(li) <= budget: best = li; break
        if len(best) > budget and L: best = min((li for _, li in L), key=len)
        used = np.unique(best); remap = -np.ones(len(P), np.int64); remap[used] = np.arange(len(used))
        data[key + '_P'] = P[used]; data[key + '_N'] = N[used]; data[key + '_U'] = U[used]; data[key + '_I'] = remap[best]
        print(f'  kit {key:10s} {len(I):6d} -> {len(best):4d} triangles')
    # textures at 512 px
    for mk, img in TEX.items():
        mi = next(i for i, m in enumerate(g['materials']) if m['name'] == img)
        im = Image.open(io.BytesIO(g['images'][g['materials'][mi]['image']])).convert('RGB').resize((512, 512), Image.LANCZOS)
        data['tex_' + mk] = np.asarray(im)
    bakes = {}
    for mk, (node, view, size) in BAKED.items():
        if node not in bakes: bakes[node] = _bake(node, node)
        data['tex_' + mk] = np.asarray(bakes[node][view].resize(size, Image.LANCZOS))
    np.savez_compressed(CACHE, **data)


_cache = None
def get(key):
    global _cache
    if _cache is None:
        if not os.path.exists(CACHE): build_cache()
        _cache = dict(np.load(CACHE))
    return _cache[key + '_P'], _cache[key + '_N'], _cache[key + '_U'], _cache[key + '_I']


def texture(mk):
    global _cache
    if _cache is None: get('post')
    a = _cache['tex_' + mk]
    return Image.fromarray(a, 'RGBA' if a.shape[2] == 4 else 'RGB')


def place(mesh, key, x, y, z, yaw=0.0, scale=1.0, phys=False):
    """a copy of a kit part standing at (x, y, z), its local +z turned to (sin yaw, cos yaw)... local x along (cos, -sin)"""
    P, N, U, I = get(key)
    c, s = np.cos(yaw), np.sin(yaw)
    R = np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    Pw = (P * scale) @ R.T + [x, y, z]
    Nw = N @ R.T
    mesh.add(PARTS[key][2], Pw, U, I, N=Nw, phys=phys)


if __name__ == '__main__':
    if os.path.exists(CACHE): os.remove(CACHE)
    build_cache()
