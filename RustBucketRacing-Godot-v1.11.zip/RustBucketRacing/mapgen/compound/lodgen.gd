extends SceneTree
# Mesh LODs for a map pack, made with Godot's own simplifier (meshoptimizer), run by tools/convert_mcr.py:
#   godot --headless --script tools/lodgen.gd -- <in.bin> <out.bin>
# in:  'LODI' u32 count, then per mesh: u32 nv, u32 ni, f32 pos[nv*3], f32 nrm[nv*3], f32 uv[nv*2], u32 idx[ni]
# out: 'LODO' u32 count, then per mesh: u32 lods, then per lod: f32 size (metres of error), u32 n, u32 idx[n]
# The vertices stay as they are (each LOD is just another index list over them) and open borders stay put,
# so neighbouring chunks still meet at every LOD.
func _initialize():
	var args := OS.get_cmdline_user_args()
	var f := FileAccess.open(args[0], FileAccess.READ)
	if f == null or f.get_buffer(4).get_string_from_ascii() != "LODI":
		printerr("lodgen: bad input"); quit(1); return
	var count := f.get_32()
	var out := FileAccess.open(args[1], FileAccess.WRITE)
	out.store_buffer("LODO".to_ascii_buffer()); out.store_32(count)
	var total_in := 0; var total_lods := 0; var t0 := Time.get_ticks_msec()
	for k in count:
		var nv := f.get_32(); var ni := f.get_32()
		var pos := f.get_buffer(nv * 12).to_float32_array()
		var nrm := f.get_buffer(nv * 12).to_float32_array()
		var uvf := f.get_buffer(nv * 8).to_float32_array()
		var idx := f.get_buffer(ni * 4).to_int32_array()
		var V := PackedVector3Array(); V.resize(nv)
		var N := PackedVector3Array(); N.resize(nv)
		var U := PackedVector2Array(); U.resize(nv)
		for i in nv:
			V[i] = Vector3(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2])
			N[i] = Vector3(nrm[i * 3], nrm[i * 3 + 1], nrm[i * 3 + 2])
			U[i] = Vector2(uvf[i * 2], uvf[i * 2 + 1])
		var arr := []; arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = V; arr[Mesh.ARRAY_NORMAL] = N; arr[Mesh.ARRAY_TEX_UV] = U; arr[Mesh.ARRAY_INDEX] = idx
		var im := ImporterMesh.new()
		im.add_surface(Mesh.PRIMITIVE_TRIANGLES, arr)
		im.generate_lods(25, 60, [])
		var a2: Array = im.get_surface_arrays(0)
		var lc := im.get_surface_lod_count(0)
		if (a2[Mesh.ARRAY_VERTEX] as PackedVector3Array).size() != nv:
			printerr("lodgen: mesh ", k, " vertices changed; no LODs for it"); lc = 0
		out.store_32(lc)
		total_in += ni / 3
		for l in lc:
			var li: PackedInt32Array = im.get_surface_lod_indices(0, l)
			out.store_float(im.get_surface_lod_size(0, l)); out.store_32(li.size()); out.store_buffer(li.to_byte_array())
			total_lods += li.size() / 3
	out.close()
	print("lodgen: %d meshes, %d triangles, %d triangles of LODs, %.1f s" % [count, total_in, total_lods, (Time.get_ticks_msec() - t0) / 1000.0])
	quit(0)
