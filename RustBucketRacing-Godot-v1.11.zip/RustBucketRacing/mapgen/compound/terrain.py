"""Terrain for the compound: a heightfield (4 m grid over +-5.2 km), road profiles, and the ground cut and filled
to meet the roads and pads.

  * rolling hills from a few octaves of smooth noise, and hills outside the fence that frame the view
  * the GP circuit's heights are designed (a height at each corner, smoothed, grade-limited to 10 %): down into a
    dip after T1, up through the esses, and up the hill to the north on the GP loop; the ground round it is pulled
    to its heights so it rides real hills, not embankments; the oval sits in a flat basin inside it
  * the endurance circuit follows the ground, smoothed; access roads too (grade at most 7 %), levelled where they
    join a track, a pad or another road, and lifted onto a bridge where they must cross a track
  * the ground: under a road it sits 0.3 m down (the road mesh covers it), then a verge falling 2 % (grass
    run-off), then an embankment blending into the natural ground over 2.2 m per metre of height difference;
    under a bridge deck it is left alone"""
import numpy as np
from scipy.ndimage import zoom, gaussian_filter1d, map_coordinates, distance_transform_edt
from scipy.spatial import cKDTree
import layout as LY
from paths import frame

EXT, RES = 5200.0, 4.0
N = int(round(2 * EXT / RES)) + 1
AX = -EXT + RES * np.arange(N)

# the GP circuit's height at each corner (m, the main straight at 0)
GP_Y = {'T1': 0, 'N2': -10, 'N3': 4, 'N4': 24, 'N5': 15, 'N6': 9, 'N7': 12, 'N8': 20, 'N9': 6, 'N10': 2, 'N11': -2, 'N12': 0,
        'E1': 17, 'E2': 40, 'E3': 66, 'E4': 55, 'E5': 33, 'E6': 26, 'E7': 20, 'I1': 46}
# heights part way between two corners (a, b, fraction, height): crests and dips on the straights
GP_MID = [('N3', 'N4', 0.5, 17), ('E1', 'E2', 0.5, 30), ('E3', 'E4', 0.45, 72), ('E4', 'E5', 0.55, 46), ('E6', 'E7', 0.5, 15),
          ('N8', 'N9', 0.5, 15), ('N2', 'N3', 0.5, -3)]
GP_GRADE = 0.10
CLEAR = 5.6                        # under a bridge deck
DECK = 0.9                         # deck thickness


def smoothstep(t):
    t = np.clip(t, 0, 1); return t * t * (3 - 2 * t)


def noise(seed):
    """sum of smooth random fields (bicubic upsampled), unit-ish amplitude per octave"""
    rng = np.random.default_rng(seed)
    total = np.zeros((N, N), np.float32)
    for lam, amp in ((2600, 1.0), (1300, 0.55), (650, 0.28), (300, 0.12), (120, 0.04)):
        k = int(np.ceil(2 * EXT / lam)) + 4
        g = rng.standard_normal((k, k)).astype(np.float32)
        z = zoom(g, (N + 2 * lam / RES) / k, order=3)
        o = int(lam / RES)
        total += amp * z[o:o + N, o:o + N]
    return total


def bump(X, Z, x, z, sig, h):
    return h * np.exp(-((X - x) ** 2 + (Z - z) ** 2) / (2 * sig * sig))


def base_height():
    X, Z = np.meshgrid(AX, AX)                                   # rows: z, cols: x
    H = 13.0 * noise(7)
    H = np.where(H < -22, -22 + (H + 22) * 0.4, H)              # no deep holes
    H += bump(X, Z, 100, -1350, 650, 40)                         # the hill north of the GP
    # the facilities south of the GP on gently rolling ground near its level
    fx = smoothstep((np.minimum(X + 1500, 2100 - X)) / 400) * smoothstep((np.minimum(Z - 450, 1450 - Z)) / 300)
    H = H * (1 - 0.85 * fx)
    # outside the fence the ground rises into hills, with more relief
    box = (np.abs(X) ** 6 + np.abs(Z) ** 6) ** (1 / 6)          # a rounded square: no creases at the corners
    rim = smoothstep((box - 3800) / 1400)
    H += rim * (120 + 60 * noise(11))
    return H.astype(np.float32)


def sample(H, x, z):
    c = (np.asarray(x) + EXT) / RES; r = (np.asarray(z) + EXT) / RES
    return map_coordinates(H, [r, c], order=1, mode='nearest')


def limit_grade(y, ds, gmax, closed, sigma):
    mode = 'wrap' if closed else 'nearest'
    for _ in range(16):
        g = np.abs(np.gradient(y) / ds)
        if g.max() <= gmax: break
        w = gaussian_filter1d(np.clip((g - 0.8 * gmax) / (0.4 * gmax), 0, 1), 20 / ds, mode=mode)
        y2 = gaussian_filter1d(y, 3 * sigma / ds, mode=mode)
        y = y + np.clip(w * 2, 0, 1) * (y2 - y)
    return y


class Road:
    """a road surface along a path: centreline heights, the paved extent across it (lo..hi, + = the left normal),
    banking (height change per metre to the left), or a cross-section of its own (prof(j, o) -> height)"""
    def __init__(self, name, P, closed, half, verge, y, bank=None, prio=5, lo=None, hi=None, prof=None):
        self.name, self.P, self.closed, self.verge, self.y, self.prio = name, P, closed, verge, y, prio
        self.lo = -half if lo is None else lo; self.hi = half if hi is None else hi
        self.half = max(-self.lo, self.hi)
        self.t, self.n, self.k = frame(P, closed)
        self.bank = np.zeros(len(P)) if bank is None else bank
        self.prof = prof
        d = np.hypot(*np.diff(P, axis=0).T)
        self.s = np.concatenate([[0], np.cumsum(d)])
        self.L = self.s[-1] + (np.hypot(*(P[0] - P[-1])) if closed else 0)
        self.decks = []                                   # [(i0, i1, track)]: spans carried on a bridge
        self.ground = np.ones(len(P), bool)               # False on a deck

    def surface(self, j, o):
        """road height at sample j, lateral offset o (+ = left), clamped to the road"""
        o = np.clip(o, self.lo, self.hi)
        if self.prof is not None: return self.prof(j, o)
        return self.y[j] + self.bank[j] * o

    def inside(self, o, margin=0.0):
        return (o > self.lo - margin) & (o < self.hi + margin)

    def dout(self, o):
        """how far outside the paved width an offset is (negative inside)"""
        return np.maximum(o - self.hi, self.lo - o)


def profile(H, P, closed, sigma, gmax, ds=1.0):
    y = sample(H, P[:, 0], P[:, 1]).astype(np.float64)
    mode = 'wrap' if closed else 'nearest'
    y = gaussian_filter1d(y, sigma / ds, mode=mode)
    return limit_grade(y, ds, gmax, closed, sigma)


def pin_ends(y, a=None, b=None, blend=0.35, flat=12.0, fade=30.0):
    """move the ends of an open profile onto given heights, the correction fading along the road; the last `flat`
    metres at a pinned end are level with it (across the road it joins), easing back over `fade` metres"""
    n = len(y); u = np.linspace(0, 1, n)
    if a is not None: y = y + (a - y[0]) * (1 - smoothstep(u / blend))
    if b is not None: y = y + (b - y[-1]) * smoothstep((u - (1 - blend)) / blend)
    if flat:
        s = np.arange(n, dtype=float)
        if a is not None: y = y + (a - y) * (1 - smoothstep((s - flat) / fade))
        if b is not None: y = y + (b - y) * (1 - smoothstep(((n - 1 - s) - flat) / fade))
    return y


def pad_height(H, r):
    xs = np.linspace(r['x0'], r['x1'], 12); zs = np.linspace(r['z0'], r['z1'], 12)
    X, Z = np.meshgrid(xs, zs)
    return float(np.median(sample(H, X.ravel(), Z.ravel())))


def corner_profile(P, keys, closed, ref=None):
    """heights along a path from the designed corner heights: each corner's height at the path point nearest to
    it, linear in between, smoothed, grade-limited"""
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
    L = s[-1] + (np.hypot(*(P[0] - P[-1])) if closed else 0)
    ss, hh = [], []
    for k in keys:
        x, z, r = LY._N[k]
        j = int(np.argmin(np.hypot(P[:, 0] - x, P[:, 1] - z)))
        ss.append(s[j]); hh.append(GP_Y[k])
    for a, b, f, h in GP_MID:
        if a not in keys or b not in keys: continue
        (xa, za, _), (xb, zb, _) = LY._N[a], LY._N[b]
        x, z = xa + (xb - xa) * f, za + (zb - za) * f
        j = int(np.argmin(np.hypot(P[:, 0] - x, P[:, 1] - z)))
        if np.hypot(P[j, 0] - x, P[j, 1] - z) < 40: ss.append(s[j]); hh.append(h)
    o = np.argsort(ss); ss = np.array(ss)[o]; hh = np.array(hh, float)[o]
    if closed:
        y = np.interp(s, np.r_[ss - L, ss, ss + L], np.r_[hh, hh, hh])
    else:
        y = np.interp(s, ss, hh)
    y = gaussian_filter1d(y, 28, mode='wrap' if closed else 'nearest')
    return limit_grade(y, 1.0, GP_GRADE, closed, 20)


def oval_section(P, y0):
    """the oval's cross-section: the track banked (20 deg in the turns, 5 on the straights) rising outward from its
    inside edge, the apron inside that falling 3 deg toward the infield"""
    from paths import frame as _f
    t, n, k = _f(P, True)
    c = np.array(LY.OVAL_C)
    out = float(np.sign(np.mean(np.einsum('ij,ij->i', n, P - c))))      # +1: the left normal points outward
    turn = np.clip(np.abs(gaussian_filter1d(k, 25, mode='wrap')) * LY.OVAL_R, 0, 1)
    bank = np.tan(np.radians(LY.OVAL_BANK_STRAIGHT + (LY.OVAL_BANK_TURN - LY.OVAL_BANK_STRAIGHT) * smoothstep(turn)))
    h, a = LY.OVAL_HALF, LY.OVAL_APRON
    ta = np.tan(np.radians(3.0))
    def prof(j, o):
        oo = np.asarray(o) * out                                          # outward
        return y0 + np.where(oo >= -h, bank[j] * (oo + h), ta * (oo + h))
    lo, hi = (-(h + a), h) if out > 0 else (-h, h + a)
    return prof, lo, hi, out, bank


def build(L):
    H0 = base_height()
    roads = {}
    # ---- GP: designed heights; the configurations' own stretches pinned to it where they leave and rejoin
    gp = L['gp']['gp']
    ygp = corner_profile(gp, LY.GP_CONFIGS['gp'], True)
    straight = (gp[:, 1] > LY.GP_STRAIGHT_Z - 20) & (gp[:, 0] > -560) & (gp[:, 0] < 980)
    w = np.clip(gaussian_filter1d(straight.astype(float), 30, mode='wrap') * 1.6, 0, 1)
    ygp = (1 - w) * ygp
    roads['gp'] = Road('gp', gp, True, 6.0, 10.0, ygp, prio=0)
    gtree = cKDTree(gp)
    for c in ('int', 'nat'):
        P = L['links'][c]
        keys = [k for k in LY.GP_CONFIGS[c] if np.min(np.hypot(P[:, 0] - LY._N[k][0], P[:, 1] - LY._N[k][1])) < 60]
        y = corner_profile(P, keys, False)
        _, ja = gtree.query(P[0]); _, jb = gtree.query(P[-1])
        y = limit_grade(pin_ends(y, ygp[ja], ygp[jb], blend=0.3, flat=30, fade=60), 1.0, GP_GRADE, False, 30)
        # where the link still overlaps the GP (leaving it or joining it), it takes the GP's heights exactly, then
        # eases onto its own over 80 m
        dg, jg = gtree.query(P)
        n = len(P); w = np.zeros(n)
        k0 = int(np.argmax(dg > 14.0)); k1 = n - 1 - int(np.argmax(dg[::-1] > 14.0))
        s_ = np.arange(n, dtype=float)
        w = np.maximum(1 - smoothstep((s_ - k0) / 80.0), 1 - smoothstep((k1 - s_) / 80.0))
        y = w * ygp[jg] + (1 - w) * y
        roads[c + '_link'] = Road(c + '_link', P, False, 6.0, 10.0, y, prio=0.5)
    roads['pit'] = Road('pit', L['pit'], False, 6.0, 0.0, np.zeros(len(L['pit'])), prio=1)
    pads = {'paddock': (LY.PADDOCK, 0.0)}
    # ---- the ground pulled to the GP's heights near it, the oval's basin flat
    X, Z = np.meshgrid(AX, AX)
    allp = np.vstack([gp] + [roads[c + '_link'].P for c in ('int', 'nat')])
    ally = np.concatenate([ygp] + [roads[c + '_link'].y for c in ('int', 'nat')])
    near = (np.abs(X) < 2200) & (Z > -2300) & (Z < 1500)
    d, j = cKDTree(allp[::4]).query(np.c_[X[near], Z[near]], k=40, distance_upper_bound=900)
    yk = ally[::4]
    ww = np.where(np.isfinite(d), np.exp(-(np.where(np.isfinite(d), d, 1e9) / 170.0) ** 2), 0.0) + 1e-12
    ys = (ww * yk[np.minimum(j, len(yk) - 1)]).sum(1) / ww.sum(1)      # a smooth blend of the nearby track heights
    wg = np.exp(-(d[:, 0] / 260.0) ** 2)
    Hn = H0[near] * (1 - wg) + ys * wg
    H0 = H0.copy(); H0[near] = Hn
    ov = L['oval']
    dov, _ = cKDTree(ov).query(np.c_[X.ravel(), Z.ravel()])
    inside_ov = (np.abs(X.ravel() - LY.OVAL_C[0]) < LY.OVAL_STRAIGHT / 2 + LY.OVAL_R) & (np.abs(Z.ravel() - LY.OVAL_C[1]) < LY.OVAL_R)
    wo = np.where(inside_ov, 1.0, 1 - smoothstep((dov - 120) / 260)).reshape(H0.shape)
    YOV = 0.5
    H0 = (H0 * (1 - wo) + YOV * wo).astype(np.float32)
    # ---- the oval: flat base, banked track, apron
    prof, lo, hi, out, bank = oval_section(ov, YOV)
    roads['oval'] = Road('oval', ov, True, 9.0, 3.0, np.full(len(ov), YOV), prio=0, lo=lo, hi=hi, prof=prof)
    roads['oval'].out = out; roads['oval'].bankv = bank
    y_apron_in = YOV - np.tan(np.radians(3.0)) * LY.OVAL_APRON
    roads['oval_pit'] = Road('oval_pit', L['oval_pit'], False, 6.0, 0.0, np.full(len(L['oval_pit']), y_apron_in), prio=1)
    pads['oval'] = (LY.OVAL_PAD, y_apron_in)
    # ---- the endurance circuit: the ground, smoothed; its straight and pits level
    en = L['enduro']
    yen = profile(H0, en, True, 60, 0.07)
    st = (en[:, 1] > 3600) & (en[:, 0] > -300) & (en[:, 0] < 1700)
    flat_en = float(np.mean(yen[st]))
    w = np.clip(gaussian_filter1d(st.astype(float), 40, mode='wrap') * 1.6, 0, 1)
    yen = limit_grade(w * flat_en + (1 - w) * yen, 1.0, 0.07, True, 60)
    roads['enduro'] = Road('enduro', en, True, 6.5, 8.0, yen, prio=0)
    roads['enduro_pit'] = Road('enduro_pit', L['enduro_pit'], False, 6.0, 0.0, np.full(len(L['enduro_pit']), flat_en), prio=1)
    pads['enduro'] = (LY.ENDURO_PAD, flat_en)
    # ---- drift track: gentle undulation; drag strip flat
    dr = L['drift']
    roads['drift'] = Road('drift', dr, True, LY.DRIFT_HALF, 4.0, profile(H0, dr, True, 80, 0.025), prio=0)
    dg = L['drag']
    yd = float(np.median(sample(H0, dg[:, 0], dg[:, 1])))
    roads['drag'] = Road('drag', dg, False, 8.0, 3.0, np.full(len(dg), yd), prio=0)
    pads['drag'] = (LY.DRAG_PAD, yd)
    for name in ('slalom', 'drift'):
        pads[name] = (LY.PADS[name], pad_height(H0, LY.PADS[name]))
    pads['drift'] = (LY.DRIFT_PAD, float(roads['drift'].y[int(np.argmin(np.hypot(dr[:, 0] - 1335, dr[:, 1] - 1060)))]))
    # ---- access roads, each starting or ending on a height that is already fixed
    R = L['roads']
    def at(name, x, z):
        rd = roads[name]; j = int(np.argmin(np.hypot(rd.P[:, 0] - x, rd.P[:, 1] - z))); return float(rd.y[j])
    def acc(name, a=None, b=None, sigma=70, half=3.6):
        P = R[name]; y = profile(H0, P, False, sigma, 0.07)
        s = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
        if s[-1] < 400 and a is not None and b is not None:          # a short connector: straight from one end to the other
            y = a + (b - a) * smoothstep(s / s[-1])
        else: y = pin_ends(y, a, b)
        roads[name] = Road(name, P, False, half, 3.0, y, prio=3)
    acc('gate', None, 0.0)
    acc('enduro_rd', at('gate', LY.GATE_X, 3380), flat_en, sigma=20)
    acc('drag_rd', at('gate', LY.GATE_X, 1030), yd, sigma=20)
    acc('slalom_rd', 0.0, pads['slalom'][1])
    acc('drift_rd', 0.0, pads['drift'][1])
    acc('drift_in', pads['drift'][1], at('drift', *R['drift_in'][-1]))
    acc('infield', 0.0, None)
    oy = float(roads['oval'].surface(int(np.argmin(np.hypot(ov[:, 0] + 25, ov[:, 1] + LY.OVAL_R))), out * LY.OVAL_HALF))
    roads['infield'].y = pin_ends(roads['infield'].y, None, oy, flat=8, fade=40)
    yi = float(roads['oval'].surface(int(np.argmin(np.hypot(ov[:, 0] + 25, ov[:, 1] + LY.OVAL_R))), -out * (LY.OVAL_HALF + LY.OVAL_APRON - 6)))
    acc('oval_in', yi, y_apron_in, sigma=10)
    for name in ('drag_turn', 'drag_return'):          # on the drag strip's level
        roads[name] = Road(name, R[name], False, 3.6, 3.0, np.full(len(R[name]), yd), prio=3)
    ACCESS = ['gate', 'enduro_rd', 'drag_rd', 'slalom_rd', 'drift_rd', 'infield', 'oval_in', 'drag_turn', 'drag_return', 'drift_in']
    for i, k in enumerate(ACCESS): roads[k].prio = 3 + 0.01 * i
    level_on_pads(roads, pads)
    make_bridges(roads)
    return H0, roads, pads


def make_bridges(roads, grade=0.07):
    """an access road that crosses a track away from its own ends goes over it on a bridge: a deck CLEAR m over the
    track, ramps at `grade` up to it, the deck spanning the track, its verges and some more"""
    from scipy.ndimage import binary_dilation, label
    tracks = [r for r in roads.values() if r.prio < 2]
    for rd in roads.values():
        if rd.prio < 2: continue
        n = len(rd.P)
        for tr in tracks:
            d, j = cKDTree(tr.P).query(rd.P)
            span = d < tr.half + tr.verge + 16
            hit = d < tr.half + 1
            far = (np.arange(n) > 40) & (np.arange(n) < n - 40)
            if not (hit & far).any(): continue
            lab, nl = label(span)
            for c in range(1, nl + 1):
                ids = np.nonzero(lab == c)[0]
                if not (hit[ids] & far[ids]).any(): continue
                i0, i1 = int(ids[0]), int(ids[-1])
                jc = j[ids[np.argmin(d[ids])]]
                top = max(tr.surface(jc, o) for o in (tr.lo, 0.0, tr.hi)) + CLEAR + DECK
                s = rd.s
                dist = np.maximum(0, np.maximum(s[i0] - s, s - s[i1]))
                need = top - grade * dist
                y = np.maximum(gaussian_filter1d(np.maximum(rd.y, need), 6, mode='nearest'), need)
                y[i0:i1 + 1] = top
                rd.y = y
                rd.decks.append((i0, i1, tr.name)); rd.ground[i0:i1 + 1] = False
                print(f'  bridge: {rd.name} over {tr.name}, deck {s[i1] - s[i0]:.0f} m long at {top:.1f} m')


def level_on_pads(roads, pads, blend=80.0):
    """where an access road crosses a pad (with a margin), it runs at the pad's level; the change fades over `blend` m"""
    for rd in roads.values():
        if rd.prio < 2: continue
        y = rd.y.copy(); d = np.zeros(len(y)); hit = np.zeros(len(y), bool)
        for (r, h) in pads.values():
            m = rd.half + 2.0
            ins = (rd.P[:, 0] > r['x0'] - m) & (rd.P[:, 0] < r['x1'] + m) & (rd.P[:, 1] > r['z0'] - m) & (rd.P[:, 1] < r['z1'] + m)
            d[ins] = h - y[ins]; hit |= ins
        if not hit.any(): continue
        dist, (near,) = distance_transform_edt(~hit, return_indices=True)
        w = 1 - smoothstep(dist / min(blend, 0.45 * rd.L))
        rd.y = y + d[near] * w


def shape(H0, roads, pads):
    """the ground cut and filled to the roads and pads; also returns the influence (0 at a road, 1 untouched)"""
    H = H0.copy(); T = np.ones_like(H0)
    def apply(mask_rc, tgt, tinf):
        r, c = mask_rc
        sub = tinf < T[r, c]
        H[r[sub], c[sub]] = tgt[sub]; T[r[sub], c[sub]] = tinf[sub]
    reach = 140.0
    for rd in sorted(roads.values(), key=lambda r: -r.prio):          # most important last: it wins ties
        gi = np.nonzero(rd.ground)[0]                                  # a bridge deck leaves the ground alone
        Pg = rd.P[gi]
        lo = Pg.min(0) - reach; hi = Pg.max(0) + reach
        c0, c1 = np.searchsorted(AX, [lo[0], hi[0]]); r0, r1 = np.searchsorted(AX, [lo[1], hi[1]])
        rr, cc = np.mgrid[r0:r1, c0:c1]; rr = rr.ravel(); cc = cc.ravel()
        px, pz = AX[cc], AX[rr]
        d, jj = cKDTree(Pg).query(np.c_[px, pz], distance_upper_bound=reach + rd.half + rd.verge)
        ok = np.isfinite(d); rr, cc, px, pz, jj = rr[ok], cc[ok], px[ok], pz[ok], jj[ok]
        j = gi[jj]
        dx, dz = px - rd.P[j, 0], pz - rd.P[j, 1]
        o = dx * rd.n[j, 0] + dz * rd.n[j, 1]
        a = dx * rd.t[j, 0] + dz * rd.t[j, 1]
        dout = rd.dout(o)
        # beyond an end (of the road, or of the ground before a deck): round caps
        first = (jj == 0) if not rd.closed else np.zeros(len(jj), bool)
        last = (jj == len(gi) - 1) if not rd.closed else np.zeros(len(jj), bool)
        brk = np.r_[np.diff(gi) > 1, False]                   # the last ground point before a deck
        brk0 = np.r_[False, np.diff(gi) > 1]                  # the first after it
        end = ((first | brk0[jj]) & (a < -0.5)) | ((last | brk[jj]) & (a > 0.5))
        dout = np.where(end, np.hypot(np.maximum(dout, 0), np.abs(a)), dout)
        ye = rd.surface(j, o)
        h0 = H0[rr, cc]
        vh = ye - 0.05 - 0.02 * rd.verge
        dh = h0 - vh
        B = np.maximum(10.0, 2.2 * np.abs(dh))
        tb = smoothstep((dout - rd.verge) / B)
        tgt = np.where(dout <= 0.3, ye - 0.3, np.where(dout <= rd.verge, ye - 0.05 - 0.02 * np.maximum(dout, 0), vh + tb * dh))
        tinf = np.where(dout <= rd.verge, 0.0, tb)
        apply((rr, cc), tgt.astype(np.float32), tinf.astype(np.float32))
    for name, (r, h) in pads.items():
        lo = np.array([r['x0'], r['z0']]) - reach; hi = np.array([r['x1'], r['z1']]) + reach
        c0, c1 = np.searchsorted(AX, [lo[0], hi[0]]); r0, r1 = np.searchsorted(AX, [lo[1], hi[1]])
        rr, cc = np.mgrid[r0:r1, c0:c1]; rr = rr.ravel(); cc = cc.ravel()
        px, pz = AX[cc], AX[rr]
        ddx = np.maximum(np.maximum(r['x0'] - px, px - r['x1']), 0); ddz = np.maximum(np.maximum(r['z0'] - pz, pz - r['z1']), 0)
        dout = np.hypot(ddx, ddz)
        inside = (px >= r['x0']) & (px <= r['x1']) & (pz >= r['z0']) & (pz <= r['z1'])
        h0 = H0[rr, cc]; vh = h - 0.1; dh = h0 - vh
        B = np.maximum(10.0, 2.2 * np.abs(dh))
        tb = smoothstep((dout - 2) / B)
        tgt = np.where(inside, h - 0.3, np.where(dout <= 2, h - 0.05, vh + tb * dh))
        tinf = np.where(dout <= 2, 0.0, tb)
        apply((rr, cc), tgt.astype(np.float32), tinf.astype(np.float32))
    return H, T


if __name__ == '__main__':
    import time
    t0 = time.time()
    L = LY.build()
    H0, roads, pads = build(L)
    print(f'base and profiles {time.time() - t0:.1f}s, H0 {H0.min():.0f}..{H0.max():.0f} m')
    for k, r in roads.items():
        g = np.abs(np.gradient(r.y) / np.maximum(np.gradient(r.s), 1e-6))
        print(f'  {k:12s} {r.L:7.0f} m  y {r.y.min():6.1f}..{r.y.max():6.1f}  max grade {g.max() * 100:4.1f} % at {r.P[int(np.argmax(g))].round()}')
    H, T = shape(H0, roads, pads)
    print(f'shaped {time.time() - t0:.1f}s')
    np.savez_compressed('terrain.npz', H=H, H0=H0, T=T)
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    from matplotlib.colors import LightSource
    fig, axs = plt.subplots(1, 2, figsize=(22, 11))
    ls = LightSource(azdeg=315, altdeg=35)
    for ax, (sl, ext) in zip(axs, ((np.s_[::3, ::3], [-EXT, EXT, EXT, -EXT]), (None, None))):
        if sl is not None:
            sub = H[sl]; ax.imshow(ls.shade(sub, cmap=plt.cm.gist_earth, vert_exag=3, blend_mode='soft', vmin=-40, vmax=160), extent=ext)
        else:
            c0, c1 = np.searchsorted(AX, [-1400, 2000]); r0, r1 = np.searchsorted(AX, [-1800, 1300])
            sub = H[r0:r1, c0:c1]
            ax.imshow(ls.shade(sub, cmap=plt.cm.gist_earth, vert_exag=4, blend_mode='soft', vmin=-20, vmax=60), extent=[AX[c0], AX[c1], AX[r1], AX[r0]])
        for k, r in roads.items():
            P = r.P if not r.closed else np.vstack([r.P, r.P[:1]])
            ax.plot(P[:, 0], P[:, 1], 'k-', lw=0.6)
            for i0, i1, tr in r.decks: ax.plot(r.P[i0:i1, 0], r.P[i0:i1, 1], 'r-', lw=3)
    fig.savefig('terrain.png', dpi=55)
    print('done')
