extends SceneTree
# Orthographic albedo renders (unshaded, clear background) of a set of textured meshes, for the transporter's
# baked cab: godot --path <dir> --script hullbake.gd -- <in.bin> <out dir>
# in: 'HULB' u32 nparts, per part: u32 nv, u32 ni, f32 P[nv*3], f32 U[nv*2], u32 I[ni]
#     u32 nsets, per set and part: u32 len + png path (utf8, '' for a plain colour), f32 rgb[3]
#     u32 nviews, per view: f32 pos[3], f32 target[3], f32 up[3], f32 size, u32 W, u32 H
# out: <out dir>/s<set>_v<view>.png
func _initialize():
	var a := OS.get_cmdline_user_args()
	var f := FileAccess.open(a[0], FileAccess.READ)
	if f == null or f.get_buffer(4).get_string_from_ascii() != "HULB":
		printerr("hullbake: bad input"); quit(1); return
	var root := Node3D.new(); get_root().add_child(root)
	var np := f.get_32()
	var mis := []
	for k in np:
		var nv := f.get_32(); var ni := f.get_32()
		var pf := f.get_buffer(nv * 12).to_float32_array(); var uf := f.get_buffer(nv * 8).to_float32_array()
		var idx := f.get_buffer(ni * 4).to_int32_array()
		var P := PackedVector3Array(); var U := PackedVector2Array()
		for i in nv:
			P.append(Vector3(pf[i * 3], pf[i * 3 + 1], pf[i * 3 + 2])); U.append(Vector2(uf[i * 2], uf[i * 2 + 1]))
		var arr := []; arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = P; arr[Mesh.ARRAY_TEX_UV] = U; arr[Mesh.ARRAY_INDEX] = idx
		var m := ArrayMesh.new(); m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mi := MeshInstance3D.new(); mi.mesh = m; root.add_child(mi); mis.append(mi)
	var nsets := f.get_32()
	var sets := []
	for s in nsets:
		var mats := []
		for k in np:
			var L := f.get_32(); var path := f.get_buffer(L).get_string_from_utf8()
			var r := f.get_float(); var g := f.get_float(); var b := f.get_float()
			var sm := StandardMaterial3D.new()
			sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			sm.cull_mode = BaseMaterial3D.CULL_DISABLED
			sm.albedo_color = Color(r, g, b)
			if path != "":
				var img := Image.load_from_file(path); img.generate_mipmaps()
				sm.albedo_texture = ImageTexture.create_from_image(img)
			mats.append(sm)
		sets.append(mats)
	var nviews := f.get_32()
	var views := []
	for v in nviews:
		var p := Vector3(f.get_float(), f.get_float(), f.get_float()); var t := Vector3(f.get_float(), f.get_float(), f.get_float())
		var up := Vector3(f.get_float(), f.get_float(), f.get_float()); var size := f.get_float()
		var W := f.get_32(); var H := f.get_32()
		views.append([p, t, up, size, W, H])
	get_root().transparent_bg = true
	get_root().msaa_3d = Viewport.MSAA_4X
	var cam := Camera3D.new(); cam.projection = Camera3D.PROJECTION_ORTHOGONAL; cam.keep_aspect = Camera3D.KEEP_HEIGHT
	cam.near = 0.5; cam.far = 200; root.add_child(cam); cam.current = true
	# warm up: the first frames come out at the window's size, whatever the viewport is set to
	var v0: Array = views[0]
	get_root().size = Vector2i(v0[4], v0[5])
	for i in 8: await process_frame
	var first := true
	for s in nsets:
		for k in np: mis[k].material_override = sets[s][k]
		for v in nviews:
			var vw: Array = views[v]
			cam.look_at_from_position(vw[0], vw[1], vw[2]); cam.size = vw[3]
			get_root().size = Vector2i(vw[4], vw[5])
			for i in (6 if first else 3): await process_frame
			first = false
			get_root().get_texture().get_image().save_png("%s/s%d_v%d.png" % [a[1], s, v])
	print("hullbake: ", nsets, " sets x ", nviews, " views")
	quit(0)
