"""Where the Grand Prix circuit's configurations part and join. The grass point between the two tracks is cut back:
the V is filled with asphalt to a rounded nose (a fillet of radius R_NOSE between the two track edges), the fill
reaching BAND m onto each track so it covers their edge lines inside the V, and a white line is painted round the
nose, joining the tracks' own edge lines either side.

The fill is found on a fine raster round each junction: the union of the two tracks' surfaces, closed
morphologically (dilated by R_NOSE, then eroded by it), less the tracks themselves, keeping only the pieces that
touch both tracks. A Fill answers inside(x, z) and height(x, z) and builds its own mesh."""
import numpy as np
from scipy.ndimage import distance_transform_edt as edt, label, map_coordinates, binary_dilation, gaussian_filter1d
from scipy.spatial import cKDTree, Delaunay
from skimage.measure import find_contours

R_NOSE = 6.0
BAND = 1.0          # how far the fill reaches onto each track from the V
LIFT = 0.015        # over the track surfaces it covers
LIP, SKIRT = 0.32, 0.55      # the edge beyond the grass line: a lip at the ground's level, a skirt below it
LINE_O, LINE_W = 0.26, 0.22   # the edge line: its centre in from the edge, its width (as the track texture's)


class Fill:
    def __init__(self, a, b, ia, ib, x0, z0, res, F, gC, Dfill):
        self.a, self.b = a, b                      # the two roads
        self.ta, self.tb = cKDTree(a.P[ia]), cKDTree(b.P[ib])
        self.ia, self.ib = ia, ib                  # their local samples
        self.x0, self.z0, self.res = x0, z0, res
        self.F, self.gC, self.Dfill = F, gC, Dfill
        ny, nx = F.shape
        self.box = (x0, z0, x0 + (nx - 1) * res, z0 + (ny - 1) * res)

    def sample(self, arr, x, z, out=99.0):
        x = np.atleast_1d(np.asarray(x, float)); z = np.atleast_1d(np.asarray(z, float))
        return map_coordinates(arr, [(z - self.z0) / self.res, (x - self.x0) / self.res], order=1, mode='constant', cval=out)

    def inside(self, x, z, margin=0.0):
        """points in the fill's area (margin > 0 shrinks it, < 0 grows it)"""
        return self.sample(self.F, x, z) < -margin

    def _road(self, rd, tree, ids, x, z):
        _, k = tree.query(np.c_[x, z]); j = ids[k]
        o = (x - rd.P[j, 0]) * rd.n[j, 0] + (z - rd.P[j, 1]) * rd.n[j, 1]
        return rd.surface(j, o), np.maximum(rd.dout(o), 0.0)

    def height(self, x, z):
        """the surface: a track's own where the fill lies over it (the first road's where over both), a blend of
        the two tracks' edge heights in the V"""
        x = np.atleast_1d(np.asarray(x, float)); z = np.atleast_1d(np.asarray(z, float))
        ya, da = self._road(self.a, self.ta, self.ia, x, z)
        yb, db = self._road(self.b, self.tb, self.ib, x, z)
        wa = 1 / (da + 0.3) ** 2; wb = 1 / (db + 0.3) ** 2
        y = (ya * wa + yb * wb) / (wa + wb)
        return np.where(da <= 0, ya, np.where(db <= 0, yb, y))

    def _contours(self, arr, level=0.0, step=0.5):
        """level lines of a field, as world polylines resampled every `step` m"""
        out = []
        for c in find_contours(arr, level):
            P = np.c_[self.x0 + c[:, 1] * self.res, self.z0 + c[:, 0] * self.res]
            closed = np.hypot(*(P[0] - P[-1])) < self.res * 1.5
            s = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
            if s[-1] < 2.0: continue
            t = np.linspace(0, s[-1], max(3, int(s[-1] / step) + 1))
            Q = np.c_[np.interp(t, s, P[:, 0]), np.interp(t, s, P[:, 1])]
            if len(Q) > 7: Q = np.c_[gaussian_filter1d(Q[:, 0], 1.0, mode='wrap' if closed else 'nearest'),
                                     gaussian_filter1d(Q[:, 1], 1.0, mode='wrap' if closed else 'nearest')]
            out.append((Q, closed))
        return out

    def nose(self):
        """the grass edge of the fill (where the ground meets it)"""
        out = []
        for Q, closed in self._contours(self.F, 0.0, 0.6):
            keep = self.sample(self.Dfill, Q[:, 0], Q[:, 1]) < BAND - 0.05        # not the edge of the band on a track
            if keep.sum() >= 2: out.append(Q[keep])
        return out

    def mesh(self, mesh):
        # points: the outline, a lip 0.32 m out (level with the ground's edge row, so a wheel always finds a
        # surface), a skirt 0.55 m out going down under the ground, and a grid inside
        rims = []
        for lev in (-0.02, LIP, SKIRT):
            rims += [Q for Q, _ in self._contours(self.F, lev, 0.5)]
        if not rims: return 0
        x0, z0, x1, z1 = self.box
        gx, gz = np.meshgrid(np.arange(x0, x1, 1.4), np.arange(z0, z1, 1.4))
        g = np.c_[gx.ravel(), gz.ravel()]
        g = g[self.sample(self.F, g[:, 0], g[:, 1]) < -0.45]
        P = np.vstack(rims + [g])
        tri = Delaunay(P)
        I = tri.simplices
        C = P[I].mean(1)
        fc = self.sample(self.F, C[:, 0], C[:, 1])
        keep = fc < SKIRT
        I, fc = I[keep], fc[keep]
        T = P[I]
        cr = (T[:, 1, 0] - T[:, 0, 0]) * (T[:, 2, 1] - T[:, 0, 1]) - (T[:, 1, 1] - T[:, 0, 1]) * (T[:, 2, 0] - T[:, 0, 0])
        I = np.where((cr > 0)[:, None], I[:, [0, 2, 1]], I)
        fp = np.clip(self.sample(self.F, P[:, 0], P[:, 1]), -1, SKIRT)
        drop = np.where(fp <= 0, -LIFT, np.where(fp <= LIP, 0.04 * fp / LIP, 0.04 + 0.26 * (fp - LIP) / (SKIRT - LIP)))
        y = self.height(P[:, 0], P[:, 1]) - drop
        V = np.c_[P[:, 0], y, P[:, 1]]
        mesh.add('track_fill', V, P / 12.0, I, phys=fc < LIP + 0.02)
        # the white line round the nose, carried a little along each track's own line
        for Q, closed in self._contours(self.gC, 0.0, 0.4):
            near = self.sample(self.Dfill, Q[:, 0], Q[:, 1]) < 2.2
            lab, n = label(near)
            for c in range(1, n + 1):
                seg = Q[lab == c]
                if len(seg) < 4: continue
                t = np.gradient(seg, axis=0); t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-9)
                nn = np.c_[-t[:, 1], t[:, 0]]
                probe = seg + nn * 0.5
                sgn = np.where(self.sample(self.gC, probe[:, 0], probe[:, 1]) < 0, 1.0, -1.0)[:, None]   # toward the asphalt
                A = seg + nn * sgn * (LINE_O - LINE_W / 2); B = seg + nn * sgn * (LINE_O + LINE_W / 2)
                ya = self.height(A[:, 0], A[:, 1]) + LIFT + 0.008; yb = self.height(B[:, 0], B[:, 1]) + LIFT + 0.008
                m = len(seg)
                PP = np.r_[np.c_[A[:, 0], ya, A[:, 1]], np.c_[B[:, 0], yb, B[:, 1]]]
                II = np.array([[i, i + 1, m + i] for i in range(m - 1)] + [[i + 1, m + i + 1, m + i] for i in range(m - 1)])
                UU = np.r_[np.c_[np.zeros(m), np.zeros(m)], np.c_[np.ones(m), np.zeros(m)]]
                mesh.add('paint', PP, UU, II, N=np.tile([0.0, 1.0, 0.0], (2 * m, 1)), phys=False)
        return len(I)


def _local(rd, j, reach):
    """indices of a road within `reach` m (along it) of sample j"""
    n = len(rd.P)
    k = np.arange(j - int(reach), j + int(reach) + 1)
    return k % n if rd.closed else k[(k >= 0) & (k < n)]


def junction_fills(roads, links=('int_link', 'nat_link'), main='gp', R=R_NOSE, res=0.2, half_win=110.0):
    """a Fill at each end of each link: where it leaves the main track and where it rejoins it"""
    A = roads[main]
    ta = cKDTree(A.P)
    out = []
    for ln in links:
        B = roads[ln]
        d, _ = ta.query(B.P)
        n = len(B.P)
        sep = A.half + B.half
        k0 = int(np.argmax(d > sep)); k1 = n - 1 - int(np.argmax(d[::-1] > sep))   # the V's points
        for k in (k0, k1):
            c = B.P[k]
            ia = _local(A, int(ta.query(c)[1]), 260); ib = _local(B, k, 260)
            xs = np.arange(c[0] - half_win, c[0] + half_win + 1e-6, res); zs = np.arange(c[1] - half_win, c[1] + half_win + 1e-6, res)
            X, Z = np.meshgrid(xs, zs)
            q = np.c_[X.ravel(), Z.ravel()]
            def foot(rd, ids):
                dd, kk = cKDTree(rd.P[ids]).query(q, distance_upper_bound=rd.half + 40)
                ok = np.isfinite(dd); j = ids[np.where(ok, kk, 0)]
                o = (q[:, 0] - rd.P[j, 0]) * rd.n[j, 0] + (q[:, 1] - rd.P[j, 1]) * rd.n[j, 1]
                a = (q[:, 0] - rd.P[j, 0]) * rd.t[j, 0] + (q[:, 1] - rd.P[j, 1]) * rd.t[j, 1]
                f = ok & rd.inside(o) & (np.abs(a) < 1.0)
                return f.reshape(X.shape)
            fa, fb = foot(A, ia), foot(B, ib)
            U = fa | fb
            Dout = edt(~U) * res
            dil = Dout <= R
            Din = edt(dil) * res
            closed = (Din > R - 0.5 * res) | U
            fill0 = closed & ~U
            lab, nl = label(fill0)
            keep = np.zeros_like(U)
            for ci in range(1, nl + 1):
                m = lab == ci
                rr, cc = np.nonzero(m)
                if len(rr) < 30: continue
                if rr.min() == 0 or cc.min() == 0 or rr.max() == U.shape[0] - 1 or cc.max() == U.shape[1] - 1: continue
                sl = np.s_[max(0, rr.min() - 3):rr.max() + 4, max(0, cc.min() - 3):cc.max() + 4]
                g = binary_dilation(m[sl], iterations=2)
                if (g & fa[sl] & ~fb[sl]).any() and (g & fb[sl] & ~fa[sl]).any(): keep |= m
            if not keep.any(): continue
            gC = np.where(U, -edt(U) * res, R - Din).astype(np.float32)
            Dfill = (edt(~keep) * res).astype(np.float32)
            F = np.maximum(gC, Dfill - BAND).astype(np.float32)
            f = Fill(A, B, ia, ib, xs[0], zs[0], res, F, gC, Dfill)
            area = keep.sum() * res * res
            print(f'  junction {ln} at {c.round()}: fill {area:.0f} m2')
            out.append(f)
    return out
