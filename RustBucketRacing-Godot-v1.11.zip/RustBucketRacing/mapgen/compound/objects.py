"""Everything that stands on the compound: pads (paddocks, parking, the slalom pad), the pit garages, race control,
grandstands, transporters and tents, workshops, the main building and gate, the drag strip's tower and lights,
walls and fences, marshal posts, trees and forests, and the scenery beyond the fence (wooded hills, tree lines,
mountains on the horizon)."""
import numpy as np
from scipy.spatial import cKDTree
from geom import box, quad, strip, card, cards, grid_tris
import layout as LY
import terrain as TR
import trackgen as TG
import hauler
import kit

RNG = np.random.default_rng(42)


def pad_mesh(mesh, G, name, r, h, mat='pad', step=16.0):
    xs = np.arange(r['x0'], r['x1'] + 1e-6, step); xs = np.unique(np.r_[r['x0'] - 0.5, r['x0'] - 0.3, xs, r['x1'], r['x1'] + 0.3, r['x1'] + 0.5])
    zs = np.arange(r['z0'], r['z1'] + 1e-6, step); zs = np.unique(np.r_[r['z0'] - 0.5, r['z0'] - 0.3, zs, r['z1'], r['z1'] + 0.3, r['z1'] + 0.5])
    X, Z = np.meshgrid(xs, zs)
    Y = np.full(X.shape, h)
    out = np.maximum(np.maximum(r['x0'] - X, X - r['x1']), np.maximum(r['z0'] - Z, Z - r['z1']))
    Y = np.where(out > 0.4, h - 0.3, np.where(out > 0.2, h - 0.04, h))       # a lip level with the ground's edge, a skirt
    # under the pit lane and other more important roads (pads rank below the tracks and the pit lanes)
    nm, yo = G.road_at(X.ravel(), Z.ravel(), margin=-0.02, y=Y.ravel(), ytol=1.5)
    sink = np.array([n_ is not None and G.roads[n_].prio < 2 for n_ in nm]).reshape(X.shape)
    Y = np.where(sink, np.minimum(Y, yo.reshape(X.shape) - 0.03), Y)
    P = np.dstack([X, Y, Z]).reshape(-1, 3)
    U = np.dstack([X / 8, Z / 8]).reshape(-1, 2)
    I = grid_tris(len(zs), len(xs))
    I = I[:, [0, 2, 1]]
    col = I % len(xs); row = I // len(xs)
    phys = ~((col == 0).any(1) | (col == len(xs) - 1).any(1) | (row == 0).any(1) | (row == len(zs) - 1).any(1))
    mesh.add(mat, P, U, I, phys=phys)


def flat_quad(mesh, mat, x0, z0, x1, z1, y, uvk=None, lift=0.0, phys=True):
    k = uvk
    uv = ((x0 / k, z1 / k), (x1 / k, z1 / k), (x1 / k, z0 / k), (x0 / k, z0 / k)) if k else ((0, 1), (1, 1), (1, 0), (0, 0))
    quad(mesh, mat, (x0, y + lift, z1), (x1, y + lift, z1), (x1, y + lift, z0), (x0, y + lift, z0), uv=uv, phys=phys)


# ---------------------------------------------------------------- buildings
def building(mesh, cx, cz, y0, w, d, h, yaw=0.0, front='facade', side='concrete', roof='roof', uvm=(8.0, 8.0), full=False):
    mats = dict(front=front, back=side, left=side, right=side, top=roof)
    return box(mesh, cx, cz, y0, w, d, h, yaw, mats, uvm=uvm, tex_full=('front',) if full else ())


def grandstand(mesh, x0, x1, zf, y0, rows=14, depth=0.85, rise=0.5, facing=1, roof=True):
    """stepped seating facing +z (facing=1) or -z (-1): front edge at zf, seats as one sloped surface"""
    D = rows * depth; Hh = rows * rise + 1.2
    zb = zf - facing * D
    # seating slope (two-sided lit, seen from the track)
    yb, yf_ = y0 + Hh, y0 + 1.2
    if facing > 0: quad(mesh, 'seats', (x0, yf_, zf), (x1, yf_, zf), (x1, yb, zb), (x0, yb, zb), uv=((0, rows), (abs(x1 - x0) / 4, rows), (abs(x1 - x0) / 4, 0), (0, 0)))
    else: quad(mesh, 'seats', (x1, yf_, zf), (x0, yf_, zf), (x0, yb, zb), (x1, yb, zb), uv=((0, rows), (abs(x1 - x0) / 4, rows), (abs(x1 - x0) / 4, 0), (0, 0)))
    # front wall, back wall, ends
    strip(mesh, 'concrete', np.array([[x0, zf], [x1, zf]]), y0, y0 + 1.2, 4.0)
    strip(mesh, 'concrete', np.array([[x0, zb], [x1, zb]]), y0, yb, 4.0)
    for x in (x0, x1):
        P = np.array([(x, y0, zf), (x, yf_, zf), (x, yb, zb), (x, y0, zb)])
        mesh.add('concrete', P, np.array([[0, 0], [0, 0.3], [D / 4, 2], [D / 4, 0]]), np.array([[0, 1, 2], [0, 2, 3]]), phys=False)
    mesh.wall((x0, zf), (x1, zf), y0 - 0.3, y0 + 1.5); mesh.wall((x0, zb), (x1, zb), y0 - 0.3, yb)
    mesh.wall((x0, zf), (x0, zb), y0 - 0.3, yb); mesh.wall((x1, zf), (x1, zb), y0 - 0.3, yb)
    if roof:
        ry = yb + 3.5
        flat_quad(mesh, 'metal', min(x0, x1), min(zf, zb) - 2 * facing * 0, max(x0, x1), max(zf, zb), ry, uvk=4.0, phys=False)
        for x in np.linspace(x0 + 2, x1 - 2, max(2, int(abs(x1 - x0) / 25) + 1)):
            box(mesh, x, zb + facing * 0.3, yb, 0.4, 0.4, 3.5, 0.0, 'post', collide=False, top=False)


def tent(mesh, cx, cz, y0, size, mat, yaw=0.0):
    """a pop-up canopy: four legs and a pyramid roof"""
    s = size / 2; c, sn = np.cos(yaw), np.sin(yaw)
    W = lambda lx, lz: (cx + lx * c - lz * sn, cz + lx * sn + lz * c)
    corners = [W(-s, -s), W(s, -s), W(s, s), W(-s, s)]
    eave, peak = y0 + 2.6, y0 + 3.8
    top = (cx, peak, cz)
    for i in range(4):
        a, b = corners[i], corners[(i + 1) % 4]
        mesh.add(mat, np.array([(a[0], eave, a[1]), (b[0], eave, b[1]), top]), np.array([[0, 1], [1, 1], [0.5, 0]]), np.array([[0, 2, 1]]), phys=False)
        strip(mesh, mat, np.array([a, b]), eave - 0.3, eave, size, 0.0, 0.1)          # valance
    for a in corners:
        box(mesh, a[0], a[1], y0, 0.08, 0.08, 2.6, yaw, 'post', collide=False, top=False)






# ---------------------------------------------------------------- drag strip, oval, gate



def perimeter_fence(mesh, G):
    H = LY.HALF
    for (a, b) in (((-H, -H), (H, -H)), ((H, -H), (H, H)), ((H, H), (-H, H)), ((-H, H), (-H, -H))):
        n = int(np.hypot(b[0] - a[0], b[1] - a[1]) / 8) + 1
        t = np.linspace(0, 1, n)
        pts = np.c_[a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
        yg = G.surface(pts[:, 0], pts[:, 1])
        strip(mesh, 'fence', pts, yg - 0.1, yg + 2.6, 3.0)
        for p, yy in zip(pts[::4], yg[::4]):
            box(mesh, p[0], p[1], yy, 0.1, 0.1, 2.7, 0.0, 'post', collide=False, top=False)
        mesh.wall_line(pts, yg - 0.5, yg + 2.6)


def marshal_posts(mesh, G, rd, every=700):
    for s in np.arange(150, rd.L - 100, every):
        j = int(s) % len(rd.P)
        p = rd.P[j] + rd.n[j] * (rd.half + 12)
        nm, _ = G.road_at([p[0]], [p[1]], margin=4)
        if nm[0] is not None: continue
        y = float(G.height([p[0]], [p[1]])[0])
        box(mesh, p[0], p[1], y, 2.4, 2.4, 2.6, float(np.arctan2(rd.t[j, 1], rd.t[j, 0])), dict(front='windows', back='metal', left='metal', right='metal', top='roof'), uvm=(2.4, 2.6))


# ---------------------------------------------------------------- trees
def keep_clear(G, X, Z, clear):
    """points at least `clear` metres from every road edge and pad"""
    ok = np.ones(len(X), bool)
    for k, rd in G.roads.items():
        d, _ = G.trees[k].query(np.c_[X, Z], distance_upper_bound=rd.half + rd.verge + clear)
        ok &= ~np.isfinite(d)
    for k, (r, h) in G.pads.items():
        ok &= ~((X > r['x0'] - clear) & (X < r['x1'] + clear) & (Z > r['z0'] - clear) & (Z < r['z1'] + clear))
    return ok



# ---------------------------------------------------------------- beyond the fence
def far_scenery(mesh, G):
    """tree lines on the hills outside the fence, a ring of high hills, mountains on the horizon"""
    import tin
    # tree lines: rows of wide cards following the ground, from just outside the fence out to 900 m
    for off in np.arange(30, 900, 70):
        for side in range(4):
            Hh = LY.HALF + off
            L = 2 * Hh
            n = int(L / 38)
            t = (np.arange(n) + RNG.uniform(0, 1, n) * 0.5) / n
            a = -Hh + L * t
            if side == 0: X, Z = a, np.full(n, -Hh)
            elif side == 1: X, Z = np.full(n, Hh), a
            elif side == 2: X, Z = -a, np.full(n, Hh)
            else: X, Z = np.full(n, -Hh), -a
            X = X + RNG.uniform(-12, 12, n); Z = Z + RNG.uniform(-12, 12, n)
            ok = tin.inside(X, Z, 60) & keep_clear(G, X, Z, 26.0)  # on the ground, short of its edge, off the roads
            X, Z, n = X[ok], Z[ok], int(ok.sum())
            Y = G.height(X, Z) - 1.0
            yaw = np.full(n, 0.0 if side in (0, 2) else np.pi / 2)
            h = RNG.uniform(16, 24, n)
            row = RNG.integers(0, 4, n)
            for r in range(4):
                sel = row == r
                if sel.any():
                    cards(mesh, 'treeline', X[sel], Y[sel], Z[sel], np.full(sel.sum(), 44.0), h[sel], yaw[sel], uv=(0, r * 0.25, 1, (r + 1) * 0.25), crossed=False)
    # a ring of high wooded hills from the edge of the heightfield out to 10 km
    from scipy.ndimage import gaussian_filter1d
    rings = np.array([tin.RING_R, 5800, 6700, 7800, 9000, 10200])
    pows = [tin.RING_P, 3.0, 2.5, 2.0, 2.0, 2.0]          # rounded square at the ground's edge, circles further out
    ang = tin.RING_A; na = len(ang)
    ex = [tin.edge(r, p) for r, p in zip(rings, pows)]
    rng = np.random.default_rng(5)
    hh = np.zeros((len(rings), na))
    for i, r in enumerate(rings):
        if i == 0: hh[i] = TR.sample(G.H, *ex[0])     # the ground's own edge points
        else:
            base = 160 + 150 * (i / len(rings)) + 110 * np.sin(ang * 3 + i) * (i > 1)
            hh[i] = gaussian_filter1d(base + rng.normal(0, 70, na) * (i > 1), 6, mode='wrap')
    hh[1] = np.maximum(hh[1], hh[0] + 20)
    a2 = np.r_[ang, ang[:1]]
    P = np.zeros((len(rings), na + 1, 3))
    for i, r in enumerate(rings):
        P[i, :, 0] = np.r_[ex[i][0], ex[i][0][:1]]; P[i, :, 2] = np.r_[ex[i][1], ex[i][1][:1]]; P[i, :, 1] = np.r_[hh[i], hh[i, :1]]
    U = np.dstack([P[:, :, 0] / 120, P[:, :, 2] / 120])
    I = grid_tris(len(rings), na + 1)
    mesh.add('far_hill', P.reshape(-1, 3), U.reshape(-1, 2), I[:, [0, 2, 1]], phys=False)
    # mountains on the horizon: big cards, the backdrop's own haze, in a ring at 12-13.5 km
    na2 = 26
    for k in range(na2):
        a = 2 * np.pi * (k + rng.uniform(-0.15, 0.15)) / na2
        r = 12500 + rng.uniform(-700, 700)
        w = 2 * np.pi * r / na2 * 1.35
        hgt = rng.uniform(900, 1500)
        cx, cz = r * np.cos(a), r * np.sin(a)
        tx, tz = -np.sin(a), np.cos(a)
        A = (cx - tx * w / 2, -150, cz - tz * w / 2); B = (cx + tx * w / 2, -150, cz + tz * w / 2)
        u0 = rng.uniform(0, 0.6)
        quad(mesh, 'alps', A, B, (B[0], hgt, B[2]), (A[0], hgt, A[2]), uv=((u0, 1), (u0 + 0.4, 1), (u0 + 0.4, 0), (u0, 0)), split=None)


# ---------------------------------------------------------------- pits and paddocks
CANV = ['canvas', 'canvas_r', 'canvas_b', 'canvas_y']


def garages(mesh, x0, x1, zf, y, facing=1, depth=20, height=8, upper=True):
    """a row of pit garages: doors facing -z (facing=1, the pit lane north of them) or +z (facing=-1)"""
    n = int((x1 - x0) / 12)
    zc = zf + facing * depth / 2
    yaw = 0.0 if facing > 0 else np.pi
    for i in range(n):
        cx = x0 + 6 + 12 * i
        box(mesh, cx, zc, y, 12, depth, height, yaw, dict(front='garage', back='block', left=None, right=None, top='roof'),
            uvm=(12, height), tex_full=('front',), collide=False)
    zb = zf + facing * depth
    for (a, b) in (((x0, zf), (x1, zf)), ((x1, zf), (x1, zb)), ((x1, zb), (x0, zb)), ((x0, zb), (x0, zf))):
        mesh.wall(a, b, y - 0.3, y + height)
    strip(mesh, 'block', np.array([[x0, zb], [x0, zf]]), y, y + height, 6.0)
    strip(mesh, 'block', np.array([[x1, zf], [x1, zb]]), y, y + height, 6.0)
    if upper:          # hospitality windows over the garages, set back
        box(mesh, (x0 + x1) / 2, zf + facing * (depth * 0.7), y + height, x1 - x0, depth * 0.6, 3.2, yaw,
            dict(front='windows', back='windows', left='block', right='block', top='roof'), uvm=(8.0, 3.2), collide=False)


def pit_wall(mesh, G, track, pit, y):
    """a concrete wall with a catch fence between a pit lane and its track, where they run side by side"""
    d, j = cKDTree(track.P).query(pit.P)
    ok = (d > track.half + pit.half - 1) & (d < track.half + pit.half + 20)
    for r in TG.runs(ok, 20):
        ids = r[2:-2][::3]
        if len(ids) < 3: continue
        mid = (pit.P[ids] + track.P[j[ids]]) / 2
        yw = np.full(len(mid), y)
        TG.conc_wall(mesh, mid, yw, 1.1)
        TG.fence(mesh, mid, yw + 1.1, yw + 4.0)


def haulers(mesh, G, xs, z, y, yaw, start=0):
    for i, x in enumerate(xs):
        hauler.place(mesh, x, y, z, yaw, start + i)


def gp_pits(mesh, G, y):
    """the GP: garages and race control along the pit lane, the pit wall, the main grandstand across the straight,
    transporters and hospitality in the paddock behind"""
    zf = LY.PIT_Z + 6 + 2                                     # garage fronts: 2 m of apron off the pit lane
    garages(mesh, -420, 140, zf, y)
    garages(mesh, 180, 800, zf, y)
    box(mesh, 160, zf + 14, y, 16, 14, 18, 0.0, dict(front='facade', back='facade', left='facade', right='facade', top='roof'), uvm=(8, 8))
    box(mesh, 160, zf + 14, y + 18, 18, 16, 3.5, 0.0, dict(front='glass', back='glass', left='glass', right='glass', top='roof'), collide=False)
    pit_wall(mesh, G, G.roads['gp'], G.roads['pit'], y)
    # the main grandstand across the straight, behind a catch fence
    zs = LY.GP_STRAIGHT_Z - 6 - 11
    grandstand(mesh, -350, 650, zs, y, rows=16, facing=1)
    fz = LY.GP_STRAIGHT_Z - 6 - 8
    TG.conc_wall(mesh, np.array([[x, fz] for x in np.arange(-380, 681, 10.0)]), y, 1.1)
    TG.fence(mesh, np.array([[x, fz] for x in np.arange(-380, 681, 10.0)]), y + 1.1, y + 5.0)
    # the paddock: a row of transporters nose-in behind the garages, an awning beside each; hospitality and workshops
    zt = zf + 20 + 26
    xs = np.arange(-380, 800, 62.0)
    haulers(mesh, G, xs, zt, y, -np.pi / 2)
    for i, x in enumerate(xs): tent(mesh, x + 7.5, zt + 3, y, 6.0, CANV[i % 4])
    # a second row facing them across the paddock road, motorhomes (hospitality units) between
    xs2 = np.arange(-350, 800, 96.0)
    haulers(mesh, G, xs2, zt + 58, y, np.pi / 2, start=3)
    for i, x in enumerate(xs2):
        box(mesh, x + 30, zt + 58, y, 12, 2.5, 3.6, 0.0, dict(front='windows', back='windows', left='truck_w', right='truck_w', top='roof'), uvm=(6, 3.6))
        tent(mesh, x + 48, zt + 58, y, 8.0, CANV[(i + 1) % 4])
    building(mesh, 600, 772, y, 90, 18, 8, 0.0, front='windows', side='block', uvm=(8, 3.2))
    for x in (-360, -240, -120):
        building(mesh, x, 772, y, 100, 22, 7, 0.0, front='metal', side='block', uvm=(4, 4))
    for x in np.arange(40, 470, 14):
        tent(mesh, x, 748, y, 8.0, CANV[int(x) // 14 % 4])
    TG.start_gantry(mesh, G, G.roads['gp'], 0.0)
    TG.masts(mesh, G, [(x, 680) for x in np.arange(-420, 850, 160)] + [(x, 786) for x in np.arange(-420, 850, 320)])


def oval_infield(mesh, G):
    """the oval: garages along its pit lane, transporters and a media centre in the infield, a grandstand along
    the front stretch outside, light masts round it"""
    r = LY.OVAL_PAD; y = G.pads['oval'][1]
    pit = G.roads['oval_pit']
    zf = LY.OVAL_PIT_Z - pit.half - 2                          # garage fronts face +z, toward the pit lane
    garages(mesh, -100, 104, zf, y, facing=-1, depth=14, height=5, upper=False)
    xs = np.arange(-170, 190, 48.0)
    haulers(mesh, G, xs, 40, y, np.pi / 2, start=2)            # nose toward the garages
    building(mesh, 0, -80, y, 120, 20, 9, 0.0, front='windows', side='facade', uvm=(8, 3.2))
    for x in np.arange(-150, 160, 20): tent(mesh, x, -40, y, 7.0, CANV[int(x) // 20 % 4])
    # grandstand outside the front stretch, facing it
    zs = LY.OVAL_C[1] + LY.OVAL_R + LY.OVAL_HALF + 14
    gy = float(G.height([0], [zs + 6])[0])
    grandstand(mesh, -260, 260, zs, gy, rows=18, facing=-1)
    # masts round the outside
    ang = np.linspace(0, 2 * np.pi, 14, endpoint=False)
    pts = []
    for a in ang:
        R = LY.OVAL_R + 40
        cx = LY.OVAL_C[0] + np.sign(np.cos(a)) * LY.OVAL_STRAIGHT / 2
        x, z = cx + R * np.cos(a), LY.OVAL_C[1] + R * np.sin(a)
        if abs(np.cos(a)) < 0.35: x = LY.OVAL_C[0] + LY.OVAL_STRAIGHT * 0.45 * np.cos(a) / 0.35
        nm, _ = G.road_at([x], [z], margin=6)
        if nm[0] is None: pts.append((x, z))
    TG.masts(mesh, G, pts)


def enduro_pits(mesh, G):
    y = G.pads['enduro'][1]; r = LY.ENDURO_PAD
    zf = LY.ENDURO_PIT_Z - 6 - 2                               # the pits face +z (the straight south of them)
    garages(mesh, 420, 1240, zf, y, facing=-1)
    pit_wall(mesh, G, G.roads['enduro'], G.roads['enduro_pit'], y)
    xs = np.arange(440, 1240, 70.0)
    haulers(mesh, G, xs, zf - 20 - 30, y, np.pi / 2, start=3)
    for i, x in enumerate(xs): tent(mesh, x + 7.5, zf - 20 - 26, y, 6.0, CANV[i % 4])
    # grandstand across the straight
    zs = 3650 + 6 + 12
    gy = float(G.height([800], [zs + 6])[0])
    grandstand(mesh, 300, 1300, zs, gy, rows=12, facing=-1)
    TG.start_gantry(mesh, G, G.roads['enduro'], 0.0)
    TG.masts(mesh, G, [(x, 3460) for x in np.arange(420, 1260, 200)])


def drift_paddock(mesh, G):
    r = LY.DRIFT_PAD; y = G.pads['drift'][1]
    building(mesh, r['x0'] + 30, r['z1'] - 14, y, 40, 14, 6, 0.0, front='garage', side='block', uvm=(12, 6))
    haulers(mesh, G, [r['x0'] + 95, r['x0'] + 140], (r['z0'] + r['z1']) / 2 + 10, y, -np.pi / 2, start=4)
    for i in range(3): tent(mesh, r['x0'] + 20 + 12 * i, r['z0'] + 14, y, 6.0, CANV[i])
    rd = G.roads['drift']
    # concrete walls close along the outside of the drift track's corners, guardrail elsewhere beyond a run-off
    for sd in (1, -1):
        o = sd * (rd.half + 6.0)
        pts = rd.P + rd.n * o
        ok = np.ones(len(pts), bool)
        nm, _ = G.road_at(pts[:, 0], pts[:, 1], margin=4.0); ok &= nm == None
        pn, _ = G.pad_at(pts[:, 0], pts[:, 1], margin=4.0); ok &= pn == None
        dd, _ = G.trees['drift'].query(pts); ok &= dd > rd.half + 5
        sh = int(np.argmin(ok)); order = np.roll(np.arange(len(pts)), -sh)
        for run in TG.runs(ok[order], 10):
            ids = order[run][::3]
            TG.conc_wall(mesh, pts[ids], G.height(pts[ids, 0], pts[ids, 1]), 1.1)
    TG.masts(mesh, G, [(1340, 560), (1800, 560), (1800, 880), (1400, 960)])


def slalom_pad(mesh, G):
    r = LY.SLALOM; y = G.pads['slalom'][1]
    TG.masts(mesh, G, [(r['x0'] - 12, r['z0'] - 12), (r['x1'] + 12, r['z0'] - 12), (r['x0'] - 12, r['z1'] + 12), (r['x1'] + 12, r['z1'] + 12)])
    building(mesh, r['x1'] - 30, r['z1'] - 12, y, 30, 12, 4, 0.0, front='windows', side='block', uvm=(6, 3))


def drag_strip(mesh, G, rd):
    """lane lines, the start and finish, walls, the lights 'tree', timing tower, a stand along the south side;
    cars run toward -x"""
    y = float(rd.y[0]); z = LY.DRAG_Z; dr = LY.DRAG_DIR
    xs = LY.DRAG_START; xf = xs + dr * 402.34
    for zz in (z - 7.6, z + 7.6):
        flat_quad(mesh, 'paint', LY.DRAG_X0, zz - 0.08, LY.DRAG_X1 + 20, zz + 0.08, y, lift=0.012)
    flat_quad(mesh, 'paint', xs - 0.3, z - 7.8, xs + 0.3, z + 7.8, y, lift=0.013)
    flat_quad(mesh, 'checker', xf - 0.6, z - 7.8, xf + 0.6, z + 7.8, y, lift=0.013)
    flat_quad(mesh, 'paint', LY.DRAG_X0 + 20, z - 0.15, xs, z + 0.15, y, lift=0.012)
    # walls along both sides (open at the staging end and where the return road turns off)
    for zz in (z - 8.6, z + 8.6):
        pts = np.array([[x, zz] for x in np.arange(xs + 30, LY.DRAG_X0 + 40, -10.0)])
        TG.conc_wall(mesh, pts, y, 1.1)
    # the divider between the lanes, from just behind the start to the end of the shut-down
    pts = np.array([[x, z] for x in np.arange(xs + 4, LY.DRAG_X0 + 90, -10.0)])
    TG.conc_wall(mesh, pts, y, 0.9)
    # the start 'tree' on the divider, facing the cars at the line
    box(mesh, xs + 4, z, y + 0.9, 0.3, 0.3, 2.6, 0.0, 'post', collide=False)
    for k, (mat, hy) in enumerate((('lamp_y', 2.9), ('lamp_y', 2.6), ('lamp_y', 2.3), ('lamp_g', 1.9), ('lamp_r', 1.6))):
        box(mesh, xs + 4, z, y + hy, 0.45, 0.45, 0.22, 0.0, mat, collide=False)
    building(mesh, xs + 30, z - 26, y, 10, 10, 9, front='facade', side='facade')
    building(mesh, xf, z - 24, y, 8, 8, 6, front='windows', side='facade', uvm=(4, 3))
    # grandstand along the south side, facing the strip
    grandstand(mesh, xf - 60, xs + 30, z + 18, y, rows=8, facing=-1)
    TG.masts(mesh, G, [(x, z - 30) for x in np.arange(xs, xf - 400, -200)] + [(x, z + 50) for x in np.arange(xs, xf - 400, -250)])
    speed_spots = []
    return speed_spots


def gatehouse(mesh, G):
    gx, gz = LY.GATE_X, LY.HALF - 18
    y = float(G.surface([gx], [gz - 10])[0])
    building(mesh, gx + 14, gz, y, 6, 4, 3, front='windows', side='concrete', uvm=(6, 3))
    box(mesh, gx, LY.HALF - 10, y + 0.9, 8.0, 0.15, 0.15, 0.0, 'lamp_r', collide=False)


# ---------------------------------------------------------------- trees
def trees(mesh, G):
    """forests in the band between the endurance circuit and the fence (thickest at the edge), copses here and there
    in the open ground inside (left mostly open, for later), lines of trees along the service roads and clumps
    beside the circuits; individual trees fade out at 1.3 km"""
    n2 = TR.noise(21)
    def F(x, z): return TR.sample(n2, x, z)
    sp = 18.0
    gx, gz = np.meshgrid(np.arange(-LY.HALF + 20, LY.HALF - 20, sp), np.arange(-LY.HALF + 20, LY.HALF - 20, sp))
    X = gx.ravel() + RNG.uniform(-sp * 0.45, sp * 0.45, gx.size); Z = gz.ravel() + RNG.uniform(-sp * 0.45, sp * 0.45, gx.size)
    f = F(X, Z)
    edge = np.maximum(np.abs(X), np.abs(Z))
    inner = np.clip((3350 - edge) / 300, 0, 1)                 # 1 well inside the endurance circuit
    core = (np.abs(X - 250) < 1700) & (Z > -2000) & (Z < 1400)  # the central complex
    dens = np.clip((f - 0.2) * 2.4, 0, 1) * (1 - inner) + np.clip((f - 0.55) * 1.6, 0, 1) * inner * np.where(core, 0.6, 0.35)
    dens += np.clip((edge - 3700) / 300, 0, 1) * 0.6
    take = RNG.random(len(X)) < dens
    X, Z = X[take], Z[take]
    ok = keep_clear(G, X, Z, 28.0)
    X, Z = X[ok], Z[ok]
    print(f'trees: {len(X)} in woods')
    roadside = []
    for k in ('gate', 'infield', 'drift_rd', 'slalom_rd'):
        rd = G.roads[k]
        for s in np.arange(10, rd.L - 10, 18):
            j = int(s)
            if not rd.ground[j]: continue
            for sd in (1, -1):
                if RNG.random() < 0.3: continue
                roadside.append(rd.P[j] + rd.n[j] * sd * (rd.half + 11 + RNG.uniform(-1.5, 1.5)))
    roadside = np.array(roadside)
    ok = keep_clear(G, roadside[:, 0], roadside[:, 1], 6.0)
    roadside = roadside[ok]
    clumps = []
    for k, clear in (('gp', 24.0), ('int_link', 24.0), ('nat_link', 24.0), ('enduro', 22.0)):
        rd = G.roads[k]
        for s in np.arange(5, rd.L - 5, 11):
            j = int(s)
            for sd in (1, -1):
                clumps.append(rd.P[j] + rd.n[j] * sd * (rd.half + rd.verge + clear + RNG.uniform(0, 22)))
    clumps = np.array(clumps)
    f2 = F(np.mod(clumps[:, 0] * 3.1 + 5700, 10400) - 5200, np.mod(clumps[:, 1] * 3.1 + 5200, 10400) - 5200)
    clumps = clumps[(f2 > 0.05) & (RNG.random(len(clumps)) < 0.7)]
    ok = keep_clear(G, clumps[:, 0], clumps[:, 1], 12.0)
    roadside = np.r_[roadside, clumps[ok]]
    X = np.r_[X, roadside[:, 0]]; Z = np.r_[Z, roadside[:, 1]]
    Y = G.height(X, Z) - 0.15
    kind = F(X * 1.7 + 900, Z * 1.7) + 0.4 * (Z < -1500)
    for mat, sel, aspect, hr in (('pine', kind > 0.35, 0.5, (14, 24)), ('tree_a', (kind <= 0.35) & (kind > -0.1), 1.0, (11, 18)),
                                 ('tree_b', kind <= -0.1, 1.0, (9, 15))):
        n = int(sel.sum())
        if not n: continue
        h = RNG.uniform(*hr, n)
        cards(mesh, mat, X[sel], Y[sel], Z[sel], h * aspect, h, RNG.uniform(0, np.pi, n))
    print(f'trees: {len(X)} in all ({len(roadside)} along the roads and circuits)')
    bx, bz = [], []
    for k, (r, h) in G.pads.items():
        per = np.r_[np.c_[np.linspace(r['x0'], r['x1'], 12), np.full(12, r['z1'] + 8)], np.c_[np.full(8, r['x0'] - 8), np.linspace(r['z0'], r['z1'], 8)]]
        bx.extend(per[:, 0]); bz.extend(per[:, 1])
    bx, bz = np.array(bx), np.array(bz)
    ok = keep_clear(G, bx, bz, 3.0)
    bx, bz = bx[ok], bz[ok]
    cards(mesh, 'bush', bx, G.height(bx, bz) - 0.1, bz, np.full(len(bx), 5.0), np.full(len(bx), 2.4), RNG.uniform(0, np.pi, len(bx)), uv=(0, 0, 1, 1))
