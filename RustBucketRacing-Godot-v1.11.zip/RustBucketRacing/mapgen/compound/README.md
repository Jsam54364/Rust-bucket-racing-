# The Motorsport Compound generator

Builds `compound.bin` and `compound.json` (the installable map) from scratch: layout, heights, ground, roads,
kerbs, run-off, barriers, buildings, trees and the scenery beyond the fence. Not part of the game build
(`mapgen/.gdignore` keeps Godot out of this folder).

Needs Python 3 with numpy, scipy, scikit-image, Pillow (webp) and matplotlib, Godot 4.7 (set `GODOT` to its binary: it simplifies
meshes and makes the LODs headless, and renders the barrier and transporter pictures under `xvfb-run`), and two models from Sketchfab
(CC BY 4.0) next to the scripts: `race_track_assets_pack.glb` ("Race Track Assets Pack" by Cherk) and
`dav_nascar_hauler.glb` ("DAV NASCAR Hauler" by jairobman).

    python3 extract_textures.py <folder with spa.bin, mcr.bin, iroha.bin>   # the borrowed textures -> tex_src/
    GODOT=/path/to/godot python3 gen.py compound.bin                         # ~1.5 min: compound.bin + compound.json
    python3 check_phys.py compound.bin                                       # holes and steps in the drive surface

- `layout.py`: where everything goes: the GP's corners and its three configurations, the oval, drift track, endurance
  circuit, drag strip, pads, service roads
- `terrain.py`: the heightfield, each road's height profile (the GP's designed corner heights; grade-limited, levelled
  at junctions and pads), the oval's banked cross-section, bridges where a service road crosses a track, cut and fill
- `junctions.py`: where the GP's configurations part and join, the V between the tracks filled with asphalt to a rounded
  nose, the edge line carried round it
- `tin.py`: the ground as one triangulation, dense near the roads, edged by a rounded square; the gravel traps are part of it
- `trackgen.py`: road surfaces (no edge line where one track runs over another), kerbs placed the way
  Spa-Francorchamps has them (none across a junction), gravel traps, tyre walls, guardrail (round the GP's
  configurations as one line, so it is never doubled), the drift track's judged zones, lines, grid
- `objects.py`: pits, paddocks, stands, transporters, tents, gate, fences, trees, and the far hills and mountains
- `kit.py`, `bake.gd`, `simplify.gd`: the assets pack simplified, and its barriers rendered to pictures for strips
- `hauler.py`, `hull_part.py`, `hullbake.gd`, `glb.py`: the transporter: its tractor unit rendered from six sides and
  rebuilt as one closed shell (the space inside its front, side and top silhouettes, meshed and simplified) wearing
  those pictures, so it has no holes at any triangle budget; its windows as tinted glass, the maker's lettering and
  the sponsor's logo left off, the wheels rebuilt as cylinders; the trailer given new texture coordinates and six
  liveries drawn here, the cab painted to match
- `writer.py`: the RBMP v2 pack (chunks, LODs, walls, the extra map data the game reads from 1.9; course groups from 1.10)
