extends SceneTree
# Simplify meshes to a triangle budget with meshoptimizer (SurfaceTool.generate_lod: no border locking, so
# meshes made of many small open pieces still come down):
#   godot --headless --script simplify.gd -- <in.bin> <out.bin>
# in:  'SIMI' u32 count, then per mesh: u32 nv, u32 ni, u32 target, f32 error, f32 pos[nv*3], u32 idx[ni]
# out: 'SIMO' u32 count, then per mesh: u32 n, u32 idx[n]
func _initialize():
	var args := OS.get_cmdline_user_args()
	var f := FileAccess.open(args[0], FileAccess.READ)
	if f == null or f.get_buffer(4).get_string_from_ascii() != "SIMI":
		printerr("simplify: bad input"); quit(1); return
	var count := f.get_32()
	var out := FileAccess.open(args[1], FileAccess.WRITE)
	out.store_buffer("SIMO".to_ascii_buffer()); out.store_32(count)
	for k in count:
		var nv := f.get_32(); var ni := f.get_32(); var target := f.get_32(); var err := f.get_float()
		var pos := f.get_buffer(nv * 12).to_float32_array()
		var idx := f.get_buffer(ni * 4).to_int32_array()
		var st := SurfaceTool.new()
		st.begin(Mesh.PRIMITIVE_TRIANGLES)
		for i in nv: st.add_vertex(Vector3(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]))
		for i in idx: st.add_index(i)
		var li: PackedInt32Array = st.generate_lod(err, target * 3)
		out.store_32(li.size()); out.store_buffer(li.to_byte_array())
	out.close()
	quit(0)
