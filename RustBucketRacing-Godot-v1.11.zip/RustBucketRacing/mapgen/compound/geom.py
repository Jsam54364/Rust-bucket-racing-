"""Mesh building blocks for the compound: an accumulator of triangles per material, and primitives (grids of
vertices, boxes, vertical strips along a line, cards)."""
import numpy as np


class Mesh:
    def __init__(self):
        self.parts = {}          # material key -> list of (P, N, UV, I, phys)
        self.walls = []          # (ax, az, bx, bz, y0, y1)

    def add(self, mat, P, UV, I, N=None, phys=True):
        P = np.asarray(P, np.float64).reshape(-1, 3); UV = np.asarray(UV, np.float64).reshape(-1, 2)
        I = np.asarray(I, np.int64).reshape(-1, 3)
        if not len(I): return
        if N is None: N = smooth_normals(P, I)
        ph = np.full(len(I), bool(phys)) if np.isscalar(phys) or isinstance(phys, bool) else np.asarray(phys, bool)
        self.parts.setdefault(mat, []).append((P, np.asarray(N, np.float64).reshape(-1, 3), UV, I, ph))

    def wall(self, A, B, y0, y1):
        if np.hypot(B[0] - A[0], B[1] - A[1]) > 0.05:
            self.walls.append((float(A[0]), float(A[1]), float(B[0]), float(B[1]), float(y0), float(y1)))

    def wall_line(self, pts, y0, y1):
        """collision along a polyline; y0, y1 per point or scalars"""
        y0 = np.broadcast_to(y0, len(pts)); y1 = np.broadcast_to(y1, len(pts))
        for i in range(len(pts) - 1):
            self.wall(pts[i], pts[i + 1], min(y0[i], y0[i + 1]), max(y1[i], y1[i + 1]))

    def stats(self):
        out = {}
        for k, L in self.parts.items():
            out[k] = (sum(len(p[0]) for p in L), sum(len(p[3]) for p in L))
        return out


def smooth_normals(P, I):
    fn = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])
    N = np.zeros_like(P)
    for k in range(3): np.add.at(N, I[:, k], fn)
    l = np.linalg.norm(N, axis=1, keepdims=True)
    N = np.where(l > 1e-12, N / np.maximum(l, 1e-12), [0, 1, 0])
    return N


def flat_normals(P, I):
    """unshared vertices per triangle with face normals (for boxes)"""
    T = P[I]; fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    fn /= np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-12)
    return np.repeat(fn, 3, axis=0)


def grid_tris(na, nc, closed=False):
    """triangles over a grid of na rows (along) by nc columns (across), row-major vertex order"""
    r, c = np.mgrid[0:na - 1 + (1 if closed else 0), 0:nc - 1]
    r1 = (r + 1) % na
    a = r * nc + c; b = r * nc + c + 1; d = r1 * nc + c; e = r1 * nc + c + 1
    return np.concatenate([np.stack([a, d, b], -1).reshape(-1, 3), np.stack([b, d, e], -1).reshape(-1, 3)])


def quad(mesh, mat, A, B, C, D, uv=((0, 0), (1, 0), (1, 1), (0, 1)), phys=False, split=40.0):
    """one quad A-B-C-D (counter-clockwise seen from its front)"""
    P = np.array([A, B, C, D], float); uv = np.array(uv, float)
    nrm = np.cross(P[1] - P[0], P[2] - P[0]); nrm /= np.linalg.norm(nrm) + 1e-12
    # long quads are cut into pieces of at most 40 m (chunks stay compact, culling stays fine)
    la = max(np.linalg.norm(P[1] - P[0]), np.linalg.norm(P[2] - P[3])); lb = max(np.linalg.norm(P[3] - P[0]), np.linalg.norm(P[2] - P[1]))
    na, nb = (int(np.ceil(la / split)), int(np.ceil(lb / split))) if split else (1, 1)
    if na <= 1 and nb <= 1:
        mesh.add(mat, P, uv, np.array([[0, 1, 2], [0, 2, 3]]), N=np.repeat(nrm[None], 4, 0), phys=phys)
        return
    s = np.linspace(0, 1, na + 1); t = np.linspace(0, 1, nb + 1)
    S, T = np.meshgrid(s, t)                                 # rows along A->D, columns along A->B
    w = [(1 - S) * (1 - T), S * (1 - T), S * T, (1 - S) * T]
    PP = sum(w[k][..., None] * P[k] for k in range(4)).reshape(-1, 3)
    UU = sum(w[k][..., None] * uv[k] for k in range(4)).reshape(-1, 2)
    I = grid_tris(nb + 1, na + 1)[:, [0, 2, 1]]
    mesh.add(mat, PP, UU, I, N=np.repeat(nrm[None], len(PP), 0), phys=phys)


def box(mesh, cx, cz, y0, w, d, h, yaw=0.0, mats=None, uvm=(4.0, 4.0), top=True, collide=True, tex_full=None):
    """an upright box: w along its local x, d along local z, standing on y0, turned by yaw.
    mats: dict side -> material ('front' faces local -z, 'back' +z, 'left' -x, 'right' +x, 'top'); a string for all.
    uvm: metres per texture repeat (u along the face, v up). tex_full: sides that take the whole texture once."""
    if isinstance(mats, str): mats = dict(front=mats, back=mats, left=mats, right=mats, top=mats)
    c, s = np.cos(yaw), np.sin(yaw)
    def W(lx, lz): return np.array([cx + lx * c - lz * s, cz + lx * s + lz * c])
    hw, hd = w / 2, d / 2
    corners = [W(-hw, -hd), W(hw, -hd), W(hw, hd), W(-hw, hd)]       # front-left, front-right, back-right, back-left
    faces = {'front': (corners[1], corners[0], w), 'right': (corners[2], corners[1], d),
             'back': (corners[3], corners[2], w), 'left': (corners[0], corners[3], d)}
    tex_full = tex_full or ()
    for name, (a, b, L) in faces.items():
        m = mats.get(name)
        if not m: continue
        if name in tex_full: U = ((0, 1), (1, 1), (1, 0), (0, 0))
        else:
            u = L / uvm[0]; v = h / uvm[1]
            U = ((0, v), (u, v), (u, 0), (0, 0))
        quad(mesh, m, (a[0], y0, a[1]), (b[0], y0, b[1]), (b[0], y0 + h, b[1]), (a[0], y0 + h, a[1]), uv=U)
    if top and mats.get('top'):
        k = uvm[0]
        P = [(p[0], y0 + h, p[1]) for p in corners]
        quad(mesh, mats['top'], P[3], P[2], P[1], P[0], uv=[(p[0] / k, p[2] / k) for p in (P[3], P[2], P[1], P[0])])
    if collide:
        for i in range(4): mesh.wall(corners[i], corners[(i + 1) % 4], y0 - 0.3, y0 + h)
    return corners


def strip(mesh, mat, pts, ybot, ytop, u_per_m, v0=0.0, v1=1.0, phys=False, face=None, tilt=0.0):
    """an upright strip along a polyline (fences, rails, walls): u along (metres / u_per_m), v from v1 at the
    bottom to v0 at the top. face: the side it is seen from (unit vectors per point); its normals then point
    that way, tipped up by `tilt` (so a barrier in shade still catches the sky)"""
    pts = np.asarray(pts, float); n = len(pts)
    if n < 2: return
    ybot = np.broadcast_to(np.asarray(ybot, float), n); ytop = np.broadcast_to(np.asarray(ytop, float), n)
    if face is not None: face = np.broadcast_to(np.asarray(face, float), (n, 2))
    seg = np.hypot(*np.diff(pts, axis=0).T)
    if seg.max() > 40.0:                                       # cut long runs into pieces of at most 40 m
        s0 = np.concatenate([[0], np.cumsum(seg)])
        s1 = np.unique(np.concatenate([s0] + [np.linspace(s0[i], s0[i + 1], int(np.ceil(seg[i] / 40.0)) + 1) for i in range(n - 1)]))
        pts = np.c_[np.interp(s1, s0, pts[:, 0]), np.interp(s1, s0, pts[:, 1])]
        if face is not None: face = np.c_[np.interp(s1, s0, face[:, 0]), np.interp(s1, s0, face[:, 1])]
        ybot = np.interp(s1, s0, ybot); ytop = np.interp(s1, s0, ytop); n = len(pts)
    s = np.concatenate([[0], np.cumsum(np.hypot(*np.diff(pts, axis=0).T))])
    P = np.zeros((n, 2, 3)); UV = np.zeros((n, 2, 2))
    P[:, 0] = np.c_[pts[:, 0], ybot, pts[:, 1]]; P[:, 1] = np.c_[pts[:, 0], ytop, pts[:, 1]]
    UV[:, 0] = np.c_[s / u_per_m, np.full(n, v1)]; UV[:, 1] = np.c_[s / u_per_m, np.full(n, v0)]
    t = np.gradient(pts, axis=0); t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-9)
    nrm = np.c_[-t[:, 1], np.zeros(n), t[:, 0]]
    if face is not None:
        f = face / np.maximum(np.linalg.norm(face, axis=1, keepdims=True), 1e-9)
        nrm = np.c_[f[:, 0] * np.sqrt(1 - tilt * tilt), np.full(n, tilt), f[:, 1] * np.sqrt(1 - tilt * tilt)]
    N = np.repeat(nrm[:, None], 2, 1)
    mesh.add(mat, P.reshape(-1, 3), UV.reshape(-1, 2), grid_tris(n, 2), N=N.reshape(-1, 3), phys=phys)


def card(mesh, mat, x, y, z, w, h, yaw, uv=(0, 0, 1, 1), crossed=True):
    """a tree card standing on (x, y, z): one quad, or two crossed"""
    u0, v0, u1, v1 = uv
    for k in ((0, np.pi / 2) if crossed else (0,)):
        c, s = np.cos(yaw + k) * w / 2, np.sin(yaw + k) * w / 2
        quad(mesh, mat, (x - c, y, z - s), (x + c, y, z + s), (x + c, y + h, z + s), (x - c, y + h, z - s),
             uv=((u0, v1), (u1, v1), (u1, v0), (u0, v0)))


def cards(mesh, mat, X, Y, Z, W, Hh, YAW, uv=(0, 0, 1, 1), crossed=True):
    """many cards at once (vectorised): arrays of positions, widths, heights, yaws"""
    X, Y, Z, W, Hh, YAW = (np.asarray(a, float) for a in (X, Y, Z, W, Hh, YAW))
    ks = (0.0, np.pi / 2) if crossed else (0.0,)
    Ps, UVs, Is, Ns = [], [], [], []
    u0, v0, u1, v1 = uv
    base = 0
    for k in ks:
        c, s = np.cos(YAW + k) * W / 2, np.sin(YAW + k) * W / 2
        P = np.stack([np.c_[X - c, Y, Z - s], np.c_[X + c, Y, Z + s], np.c_[X + c, Y + Hh, Z + s], np.c_[X - c, Y + Hh, Z - s]], 1)
        n = np.tile([0.0, 1.0, 0.0], (len(X), 1))        # straight up: both crossed cards light alike, from either side
        Ps.append(P.reshape(-1, 3)); Ns.append(np.repeat(n, 4, 0))
        UVs.append(np.tile([[u0, v1], [u1, v1], [u1, v0], [u0, v0]], (len(X), 1)))
        q = base + 4 * np.arange(len(X))[:, None]
        Is.append(np.concatenate([q + [0, 1, 2], q + [0, 2, 3]]))
        base += 4 * len(X)
    mesh.add(mat, np.concatenate(Ps), np.concatenate(UVs), np.concatenate(Is), N=np.concatenate(Ns), phys=False)
