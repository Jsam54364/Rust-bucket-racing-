"""The transporter's tractor unit as one baked shell: the model's cab, chassis, tanks and steps rendered
orthographically from six sides (hullbake.gd); a solid made of the space inside all three silhouettes (front, side
and top) is meshed (marching cubes) and simplified to a small closed mesh, and each of its faces takes its colour
from the render it faces most. No holes, whatever the triangle budget, and the model's detail stays in the
pictures."""
import os, io, struct, subprocess, tempfile, shutil
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
from skimage.measure import marching_cubes

HERE = os.path.dirname(os.path.abspath(__file__))
VIEWS = [('front', (-1, 0, 0), (0, 1, 0)), ('back', (1, 0, 0), (0, 1, 0)), ('left', (0, 0, -1), (0, 1, 0)),
         ('right', (0, 0, 1), (0, 1, 0)), ('top', (0, -1, 0), (1, 0, 0)), ('bottom', (0, 1, 0), (1, 0, 0))]
PPM = 120.0          # bake resolution, px per metre
VOX = 0.02           # the solid's voxel size


def _basis(fwd, up):
    """Godot's Basis.looking_at: right, up, back (z)"""
    z = -np.asarray(fwd, float); x = np.cross(up, z); x /= np.linalg.norm(x); y = np.cross(z, x)
    return x, y, z


def _views(lo, hi, margin=0.06):
    c = (lo + hi) / 2
    corners = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])])
    out = []
    for name, fwd, up in VIEWS:
        x, y, z = _basis(fwd, up)
        px, py = corners @ x, corners @ y
        w = px.max() - px.min() + 2 * margin; h = py.max() - py.min() + 2 * margin
        W, H = int(np.ceil(w * PPM)), int(np.ceil(h * PPM))
        out.append(dict(name=name, fwd=np.array(fwd, float), up=np.array(up, float), x=x, y=y, c=c, size=H / PPM, W=W, H=H,
                        pos=c - np.array(fwd, float) * 60.0))
    return out


def _pix(v, P):
    """world points -> pixel coordinates (column, row) in view v's render"""
    k = v['H'] / v['size']
    return np.c_[v['W'] / 2 + ((P - v['c']) @ v['x']) * k, v['H'] / 2 - ((P - v['c']) @ v['y']) * k]


def bake(parts, sets, godot, views):
    """parts: [(P, U, I)]; sets: per livery, per part (png path or '', rgb). -> images[set][view] (RGBA)"""
    tmp = tempfile.mkdtemp(prefix='hullbake')
    with open(os.path.join(tmp, 'in.bin'), 'wb') as f:
        f.write(b'HULB' + struct.pack('<I', len(parts)))
        for P, U, I in parts:
            f.write(struct.pack('<II', len(P), I.size)); f.write(P.astype('<f4').tobytes()); f.write(U.astype('<f4').tobytes()); f.write(I.astype('<u4').tobytes())
        f.write(struct.pack('<I', len(sets)))
        for s in sets:
            for path, rgb in s:
                b = path.encode(); f.write(struct.pack('<I', len(b)) + b + struct.pack('<fff', *rgb))
        f.write(struct.pack('<I', len(views)))
        for v in views:
            f.write(struct.pack('<10fII', *v['pos'], *v['c'], *v['up'], v['size'], v['W'], v['H']))
    open(os.path.join(tmp, 'project.godot'), 'w').write('config_version=5\n[application]\nconfig/name="hullbake"\n'
                                                       '[rendering]\nrenderer/rendering_method="gl_compatibility"\n')
    shutil.copy(os.path.join(HERE, 'hullbake.gd'), tmp)
    out = os.path.join(tmp, 'out'); os.makedirs(out)
    r = subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 2048x2048x24', godot, '--path', tmp, '--script', 'res://hullbake.gd', '--',
                        os.path.join(tmp, 'in.bin'), out], capture_output=True, text=True, timeout=1200)
    if r.returncode: print(r.stdout[-2000:], r.stderr[-2000:]); raise SystemExit('hull: bake failed')
    imgs = [[Image.open(os.path.join(out, f's{s}_v{v}.png')).convert('RGBA') for v in range(len(views))] for s in range(len(sets))]
    shutil.rmtree(tmp)
    return imgs


def scrub(imgs, views, boxes):
    """paint over lettering in the renders: boxes (x0, x1, y0, y1, z0, z1) in metres, filled with the colour round
    their edge, in every view that faces them"""
    for v, im in zip(views, imgs):
        a = np.asarray(im).astype(np.float32).copy()
        for b in boxes:
            P = np.array([[x, y, z] for x in b[0:2] for y in b[2:4] for z in b[4:6]])
            q = _pix(v, P)
            # only views that look at the box's big face: it is thin along the view direction
            ext = np.abs(np.array([b[1] - b[0], b[3] - b[2], b[5] - b[4]]) @ np.abs(v['fwd']))
            if ext > 0.5: continue
            c0, r0 = np.floor(q.min(0)).astype(int); c1, r1 = np.ceil(q.max(0)).astype(int)
            c0, r0 = max(c0, 1), max(r0, 1); c1, r1 = min(c1, v['W'] - 2), min(r1, v['H'] - 2)
            if c1 <= c0 or r1 <= r0: continue
            ring = np.r_[a[r0 - 1, c0:c1], a[r1, c0:c1], a[r0:r1, c0 - 1], a[r0:r1, c1]]
            ring = ring[ring[:, 3] > 127]
            if not len(ring): continue
            col = np.median(ring, 0)
            # a vertical blend between the rows above and below keeps any shading
            top = a[r0 - 1, c0:c1]; bot = a[r1, c0:c1]
            t = np.linspace(0, 1, r1 - r0)[:, None, None]
            fill = (top[None] * (1 - t) + bot[None] * t) * 0.5 + col * 0.5
            m = a[r0:r1, c0:c1, 3:4] > 127
            a[r0:r1, c0:c1, :3] = np.where(m, fill[..., :3], a[r0:r1, c0:c1, :3])
        imgs[imgs.index(im)] = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA')
    return imgs


def depth(v, P, I):
    """an orthographic z-buffer of triangles in view v: distance along the view direction, inf where empty"""
    q = _pix(v, P); d = (P - v['c']) @ v['fwd']
    zb = np.full((v['H'], v['W']), np.inf)
    T = q[I]; D = d[I]
    for t in range(len(I)):
        (ax, ay), (bx, by), (cx, cy) = T[t]
        x0 = max(int(np.floor(min(ax, bx, cx))), 0); x1 = min(int(np.ceil(max(ax, bx, cx))), v['W'] - 1)
        y0 = max(int(np.floor(min(ay, by, cy))), 0); y1 = min(int(np.ceil(max(ay, by, cy))), v['H'] - 1)
        if x1 < x0 or y1 < y0: continue
        den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
        if abs(den) < 1e-9: continue
        X, Y = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        w0 = ((by - cy) * (X - cx) + (cx - bx) * (Y - cy)) / den
        w1 = ((cy - ay) * (X - cx) + (ax - cx) * (Y - cy)) / den
        w2 = 1 - w0 - w1
        m = (w0 >= -1e-6) & (w1 >= -1e-6) & (w2 >= -1e-6)
        if not m.any(): continue
        z = np.where(m, w0 * D[t, 0] + w1 * D[t, 1] + w2 * D[t, 2], np.inf)
        sub = zb[y0:y1 + 1, x0:x1 + 1]; np.minimum(sub, z, out=sub)
    return zb


def hull_depth(v, occ, axes):
    """the solid's own z-buffer in view v (it is axis-aligned): distance along the view direction to its first voxel"""
    k = int(np.argmax(np.abs(v['fwd']))); sg = np.sign(v['fwd'][k])
    rr, cc = np.mgrid[0:v['H'], 0:v['W']]
    kk = v['H'] / v['size']
    P = v['c'] + np.outer((cc.ravel() + 0.5 - v['W'] / 2) / kk, v['x']) + np.outer((v['H'] / 2 - rr.ravel() - 0.5) / kk, v['y'])
    o = [a for a in range(3) if a != k]
    ij = [np.clip(np.round((P[:, a] - axes[a][0]) / VOX).astype(int), 0, len(axes[a]) - 1) for a in o]
    occk = np.moveaxis(occ, k, 0)                                    # (k, o0, o1)
    anyk = occk.any(0)
    first = np.argmax(occk, 0) if sg > 0 else occk.shape[0] - 1 - np.argmax(occk[::-1], 0)
    f = first[ij[0], ij[1]]; hit = anyk[ij[0], ij[1]]
    d = (axes[k][f] - v['c'][k]) * v['fwd'][k]
    return np.where(hit, d, np.inf).reshape(v['H'], v['W'])


def recesses(views, imgs_sets, parts, occ, axes, deep=0.22):
    """where the model, seen from a side, is much deeper than the shell (open windows, wheel arches, grilles): those
    pixels darkened, as glass and shadow"""
    P = np.concatenate([p for p, u, i in parts]); base = 0; Is = []
    for p, u, i in parts: Is.append(i + base); base += len(p)
    I = np.concatenate(Is)
    for vi, v in enumerate(views):
        zm = depth(v, P, I); zh = hull_depth(v, occ, axes)
        m = (zm - zh > deep) & np.isfinite(zh)
        for imgs in imgs_sets:
            a = np.asarray(imgs[vi]).astype(np.float32).copy()
            sel = m & (a[:, :, 3] > 127)
            a[sel, :3] = a[sel, :3] * 0.22 + np.array([10, 13, 17], np.float32)
            imgs[vi] = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA')
        print(f'  hull: {v["name"]}: {m.mean() * 100:.1f} % recessed')
    return imgs_sets


def solid(views, sil, lo, hi):
    """the voxels inside the front, side and top silhouettes -> marching-cubes mesh (V, F)"""
    gx = np.arange(lo[0] - 0.04, hi[0] + 0.04, VOX); gy = np.arange(lo[1] - 0.04, hi[1] + 0.04, VOX); gz = np.arange(lo[2] - 0.04, hi[2] + 0.04, VOX)
    vd = {v['name']: (v, s) for v, s in zip(views, sil)}
    def mask(name, A, B, ia, ib):
        v, s = vd[name]
        a, b = np.meshgrid(A, B, indexing='ij')
        P = np.zeros(a.shape + (3,)); P[..., ia] = a; P[..., ib] = b
        P[..., 3 - ia - ib] = v['c'][3 - ia - ib]
        q = _pix(v, P.reshape(-1, 3))
        c = np.clip(np.round(q[:, 0] - 0.5).astype(int), 0, v['W'] - 1); r = np.clip(np.round(q[:, 1] - 0.5).astype(int), 0, v['H'] - 1)
        return s[r, c].reshape(a.shape)
    side = mask('left', gx, gy, 0, 1)          # (x, y)
    front = mask('front', gy, gz, 1, 2)        # (y, z)
    top = mask('top', gx, gz, 0, 2)            # (x, z)
    occ = side[:, :, None] & front[None, :, :] & top[:, None, :]
    vol = gaussian_filter(np.pad(occ, 2).astype(np.float32), 0.8)
    V, F, _, _ = marching_cubes(vol, 0.5)
    V = (V - 2) * VOX + np.array([gx[0], gy[0], gz[0]])
    print(f'  hull: {occ.sum()} voxels, marching cubes {len(F)} triangles')
    return V, F, occ, (gx, gy, gz)


def face_normals(V, F):
    n = np.cross(V[F[:, 1]] - V[F[:, 0]], V[F[:, 2]] - V[F[:, 0]])
    return n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)


def shell(V, F, views, split_x, weights, atlas=512, pad=2):
    """UVs: each face onto the render it faces most, a rectangle of the atlas per (view, front/back part);
    returns P, N, I (vertices split per rectangle), U, and the layout [(view, x0, y0, x1, y1 in render px, ax, ay, scale)]"""
    fn = face_normals(V, F)
    C = V[F].mean(1)
    if np.mean(np.einsum('ij,ij->i', fn, C - V.mean(0))) < 0: F = F[:, [0, 2, 1]]; fn = -fn
    score = np.stack([fn @ (-v['fwd']) for v in views], 1)
    best = np.argmax(score, 1)
    part = (C[:, 0] < split_x).astype(int)                    # 0 the cab, 1 the chassis behind it
    groups = {}
    for i, (b, p) in enumerate(zip(best, part)): groups.setdefault((int(b), int(p)), []).append(i)
    rects = []
    for (b, p), fl in groups.items():
        fl = np.array(fl); q = _pix(views[b], V[F[fl]].reshape(-1, 3))
        x0, y0 = np.floor(q.min(0)) - pad; x1, y1 = np.ceil(q.max(0)) + pad
        rects.append(dict(view=b, part=p, faces=fl, x0=max(0, x0), y0=max(0, y0), x1=min(views[b]['W'], x1), y1=min(views[b]['H'], y1)))
    # the largest scale at which the rectangles shelf-pack into the atlas
    def pack(sc):
        order = sorted(rects, key=lambda r: -(r['y1'] - r['y0']) * weights[r['view']][r['part']])
        x = y = sh = 0; out = []
        for r in order:
            k = sc * weights[r['view']][r['part']]
            w = int(np.ceil((r['x1'] - r['x0']) * k)) + 2; h = int(np.ceil((r['y1'] - r['y0']) * k)) + 2
            if w > atlas: return None
            if x + w > atlas: x = 0; y += sh; sh = 0
            if y + h > atlas: return None
            out.append((r, x + 1, y + 1)); x += w; sh = max(sh, h)
        return out
    lo_s, hi_s = 0.01, 2.0
    for _ in range(30):
        m = (lo_s + hi_s) / 2
        if pack(m): lo_s = m
        else: hi_s = m
    layout = pack(lo_s)
    print(f'  hull: {len(rects)} rectangles, cab sides at {lo_s * weights[2][0] * PPM:.0f} px/m')
    Ps, Ns, Us, Is, base = [], [], [], [], 0
    lay = []
    for r, ax, ay in layout:
        sc = lo_s * weights[r['view']][r['part']]
        v = views[r['view']]
        fl = r['faces']; Fi = F[fl]
        used, inv = np.unique(Fi, return_inverse=True); inv = inv.reshape(-1, 3)
        Pv = V[used]
        q = _pix(v, Pv)
        U = np.c_[(ax + (q[:, 0] - r['x0']) * sc) / atlas, (ay + (q[:, 1] - r['y0']) * sc) / atlas]
        Nv = np.zeros_like(Pv)
        for k in range(3): np.add.at(Nv, inv[:, k], fn[fl])
        Nv /= np.maximum(np.linalg.norm(Nv, axis=1, keepdims=True), 1e-12)
        Ps.append(Pv); Ns.append(Nv); Us.append(U); Is.append(inv + base); base += len(Pv)
        lay.append((r['view'], r['x0'], r['y0'], r['x1'], r['y1'], ax, ay, sc))
    return np.concatenate(Ps), np.concatenate(Ns), np.concatenate(Us), np.concatenate(Is), lay


def atlas_image(imgs, lay, atlas=512):
    out = Image.new('RGBA', (atlas, atlas), (0, 0, 0, 0))
    for vi, x0, y0, x1, y1, ax, ay, sc in lay:
        crop = imgs[vi].crop((int(x0), int(y0), int(x1), int(y1)))
        w = max(1, int(round((x1 - x0) * sc))); h = max(1, int(round((y1 - y0) * sc)))
        out.alpha_composite(crop.resize((w, h), Image.LANCZOS), (int(ax), int(ay)))
    import assets
    return assets.bleed(out).convert('RGB')
