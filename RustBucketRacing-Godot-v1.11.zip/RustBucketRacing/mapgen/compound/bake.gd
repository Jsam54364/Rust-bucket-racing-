extends SceneTree
# orthographic albedo renders of one mesh of a glb: front (looking along -z), top (looking down)
# args: <glb> <mesh name> <out prefix> <px per metre>
func _initialize():
	var a := OS.get_cmdline_user_args()
	var doc := GLTFDocument.new(); var st := GLTFState.new()
	if doc.append_from_file(a[0], st) != OK: printerr("bake: can't read"); quit(1); return
	var scene: Node = doc.generate_scene(st)
	var holder: Node = null
	for n in scene.find_children("*", "", true, false):
		if n.name == a[1]: holder = n; break
	if holder == null: printerr("bake: no node ", a[1]); quit(1); return
	var root := Node3D.new(); get_root().add_child(root)
	var aabb := AABB(); var first := true
	var parts: Array = [holder] if holder is MeshInstance3D else holder.find_children("*", "MeshInstance3D", true, false)
	for t in parts:
		var mi := MeshInstance3D.new(); mi.mesh = t.mesh; root.add_child(mi)
		for i in mi.mesh.get_surface_count():
			var m = mi.mesh.surface_get_material(i)
			if m is BaseMaterial3D: m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		aabb = mi.mesh.get_aabb() if first else aabb.merge(mi.mesh.get_aabb()); first = false
	print("aabb ", aabb, " parts ", parts.size())
	var ppm := float(a[3])
	get_root().transparent_bg = true
	var cam := Camera3D.new(); cam.projection = Camera3D.PROJECTION_ORTHOGONAL; root.add_child(cam); cam.current = true
	var c := aabb.get_center()
	for view in ["warm", "front", "top", "back"]:
		var w: float; var h: float
		if view == "top" or view == "warm":
			w = aabb.size.x; h = aabb.size.z
			cam.look_at_from_position(c + Vector3(0, 50, 0), c, Vector3(0, 0, -1))
		elif view == "front":
			w = aabb.size.x; h = aabb.size.y
			cam.look_at_from_position(c + Vector3(0, 0, 50), c, Vector3.UP)
		else:
			w = aabb.size.x; h = aabb.size.y
			cam.look_at_from_position(c + Vector3(0, 0, -50), c, Vector3.UP)
		cam.size = h; cam.near = 1; cam.far = 200
		var W := int(round(w * ppm)); var H := int(round(h * ppm))
		get_root().size = Vector2i(W, H)
		cam.keep_aspect = Camera3D.KEEP_HEIGHT
		for i in 4: await process_frame
		var img := get_root().get_texture().get_image()
		if view == "warm": continue
		img.save_png("%s_%s.png" % [a[2], view])
		print("bake: ", view, " ", img.get_size())
	quit(0)
