"""read an RBMP map pack: header, images, geometry (for borrowing textures and meshes)"""
import struct, json, gzip, numpy as np
def load(path):
    b = open(path, 'rb').read()
    assert b[:4] == b'RBMP'
    jl = struct.unpack('<I', b[4:8])[0]; h = json.loads(b[8:8 + jl]); base = 8 + jl
    imgs = [b[base + o: base + o + n] for o, n, t in h['images']]
    g = h['geo']; geo = gzip.decompress(b[base + g[0]: base + g[0] + g[1]])
    return dict(h=h, imgs=imgs, geo=geo, base=base, raw=b)

def triangles(p, mat_ids=None):
    """world-space triangles (n,3,3) and their material ids, from every draw (all indices, not only physics)"""
    h, geo = p['h'], p['geo']
    VL = h['geo'][2]
    V = np.frombuffer(geo[:VL], dtype=[('p', '<i2', 3), ('pad', '<i2'), ('n', 'i1', 4), ('uv', '<i2', 2)])
    I = np.frombuffer(geo[VL:VL + h['geo'][3]], '<u2')
    out, mats = [], []
    for c in h['chunks']:
        qs = c.get('qs', h.get('qs', 64)); o = np.array(c['o']); v0 = c['v'][0]; i0 = c['i'][0]
        for d in c['d']:
            m = d[0]
            if mat_ids is not None and m not in mat_ids: continue
            idx = I[i0 + d[1]: i0 + d[1] + d[2]].astype(np.int64) + v0
            P = V['p'][idx].astype(np.float64) / qs + o
            out.append(P.reshape(-1, 3, 3)); mats.append(np.full(len(idx) // 3, m))
    if not out: return np.zeros((0, 3, 3)), np.zeros(0, int)
    return np.concatenate(out), np.concatenate(mats)

def line(p):
    h, b, base = p['h'], p['raw'], p['base']
    o, n, cnt = h['line']
    return np.frombuffer(b[base + o: base + o + cnt * 8], '<f4').reshape(-1, 2).astype(np.float64)
