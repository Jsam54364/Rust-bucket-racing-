"""Write a map pack (RBMP v2, as tools/convert_mcr.py) from a geom.Mesh: chunks that start at 800 m and split in
four wherever a chunk would pass the 16-bit vertex limit (down to 100 m), the 'far' backdrop in a chunk of its own
with coarse position steps, one draw per material per chunk (physics triangles first), LODs from Godot's
simplifier, walls, the circuit's centreline and the game's extra map data."""
import os, json, gzip, struct, shutil, subprocess, tempfile, time
import numpy as np

GODOT = os.environ.get('GODOT', '/home/claude/tools/Godot_v4.7.2-stable_linux.x86_64')
LODGEN = os.environ.get('LODGEN', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lodgen.gd'))
QS, QS_FAR = 64.0, 2.0
VMAX = 60000


def log(*a): print(f'[{time.strftime("%H:%M:%S")}]', *a, flush=True)


def flatten(mesh, mat_index, materials):
    """all triangles with their material, phys flag, and per-corner P, N, UV"""
    TP, TN, TU, TM, TF = [], [], [], [], []
    for key, parts in mesh.parts.items():
        m = mat_index[key]
        for P, N, UV, I, ph in parts:
            TP.append(P[I]); TN.append(N[I]); TU.append(UV[I]); TM.append(np.full(len(I), m)); TF.append(ph)
    return np.concatenate(TP), np.concatenate(TN), np.concatenate(TU), np.concatenate(TM), np.concatenate(TF)


def chunk_keys(C, far, cell=800.0):
    """assign triangles (centroids C) to chunks: quadtree cells split while a cell has too many vertices"""
    keys = np.empty(len(C), object)
    for i in np.nonzero(far)[0]: keys[i] = ('far',)          # (a tuple assigned to a slice would be taken apart)
    idx = np.nonzero(~far)[0]
    def split(ids, x0, z0, size, depth):
        if 3 * len(ids) <= VMAX * 1.6 or size <= 100:   # corners per cell, before welding (welding about halves them)
            for i in ids: keys[i] = (round(x0, 1), round(z0, 1), size)
            return
        h = size / 2
        cx, cz = C[ids, 0], C[ids, 2]
        for dx in (0, 1):
            for dz in (0, 1):
                sel = ids[((cx >= x0 + h) == bool(dx)) & ((cz >= z0 + h) == bool(dz))]
                if len(sel): split(sel, x0 + dx * h, z0 + dz * h, h, depth + 1)
    gx = np.floor(C[idx, 0] / cell).astype(np.int64); gz = np.floor(C[idx, 2] / cell).astype(np.int64)
    order = np.lexsort((gz, gx))
    gx, gz, idx2 = gx[order], gz[order], idx[order]
    br = np.nonzero(np.diff(gx) | np.diff(gz))[0] + 1
    for part, a, b in zip(np.split(idx2, br), np.split(gx, br), np.split(gz, br)):
        split(part, a[0] * cell, b[0] * cell, cell, 0)
    return keys


def write_pack(out, mesh, materials, mat_index, images, line, lineY, meta, name, line_len):
    TP, TN, TU, TM, TF = flatten(mesh, mat_index, materials)
    log(f'{len(TP)} triangles, {len(materials)} materials, {len(images)} textures')
    cat = np.array([materials[m]['cat'] for m in range(len(materials))])
    far = cat[TM] == 'far'
    C = TP.mean(1)
    keys = chunk_keys(C, far)
    groups = {}
    for i, k in enumerate(keys): groups.setdefault(k, []).append(i)
    mat_order = sorted(range(len(materials)), key=lambda i: (materials[i]['mode'], i))
    rank = {m: r for r, m in enumerate(mat_order)}
    verts_out, idx_out, chunks, draw_refs = [], [], [], []
    v_total = i_total = 0
    for key in sorted(groups, key=lambda k: (len(k), str(k))):
        tri = np.array(groups[key])
        isfar = key == ('far',)
        qs = QS_FAR if isfar else QS
        allp = TP[tri].reshape(-1, 3)
        if isfar: ox, oz = 0.0, 0.0
        else: ox, oz = round(float((allp[:, 0].min() + allp[:, 0].max()) / 2), 1), round(float((allp[:, 2].min() + allp[:, 2].max()) / 2), 1)
        oy = round(float((allp[:, 1].min() + allp[:, 1].max()) / 2), 1)
        org_q = np.round(np.array([ox, oy, oz]) * qs).astype(np.int64)
        # vertices: weld identical corners (position, normal, uv) within the chunk
        by_mat = {}
        for t in tri: by_mat.setdefault(int(TM[t]), []).append(t)
        vkey = {}; vpos, vnor, vuv = [], [], []
        draws, ch_idx = [], []
        for m in sorted(by_mat, key=lambda m: rank[m]):
            ts = np.array(by_mat[m])
            ts = ts[np.argsort(~TF[ts], kind='stable')]                # physics first
            nphys = int(TF[ts].sum()) * 3
            P = TP[ts].reshape(-1, 3); N = TN[ts].reshape(-1, 3); U = TU[ts].reshape(-1, 2)
            k = np.c_[np.round(P * qs).astype(np.int64), np.round(N * 100).astype(np.int64), np.round(U * 2048).astype(np.int64), np.full(len(P), m)]
            uk, first, inv = np.unique(k, axis=0, return_index=True, return_inverse=True)
            inv = inv.ravel()
            base = len(vpos)
            vpos.extend(P[first]); vnor.extend(N[first]); vuv.extend(U[first])
            ids = inv + base
            uv = U[first]
            o = np.floor(uv.min(0)); rel = np.abs(uv - o).max()
            kq = 4096
            while rel * kq > 32000 and kq > 1: kq //= 2
            draws.append(dict(m=m, i0=len(ch_idx), n=len(ids), uv=[float(o[0]), float(o[1]), int(kq)], ids=ids, nphys=nphys, base=base, nv=len(first)))
            ch_idx.extend(ids.tolist())
        if len(vpos) >= 65536: raise SystemExit(f'chunk {key}: {len(vpos)} vertices')
        vpos = np.array(vpos); vnor = np.array(vnor); vuv = np.array(vuv)
        q = np.round(vpos * qs).astype(np.int64) - org_q
        if np.abs(q).max() >= 32767: raise SystemExit(f'chunk {key}: positions out of range ({np.abs(q).max()})')
        uvq = np.zeros((len(vpos), 2), np.int16)
        for d in draws:
            sl = slice(d['base'], d['base'] + d['nv'])
            uvq[sl] = np.round((vuv[sl] - np.array(d['uv'][:2])) * d['uv'][2]).astype(np.int16)
        vnor = vnor / np.maximum(np.linalg.norm(vnor, axis=1, keepdims=True), 1e-9)
        rec = np.zeros(len(vpos), dtype=[('p', '<i2', 3), ('pad', '<i2'), ('n', 'i1', 4), ('uv', '<i2', 2)])
        rec['p'] = q; rec['n'][:, :3] = np.round(vnor * 127).astype(np.int8); rec['uv'] = uvq
        deq = (q + org_q) / qs
        ch = dict(o=(org_q / qs).tolist(), min=deq.min(0).round(2).tolist(), max=deq.max(0).round(2).tolist(),
                  v=[v_total, len(vpos)], i=[i_total, len(ch_idx)], d=[])
        if isfar: ch['qs'] = qs
        chunks.append(ch)
        for d in draws:
            local, li = {}, []
            for v in d['ids']:
                if v not in local: local[v] = len(local)
                li.append(local[v])
            order = np.array(list(local.keys()))
            d['local'] = (deq[order], rec['n'][order, :3] / 127.0, uvq[order] / d['uv'][2] + np.array(d['uv'][:2]), np.array(li, np.int64))
            draw_refs.append((ch, d))
        verts_out.append(rec.tobytes()); idx_out.append(np.array(ch_idx, np.uint16).tobytes())
        v_total += len(vpos); i_total += len(ch_idx)
    log(f'{len(chunks)} chunks, {v_total} vertices, {i_total // 3} triangles, {len(draw_refs)} draws')
    # LODs
    def lod_ok(d):
        m = materials[d['m']]
        return m['mode'] == 0 and m['cat'] not in ('far',) and d['n'] >= 3 * 64
    todo = [(ch, d) for ch, d in draw_refs if lod_ok(d)]
    tmp = tempfile.mkdtemp(prefix='lodgen')
    with open(os.path.join(tmp, 'in.bin'), 'wb') as fo:
        fo.write(b'LODI' + struct.pack('<I', len(todo)))
        for ch, d in todo:
            P, N, U, I = d['local']
            fo.write(struct.pack('<II', len(P), len(I)))
            fo.write(P.astype('<f4').tobytes()); fo.write(N.astype('<f4').tobytes()); fo.write(U.astype('<f4').tobytes()); fo.write(I.astype('<u4').tobytes())
    open(os.path.join(tmp, 'project.godot'), 'w').write('config_version=5\n[application]\nconfig/name="lodgen"\n')
    shutil.copy(LODGEN, os.path.join(tmp, 'lodgen.gd'))
    r = subprocess.run([GODOT, '--headless', '--path', tmp, '--script', 'res://lodgen.gd', '--', os.path.join(tmp, 'in.bin'), os.path.join(tmp, 'out.bin')],
                       capture_output=True, text=True, timeout=3600)
    print('\n'.join(l for l in r.stdout.splitlines() if 'lodgen' in l))
    if r.returncode != 0: print(r.stdout[-3000:], r.stderr[-3000:]); raise SystemExit('lodgen failed')
    lod_idx = []; lod_total = 0
    with open(os.path.join(tmp, 'out.bin'), 'rb') as fi:
        assert fi.read(4) == b'LODO'
        (cnt,) = struct.unpack('<I', fi.read(4)); assert cnt == len(todo)
        for ch, d in todo:
            (nl,) = struct.unpack('<I', fi.read(4))
            d['lods'] = []
            for _ in range(nl):
                size, n = struct.unpack('<fI', fi.read(8))
                li = np.frombuffer(fi.read(n * 4), '<u4')
                d['lods'].append([round(float(size), 5), lod_total, int(n)])
                lod_idx.append(li.astype(np.uint16).tobytes()); lod_total += n
    shutil.rmtree(tmp)
    for ch, d in draw_refs:
        e = [d['m'], d['i0'], d['n'], d['uv'], d['nphys']]
        if d.get('lods'): e.append(d['lods'])
        ch['d'].append(e)
    log(f'LODs: {lod_total // 3} triangles over {sum(1 for _, d in todo if d.get("lods"))} draws')
    # pack
    blob = bytearray()
    def put(b):
        while len(blob) % 4: blob.append(0)
        o = len(blob); blob.extend(b); return [o, len(b)]
    geo = gzip.compress(b''.join(verts_out) + b''.join(idx_out) + b''.join(lod_idx), 9)
    walls = np.array(mesh.walls, np.float32).reshape(-1, 6)
    def conv(obj):        # arrays in the extra map data go in the blob as float32: [offset, bytes, count]
        if isinstance(obj, np.ndarray):
            a = np.ascontiguousarray(obj, np.float32); return put(a.tobytes()) + [len(a)]
        if isinstance(obj, dict): return {k: conv(v) for k, v in obj.items()}
        if isinstance(obj, list): return [conv(v) for v in obj]
        return obj
    meta = conv(meta)
    head = dict(
        version=2, name=name, scale=1.0, origin=[0, 0, 0], qs=QS, chunk=800,
        materials=materials,
        images=[put(b) + ['image/webp'] for b in images],
        geo=put(geo) + [v_total * 16, i_total * 2, lod_total * 2], vstride=16,
        chunks=chunks,
        walls=put(walls.tobytes()) + [len(walls)],
        line=put(np.asarray(line, np.float32).tobytes()) + [len(line)], lineLen=line_len,
        lineY=put(np.asarray(lineY, np.float32).tobytes()) + [len(lineY)],
        meta=meta,
    )
    hj = json.dumps(head, separators=(',', ':')).encode()
    while (8 + len(hj)) % 4: hj += b' '
    data = b'RBMP' + struct.pack('<I', len(hj)) + hj + bytes(blob)
    open(out, 'wb').write(data)
    tex = sum(map(len, images))
    log(f'textures {tex / 1e6:.2f} MB, geometry {len(geo) / 1e6:.2f} MB gz (raw {(v_total * 16 + (i_total + lod_total) * 2) / 1e6:.2f}), '
        f'walls {walls.nbytes / 1e6:.2f} MB ({len(walls)}), header {len(hj) / 1e3:.0f} kB')
    log(f'pack {len(data) / 1e6:.2f} MB -> {out}')
    return dict(chunks=len(chunks), verts=v_total, tris=i_total // 3, lod_tris=lod_total // 3, size=len(data))
