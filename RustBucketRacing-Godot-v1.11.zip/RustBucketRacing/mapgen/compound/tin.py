"""The ground as one triangulated surface: points from the shaped heightfield, dense near roads and pads (8 m),
coarser away from them (16, 32, 48 m) and outside the fence (64 m); rows of points along every road edge
(0.25 m out, 3.5 cm under the road) and verge, and round every pad, so the ground meets them closely. The
triangles under roads and pads are dropped (those surfaces have their own meshes)."""
import numpy as np
from scipy.spatial import Delaunay, cKDTree
from scipy.ndimage import distance_transform_edt
import terrain as TR
import layout as LY

RES, AX = TR.RES, TR.AX
RING_R = 5150.0                    # the ground's edge: a rounded square (superellipse) that takes in the fence's corners
RING_P = 4.0
RING_A = np.linspace(0, 2 * np.pi, 504, endpoint=False)

def edge(R, p, ang=RING_A):
    """points on the superellipse |x|^p + |z|^p = R^p, by parameter angle"""
    c, s = np.cos(ang), np.sin(ang)
    return R * np.sign(c) * np.abs(c) ** (2 / p), R * np.sign(s) * np.abs(s) ** (2 / p)

def inside(x, z, margin=0.0, R=RING_R, p=RING_P):
    return (np.abs(x) ** p + np.abs(z) ** p) ** (1 / p) < R - margin


class Ground:
    def __init__(self, H, T, roads, pads, fills=(), traps=()):
        self.H, self.T, self.roads, self.pads = H, T, roads, pads
        self.fills, self.traps = list(fills), list(traps)
        near = T <= 0.0                                         # verges and pads
        self.D = distance_transform_edt(~near).astype(np.float32) * RES
        self.trees = {k: cKDTree(r.P) for k, r in roads.items()}
        self.build()

    # ---------------------------------------------------------------- where things are
    def road_at(self, x, z, exclude=None, margin=0.0, y=None, ytol=1.5):
        """for points (x, z): the highest-priority road whose footprint (+margin) holds each one: (name, surface y).
        With heights y, only a road surface within ytol of them counts (a bridge deck over a track doesn't)"""
        x = np.asarray(x, float); z = np.asarray(z, float)
        name = np.full(x.shape, None, object); yo = np.full(x.shape, np.nan)
        best = np.full(x.shape, 99.0)
        for k, r in self.roads.items():
            if k == exclude: continue
            d, j = self.trees[k].query(np.c_[x, z], distance_upper_bound=r.half + margin + 2)
            ok = np.isfinite(d)
            if not ok.any(): continue
            jj = np.where(ok, j, 0)
            dx, dz = x - r.P[jj, 0], z - r.P[jj, 1]
            o = dx * r.n[jj, 0] + dz * r.n[jj, 1]; a = dx * r.t[jj, 0] + dz * r.t[jj, 1]
            inside = ok & r.inside(o, margin)
            if not r.closed:
                inside &= ~(((jj == 0) & (a < -0.3)) | ((jj == len(r.P) - 1) & (a > 0.3)))
            ys = r.surface(jj, o)
            if y is not None: inside &= np.abs(ys - np.asarray(y)) < ytol
            win = inside & (r.prio < best)
            name[win] = k; yo[win] = ys[win]; best[win] = r.prio
        return name, yo

    def fill_at(self, x, z, margin=0.0):
        """points in a junction fill (the asphalt in the V where two tracks part)"""
        x = np.atleast_1d(np.asarray(x, float)); z = np.atleast_1d(np.asarray(z, float))
        out = np.zeros(x.shape, bool)
        for f in self.fills:
            bx = f.box
            near = (x > bx[0]) & (x < bx[2]) & (z > bx[1]) & (z < bx[3])
            if near.any(): out[near] |= f.inside(x[near], z[near], margin)
        return out

    def trap_at(self, x, z):
        x = np.atleast_1d(np.asarray(x, float)); z = np.atleast_1d(np.asarray(z, float))
        out = np.zeros(x.shape, bool)
        for t in self.traps:
            bx = t.box
            near = (x > bx[0]) & (x < bx[2]) & (z > bx[1]) & (z < bx[3])
            if near.any(): out[near] |= t.inside(x[near], z[near])
        return out

    def pad_at(self, x, z, margin=0.0):
        x = np.asarray(x, float); z = np.asarray(z, float)
        name = np.full(x.shape, None, object); y = np.full(x.shape, np.nan)
        for k, (r, h) in self.pads.items():
            ins = (x > r['x0'] - margin) & (x < r['x1'] + margin) & (z > r['z0'] - margin) & (z < r['z1'] + margin)
            name[ins] = k; y[ins] = h
        return name, y

    # ---------------------------------------------------------------- the surface
    def build(self):
        H, D = self.H, self.D
        n = len(AX)
        r, c = np.mgrid[0:n, 0:n]
        box = np.maximum(np.abs(AX[c]), np.abs(AX[r]))
        stride = np.where(D <= 0, 2, np.where(D < 40, 2, np.where(D < 150, 4, np.where(D < 500, 8, 12))))
        stride = np.where(box > LY.HALF + 40, 16, stride)
        sel = (r % stride == 0) & (c % stride == 0)
        pr, pc = r[sel], c[sel]
        px, pz, py = AX[pc], AX[pr], H[pr, pc].astype(np.float64)
        # off the roads and pads
        nm, _ = self.road_at(px, pz, margin=0.6, y=py, ytol=2.0)
        pn, _ = self.pad_at(px, pz, margin=0.6)
        keep = (nm == None) & (pn == None) & inside(px, pz, 30) & ~self.fill_at(px, pz, -0.6)
        pts = [np.c_[px[keep], py[keep], pz[keep]]]
        # the edge: a circle that the ring of far hills starts from (objects.far_scenery uses the same points)
        rx, rz = edge(RING_R, RING_P)
        pts.append(np.c_[rx, TR.sample(H, rx, rz), rz])
        # rows along the road edges and verges (none along a bridge deck)
        for k, rd in self.roads.items():
            idx = self.stations(rd, 3.0, 6.0)
            idx = idx[rd.ground[idx]]
            for eo, sgn in ((rd.hi, 1), (rd.lo, -1)):
                o = eo + sgn * 0.25
                xy = rd.P[idx] + rd.n[idx] * o
                y = rd.surface(idx, eo) - 0.035
                pts.append(np.c_[xy[:, 0], y, xy[:, 1]])
                if rd.verge > 2:
                    iv = idx[::2]
                    o2 = eo + sgn * rd.verge
                    xy = rd.P[iv] + rd.n[iv] * o2
                    y = rd.surface(iv, eo) - 0.05 - 0.02 * rd.verge
                    pts.append(np.c_[xy[:, 0], y, xy[:, 1]])
        for k, (pr_, h) in self.pads.items():
            x0, x1, z0, z1 = pr_['x0'] - 0.25, pr_['x1'] + 0.25, pr_['z0'] - 0.25, pr_['z1'] + 0.25
            per = []
            for (a, b) in (((x0, z0), (x1, z0)), ((x1, z0), (x1, z1)), ((x1, z1), (x0, z1)), ((x0, z1), (x0, z0))):
                L = np.hypot(b[0] - a[0], b[1] - a[1]); m = max(2, int(L / 4))
                t = np.linspace(0, 1, m, endpoint=False)
                per.append(np.c_[a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t])
            per = np.concatenate(per)
            pts.append(np.c_[per[:, 0], np.full(len(per), h - 0.035), per[:, 1]])
        # round each junction fill's grass edge, 0.25 m out, just under it
        for f in self.fills:
            for Q in f.nose():
                t = np.gradient(Q, axis=0); t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-9)
                nn = np.c_[-t[:, 1], t[:, 0]]
                sg = np.where(f.inside(*(Q + nn * 0.5).T), -1.0, 1.0)[:, None]
                q = Q + nn * sg * 0.25
                pts.append(np.c_[q[:, 0], f.height(Q[:, 0], Q[:, 1]) - 0.035, q[:, 1]])
        # gravel traps: rows along their inner and outer edges every metre, and points 1.6 m apart inside (where a
        # trap is cut back by another road its edge follows them)
        for tr in self.traps:
            for fr in (0.0, 1.0):
                xy = tr.rd.P[tr.ids] + tr.rd.n[tr.ids] * (tr.sd * (tr.o0 + tr.wid * fr))[:, None]
                pts.append(np.c_[xy[:, 0], TR.sample(H, xy[:, 0], xy[:, 1]), xy[:, 1]])
            # a 1.6 m lattice over the trap's whole frame and a little round it, so where the trap is cut back
            # (near another track) the ground's triangles are small enough to follow the cut
            k = np.arange(1, len(tr.ids) - 1, 2)
            o = tr.o0 - 1.6 + np.arange(0, tr.W + 4.0, 1.6)
            xy = (tr.rd.P[tr.ids[k]][:, None, :] + tr.rd.n[tr.ids[k]][:, None, :] * (tr.sd * o)[None, :, None]).reshape(-1, 2)
            near = (o[None, :] <= tr.o0 + tr.wid[k][:, None] + 3.0) & (tr.wid[k][:, None] > 0)
            xy = xy[near.ravel()]
            pts.append(np.c_[xy[:, 0], TR.sample(H, xy[:, 0], xy[:, 1]), xy[:, 1]])
        P = np.concatenate(pts)
        # edge rows that land on another road, pad or fill go (that surface covers them)
        nm, _ = self.road_at(P[:, 0], P[:, 2], margin=-0.05, y=P[:, 1])
        pn, _ = self.pad_at(P[:, 0], P[:, 2], margin=-0.05)
        P = P[(nm == None) & (pn == None) & ~self.fill_at(P[:, 0], P[:, 2], 0.05)]
        # merge near-duplicates
        key = np.round(P[:, [0, 2]] / 0.5).astype(np.int64)
        _, first = np.unique(key, axis=0, return_index=True)
        P = P[np.sort(first)]
        tri = Delaunay(P[:, [0, 2]])
        I = tri.simplices.copy()
        C = P[I].mean(1)
        nm, _ = self.road_at(C[:, 0], C[:, 2], margin=-0.02, y=C[:, 1], ytol=2.0)
        pn, _ = self.pad_at(C[:, 0], C[:, 2], margin=-0.02)
        I = I[(nm == None) & (pn == None) & ~self.fill_at(C[:, 0], C[:, 2])]
        # counter-clockwise seen from above (normals up)
        T = P[I]
        cr = (T[:, 1, 0] - T[:, 0, 0]) * (T[:, 2, 2] - T[:, 0, 2]) - (T[:, 1, 2] - T[:, 0, 2]) * (T[:, 2, 0] - T[:, 0, 0])
        I[cr > 0] = I[cr > 0][:, [0, 2, 1]]
        self.P, self.I = P, I
        self.tri = Delaunay(P[:, [0, 2]])                       # for height look-ups (the full triangulation)
        print(f'ground: {len(P)} points, {len(I)} triangles')

    def stations(self, rd, fine, coarse):
        """sample indices along a road: every `fine` m on curves, `coarse` m on straights"""
        k = np.abs(rd.k)
        step = np.where(k > 1 / 150, fine, coarse)
        idx = [0]; acc = 0.0
        for i in range(1, len(rd.P)):
            acc += 1.0
            if acc >= step[i]: idx.append(i); acc = 0.0
        if idx[-1] != len(rd.P) - 1: idx.append(len(rd.P) - 1)
        return np.array(idx)

    def height(self, x, z):
        """the ground surface (this triangulation) at points; roads and pads are not included"""
        x = np.atleast_1d(np.asarray(x, float)); z = np.atleast_1d(np.asarray(z, float))
        q = np.c_[x, z]
        s = self.tri.find_simplex(q)
        out = TR.sample(self.H, x, z).astype(np.float64)
        ok = s >= 0
        if ok.any():
            Tm = self.tri.transform[s[ok]]
            b = np.einsum('ijk,ik->ij', Tm[:, :2], q[ok] - Tm[:, 2])
            bc = np.c_[b, 1 - b.sum(1)]
            out[ok] = (self.P[self.tri.simplices[s[ok]], 1] * bc).sum(1)
        return out

    def surface(self, x, z):
        """what the car drives on: a road or pad where there is one, the ground elsewhere"""
        y = self.height(x, z)
        nm, yr = self.road_at(x, z)
        y = np.where(nm != None, yr, y)
        pn, yp = self.pad_at(x, z)
        return np.where((pn != None) & (nm == None), yp, y)

    def mesh(self, mesh):
        P, I = self.P, self.I
        C = P[I].mean(1)
        box = np.maximum(np.abs(C[:, 0]), np.abs(C[:, 2]))
        rr = np.clip(np.round((C[:, 2] + TR.EXT) / RES).astype(int), 0, len(AX) - 1)
        cc = np.clip(np.round((C[:, 0] + TR.EXT) / RES).astype(int), 0, len(AX) - 1)
        d = self.D[rr, cc]
        outside = box > LY.HALF + 2
        gravel = self.trap_at(C[:, 0], C[:, 2]) & ~outside
        mown = (~outside) & (d < 25) & ~gravel
        for mat, sel, k in (('grass', mown, 9.0), ('field', (~outside) & (~mown) & ~gravel, 13.0), ('hill', outside, 17.0), ('gravel', gravel, 6.0)):
            if not sel.any(): continue
            Ii = I[sel]; used = np.unique(Ii)
            remap = -np.ones(len(P), np.int64); remap[used] = np.arange(len(used))
            Pp = P[used]
            mesh.add(mat, Pp, Pp[:, [0, 2]] / k, remap[Ii])
