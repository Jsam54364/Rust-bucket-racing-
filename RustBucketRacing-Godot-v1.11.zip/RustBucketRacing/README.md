# Rust Bucket Racing (Godot 4.7, C#, mobile)

This is a Godot port of the browser game. It includes all three cars (Rust Bucket, Monte Carlo SS and CTS-V race car), the proving ground with its race track built in, and more maps to download (Spa-Francorchamps 1992, the Monte Carlo Rally mountain stage, the Irohazaka hairpins and the Motorsport Compound so far). It also includes:

- the 480 Hz suspension, tyre and drivetrain simulation;
- the granular engine sound;
- every camera, including the interior cameras;
- touch controls, the HUD, telemetry, the car setup and controls panels, the lap timer, and a stage timer that runs either way on Monte Carlo and Irohazaka.

The game is built for phones in landscape. It also runs on desktop with a keyboard or gamepad, which is the quickest way to try it.

> **If the game closes on start-up**, open it again: it shows the log of the run that closed, with a **Copy report** button. **Settings → Other** also has **Copy debug log** for problems that don't close the game. Send either one over and it can be fixed.

## What you need

| | |
|---|---|
| Godot | **4.7.2, .NET edition** (godotengine.org → Download → "Godot Engine - .NET") |
| .NET SDK | **9.0 or newer** (Android export needs 9; desktop needs 8 or later) |
| Android export | JDK 17, the Android SDK (easiest to get through Android Studio), and Godot's export templates (.NET) |
| iOS export | A Mac with Xcode, and an Apple developer account for signing |

If you use a different 4.7.x editor, change the version on the first line of `RustBucket.csproj` (`Godot.NET.Sdk/4.7.2`) to match it.

## First run (desktop)

1. Unzip the project and open `project.godot` in Godot 4.7 .NET. The first import takes a minute: it imports `models/rust.glb` and compiles the shaders.
2. Press the hammer icon (**Build**) at the top right. If there are errors, the MSBuild panel at the bottom lists them.
3. Press **Run** (F5). The game opens at the main menu: **Free Roam** picks a map and a start, **Drive** starts.

## Build the APK on GitHub (no Godot or .NET needed)

`.github/workflows/main.yml` runs `ci/build.sh` on GitHub's servers on every push to `main`. The workflow also works if the repository holds just this project zipped as `RustBucketRacing-Godot.zip`. The build:

1. downloads Godot 4.7.2 .NET and its export templates;
2. compiles the C# and imports the assets;
3. runs a **self-test**: the game on a virtual screen with software OpenGL, driving every car on both maps, switching cameras, opening the menus and taking screenshots;
4. exports a debug APK and checks the C# code is inside it.

**Maps in their own zips.** The proving ground is the only map in the project zip. Each other map is a `RustBucketRacing-Maps-<name>.zip` (Spa, MonteCarlo, Irohazaka) uploaded next to it once; it stays in the repository, and every build publishes it to the release **maps** for the game to download (see Maps below).

**Getting the APK.** The APK is published as the release **latest-apk**. On your phone, open `https://github.com/<you>/<repo>/releases/latest/download/RustBucketRacing.apk`, or the repository's **Releases** page. Android asks you to allow installs from your browser the first time.

**Logs.** The logs (`csharp-build.log`, `import.log`, `smoke.log`, `export.log`) and the self-test screenshots go to the branch **ci-logs**. The run's summary page shows each step's result.

Godot's exporter needs the solution file `RustBucket.sln`. Without it, Godot treats the project as having no C# code, and the APK closes right after the splash screen.

## Export to Android

1. In **Editor → Manage Export Templates**, download the templates for your Godot version.
2. In **Editor → Editor Settings → Export → Android**, set:
   - **Java SDK Path**, to your JDK 17 folder;
   - **Android SDK Path**, to the folder Android Studio installed the SDK into;
   - a debug keystore. Godot can make one for you; see "Exporting for Android" in the Godot docs.
3. **Project → Export…** already has an **Android** preset, set to arm64 with the package name `com.rustbucket.racing`. Press **Export Project** to get an APK, or plug in a phone with USB debugging enabled and use the one-click deploy icon at the top right of the editor.

The game data under `data/` (maps, car packs and engine recordings) is included through the preset's **Resources → Filters to export non-resource files** = `data/*`. Keep that filter if you make a new preset.

## Export to iOS

On a Mac, add your Apple **Team ID** to the iOS preset (**Project → Export → iOS → App Store Team ID**) and export. This creates an Xcode project; build and sign it in Xcode. Godot's C# support on iOS is still marked experimental.

## Controls

**Touch** (shown automatically on touch screens):

- **Left thumb.** Slide along the steering pad. Flick the gear slider up or down to shift, or tap either end of it.
- **Right thumb.** Use **Gas**, **Brake** and **Hand**. Gas and Brake are pressure-sensitive: press higher on the pedal for more, lower to feather it.
- **Top right.** The camera button cycles chase, orbit, bumper, interior and trackside. The menu button opens **Settings** and the **Main menu** (top row), the car, map, car setup, resets and stage starts. The phone's back button pauses to the main menu.
- **Orbit camera.** Drag to fly round the car; pinch to zoom.
- **Settings → Controls.** Switches the steering pad to two buttons, and turns analogue pedals on or off.

**Keyboard:**

| Key | Action |
|---|---|
| W / S | throttle, brake |
| A / D | steer |
| Space | handbrake |
| Q / E | shift down / up |
| C | camera |
| G | telemetry |
| T | car setup |
| K | controls |
| M | gearbox mode |
| V | next car |
| N | next map |
| L | starting grid |
| R | reset (Shift+R: back to the start) |
| H | help |
| + / − or mouse wheel | zoom |
| drag | look around |

**Gamepad:**

| Input | Action |
|---|---|
| left stick | steer |
| RT / LT | throttle / brake |
| A or B | handbrake |
| RB / LB | shift up / down |
| Y | camera |
| X | gearbox mode |
| Start | reset |
| Back | car setup |

## Project layout

```
project.godot, RustBucket.csproj, export_presets.cfg, Main.tscn (one node, scripts/Game/Main.cs)
data/       monte.bin / cts.bin (car packs), engine_*.json, sfx.json (maps are downloads: see Maps below)
models/     rust.glb (imported by Godot)
shaders/    surface (proving ground), track, world_* (Spa), world_arr_* and world_far (Monte Carlo), skid, smoke, shared includes
scripts/Sim/     the simulation, a line-by-line port of physics.js (pure C#, no Godot types), map packs, timed courses
scripts/Render/  map chunks, proving-ground meshes, car models, skid marks, smoke
scripts/Audio/   granular engine, tyres, kerbs, wind, shifts, pops; AudioStreamGenerator output
scripts/Game/    main loop, cameras, input, touch controls, HUD, in-game menu, front end (main menu, garage, settings), settings store
mapgen/compound/ the Motorsport Compound's generator (Python; not part of the game build)
```

## Maps (downloads)

Only the proving ground is built into the APK. Every other map is a download: the **Maps** page in the main menu lists them, downloads the ones you pick into the phone's storage for the game, updates them when a new version is published, and removes them to free space. Free Roam lists every map on the phone, with a **More maps** card that leads to the Maps page.

**The Motorsport Compound** (game 1.10 or later) is five miles square. In the middle, a hilly Grand Prix circuit in three configurations (GP, International, National: they share the main straight and its pits) wraps a NASCAR-style oval (18 m wide, banked 20 degrees in the turns, with a paved apron and its own pit lane and paddock in the infield, entered through a gate in its outside wall). Where the configurations part and join, the grass between the tracks ends in a rounded nose. Beside the GP paddock are a drift track with wide flowing corners (no kerbs: an outer zone and a clipping point marked at every corner, as at drift events; a lane from its paddock leads onto it), a quarter-mile drag strip and a slalom/skid pad; an endurance circuit (about 28 km) runs round the edge of the compound with its own pits by the main gate, and the ground between is left open for later. Service roads bridge the circuits where they must cross them. Each course times itself: laps (the GP times whichever configuration you drive), runs from line to line on the drag strip (with the speed over the line) and the slaloms (2 s for every cone knocked over). Free Roam and the in-game menu's **Go to** start you at any of them; **Reset car** puts you back on the nearest road when you're off one. The track furniture (guardrail, concrete barriers, tyre barriers, light masts, brake boards, signs, start lights) comes from the Race Track Assets Pack, cut down to a few hundred triangles a piece or drawn as pictures on simple strips; the transporters are the DAV NASCAR Hauler model, its tractor unit rebuilt as one baked shell, in six liveries of our own. It is generated from scratch by `mapgen/compound/gen.py` (see the README there).

Each map comes as **RustBucketRacing-Maps-<name>.zip** in the repo, holding the map pack (`<id>.bin`) and its description (`<id>.json`: name, length, blurb, credit, fog, stage lines, start points). A pack can also carry extra courses, road centrelines, pads, cones and start points (`meta.tracks`, `roads`, `pads`, `cones`, `spots`); games older than 1.9 ignore them, so such a map asks for 1.9 (`minGame`). On every build, `ci/build.sh` lists them in `maps.json` (with each pack's size and sha256) and publishes them to the GitHub release **maps**; only packs that changed are uploaded again. The game checks a download against that size and sha256 before installing it. So a new map needs only its zip uploaded to the repo, never a new APK. The self-test downloads every map from the release, drives them, and removes two again.

## Menus (alpha)

The game opens at the **main menu**, with the current car turning on a platform in the garage studio behind it. **Free Roam** is the one mode so far: pick a map, a start (test areas or race track; uphill or downhill on the stages) and drive. **Time Trial**, **Career** and **Multiplayer** each have their own page already, marked in development, with what is planned for them.

The **garage** shows each car on a turntable in a small studio with its own lights (a world of its own, drawn into a texture behind the menus; the game's own 3D is switched off meanwhile). Drag to turn the platform, up and down to look from higher or lower, pinch or scroll to zoom. The panel gives power and torque (from the full-throttle curve), weight, drive, gearbox, size and your best times with that car.

**Settings** has five tabs: Audio (sound on or off, and a volume for the master, engine, tyres and road, crashes and impacts, and effects, each playing a sample as you move it), Display (graphics, units, telemetry), Driving (gearbox, steering speed, the assists), Controls (sensitivity, touch steering, analogue pedals) and Other (copy debug log). Opened from the drive, it pauses it and shows it dimmed behind.

**The mix** is balanced at the output, measured by the self-test (loudest 100 ms of each kind of sound on its own): a full-throttle engine about -9 dB, a big crash -7, a four-wheel slide on tarmac -9.5, rolling at 100 km/h -16.5, a gear change -13, a hard cone hit -14.5, wind at 160 km/h -24.

The whole scene is built in code at start-up, so there is nothing to wire up in the editor.

## Tuning the look

The browser version had its own lighting. This port uses Godot's sun, sky, shadows, fog and ACES tonemapping instead, so colours won't match exactly. You can adjust them with the constants at the top of `scripts/Game/Main.cs`:

- `SunEnergy`
- `AmbientSky`
- `Exposure`
- `FogGrid`
- `FogMap`

The renderer is **Compatibility** (OpenGL ES 3), which runs on the widest range of phones.

Monte Carlo is drawn with a level-of-detail system: every chunk of ground, rock, wall and building carries simplified versions (made with Godot's own mesh simplifier when the map pack is built), and the renderer swaps to a coarser one as it gets further away (how coarse is set by the graphics quality); trees, bushes, fences and guardrails fade out with distance; all the textures sit in one texture array so each chunk draws in a handful of calls; and the hills act as occluders, so what's behind a ridge isn't drawn at all. Irohazaka is drawn the same way.

**Body collisions** use one convex collider per car, fitted to its body (31-35 corners) with bevelled front corners, so an angled hit slides the car off. They are solved as impulses: a hull point that touches a wall, a box or the ground stops going into it at once (so the body never sinks into a guardrail and catches the posts behind it), with a small bounce (a quarter of the speed it hit at, down to a twentieth for a big hit) and low friction along walls, so a glancing hit keeps most of the speed and turns the car along the wall. The self-test checks straight hits, glancing hits on the garage block and a guardrail on Monte Carlo.

## Credits

All models are CC BY 4.0:

- "Lowpoly Abandoned Simple Car Prop" by Rashad Ibrahimli
- "1987 Chevrolet Monte Carlo SS" by Randomness
- "Circuit de Spa-Francorchamps 1992 layout" by Dave Love (sketchfab.com/Tyler_Dave)
- "Monte Carlo Rally" by Dave Love (sketchfab.com/Tyler_Dave)
- "2004 Cadillac CTS-V race car" by Dave Love (sketchfab.com/Tyler_Dave)
- "Race Track Assets Pack" by Cherk (sketchfab.com/alex20010804): the compound's track furniture
- "DAV NASCAR Hauler" by jairobman (sketchfab.com/jairobman): the compound's transporters (its sponsor's logos left off, liveries of our own)

"Irohazaka Slope", an Assetto Corsa track by sost and its original authors, is a free community mod: it is used here free and not for sale, with credit, and anything made from it stays free.
