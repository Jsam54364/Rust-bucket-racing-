// A map pack drawn in Godot: one MeshInstance3D per chunk and fade class, so frustum culling drops chunks out
// of view and visibility ranges drop small things far away; the shader dithers them out over the last 22 % of
// their range.
//   * Draws that come with LODs (made by Godot's own simplifier when the pack was built) hand them to the mesh,
//     and the renderer picks the coarsest one whose error stays under Viewport.MeshLodThreshold pixels.
//   * Packs that ask for it ("merge", Monte Carlo) put every texture in one Texture2DArray and draw all the
//     materials of a chunk that share a shader and a fade as one surface (the layer, tint and highlight ride on
//     each vertex): a handful of draws per chunk instead of one per material. Other packs (Spa) draw a
//     surface per material as before.
//   * Packs with hills get occluders: the drivable ground, coarsened and sunk out of sight, so chunks behind a
//     ridge aren't drawn at all.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class MapWorldView
    {
        public readonly Node3D Root = new Node3D { Name = "MapWorld" };
        public readonly float FloorY;
        public int Occluders, LodDraws, Surfaces;

        const float OccSink = 1.5f;     // occluders sit this far under the ground they come from
        const double OccError = 0.6;    // ...and use the coarsest LOD within this many metres of it
        const int ArrSize = 512;        // texture array layers are this size

        // depth bias toward the camera for stacked ground layers: (metres, metres per metre of distance)
        public static readonly Vector2 BiasUnder = new Vector2(-0.006f, -0.0012f);
        public static readonly Vector2 BiasPit = new Vector2(0.004f, 0.0007f);

        // one draw, decoded: its own vertex list (in first-use order, which the pack's LODs index), its indices
        // and its LODs (error in metres, indices)
        sealed class Draw
        {
            public MapDraw D;
            public Vector3[] P, N;
            public Vector2[] UV;
            public int[] I;
            public List<(double size, int[] idx)> Lods = new List<(double, int[])>();
        }

        readonly MapPack pk;
        int[] remap;
        readonly List<int> touched = new List<int>();
        readonly List<Vector3> pos = new List<Vector3>(), nrm = new List<Vector3>();
        readonly List<Vector2> uvs = new List<Vector2>();
        readonly List<Vector3> occP = new List<Vector3>();
        readonly List<int> occI = new List<int>();

        static bool GroundLike(MapMat m) => m.Cat == "ground" || m.Cat == "far"; // far hills light like the ground

        public MapWorldView(MapPack pack, bool wantOcc = false)
        {
            pk = pack;
            bool merge = pk.Merge;
            var shGround = GD.Load<Shader>("res://shaders/world_ground.gdshader");
            var shCut = GD.Load<Shader>("res://shaders/world_cut.gdshader");
            var shBlend = GD.Load<Shader>("res://shaders/world_blend.gdshader");
            Shader shFar = null;

            // textures: one Texture2D each, or (merged packs) one array with a white layer at the end
            var tex = new Texture2D[pk.ImageCount];
            Texture2DArray texArr = null;
            int white = -1;
            if (merge)
            {
                var imgs = new Godot.Collections.Array<Image>();
                for (int i = 0; i < pk.ImageCount; i++)
                {
                    var img = new Image();
                    if (img.LoadWebpFromBuffer(pk.Image(i)) != Error.Ok || img.IsEmpty())
                    {
                        GD.PushWarning($"map texture {i} did not load");
                        img = Image.CreateEmpty(ArrSize, ArrSize, false, Image.Format.Rgba8); img.Fill(new Color(0.5f, 0.5f, 0.5f));
                    }
                    imgs.Add(ArrLayer(img));
                    // the backdrop (drawn on its own) still wants its own texture
                    tex[i] = null;
                }
                var wimg = Image.CreateEmpty(ArrSize, ArrSize, false, Image.Format.Rgba8); wimg.Fill(Colors.White);
                white = imgs.Count; imgs.Add(ArrLayer(wimg));
                texArr = new Texture2DArray();
                var err = texArr.CreateFromImages(imgs);
                if (err != Error.Ok) { GD.PushWarning("map texture array: " + err); merge = false; }
            }
            if (!merge || HasNoFog())
                for (int i = 0; i < tex.Length; i++)
                {
                    if (merge && !UsedByNoFog(i)) continue;
                    try { tex[i] = MeshUtil.LoadImage(pk.Image(i), "image/webp"); }
                    catch (Exception e) { GD.PushWarning($"map texture {i}: {e.Message}"); }
                }

            // a material per pack material (all of them unmerged; only backdrops when merged)
            var mats = new ShaderMaterial[pk.Materials.Length];
            for (int i = 0; i < mats.Length; i++)
            {
                var m = pk.Materials[i];
                if (merge && m.Fog) continue;
                bool hasTex = m.Tex >= 0 && m.Tex < tex.Length && tex[m.Tex] != null;
                var c = m.Color;
                if (!m.Fog)
                {
                    // a backdrop with its own haze (shaders/world_far.gdshader)
                    shFar ??= GD.Load<Shader>("res://shaders/world_far.gdshader");
                    var fm = new ShaderMaterial { Shader = shFar };
                    if (hasTex) fm.SetShaderParameter("tex", tex[m.Tex]);
                    fm.SetShaderParameter("has_tex", hasTex);
                    fm.SetShaderParameter("color", new Vector4((float)c[0], (float)c[1], (float)c[2], c.Length > 3 ? (float)c[3] : 1f));
                    fm.SetShaderParameter("mat_mode", m.Mode == 0 ? 0 : 1);
                    mats[i] = fm;
                    continue;
                }
                bool groundLike = GroundLike(m);
                Shader sh = m.Mode == 2 ? shBlend : (groundLike && m.Mode == 0 ? shGround : shCut);
                var sm = new ShaderMaterial { Shader = sh };
                if (hasTex) sm.SetShaderParameter("tex", tex[m.Tex]);
                sm.SetShaderParameter("has_tex", hasTex);
                sm.SetShaderParameter("color", new Vector4((float)c[0], (float)c[1], (float)c[2], c.Length > 3 ? (float)c[3] : 1f));
                sm.SetShaderParameter("kind", groundLike ? 0 : m.Cat == "veg" ? 1 : 2);
                sm.SetShaderParameter("mat_mode", m.Mode);
                sm.SetShaderParameter("spec", (float)m.Spec);
                sm.SetShaderParameter("fade", m.Fade > 0 ? new Vector2((float)(m.Fade * 0.78), (float)m.Fade) : Vector2.Zero);
                if (m.UnderTex >= 0 && m.UnderTex < tex.Length && tex[m.UnderTex] != null)
                {
                    sm.SetShaderParameter("under_tex", tex[m.UnderTex]);
                    sm.SetShaderParameter("under_k", new Vector2((float)m.UnderK, 1f));
                }
                else sm.SetShaderParameter("under_k", Vector2.Zero);
                sm.SetShaderParameter("bias", m.Layer > 0 ? BiasPit : m.Layer < 0 ? BiasUnder : Vector2.Zero);
                mats[i] = sm;
            }

            // merged materials: one per (shader, fade, depth layer)
            var arrShaders = merge ? new[]
            {
                GD.Load<Shader>("res://shaders/world_arr_ground.gdshader"),
                GD.Load<Shader>("res://shaders/world_arr_cut.gdshader"),
                GD.Load<Shader>("res://shaders/world_arr_blend.gdshader"),
            } : null;
            var arrMats = new Dictionary<(int, double, int), ShaderMaterial>();
            ShaderMaterial ArrMat(int shader, double fade, int layer)
            {
                var key = (shader, fade, layer);
                if (arrMats.TryGetValue(key, out var am)) return am;
                am = new ShaderMaterial { Shader = arrShaders[shader] };
                am.SetShaderParameter("texarr", texArr);
                am.SetShaderParameter("fade", fade > 0 ? new Vector2((float)(fade * 0.78), (float)fade) : Vector2.Zero);
                am.SetShaderParameter("bias", layer > 0 ? BiasPit : layer < 0 ? BiasUnder : Vector2.Zero);
                arrMats[key] = am;
                return am;
            }

            double floor = double.PositiveInfinity;
            foreach (var ch in pk.Chunks) if (ch.Qs == pk.Qs) floor = Math.Min(floor, ch.Min[1]);
            if (double.IsInfinity(floor)) floor = 0;
            FloorY = (float)(floor - 3);

            int maxVn = 1;
            foreach (var ch in pk.Chunks) maxVn = Math.Max(maxVn, ch.VN);
            remap = new int[maxVn];
            for (int i = 0; i < remap.Length; i++) remap[i] = -1;

            int ci = 0;
            foreach (var ch in pk.Chunks)
            {
                occP.Clear(); occI.Clear();
                var center = new Vector3((float)((ch.Min[0] + ch.Max[0]) / 2), (float)((ch.Min[1] + ch.Max[1]) / 2), (float)((ch.Min[2] + ch.Max[2]) / 2));
                double rx = (ch.Max[0] - ch.Min[0]) / 2, ry = (ch.Max[1] - ch.Min[1]) / 2, rz = (ch.Max[2] - ch.Min[2]) / 2;
                double radius = Math.Sqrt(rx * rx + ry * ry + rz * rz);
                // one instance per (fade distance, casts shadows)
                var groups = new Dictionary<(double, bool), List<MapDraw>>();
                var order = new List<(double, bool)>();
                foreach (var d in ch.Draws)
                {
                    var m = pk.Materials[d.Mat];
                    var key = (m.Fade, m.Shadow);
                    if (!groups.TryGetValue(key, out var list)) { list = new List<MapDraw>(); groups[key] = list; order.Add(key); }
                    list.Add(d);
                }
                foreach (var key in order)
                {
                    var mesh = new ArrayMesh();
                    // decode every draw of the group
                    var draws = new List<Draw>();
                    foreach (var d in groups[key])
                    {
                        var dr = Decode(ch, d, center);
                        if (dr == null) continue;
                        draws.Add(dr);
                        var mm = pk.Materials[d.Mat];
                        if (wantOcc && mm.Cat == "ground" && mm.Surf > 0 && mm.Mode == 0 && mm.Layer == 0) AddOccluder(dr, center);
                    }
                    if (merge)
                    {
                        // backdrops alone; everything else merged by (shader, depth layer)
                        var sub = new Dictionary<(int, int), List<Draw>>();
                        var subOrder = new List<(int, int)>();
                        foreach (var dr in draws)
                        {
                            var m = pk.Materials[dr.D.Mat];
                            if (!m.Fog) { AddSurface(mesh, new List<Draw> { dr }, mats[dr.D.Mat], false, white); continue; }
                            var k = (m.Mode == 2 ? 2 : (m.Mode == 1 || m.Fade > 0) ? 1 : 0, Math.Sign(m.Layer));
                            if (!sub.TryGetValue(k, out var l)) { l = new List<Draw>(); sub[k] = l; subOrder.Add(k); }
                            l.Add(dr);
                        }
                        foreach (var k in subOrder) AddSurface(mesh, sub[k], ArrMat(k.Item1, key.Item1, k.Item2), true, white);
                    }
                    else
                        foreach (var dr in draws) AddSurface(mesh, new List<Draw> { dr }, mats[dr.D.Mat], false, white);
                    if (mesh.GetSurfaceCount() == 0) continue;
                    var mi = new MeshInstance3D
                    {
                        Name = $"chunk{ci}_{(int)key.Item1}{(key.Item2 ? "s" : "")}",
                        Mesh = mesh,
                        Position = center,
                        CastShadow = key.Item2 ? GeometryInstance3D.ShadowCastingSetting.On : GeometryInstance3D.ShadowCastingSetting.Off,
                    };
                    if (key.Item1 > 0) mi.VisibilityRangeEnd = (float)(key.Item1 + radius);
                    Root.AddChild(mi);
                }
                if (occI.Count >= 3)
                {
                    var ao = new ArrayOccluder3D();
                    ao.SetArrays(occP.ToArray(), occI.ToArray());
                    Root.AddChild(new OccluderInstance3D { Name = $"occ{ci}", Occluder = ao });
                    Occluders++;
                }
                ci++;
            }
            remap = null;
        }

        bool HasNoFog() { foreach (var m in pk.Materials) if (!m.Fog) return true; return false; }
        bool UsedByNoFog(int img) { foreach (var m in pk.Materials) if (!m.Fog && m.Tex == img) return true; return false; }

        static Image ArrLayer(Image img)
        {
            if (img.IsCompressed()) img.Decompress();
            if (img.HasMipmaps()) img.ClearMipmaps();
            if (img.GetFormat() != Image.Format.Rgba8) img.Convert(Image.Format.Rgba8);
            if (img.GetWidth() != ArrSize || img.GetHeight() != ArrSize) img.Resize(ArrSize, ArrSize, Image.Interpolation.Bilinear);
            img.GenerateMipmaps();
            return img;
        }

        // a draw's own vertex list, indices and LODs, positions relative to the chunk's centre
        Draw Decode(MapChunk ch, MapDraw d, Vector3 center)
        {
            if (d.N < 3) return null;
            double q = 1 / ch.Qs;
            pos.Clear(); nrm.Clear(); uvs.Clear(); touched.Clear();
            var idx = new int[d.N - d.N % 3];
            double ku = 1 / d.Kq;
            for (int j = 0; j < idx.Length; j++)
            {
                int li = pk.Idx[ch.I0 + d.I0 + j];
                if (li >= remap.Length) { idx[j] = 0; continue; }
                if (remap[li] < 0)
                {
                    remap[li] = pos.Count; touched.Add(li);
                    int v = ch.V0 + li;
                    pos.Add(new Vector3(
                        (float)(ch.O[0] + pk.PosQ(v, 0) * q - center.X),
                        (float)(ch.O[1] + pk.PosQ(v, 1) * q - center.Y),
                        (float)(ch.O[2] + pk.PosQ(v, 2) * q - center.Z)));
                    var n = new Vector3(Math.Max(pk.NrmQ(v, 0) / 127f, -1f), Math.Max(pk.NrmQ(v, 1) / 127f, -1f), Math.Max(pk.NrmQ(v, 2) / 127f, -1f));
                    nrm.Add(n.LengthSquared() > 1e-8f ? n.Normalized() : Vector3.Up);
                    uvs.Add(new Vector2((float)(pk.UvQ(v, 0) * ku + d.UOff), (float)(pk.UvQ(v, 1) * ku + d.VOff)));
                }
                idx[j] = remap[li];
            }
            foreach (int li in touched) remap[li] = -1;
            if (pos.Count == 0) return null;
            var dr = new Draw { D = d, P = pos.ToArray(), N = nrm.ToArray(), UV = uvs.ToArray(), I = idx };
            if (d.Lods != null)
                foreach (var l in d.Lods)
                {
                    if (l.N < 3) continue;
                    var li2 = new int[l.N];
                    bool ok = true;
                    for (int j = 0; ok && j < l.N; j++) { int v = pk.LodIdx[l.I0 + j]; if (v >= dr.P.Length) ok = false; else li2[j] = v; }
                    if (ok) dr.Lods.Add((l.Size, li2));
                }
            dr.Lods.Sort((a, b) => a.size.CompareTo(b.size));
            return dr;
        }

        // drivable ground at the coarsest LOD within OccError of it, sunk OccSink
        void AddOccluder(Draw dr, Vector3 center)
        {
            int[] oi = dr.I;
            foreach (var (size, idx) in dr.Lods) if (size <= OccError) oi = idx;
            int b = occP.Count;
            var sink = center + new Vector3(0, -OccSink, 0);
            foreach (var p in dr.P) occP.Add(p + sink);
            foreach (int v in oi) occI.Add(b + v);
        }

        // One surface from one or more draws. LOD level k of a merged surface takes each draw's k-th LOD (or its
        // coarsest, or its full mesh if it has none), and counts the largest error among them.
        void AddSurface(ArrayMesh mesh, List<Draw> draws, Material mat, bool arr, int white)
        {
            if (draws.Count == 0 || mat == null) return;
            int nv = 0, ni = 0, levels = 0;
            foreach (var dr in draws) { nv += dr.P.Length; ni += dr.I.Length; levels = Math.Max(levels, dr.Lods.Count); }
            var P = new Vector3[nv]; var N = new Vector3[nv]; var UV = new Vector2[nv];
            var UV2 = arr ? new Vector2[nv] : null; var COL = arr ? new Color[nv] : null;
            var I = new int[ni];
            int vb = 0, ib = 0;
            var bases = new int[draws.Count];
            for (int k = 0; k < draws.Count; k++)
            {
                var dr = draws[k]; bases[k] = vb;
                Array.Copy(dr.P, 0, P, vb, dr.P.Length); Array.Copy(dr.N, 0, N, vb, dr.N.Length); Array.Copy(dr.UV, 0, UV, vb, dr.UV.Length);
                if (arr)
                {
                    var m = pk.Materials[dr.D.Mat];
                    float layer = m.Tex >= 0 && m.Tex < white ? m.Tex : white;
                    float kind = (GroundLike(m) ? 0 : m.Cat == "veg" ? 1 : 2) + (m.Mode == 1 ? 4 : 0);
                    var c = m.Color;
                    var col = new Color((float)c[0], (float)c[1], (float)c[2], (float)m.Spec);
                    for (int v = 0; v < dr.P.Length; v++) { UV2[vb + v] = new Vector2(layer, kind); COL[vb + v] = col; }
                }
                for (int j = 0; j < dr.I.Length; j++) I[ib + j] = dr.I[j] + vb;
                vb += dr.P.Length; ib += dr.I.Length;
            }
            Godot.Collections.Dictionary lods = null;
            if (levels > 0)
            {
                lods = new Godot.Collections.Dictionary();
                double prev = 0;
                for (int lv = 0; lv < levels; lv++)
                {
                    double size = 0; int n = 0;
                    foreach (var dr in draws)
                    {
                        if (dr.Lods.Count == 0) { n += dr.I.Length; continue; }
                        var l = dr.Lods[Math.Min(lv, dr.Lods.Count - 1)];
                        size = Math.Max(size, l.size); n += l.idx.Length;
                    }
                    var li = new int[n]; int o = 0;
                    for (int k = 0; k < draws.Count; k++)
                    {
                        var dr = draws[k];
                        var src = dr.Lods.Count == 0 ? dr.I : dr.Lods[Math.Min(lv, dr.Lods.Count - 1)].idx;
                        for (int j = 0; j < src.Length; j++) li[o++] = src[j] + bases[k];
                    }
                    if (size <= prev) size = prev * 1.001 + 1e-5; // keys must rise
                    prev = size;
                    lods[(float)size] = li;
                }
                LodDraws++;
            }
            var a = new Godot.Collections.Array();
            a.Resize((int)Mesh.ArrayType.Max);
            a[(int)Mesh.ArrayType.Vertex] = P;
            a[(int)Mesh.ArrayType.Normal] = N;
            a[(int)Mesh.ArrayType.TexUV] = UV;
            if (arr) { a[(int)Mesh.ArrayType.TexUV2] = UV2; a[(int)Mesh.ArrayType.Color] = COL; }
            a[(int)Mesh.ArrayType.Index] = I;
            mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, a, null, lods);
            mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, mat);
            Surfaces++;
        }
    }
}
