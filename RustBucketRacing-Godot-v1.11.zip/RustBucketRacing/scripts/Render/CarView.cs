// A car model: body, four wheels, optional non-spinning hubs (callipers) and steering wheel, posed every frame
// from the simulation. Monte Carlo and CTS-V come from multi-material car packs (tools/convert_*.py, the same
// files the web version embeds); the Rust Bucket is an imported GLB.
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class CarView
    {
        public static readonly string[] WheelNames = { "wheel_FL", "wheel_FR", "wheel_RL", "wheel_RR" };

        public readonly Node3D Root = new Node3D { Name = "Car" };
        Node3D body, steer;
        readonly Node3D[] wheels = new Node3D[4], hubs = new Node3D[4];
        bool hasSteer;
        Vector3 steerPivot, steerAxis = Vector3.Forward;
        readonly List<StandardMaterial3D> glass = new List<StandardMaterial3D>();
        readonly List<float> glassAlpha = new List<float>();
        bool inside;
        float scale = 1; Basis scaleB = Basis.Identity;

        // the model drawn at this size about its origin (on the ground, midway between the axles)
        public float ModelScale
        {
            get => scale;
            set { scale = value; scaleB = Basis.Identity.Scaled(new Vector3(value, value, value)); }
        }

        Node3D Part(string name)
        {
            var n = new Node3D { Name = name };
            Root.AddChild(n);
            return n;
        }

        /* ---------------- car pack: 'RBCP' | u32 json length | json | blob ---------------- */
        public static CarView FromPack(byte[] buf)
        {
            if (buf.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 0, 4)) != 0x50434252) throw new Exception("not a car pack");
            int jl = (int)BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 4, 4));
            int bas = 8 + jl;
            var cv = new CarView();
            using var doc = JsonDocument.Parse(new ReadOnlyMemory<byte>(buf, 8, jl));
            var h = doc.RootElement;
            // gzipped geometry (gz = [offset, length, raw length]): primitive buffers index the unpacked block
            byte[] gbuf = buf; int gbase = bas;
            if (h.TryGetProperty("gz", out var gz) && gz.ValueKind == JsonValueKind.Array)
            {
                var g = Nums(gz);
                using var ms = new MemoryStream(buf, bas + (int)g[0], (int)g[1]);
                using var zs = new GZipStream(ms, CompressionMode.Decompress);
                using var outMs = new MemoryStream((int)g[2]);
                zs.CopyTo(outMs);
                gbuf = outMs.ToArray(); gbase = 0;
            }
            // textures
            var texList = new List<Texture2D>();
            foreach (var im in h.GetProperty("images").EnumerateArray())
            {
                var a = Nums(im, 2);
                string mime = "image/webp";
                int k = 0;
                foreach (var e in im.EnumerateArray()) { if (k == 2 && e.ValueKind == JsonValueKind.String) mime = e.GetString(); k++; }
                var bytes = new byte[(int)a[1]];
                Buffer.BlockCopy(buf, bas + (int)a[0], bytes, 0, bytes.Length);
                Texture2D t = null;
                try { t = MeshUtil.LoadImage(bytes, mime); } catch (Exception ex) { GD.PushWarning("car texture: " + ex.Message); }
                texList.Add(t);
            }
            // materials
            var mats = new List<StandardMaterial3D>();
            var noShadow = new List<bool>();
            foreach (var m in h.GetProperty("materials").EnumerateArray())
            {
                var col = m.TryGetProperty("color", out var c) ? Nums(c) : new double[] { 1, 1, 1 };
                double alpha = Num(m, "alpha", 1);
                int mode = (int)Num(m, "mode", 0);
                int tex = m.TryGetProperty("tex", out var tx) && tx.ValueKind == JsonValueKind.Number ? (int)Math.Round(tx.GetDouble()) : -1;
                var sm = new StandardMaterial3D
                {
                    // pack colours are linear (glTF factors); albedo_color is sRGB
                    AlbedoColor = new Color((float)col[0], (float)col[1], (float)col[2], 1f).LinearToSrgb(),
                    Metallic = (float)Num(m, "metal", 0),
                    Roughness = (float)Math.Clamp(Num(m, "rough", 0.8), 0.06, 1.0),
                    CullMode = BaseMaterial3D.CullModeEnum.Disabled,
                    TextureFilter = BaseMaterial3D.TextureFilterEnum.LinearWithMipmapsAnisotropic,
                };
                var ac = sm.AlbedoColor; ac.A = (float)alpha; sm.AlbedoColor = ac;
                if (tex >= 0 && tex < texList.Count && texList[tex] != null) sm.AlbedoTexture = texList[tex];
                double cc = Num(m, "cc", 0);
                if (cc > 0) { sm.ClearcoatEnabled = true; sm.Clearcoat = (float)cc; sm.ClearcoatRoughness = (float)Math.Clamp(Num(m, "ccRough", 0.03), 0.03, 1.0); }
                if (mode == 1) { sm.Transparency = BaseMaterial3D.TransparencyEnum.AlphaScissor; sm.AlphaScissorThreshold = 0.5f; }
                else if (mode == 2)
                {
                    // glass and lenses: tinted, blended, reflections on top
                    sm.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
                    sm.Roughness = Math.Min(sm.Roughness, 0.08f);
                    sm.MetallicSpecular = 0.6f;
                    cv.glass.Add(sm); cv.glassAlpha.Add((float)alpha);
                }
                mats.Add(sm);
                noShadow.Add(m.TryGetProperty("noShadow", out var ns) && ns.ValueKind == JsonValueKind.True);
            }
            // parts: each becomes a node with up to two mesh instances (shadow casters and the rest)
            foreach (var part in h.GetProperty("parts").EnumerateObject())
            {
                var meshCast = new ArrayMesh(); var meshNo = new ArrayMesh();
                foreach (var pr in part.Value.GetProperty("prims").EnumerateArray())
                {
                    int mat = (int)Num(pr, "mat", 0);
                    var posRef = Nums(pr.GetProperty("pos"));
                    var lo = Nums(pr.GetProperty("posLo")); var rng = Nums(pr.GetProperty("posRng"));
                    int nv = (int)posRef[1] / 6;
                    var pos = new Vector3[nv];
                    for (int i = 0; i < nv; i++)
                    {
                        int o = gbase + (int)posRef[0] + i * 6;
                        pos[i] = new Vector3(
                            (float)(lo[0] + U16(gbuf, o) / 65535.0 * rng[0]),
                            (float)(lo[1] + U16(gbuf, o + 2) / 65535.0 * rng[1]),
                            (float)(lo[2] + U16(gbuf, o + 4) / 65535.0 * rng[2]));
                    }
                    var norRef = Nums(pr.GetProperty("nor"));
                    var nrm = new Vector3[nv];
                    for (int i = 0; i < nv; i++)
                    {
                        int o = gbase + (int)norRef[0] + i * 3;
                        var n = new Vector3((sbyte)gbuf[o] / 127f, (sbyte)gbuf[o + 1] / 127f, (sbyte)gbuf[o + 2] / 127f);
                        nrm[i] = n.LengthSquared() > 1e-8f ? n.Normalized() : Vector3.Up;
                    }
                    Vector2[] uv = null;
                    if (pr.TryGetProperty("uv", out var uvp) && uvp.ValueKind == JsonValueKind.Array)
                    {
                        var uvRef = Nums(uvp);
                        var ulo = Nums(pr.GetProperty("uvLo")); var urng = Nums(pr.GetProperty("uvRng"));
                        uv = new Vector2[nv];
                        for (int i = 0; i < nv; i++)
                        {
                            int o = gbase + (int)uvRef[0] + i * 4;
                            uv[i] = new Vector2((float)(ulo[0] + U16(gbuf, o) / 65535.0 * urng[0]), (float)(ulo[1] + U16(gbuf, o + 2) / 65535.0 * urng[1]));
                        }
                    }
                    var idxRef = Nums(pr.GetProperty("idx"));
                    bool i32 = pr.TryGetProperty("idx32", out var b32) && b32.ValueKind == JsonValueKind.True;
                    int ni = i32 ? (int)idxRef[1] / 4 : (int)idxRef[1] / 2;
                    var idx = new int[ni];
                    for (int i = 0; i < ni; i++)
                    {
                        int o = gbase + (int)idxRef[0] + i * (i32 ? 4 : 2);
                        idx[i] = i32 ? (int)BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(gbuf, o, 4)) : U16(gbuf, o);
                    }
                    if (nv == 0 || ni < 3) continue;
                    MeshUtil.Reverse(idx);
                    bool ns = mat >= 0 && mat < noShadow.Count && noShadow[mat];
                    var target = ns ? meshNo : meshCast;
                    target.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, MeshUtil.Arrays(pos, nrm, uv, null, idx));
                    if (mat >= 0 && mat < mats.Count) target.SurfaceSetMaterial(target.GetSurfaceCount() - 1, mats[mat]);
                }
                var node = cv.Part(part.Name);
                if (meshCast.GetSurfaceCount() > 0) node.AddChild(new MeshInstance3D { Mesh = meshCast });
                if (meshNo.GetSurfaceCount() > 0) node.AddChild(new MeshInstance3D { Mesh = meshNo, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
                cv.Assign(part.Name, node);
            }
            // steering wheel pivot
            if (h.TryGetProperty("meta", out var meta) && meta.TryGetProperty("steer", out var st))
            {
                var pv = Nums(st.GetProperty("pivot")); var ax = Nums(st.GetProperty("axis"));
                cv.steerPivot = new Vector3((float)pv[0], (float)pv[1], (float)pv[2]);
                var axis = new Vector3((float)ax[0], (float)ax[1], (float)ax[2]);
                cv.steerAxis = axis.LengthSquared() > 1e-8f ? axis.Normalized() : Vector3.Back;
                cv.hasSteer = cv.steer != null;
            }
            return cv;
        }

        /* ---------------- imported GLB (Rust Bucket): nodes body, wheel_FL, ... ---------------- */
        public static CarView FromScene(string resPath)
        {
            var cv = new CarView();
            var ps = GD.Load<PackedScene>(resPath);
            if (ps == null) throw new Exception("car model missing: " + resPath);
            var inst = ps.Instantiate<Node3D>();
            foreach (var name in new[] { "body", "wheel_FL", "wheel_FR", "wheel_RL", "wheel_RR" })
            {
                var src = Find(inst, name);
                if (src == null) continue;
                var node = cv.Part(name);
                var mi = new MeshInstance3D { Mesh = src.Mesh, MaterialOverride = src.MaterialOverride };
                for (int i = 0; i < src.GetSurfaceOverrideMaterialCount(); i++)
                {
                    var om = src.GetSurfaceOverrideMaterial(i);
                    if (om != null) mi.SetSurfaceOverrideMaterial(i, om);
                }
                node.AddChild(mi);
                cv.Assign(name, node);
            }
            inst.QueueFree();
            if (cv.body == null) throw new Exception("car model has no body");
            return cv;
        }

        static MeshInstance3D Find(Node n, string name)
        {
            if (n is MeshInstance3D mi && (n.Name == name || ((string)n.Name).StartsWith(name))) return mi;
            foreach (var c in n.GetChildren())
            {
                var r = Find(c, name);
                if (r != null) return r;
            }
            return null;
        }

        void Assign(string name, Node3D node)
        {
            if (name == "body") body = node;
            else if (name == "steer") { steer = node; hasSteer = true; }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    if (name == WheelNames[i]) wheels[i] = node;
                    if (name == "hub_" + WheelNames[i].Substring(6)) hubs[i] = node;
                }
            }
        }

        static double Num(JsonElement e, string k, double def) =>
            e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : def;

        static double[] Nums(JsonElement e, int max = int.MaxValue)
        {
            var o = new List<double>();
            foreach (var x in e.EnumerateArray()) { if (o.Count >= max) break; o.Add(x.ValueKind == JsonValueKind.Number ? x.GetDouble() : 0); }
            return o.ToArray();
        }

        static int U16(byte[] b, int o) => b[o] | (b[o + 1] << 8);

        public static Transform3D CarMatrix(Car car)
        {
            var q = car.Q;
            var basis = new Basis(new Quaternion((float)q.X, (float)q.Y, (float)q.Z, (float)q.W).Normalized());
            var t = new Transform3D(basis, MeshUtil.V(car.Pos));
            return t * new Transform3D(Basis.Identity, -MeshUtil.V(car.ComModel));
        }

        // pose every part from the simulation; steerRatio turns the steering wheel with the front wheels
        public void Update(Car car, double steerRatio)
        {
            var carM = CarMatrix(car);
            if (body != null) body.Transform = carM * new Transform3D(scaleB, Vector3.Zero);
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i];
                var hub = MeshUtil.V(w.MountModel.X, w.MountModel.Y - w.DVis, w.MountModel.Z);
                var steerB = new Basis(Vector3.Up, (float)w.Steer);
                if (wheels[i] != null) wheels[i].Transform = carM * new Transform3D(steerB * new Basis(Vector3.Right, (float)-w.Spin) * scaleB, hub);
                // callipers steer with the wheel but don't spin
                if (hubs[i] != null) hubs[i].Transform = carM * new Transform3D(steerB * scaleB, hub);
            }
            if (hasSteer && steer != null)
            {
                double ang = (car.Wheels[0].Steer + car.Wheels[1].Steer) / 2 * steerRatio;
                steer.Transform = carM * new Transform3D(scaleB, Vector3.Zero) * new Transform3D(new Basis(new Quaternion(steerAxis, (float)ang)), steerPivot);
            }
        }

        // From the cabin the windows are close to clear: hardly any tint and only a faint reflection
        public void SetInside(bool on, float insideAlpha)
        {
            if (on == inside) return;
            inside = on;
            for (int i = 0; i < glass.Count; i++)
            {
                var c = glass[i].AlbedoColor;
                c.A = on ? Math.Min(glassAlpha[i], insideAlpha) : glassAlpha[i];
                glass[i].AlbedoColor = c;
                glass[i].MetallicSpecular = on ? 0.05f : 0.6f;
            }
        }

        public void SetVisible(bool v) => Root.Visible = v;

        /* ---------------- shadow stand-in ----------------
           The real models are hundreds of thousands of triangles; drawing them a second time into the shadow map
           was most of the cost of shadows. They no longer cast shadows; a stand-in of about 150 triangles does:
           the body as a box to the waist, a roof on four pillars (so sunlight still comes in through the windows),
           and an eight-sided disc per wheel that turns and steers with it. It is a little inside the real body, so
           the body is not shaded by it on the sides the sun reaches. Sizes come from the physics hull (car frame,
           unscaled), so mirrors and aerials don't stretch it. */
        public void AddShadowProxy(CarSpec spec)
        {
            NoShadows(Root);
            double k = spec.GeomScale > 0 ? spec.GeomScale : 1; // the hull is in scaled metres; the model is unscaled here
            float x0 = (float)(spec.HullMinX / k), x1 = (float)(spec.HullMaxX / k), y0 = (float)(spec.HullMinY / k), y1 = (float)(spec.HullMaxY / k);
            float z0 = (float)(spec.HullMinZ / k), z1 = (float)(spec.HullMaxZ / k);
            float w = (x1 - x0) * 0.47f, len = z1 - z0, zc = (z0 + z1) / 2, belt = y0 + (y1 - y0) * 0.48f;
            var st = new SurfaceTool();
            st.Begin(Mesh.PrimitiveType.Triangles);
            // lower body to the waist
            Box(st, new Vector3(-w, y0 + 0.04f, z0 + len * 0.015f), new Vector3(w, belt, z1 - len * 0.015f));
            // roof slab and pillars: cabin from about 30 % to 78 % of the length (front to back), roof a little shorter
            float cz0 = z0 + len * 0.30f, cz1 = z0 + len * 0.78f, rw = w * 0.86f, ry0 = y1 - 0.07f * (y1 - y0), ry1 = y1 - 0.02f * (y1 - y0);
            Box(st, new Vector3(-rw, ry0, cz0 + len * 0.06f), new Vector3(rw, ry1, cz1 - len * 0.03f));
            float pw = 0.07f;
            foreach (float px in new[] { -rw, rw - pw })
            {
                Slant(st, px, pw, cz0, belt, cz0 + len * 0.06f, ry0);       // A-pillar, raked back
                Slant(st, px, pw, cz1, belt, cz1 - len * 0.03f, ry0);       // C-pillar
            }
            st.GenerateNormals();
            var proxy = new MeshInstance3D { Name = "ShadowProxy", Mesh = st.Commit(), CastShadow = GeometryInstance3D.ShadowCastingSetting.ShadowsOnly };
            if (body != null) body.AddChild(proxy);
            // wheels: an eight-sided disc each
            for (int i = 0; i < 4; i++)
            {
                if (wheels[i] == null) continue;
                bool front = i < 2;
                float r = (float)((front && spec.WheelRadiusF > 0 ? spec.WheelRadiusF : spec.WheelRadius) / k) * 0.97f;
                float hw = (float)(spec.WheelWidth / k) * 0.5f;
                var ws = new SurfaceTool();
                ws.Begin(Mesh.PrimitiveType.Triangles);
                Disc(ws, r, hw, 8);
                ws.GenerateNormals();
                wheels[i].AddChild(new MeshInstance3D { Name = "ShadowProxy", Mesh = ws.Commit(), CastShadow = GeometryInstance3D.ShadowCastingSetting.ShadowsOnly });
            }
        }

        static void NoShadows(Node n)
        {
            if (n is GeometryInstance3D g) g.CastShadow = GeometryInstance3D.ShadowCastingSetting.Off;
            foreach (var c in n.GetChildren()) NoShadows(c);
        }

        static void Quad(SurfaceTool st, Vector3 a, Vector3 b, Vector3 c, Vector3 d)
        {
            st.AddVertex(a); st.AddVertex(b); st.AddVertex(c);
            st.AddVertex(a); st.AddVertex(c); st.AddVertex(d);
        }

        static void Box(SurfaceTool st, Vector3 lo, Vector3 hi) => Hexa(st,
            new Vector3(lo.X, lo.Y, lo.Z), new Vector3(hi.X, lo.Y, lo.Z), new Vector3(hi.X, lo.Y, hi.Z), new Vector3(lo.X, lo.Y, hi.Z),
            new Vector3(lo.X, hi.Y, lo.Z), new Vector3(hi.X, hi.Y, lo.Z), new Vector3(hi.X, hi.Y, hi.Z), new Vector3(lo.X, hi.Y, hi.Z));

        // a pillar: a thin slab from (z at the waist) up to (z at the roof)
        static void Slant(SurfaceTool st, float x, float w, float zBottom, float yBottom, float zTop, float yTop)
        {
            const float d = 0.06f;
            Hexa(st,
                new Vector3(x, yBottom, zBottom - d), new Vector3(x + w, yBottom, zBottom - d), new Vector3(x + w, yBottom, zBottom + d), new Vector3(x, yBottom, zBottom + d),
                new Vector3(x, yTop, zTop - d), new Vector3(x + w, yTop, zTop - d), new Vector3(x + w, yTop, zTop + d), new Vector3(x, yTop, zTop + d));
        }

        // eight corners: bottom face 0-3, top face 4-7 (same order); faces both ways, so winding doesn't matter
        static void Hexa(SurfaceTool st, Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4, Vector3 p5, Vector3 p6, Vector3 p7)
        {
            Vector3[] v = { p0, p1, p2, p3, p4, p5, p6, p7 };
            int[,] f = { { 0, 1, 2, 3 }, { 4, 7, 6, 5 }, { 0, 4, 5, 1 }, { 1, 5, 6, 2 }, { 2, 6, 7, 3 }, { 3, 7, 4, 0 } };
            for (int i = 0; i < 6; i++)
            {
                Quad(st, v[f[i, 0]], v[f[i, 1]], v[f[i, 2]], v[f[i, 3]]);
                Quad(st, v[f[i, 3]], v[f[i, 2]], v[f[i, 1]], v[f[i, 0]]);
            }
        }

        // a disc around the X axis (the axle), n sides
        static void Disc(SurfaceTool st, float r, float hw, int n)
        {
            for (int i = 0; i < n; i++)
            {
                float a0 = Mathf.Tau * i / n, a1 = Mathf.Tau * (i + 1) / n;
                var p0 = new Vector3(0, Mathf.Cos(a0) * r, Mathf.Sin(a0) * r);
                var p1 = new Vector3(0, Mathf.Cos(a1) * r, Mathf.Sin(a1) * r);
                var L = new Vector3(-hw, 0, 0); var R = new Vector3(hw, 0, 0);
                Quad(st, p0 + L, p1 + L, p1 + R, p0 + R);
                Quad(st, p0 + R, p1 + R, p1 + L, p0 + L);
                st.AddVertex(L); st.AddVertex(p0 + L); st.AddVertex(p1 + L);
                st.AddVertex(L); st.AddVertex(p1 + L); st.AddVertex(p0 + L);
                st.AddVertex(R); st.AddVertex(p0 + R); st.AddVertex(p1 + R);
                st.AddVertex(R); st.AddVertex(p1 + R); st.AddVertex(p0 + R);
            }
        }

        // nothing to draw (the model failed to load): the game still runs
        public static CarView Empty() => new CarView();
    }
}
