// The proving ground drawn in Godot: the grid plane (follows the camera in whole tiles), every terrain feature
// tessellated from the same height functions the wheels use, the circuit and pit-lane ribbons, the pit wall,
// garages and gantry, and the cones.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class ProvingGroundView
    {
        public readonly Node3D Root = new Node3D { Name = "ProvingGround" };
        public static readonly Vector2 BiasPit = new Vector2(0.004f, 0.0007f);
        public static readonly Vector2 BiasTrack = new Vector2(0.007f, 0.0012f);
        public static readonly Vector2 BiasKerb = new Vector2(0.012f, 0.0018f);

        public ProvingGroundView(GridTerrain terrain)
        {
            var surf = GD.Load<Shader>("res://shaders/surface.gdshader");
            var tris = new List<(int n, string what)>();
            foreach (var f in terrain.Features)
            {
                int kind = f.Kind == "ramp" ? (f.Tint == 1 ? 2 : 1) : f.Kind == "bumps" ? 2 : f.Kind == "moguls" ? 3
                    : f.Kind == "strip" ? (f.Surface == Surf.Dirt ? 5 : f.Surface == Surf.Gravel ? 6 : 7) : f.Kind == "rumble" ? 8 : 4;
                var mat = new ShaderMaterial { Shader = surf };
                mat.SetShaderParameter("kind", kind);
                mat.SetShaderParameter("bias", kind == 8 ? BiasKerb : Vector2.Zero);
                mat.SetShaderParameter("arc", f.Arc != null ? new Vector4((float)f.Arc.Cx, (float)f.Arc.Cz, (float)f.Arc.R, 1f) : Vector4.Zero);
                var mesh = FeatureMesh(f, mat);
                tris.Add((mesh.SurfaceGetArrayIndexLen(0) / 3, f.Kind + (f.HasSurface ? "/" + f.Surface : "")));
                // kerbs and gravel are flat enough not to need shadow casting
                bool cast = f.Kind == "ramp" || f.Kind == "bowl" || f.Kind == "moguls" || f.Kind == "bumps";
                Root.AddChild(new MeshInstance3D { Mesh = mesh, CastShadow = cast ? GeometryInstance3D.ShadowCastingSetting.On : GeometryInstance3D.ShadowCastingSetting.Off });
            }
            var c = terrain.Circuit;
            if (c != null && c.Path is ArcPath path)
            {
                var track = GD.Load<Shader>("res://shaders/track.gdshader");
                var marks = new float[24];
                for (int i = 0; i < Math.Min(24, c.Markers.Count); i++) marks[i] = (float)c.Markers[i];
                ShaderMaterial TrackMat(int mode, double half, Vector2 bias)
                {
                    var m = new ShaderMaterial { Shader = track };
                    m.SetShaderParameter("track_mode", mode);
                    m.SetShaderParameter("path_len", (float)path.Len);
                    m.SetShaderParameter("line_s", (float)c.SLine);
                    m.SetShaderParameter("half_w", (float)half);
                    m.SetShaderParameter("marks", marks);
                    m.SetShaderParameter("n_marks", Math.Min(24, c.Markers.Count));
                    m.SetShaderParameter("bias", bias);
                    m.SetShaderParameter("box_len", 12f);
                    return m;
                }
                var trackMat = TrackMat(0, c.Width / 2, BiasTrack);
                Root.AddChild(new MeshInstance3D { Mesh = PathMesh(path, c.Width / 2, true, 0.004, trackMat), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
                if (c.Pit != null)
                {
                    var pitMat = TrackMat(1, c.Pit.Width / 2, BiasPit);
                    var pp = c.Pit.Path.Parts[2]; // the straight between the entry and exit curves
                    var b = c.Pit.Boxes;
                    pitMat.SetShaderParameter("boxes", new Vector2((float)(pp.S0 + (b[0] - pp.X)), (float)(pp.S0 + (b[b.Count - 1] + 12 - pp.X))));
                    Root.AddChild(new MeshInstance3D { Mesh = PathMesh(c.Pit.Path, c.Pit.Width / 2, false, 0.003, pitMat), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
                }
                Root.AddChild(new MeshInstance3D { Mesh = BoxMesh(CircuitBoxes(c)) });
            }
            // triangle budget, for the log
            int total = 0; foreach (var t in tris) total += t.n;
            tris.Sort((a, b) => b.n.CompareTo(a.n));
            var top = new List<string>();
            for (int i = 0; i < Math.Min(8, tris.Count); i++) top.Add(tris[i].what + " " + tris[i].n / 1000 + "k");
            GD.Print($"[boot] proving ground features: {tris.Count}, {total / 1000}k triangles; largest: {string.Join(", ", top)}");
        }

        static double HV(Feature f, double x, double z) => f.HVis(x, z);

        static Vector3 FeatureNormal(Feature f, double x, double z)
        {
            const double e = 0.03;
            double nx = -(HV(f, x + e, z) - HV(f, x - e, z)) / (2 * e), nz = -(HV(f, x, z + e) - HV(f, x, z - e)) / (2 * e);
            double l = Math.Sqrt(nx * nx + 1 + nz * nz);
            return new Vector3((float)(nx / l), (float)(1 / l), (float)(nz / l));
        }

        static double[] Sorted(SortedSet<double> set, double lo, double hi)
        {
            var o = new List<double>();
            foreach (var x in set) if (x >= lo && x <= hi) o.Add(x);
            return o.ToArray();
        }

        static double R4(double x) => Math.Round(x, 4, MidpointRounding.AwayFromZero);
        static double R3(double x) => Math.Round(x, 3, MidpointRounding.AwayFromZero);

        // Samples off the feature tuck under the grid; kerbs (drawn on their own depth layer) keep their feathered
        // edge so the outline stays clean instead of following the ridge troughs.
        public static ArrayMesh FeatureMesh(Feature f, Material mat)
        {
            var m = f.Mesh;
            var pos = new List<Vector3>(); var nor = new List<Vector3>();
            int nu, nv;
            double floor = f.HasSurface && f.Surface == Surf.Rumble ? 1e-7 : 0.0005;
            void Push(double x, double z)
            {
                double h = HV(f, x, z);
                if (h > floor) { pos.Add(MeshUtil.V(x, h, z)); nor.Add(FeatureNormal(f, x, z)); }
                else { pos.Add(MeshUtil.V(x, -0.03, z)); nor.Add(Vector3.Up); }
            }
            if (!m.Polar)
            {
                var fr = m.Frame; double L = fr.L, W = fr.W;
                var us = new SortedSet<double>(); var vs = new SortedSet<double>();
                double du = double.IsNaN(m.Du) || m.Du == 0 ? 0.5 : m.Du, dv = double.IsNaN(m.Dv) || m.Dv == 0 ? 0.5 : m.Dv;
                double ve = double.IsNaN(m.VEdge) ? 0.3 : m.VEdge;
                for (double u = -0.2; u <= L + 0.2 + 1e-6; u += du) us.Add(R4(u));
                foreach (double b in m.UBreaks) { us.Add(b - 0.003); us.Add(b); us.Add(b + 0.003); }
                us.Add(L + 0.2);
                for (double v = -W / 2 - 0.2; v <= W / 2 + 0.2 + 1e-6; v += dv) vs.Add(R4(v));
                foreach (double s in new double[] { -1, 1 })
                {
                    for (int k = 0; k <= 6; k++) vs.Add(R4(s * (W / 2 - (Math.Min(ve, W / 2) * k) / 6)));
                    vs.Add(s * (W / 2 + 0.01));
                }
                var uA = Sorted(us, -0.2, L + 0.2); var vA = Sorted(vs, -W / 2 - 0.2, W / 2 + 0.2);
                nu = uA.Length; nv = vA.Length;
                foreach (double u in uA) foreach (double v in vA) Push(fr.Ox + fr.Fx * u + fr.Rx * v, fr.Oz + fr.Fz * u + fr.Rz * v);
            }
            else
            {
                // full ring (bowl), or a sector amid +- half (curved kerbs, gravel traps)
                double pad = m.HasHalf ? 0.15 : 0.3, dr = double.IsNaN(m.Dr) || m.Dr == 0 ? 0.5 : m.Dr;
                var rs = new SortedSet<double>();
                for (double r = m.R0 - pad; r <= m.R + pad; r += dr) rs.Add(R3(r));
                foreach (double b in m.RBreaks) { rs.Add(b - 0.003); rs.Add(b); rs.Add(b + 0.003); }
                rs.Add(m.R + pad);
                var rA = Sorted(rs, m.R0 - pad, m.R + pad);
                double a0 = m.HasHalf ? m.Amid - m.Half - pad / m.R : 0;
                double span = m.HasHalf ? 2 * m.Half + (2 * pad) / m.R : Math.PI * 2;
                double ds = double.IsNaN(m.Ds) || m.Ds == 0 ? 0.5 : m.Ds;
                int nA = m.HasHalf ? Math.Max(8, (int)Math.Ceiling((span * (m.R + pad)) / ds)) : 400;
                nu = nA + 1; nv = rA.Length;
                for (int i = 0; i <= nA; i++)
                {
                    double a = a0 + ((double)i / nA) * span;
                    foreach (double r in rA) Push(m.Cx + Math.Cos(a) * r, m.Cz + Math.Sin(a) * r);
                }
            }
            var P = pos.ToArray(); var N = nor.ToArray();
            var idx = MeshUtil.GridIndices(nu, nv);
            MeshUtil.FixWinding(P, N, idx);
            return MeshUtil.Build(P, N, null, null, idx, mat);
        }

        // big flat grid around the camera
        public static ArrayMesh GroundMesh(int tiles, float size, Material mat)
        {
            int n = tiles + 1; float half = tiles * size / 2;
            var pos = new Vector3[n * n]; var nor = new Vector3[n * n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++) { pos[i * n + j] = new Vector3(-half + i * size, 0, -half + j * size); nor[i * n + j] = Vector3.Up; }
            var idx = MeshUtil.GridIndices(n, n);
            MeshUtil.FixWinding(pos, nor, idx);
            return MeshUtil.Build(pos, nor, null, null, idx, mat);
        }

        // asphalt ribbon along a path, with UV = (s, d) for the markings shader
        public static ArrayMesh PathMesh(ArcPath path, double half, bool closed, double y, Material mat)
        {
            var ss = new List<double>();
            foreach (var p in path.Parts)
            {
                double step = p.Type == 'S' ? 4 : Math.Max(0.4, Math.Min(2, p.R / 25));
                int n = Math.Max(1, (int)Math.Ceiling(p.Len / step));
                for (int i = 0; i < n; i++) ss.Add(p.S0 + (p.Len * i) / n);
            }
            ss.Add(path.Len);
            var pos = new Vector3[ss.Count * 2]; var nor = new Vector3[ss.Count * 2]; var uv = new Vector2[ss.Count * 2];
            for (int k = 0; k < ss.Count; k++)
            {
                double sv = ss[k];
                var p = path.At(Math.Min(sv, path.Len - 1e-6));
                var q = sv >= path.Len && closed ? path.At(0) : p;
                double rx = -Math.Sin(q.H), rz = Math.Cos(q.H);
                for (int e = 0; e < 2; e++)
                {
                    double d = e == 0 ? -half : half;
                    pos[k * 2 + e] = MeshUtil.V(q.X + rx * d, y, q.Z + rz * d);
                    nor[k * 2 + e] = Vector3.Up;
                    uv[k * 2 + e] = new Vector2((float)sv, (float)d);
                }
            }
            var idx = new int[(ss.Count - 1) * 6];
            for (int i = 0; i < ss.Count - 1; i++)
            {
                int a = i * 2;
                idx[i * 6] = a; idx[i * 6 + 1] = a + 1; idx[i * 6 + 2] = a + 2; idx[i * 6 + 3] = a + 1; idx[i * 6 + 4] = a + 3; idx[i * 6 + 5] = a + 2;
            }
            MeshUtil.FixWinding(pos, nor, idx);
            return MeshUtil.Build(pos, nor, uv, null, idx, mat);
        }

        public struct BoxDef
        {
            public double Cx, Cz, Y0, Hx, Hy, Hz, Yaw;
            public Color Col, Top;
            public bool HasTop;
        }

        static Color Lin(double r, double g, double b) => new Color((float)r, (float)g, (float)b);

        public static List<BoxDef> CircuitBoxes(Circuit c)
        {
            var o = new List<BoxDef>();
            foreach (var sb in c.Solids)
            {
                Color col = sb.Col == "wall" ? Lin(0.62, 0.62, 0.6) : sb.Col == "garage" ? Lin(0.5, 0.52, 0.55) : Lin(0.16, 0.17, 0.19);
                bool hasTop = sb.Col == "garage" || sb.Col == "wall";
                Color top = sb.Col == "garage" ? Lin(0.24, 0.25, 0.27) : Lin(0.75, 0.2, 0.15);
                o.Add(new BoxDef { Cx = sb.Cx, Cz = sb.Cz, Hx = sb.Hx, Hz = sb.Hz, Hy = sb.H, Yaw = sb.Yaw, Col = col, Top = top, HasTop = hasTop });
            }
            if (c.Pit != null)
            {
                // garage doors facing the pit lane, one per box, with a number-board strip
                double front = c.Pit.Z + c.Pit.Width / 2 + 0.5;
                foreach (double x in c.Pit.Boxes)
                {
                    o.Add(new BoxDef { Cx = x + 6, Cz = front - 0.03, Hx = 4.6, Hz = 0.05, Hy = 4.0, Col = Lin(0.05, 0.055, 0.06) });
                    o.Add(new BoxDef { Cx = x + 6, Cz = front - 0.04, Hx = 4.6, Hz = 0.05, Y0 = 4.3, Hy = 0.6, Col = Lin(0.85, 0.55, 0.08) });
                }
            }
            if (c.HasGantry)
            {
                // start gantry: beam over the line with five lights facing the grid
                double w = c.Width / 2 + 2.2;
                o.Add(new BoxDef { Cx = c.GantryX, Cz = c.GantryZ, Hx = 0.45, Hz = w + 0.35, Y0 = 6.2, Hy = 1.0, Col = Lin(0.16, 0.17, 0.19) });
                for (int i = 0; i < 5; i++) o.Add(new BoxDef { Cx = c.GantryX - 0.5, Cz = c.GantryZ - 2.4 + i * 1.2, Hx = 0.06, Hz = 0.38, Y0 = 6.35, Hy = 0.7, Col = Lin(0.25, 0.02, 0.02) });
            }
            return o;
        }

        public static ArrayMesh BoxMesh(List<BoxDef> boxes)
        {
            var pos = new List<Vector3>(); var nor = new List<Vector3>(); var col = new List<Color>(); var idx = new List<int>();
            foreach (var b in boxes)
            {
                double c = Math.Cos(b.Yaw), sn = Math.Sin(b.Yaw);
                Vector3 P(double u, double y, double v) => MeshUtil.V(b.Cx + c * u - sn * v, y, b.Cz + sn * u + c * v);
                Vector3 N(double nu, double ny, double nv) => MeshUtil.V(c * nu - sn * nv, ny, sn * nu + c * nv);
                double y0 = b.Y0, y1 = y0 + b.Hy, X = b.Hx, Z = b.Hz;
                void Quad(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, Vector3 n, Color cl)
                {
                    int o = pos.Count;
                    pos.Add(p0); pos.Add(p1); pos.Add(p2); pos.Add(p3);
                    for (int k = 0; k < 4; k++) { nor.Add(n); col.Add(cl); }
                    idx.Add(o); idx.Add(o + 1); idx.Add(o + 2); idx.Add(o); idx.Add(o + 2); idx.Add(o + 3);
                }
                Color side = b.Col, top = b.HasTop ? b.Top : b.Col;
                Quad(P(-X, y1, -Z), P(-X, y1, Z), P(X, y1, Z), P(X, y1, -Z), N(0, 1, 0), top);
                Quad(P(-X, y0, Z), P(X, y0, Z), P(X, y1, Z), P(-X, y1, Z), N(0, 0, 1), side);
                Quad(P(X, y0, -Z), P(-X, y0, -Z), P(-X, y1, -Z), P(X, y1, -Z), N(0, 0, -1), side);
                Quad(P(X, y0, Z), P(X, y0, -Z), P(X, y1, -Z), P(X, y1, Z), N(1, 0, 0), side);
                Quad(P(-X, y0, -Z), P(-X, y0, Z), P(-X, y1, Z), P(-X, y1, -Z), N(-1, 0, 0), side);
                if (y0 > 0.01) Quad(P(-X, y0, Z), P(-X, y0, -Z), P(X, y0, -Z), P(X, y0, Z), N(0, -1, 0), side);
            }
            var Pa = pos.ToArray(); var Na = nor.ToArray(); var Ia = idx.ToArray();
            MeshUtil.FixWinding(Pa, Na, Ia);
            var mat = new StandardMaterial3D { VertexColorUseAsAlbedo = true, Roughness = 0.8f, CullMode = BaseMaterial3D.CullModeEnum.Disabled };
            return MeshUtil.Build(Pa, Na, null, col.ToArray(), Ia, mat);
        }

        // traffic cone with weighted base; origin at base centre
        public static ArrayMesh ConeMesh()
        {
            var pos = new List<Vector3>(); var nor = new List<Vector3>(); var col = new List<Color>(); var idx = new List<int>();
            Color orange = Lin(0.85, 0.22, 0.02), white = Lin(0.85, 0.85, 0.82), black = Lin(0.03, 0.03, 0.03);
            const int seg = 20; const double h = 0.7, rb = 0.15, rt = 0.025, y0 = 0.035;
            double[] ys = { y0, 0.32, 0.32, 0.46, 0.46, h };
            double slope = (rb - rt) / (h - y0);
            for (int k = 0; k < ys.Length; k++)
            {
                double y = ys[k], r = rb - (y - y0) * slope;
                Color c = k < 2 ? orange : k < 4 ? white : orange;
                for (int i = 0; i <= seg; i++)
                {
                    double a = (double)i / seg * Math.PI * 2;
                    pos.Add(MeshUtil.V(Math.Cos(a) * r, y, Math.Sin(a) * r));
                    double nl = Math.Sqrt(1 + slope * slope);
                    nor.Add(MeshUtil.V(Math.Cos(a) / nl, slope / nl, Math.Sin(a) / nl));
                    col.Add(c);
                }
            }
            foreach (int k in new[] { 0, 2, 4 })
                for (int i = 0; i < seg; i++)
                {
                    int a = k * (seg + 1) + i, b = a + 1, c = a + seg + 1, d = c + 1;
                    idx.Add(a); idx.Add(c); idx.Add(b); idx.Add(b); idx.Add(c); idx.Add(d);
                }
            // base slab
            const double s = 0.2;
            void Quad(Vector3[] pts, Vector3 n)
            {
                int o = pos.Count;
                foreach (var p in pts) { pos.Add(p); nor.Add(n); col.Add(black); }
                idx.Add(o); idx.Add(o + 1); idx.Add(o + 2); idx.Add(o); idx.Add(o + 2); idx.Add(o + 3);
            }
            Vector3 V(double x, double y, double z) => MeshUtil.V(x, y, z);
            Quad(new[] { V(-s, y0, -s), V(-s, y0, s), V(s, y0, s), V(s, y0, -s) }, Vector3.Up);
            Quad(new[] { V(-s, 0, s), V(s, 0, s), V(s, y0, s), V(-s, y0, s) }, Vector3.Back);
            Quad(new[] { V(s, 0, -s), V(-s, 0, -s), V(-s, y0, -s), V(s, y0, -s) }, Vector3.Forward);
            Quad(new[] { V(s, 0, s), V(s, 0, -s), V(s, y0, -s), V(s, y0, s) }, Vector3.Right);
            Quad(new[] { V(-s, 0, -s), V(-s, 0, s), V(-s, y0, s), V(-s, y0, -s) }, Vector3.Left);
            var Pa = pos.ToArray(); var Na = nor.ToArray(); var Ia = idx.ToArray();
            MeshUtil.FixWinding(Pa, Na, Ia);
            var mat = new StandardMaterial3D { VertexColorUseAsAlbedo = true, Roughness = 0.55f };
            return MeshUtil.Build(Pa, Na, null, col.ToArray(), Ia, mat);
        }
    }

    // the cones as one multimesh, posed from the simulation each frame
    public sealed class ConesView
    {
        public readonly MultiMeshInstance3D Node;
        readonly MultiMesh mm;

        public ConesView(int count)
        {
            mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, Mesh = ProvingGroundView.ConeMesh() };
            mm.InstanceCount = Math.Max(1, count);
            mm.VisibleInstanceCount = count;
            mm.CustomAabb = new Aabb(new Vector3(-6000, -400, -6000), new Vector3(12000, 1200, 12000));
            Node = new MultiMeshInstance3D { Name = "Cones", Multimesh = mm };
        }

        // a map's own set of cones (or none)
        public void Use(int count)
        {
            if (count > mm.InstanceCount) mm.InstanceCount = count;
            mm.VisibleInstanceCount = count;
        }

        public void Update(Cones cones)
        {
            int n = Math.Min(cones.List.Count, mm.InstanceCount);
            for (int i = 0; i < n; i++)
            {
                Cones.Pose(cones.List[i], out V3 p, out Q4 q);
                var b = new Basis(new Quaternion((float)q.X, (float)q.Y, (float)q.Z, (float)q.W).Normalized());
                mm.SetInstanceTransform(i, new Transform3D(b, MeshUtil.V(p)));
            }
        }
    }
}
