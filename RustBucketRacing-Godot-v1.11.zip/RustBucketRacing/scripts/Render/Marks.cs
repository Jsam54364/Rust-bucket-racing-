// Skid marks (a ring buffer of quads, uploaded in chunks as they change) and tyre smoke / dust billboards.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    // One MultiMesh: each segment is an instance of a unit quad (x -1..1 across, z 0..1 along) whose basis maps it
    // onto the segment. Adding a mark writes one instance; nothing is rebuilt and nothing is allocated per frame.
    public sealed class SkidMarks
    {
        const int MAX = 8000;
        public readonly Node3D Root = new Node3D { Name = "SkidMarks" };
        readonly MultiMesh mm;
        int head, count;

        public SkidMarks()
        {
            var mat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/skid.gdshader") };
            var qp = new[] { new Vector3(-1, 0, 0), new Vector3(1, 0, 0), new Vector3(-1, 0, 1), new Vector3(1, 0, 1) };
            var qn = new[] { Vector3.Up, Vector3.Up, Vector3.Up, Vector3.Up };
            var qc = new[] { Colors.White, Colors.White, Colors.White, Colors.White };
            var mesh = MeshUtil.Build(qp, qn, null, qc, new[] { 0, 1, 2, 1, 3, 2 }, mat);
            mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, UseColors = true, Mesh = mesh };
            mm.InstanceCount = MAX;
            mm.VisibleInstanceCount = 0;
            mm.CustomAabb = new Aabb(new Vector3(-50000, -5000, -50000), new Vector3(100000, 10000, 100000));
            Root.AddChild(new MultiMeshInstance3D { Name = "Marks", Multimesh = mm, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off });
        }

        // a, b: segment endpoints on the ground; n: ground normal; w: half width
        public void Add(V3 a, V3 b, V3 n, double w, double alpha, Color c)
        {
            V3 d = b - a;
            V3 s = V3.Cross(d, n);
            double l = s.Length(); if (!(l > 0)) return;
            s = s * (w / l);
            const double lift = 0.012;
            var basis = new Basis(MeshUtil.V(s), MeshUtil.V(n), MeshUtil.V(d));
            mm.SetInstanceTransform(head, new Transform3D(basis, MeshUtil.V(a.X, a.Y + lift, a.Z)));
            mm.SetInstanceColor(head, new Color(c.R, c.G, c.B, (float)alpha));
            head = (head + 1) % MAX;
            if (count < MAX) { count++; mm.VisibleInstanceCount = count; }
        }

        public void Clear() { head = 0; count = 0; mm.VisibleInstanceCount = 0; }

        // kept for the frame loop; marks go straight into the MultiMesh now
        public void Flush() { }

        // draw one invisible mark for a few frames so the shader is compiled before the first real skid
        public void Warm(bool on, Vector3 at)
        {
            if (count > 0) return;
            if (on)
            {
                mm.SetInstanceTransform(0, new Transform3D(new Basis(Vector3.Right * 0.01f, Vector3.Up, Vector3.Back * 0.01f), at));
                mm.SetInstanceColor(0, new Color(0, 0, 0, 0));
                mm.VisibleInstanceCount = 1;
            }
            else mm.VisibleInstanceCount = 0;
        }
    }

    public sealed class SmokeView
    {
        public const int MAX = 700;
        public readonly MultiMeshInstance3D Node;
        readonly MultiMesh mm;

        public SmokeView()
        {
            var quadPos = new[] { new Vector3(-0.5f, -0.5f, 0), new Vector3(0.5f, -0.5f, 0), new Vector3(-0.5f, 0.5f, 0), new Vector3(0.5f, 0.5f, 0) };
            var quadUv = new[] { new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(1, 1) };
            var quadN = new[] { Vector3.Back, Vector3.Back, Vector3.Back, Vector3.Back };
            var quadC = new[] { Colors.White, Colors.White, Colors.White, Colors.White };
            var mat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/smoke.gdshader") };
            var mesh = MeshUtil.Build(quadPos, quadN, quadUv, quadC, new[] { 0, 1, 2, 1, 3, 2 }, mat);
            mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, UseColors = true, Mesh = mesh };
            mm.InstanceCount = MAX;
            mm.VisibleInstanceCount = 0;
            mm.CustomAabb = new Aabb(new Vector3(-50000, -5000, -50000), new Vector3(100000, 10000, 100000));
            Node = new MultiMeshInstance3D { Name = "Smoke", Multimesh = mm, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
        }

        readonly List<(double d, int i)> order = new List<(double, int)>();

        // far to near so blending reads correctly; quads face the camera
        public void Update(List<Puff> puffs, Vector3 camPos, Vector3 camTarget)
        {
            var fwd = camTarget - camPos;
            var right = new Vector3(-fwd.Z, 0, fwd.X);
            right = right.LengthSquared() > 1e-8f ? right.Normalized() : Vector3.Right;
            var f = fwd.LengthSquared() > 1e-8f ? fwd.Normalized() : Vector3.Forward;
            var up = right.Cross(f);
            int n = Math.Min(puffs.Count, MAX);
            order.Clear();
            for (int i = 0; i < n; i++)
            {
                var p = puffs[i].P;
                double dx = p.X - camPos.X, dy = p.Y - camPos.Y, dz = p.Z - camPos.Z;
                order.Add((dx * dx + dy * dy + dz * dz, i));
            }
            order.Sort((a, b) => b.d.CompareTo(a.d));
            for (int k = 0; k < n; k++)
            {
                var s = puffs[order[k].i];
                float size = (float)s.Size;
                var basis = new Basis(right * size, up * size, -f);
                mm.SetInstanceTransform(k, new Transform3D(basis, MeshUtil.V(s.P)));
                mm.SetInstanceColor(k, new Color(s.Col.R, s.Col.G, s.Col.B, (float)s.A));
            }
            mm.VisibleInstanceCount = n;
        }

        // with no smoke on screen, draw one invisible puff so the shader is compiled before the first real one
        public void Warm(Vector3 at)
        {
            if (mm.VisibleInstanceCount > 0) return;
            mm.SetInstanceTransform(0, new Transform3D(new Basis(Vector3.Right * 0.01f, Vector3.Up * 0.01f, Vector3.Back * 0.01f), at));
            mm.SetInstanceColor(0, new Color(1, 1, 1, 0));
            mm.VisibleInstanceCount = 1;
        }
    }

    public sealed class Puff
    {
        public V3 P, V;
        public double Age, Life, S0, S1, A0, Size, A;
        public bool Dust;
        public Color Col = new Color(0.78f, 0.78f, 0.8f);
    }
}
