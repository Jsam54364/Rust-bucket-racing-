// The cars: physics spec, where the model and engine recordings live, camera framing, and the maps.
using System;
using System.Collections.Generic;
using System.Text.Json;
using RustBucket.Audio;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class CarDef
    {
        public string Id, Title, Sub, Toast;
        public CarSpec Spec;
        public string Model;        // res:// path
        public bool Pack;           // car pack (true) or imported scene (false)
        public string Engine;       // engine recordings (json)
        public double Chase = 6.5;
        public V3 Bumper;
        public bool HasCockpit;
        public V3 Cockpit;
        public double SteerRatio = 8;
        public float GlassInside = 0.04f;
        public double SpeedoKmh = 200, SpeedoMph = 120; // full scale of the speedometer
        public float ModelScale = 1;  // the model drawn at this size (matches CarSpec.GeomScale)
        // the CTS-V borrows the Monte Carlo's V8, heard through a race exhaust
        public System.Action<Profile> EngineProfile;
    }

    // A map: the proving ground is built in; every other map is a download from the map library, described by the
    // <id>.json that comes with its pack (the same fields, in camelCase).
    public sealed class MapDef
    {
        public string Id, Name, Short, Sub, Toast, Pack;
        public string Blurb = "", Guide = "", Credit = "";
        public float Far = 6000;     // camera far plane (m)
        public float Fog = 0;        // fog density, 0 = the usual for map packs
        public bool Occlude;         // build occluders from the ground (mountains hide most of the map)
        public bool Stage;           // a point-to-point stage, raced up or down
        public bool Installable;     // a download (user://maps), not built in
        public string[] Starts = Array.Empty<string>();   // names of the pack's start points (Free Roam offers them)
        // what the stage lines are called (the toasts at a stage start)
        public string TopLine = "the line at the top", BottomLine = "the line at the bottom";
        // library: the pack's file name, size and sha256 (which version), the oldest game version that loads it
        public string File = "", Sha = "", MinGame = "";
        public long Bytes;
        public string Json = "";     // the description as it came, saved next to the installed pack

        static string S(JsonElement e, string k, string def) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : def;
        static double N(JsonElement e, string k, double def) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : def;
        static bool B(JsonElement e, string k, bool def) => e.TryGetProperty(k, out var v) && (v.ValueKind == JsonValueKind.True || v.ValueKind == JsonValueKind.False) ? v.GetBoolean() : def;

        public static MapDef FromJson(JsonElement e)
        {
            var d = new MapDef { Id = S(e, "id", "") };
            if (d.Id.Length == 0 || d.Id == "grid" || d.Id.IndexOfAny(new[] { '/', '\\', '.', ' ' }) >= 0) throw new Exception("a map needs a plain id");
            d.Name = S(e, "name", d.Id); d.Short = S(e, "short", d.Name); d.Sub = S(e, "sub", ""); d.Toast = S(e, "toast", d.Name);
            d.Blurb = S(e, "blurb", ""); d.Guide = S(e, "guide", ""); d.Credit = S(e, "credit", "");
            d.Far = (float)N(e, "far", 6000); d.Fog = (float)N(e, "fog", 0);
            d.Occlude = B(e, "occlude", false); d.Stage = B(e, "stage", false);
            d.TopLine = S(e, "topLine", d.TopLine); d.BottomLine = S(e, "bottomLine", d.BottomLine);
            d.File = S(e, "file", d.Id + ".bin"); d.Sha = S(e, "sha", ""); d.MinGame = S(e, "minGame", "");
            d.Bytes = (long)N(e, "bytes", 0);
            if (e.TryGetProperty("starts", out var st) && st.ValueKind == JsonValueKind.Array)
            {
                var l = new List<string>();
                foreach (var x in st.EnumerateArray()) if (x.ValueKind == JsonValueKind.String) l.Add(x.GetString());
                d.Starts = l.ToArray();
            }
            d.Installable = true;
            d.Json = e.GetRawText();
            return d;
        }
    }

    public static class Defs
    {
        public static readonly string[] CarOrder = { "rust", "monte", "cts" };
        // the maps on offer, in order: the proving ground, then the installed maps by name (MapLibrary keeps it up to date)
        public static string[] MapOrder = { "grid" };

        public static void RefreshMapOrder()
        {
            var ids = new List<string> { "grid" };
            var rest = new List<MapDef>();
            foreach (var m in Maps.Values) if (m.Id != "grid") rest.Add(m);
            rest.Sort((x, y) => string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase));
            foreach (var m in rest) ids.Add(m.Id);
            MapOrder = ids.ToArray();
        }

        public static readonly Dictionary<string, CarDef> Cars = new Dictionary<string, CarDef>
        {
            ["rust"] = new CarDef
            {
                Id = "rust", Title = "Rust Bucket", Sub = "92 hp four · 1.25 t", Toast = "Rust Bucket · 92 hp four",
                Spec = Sim.Cars.Rust, Model = "res://models/rust.glb", Pack = false, Engine = "res://data/engine_audio.json",
                Chase = 6.0, Bumper = new V3(0, 0.74 * Sim.Cars.RustScale, -2.3 * Sim.Cars.RustScale), ModelScale = (float)Sim.Cars.RustScale,
            },
            ["monte"] = new CarDef
            {
                Id = "monte", Title = "Monte Carlo SS", Sub = "320 hp V8 · 1.55 t", Toast = "Monte Carlo SS · 320 hp V8",
                Spec = Sim.Cars.Monte, Model = "res://data/monte.bin", Pack = true, Engine = "res://data/engine_v8.json",
                Chase = 6.9, Bumper = new V3(0, 0.8, -2.52), HasCockpit = true, Cockpit = new V3(-0.405, 1.185, 0.27), SteerRatio = 12,
                SpeedoKmh = 240, SpeedoMph = 160,
            },
            ["cts"] = new CarDef
            {
                Id = "cts", Title = "CTS-V Race", Sub = "500 hp V8 · slicks", Toast = "Cadillac CTS-V race car · 500 hp V8 · slicks",
                Spec = Sim.Cars.Cts, Model = "res://data/cts.bin", Pack = true, Engine = "res://data/engine_v8.json",
                Chase = 7.0, Bumper = new V3(0, 0.62, -2.47), HasCockpit = true, Cockpit = new V3(-0.373, 0.97, 0.32), SteerRatio = 8.5,
                SpeedoKmh = 300, SpeedoMph = 180,
                // muffled top end, a little more weight low down, spread over its 1100-7800 rpm range
                EngineProfile = (p) =>
                {
                    p.Rpm0 = 1100; p.Rpm1 = 7800; p.IdleFade0 = 1350; p.IdleFade1 = 2100; p.Level = 1.85;
                    p.PopRpm = 4200; p.PopPitch = 0.9; p.Lowpass = 2100; p.LowpassQ = 0.55; p.ShelfF = 170; p.ShelfG = 3;
                },
            },
        };

        public static readonly Dictionary<string, MapDef> Maps = new Dictionary<string, MapDef>
        {
            ["grid"] = new MapDef
            {
                Id = "grid", Name = "Proving ground", Short = "Proving", Sub = "Test areas · 3.2 km circuit", Toast = "Proving ground",
                Blurb = "Runway, slalom, jumps, a skid pad, test strips of dirt and gravel, and a 3.2 km circuit with 16 corners.",
                Guide = "A 1.5 km runway with rumble strips, a tabletop and warning strips; speed bumps, an articulation strip, moguls and a gap jump that needs 100 km/h; a cone slalom, kickers, a skid-pad ring and a banked bowl; test strips of dirt, gravel and grass; and a 3.2 km race track around it all, with kerbs, gravel traps and a 10-car grid. The lap timer starts at the line.",
            },
        };
    }
}
