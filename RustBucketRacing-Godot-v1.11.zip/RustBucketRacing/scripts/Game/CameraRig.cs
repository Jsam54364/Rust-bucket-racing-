// Cameras: chase, orbit, bumper, trackside and interior (cars that have a cockpit). Drag to look (orbit: fly
// round the car); pinch or the wheel zooms the orbit and chase cameras.
using System;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class CameraRig
    {
        public static readonly string[] Names = { "Chase cam", "Orbit cam", "Bumper cam", "Trackside cam", "Interior cam" };
        static readonly int[] CycleOrder = { 0, 1, 2, 4, 3 }; // chase, orbit, bumper, interior (cars that have one), trackside

        public int Mode;
        public V3 Pos = new V3(0, 3, 12), Target = new V3(0, 0.6, 0), Up = V3.UnitY;
        public double Fov = 1.05;
        public double Aspect = 1.6;
        public bool Dragging;
        public double ChaseDist = 6.2;
        public V3 Bumper = new V3(0, 0.74, -2.3);
        public bool HasCockpit;
        public V3 Cockpit;
        double yaw, ySm = 0.5;
        double lookYaw, lookPitch;
        double orbitYaw = 0.7, orbitPitch = 0.28, orbitDist = 7.5;
        bool hasTrack; V3 track;
        V3 head; double glance;

        // f > 1 pulls the camera back, < 1 brings it in (orbit: distance from the car; chase: follow distance)
        public void Zoom(double f)
        {
            if (Mode == 1) orbitDist = M.Clamp(orbitDist * f, 2.5, 60);
            else if (Mode == 0) ChaseDist = M.Clamp(ChaseDist * f, 4, 16);
        }

        // drag by (dx, dy) radians-ish
        public void Drag(double dx, double dy)
        {
            if (Mode == 1) { orbitYaw -= dx; orbitPitch = M.Clamp(orbitPitch + dy, -0.05, 1.35); }
            else { lookYaw -= dx; lookPitch = M.Clamp(lookPitch + dy, -0.35, 1.1); }
        }

        public string Cycle()
        {
            int i = Array.IndexOf(CycleOrder, Mode);
            Mode = CycleOrder[(i + 1) % CycleOrder.Length];
            if (Mode == 4 && !HasCockpit) Mode = CycleOrder[(Array.IndexOf(CycleOrder, 4) + 1) % CycleOrder.Length];
            hasTrack = false; lookYaw = lookPitch = 0;
            return Names[Mode];
        }

        public void ClearTrack() => hasTrack = false;

        public void Snap(Car car) { yaw = car.Yaw; ySm = car.Pos.Y; }

        public void Update(double dt, Car car, TerrainBase terrain)
        {
            V3 p = car.Pos;
            double a = 1 - Math.Exp(-dt * 4.5);
            double dy = M.WrapA(car.Yaw - yaw);
            double vFwd = car.Tel.Speed;
            if (!(vFwd < -1 && Mode == 0)) yaw += dy * a;
            ySm = M.Lerp(ySm, p.Y, 1 - Math.Exp(-dt * 7));
            if (!Dragging) { lookYaw *= Math.Exp(-dt * 1.4); lookPitch *= Math.Exp(-dt * 1.4); }
            double speed = Math.Abs(vFwd);
            Up = V3.UnitY;
            if (Mode == 0)
            {
                double yw = yaw + lookYaw, pitch = 0.2 + lookPitch, d = ChaseDist * (Aspect < 0.9 ? 1.4 : 1);
                V3 back = new V3(Math.Sin(yw), 0, Math.Cos(yw));
                Pos = new V3(p.X + back.X * d * Math.Cos(pitch), ySm + 0.85 + d * Math.Sin(pitch), p.Z + back.Z * d * Math.Cos(pitch));
                Target = new V3(p.X - back.X * 1.6, ySm + 0.55, p.Z - back.Z * 1.6);
                Fov = M.Lerp(Fov, (58 + Math.Min(speed * 0.22, 14)) * Math.PI / 180, 1 - Math.Exp(-dt * 3));
            }
            else if (Mode == 1)
            {
                Target = new V3(p.X, ySm + 0.2, p.Z);
                Pos = new V3(p.X + Math.Sin(orbitYaw) * Math.Cos(orbitPitch) * orbitDist, ySm + 0.2 + Math.Sin(orbitPitch) * orbitDist, p.Z + Math.Cos(orbitYaw) * Math.Cos(orbitPitch) * orbitDist);
                Fov = 50 * Math.PI / 180;
            }
            else if (Mode == 2)
            {
                V3 eye = car.ToWorld(Bumper - car.ComModel);
                V3 fwd = car.Forward, up = car.Up;
                double ly = lookYaw;
                V3 dir = fwd * Math.Cos(ly) + car.Right * -Math.Sin(ly);
                Pos = eye; Target = eye + dir * 10 + up * (-0.35 + lookPitch * 4); Up = up;
                Fov = 68 * Math.PI / 180;
            }
            else if (Mode == 4 && HasCockpit)
            {
                // driver's eye: the head rides with the body but sways against the g-forces (forward under braking,
                // back under power, out of the corner) and glances towards where the car is being steered
                var tel = car.Tel;
                double k = 1 - Math.Exp(-dt * 6);
                double hx = M.Clamp(-tel.GLat * 0.022, -0.045, 0.045), hz = M.Clamp(tel.GLong * 0.03, -0.05, 0.04);
                head = new V3(M.Lerp(head.X, hx, k), 0, M.Lerp(head.Z, hz, k));
                glance = M.Lerp(glance, M.Clamp(car.SteerSm, -1, 1) * 0.16, 1 - Math.Exp(-dt * 3));
                V3 eye = car.ToWorld(Cockpit + head - car.ComModel);
                double ly = lookYaw + glance, lp = -0.07 + lookPitch * 0.9;
                V3 fwd = car.Forward, up = car.Up, rgt = car.Right;
                V3 flat = fwd * Math.Cos(ly) + rgt * -Math.Sin(ly);
                V3 dir = flat * Math.Cos(lp) + up * Math.Sin(lp);
                Pos = eye; Target = eye + dir * 10; Up = up;
                Fov = 72 * Math.PI / 180;
            }
            else
            {
                V3 v = car.Vel; double sp = v.Length();
                bool far = !hasTrack || (track - p).Length() > 75;
                if (far)
                {
                    V3 dir = sp > 2 ? v * (1 / sp) : car.Forward;
                    V3 side = V3.Cross(dir, V3.UnitY).Normalized();
                    double s = M.Rand() < 0.5 ? -1 : 1;
                    V3 c = p + dir * Math.Min(18 + sp * 1.6, 60) + side * (s * (7 + M.Rand() * 6));
                    double gy = terrain.HeightAt(c.X, c.Z, p.Y + 3);
                    if (gy < p.Y - 8) gy = p.Y - 1; // over a drop (mountain roads): stand level with the road
                    c = new V3(c.X, gy + 1.4 + M.Rand() * 1.2, c.Z);
                    track = c; hasTrack = true;
                }
                Pos = track;
                Target = p;
                double dist = (Target - Pos).Length();
                Fov = M.Clamp(2 * Math.Atan2(4.2, dist), 0.16, 1.0);
            }
            if (Mode != 2 && Mode != 4)
            {
                double gh = terrain.HeightAt(Pos.X, Pos.Z, Pos.Y) + 0.35;
                if (Pos.Y < gh) Pos = new V3(Pos.X, gh, Pos.Z);
            }
        }
    }
}
