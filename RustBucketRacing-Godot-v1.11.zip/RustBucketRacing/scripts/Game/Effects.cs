// Skid marks and ruts, tyre smoke and dust from loose surfaces.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class Effects
    {
        static readonly Color[] MarkCol =
        {
            new Color(0.008f, 0.008f, 0.008f), new Color(0.008f, 0.008f, 0.008f), new Color(0.075f, 0.045f, 0.025f),
            new Color(0.13f, 0.11f, 0.085f), new Color(0.05f, 0.065f, 0.02f),
        }; // by Surf
        struct Dust { public Color Col; public double Rate, A; }
        static readonly Dust[] DustOf =
        {
            default, default,
            new Dust { Col = new Color(0.5f, 0.39f, 0.27f), Rate = 2.6, A = 0.3 },
            new Dust { Col = new Color(0.56f, 0.52f, 0.46f), Rate = 1.9, A = 0.24 },
            new Dust { Col = new Color(0.34f, 0.36f, 0.2f), Rate = 0.5, A = 0.12 },
        };
        const int MAX_PUFFS = 680;

        readonly SkidMarks skids;
        public TerrainBase Terrain;
        public readonly List<Puff> Smoke = new List<Puff>();
        readonly V3[] last = new V3[4];
        readonly bool[] hasLast = new bool[4];
        readonly double[] acc = new double[4], dacc = new double[4];

        public Effects(SkidMarks skids, TerrainBase terrain) { this.skids = skids; Terrain = terrain; }

        public void Clear() { skids.Clear(); Smoke.Clear(); ResetTrails(); }
        public void ResetTrails() { for (int i = 0; i < 4; i++) hasLast[i] = false; }

        public void Update(double dt, Car car)
        {
            double speed = Math.Abs(car.Tel.Speed);
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i];
                var surf = w.Surface;
                bool loose = Surfaces.Loose(surf);
                // marks: rubber on tarmac when sliding; ruts on loose ground whenever the tyre rolls through it
                bool marking = w.Contact && (w.Sliding > 0.04 || (loose && speed > 1.5));
                if (marking)
                {
                    // sit the mark on the surface as drawn; on a kerb, ride over the ridge tops rather than cut through them
                    V3 cp = w.ContactPt;
                    V3 p = new V3(cp.X, Terrain.HeightVisAt(cp.X, cp.Z, cp.Y, 0.1) + (surf == Surf.Rumble ? Terrain.KerbLift : 0), cp.Z);
                    double gap = w.Sliding > 0.04 ? 0.2 : 0.45;
                    double alpha = w.Sliding > 0.04 ? M.Clamp(0.2 + w.Sliding, 0.2, 1) : 0.22;
                    if (hasLast[i])
                    {
                        if ((p - last[i]).Length() > gap) { skids.Add(last[i], p, w.Normal, 0.105, alpha, MarkCol[(int)surf]); last[i] = p; }
                    }
                    else { last[i] = p; hasLast[i] = true; }
                }
                else hasLast[i] = false;
                if (!w.Contact) continue;
                V3 cpt = w.ContactPt;
                // tyre smoke on hard surfaces
                if (!loose && w.Sliding > 0.2 && w.SlipVel > 3.5)
                {
                    acc[i] += dt * 26 * w.Sliding;
                    while (acc[i] > 1 && Smoke.Count < MAX_PUFFS)
                    {
                        acc[i] -= 1;
                        V3 v = car.Vel * 0.2 + new V3((M.Rand() - 0.5) * 1.2, 0.5 + M.Rand() * 0.6, (M.Rand() - 0.5) * 1.2);
                        Smoke.Add(new Puff { P = cpt + new V3(0, 0.2, 0), V = v, Life = 1.6 + M.Rand() * 1.2, S0 = 0.5, S1 = 2.6 + M.Rand() * 1.6, A0 = 0.28 * Math.Min(1, w.Sliding * 1.3) });
                    }
                }
                // dust thrown up from loose surfaces, more with speed and wheelspin
                if (loose && (speed > 2.5 || w.SlipVel > 2))
                {
                    var d = DustOf[(int)surf];
                    dacc[i] += dt * d.Rate * (Math.Min(speed, 30) * 0.5 + w.SlipVel * 1.2) * (i >= 2 ? 1 : 0.5);
                    while (dacc[i] > 1 && Smoke.Count < MAX_PUFFS)
                    {
                        dacc[i] -= 1;
                        V3 v = car.Vel * 0.12 + new V3((M.Rand() - 0.5) * 1.6, 0.4 + M.Rand() * 0.9, (M.Rand() - 0.5) * 1.6);
                        float k = (float)(0.9 + M.Rand() * 0.2);
                        Smoke.Add(new Puff
                        {
                            P = cpt + new V3(0, 0.15, 0), V = v, Life = 1.8 + M.Rand() * 1.6, S0 = 0.6, S1 = 3 + M.Rand() * 2.5,
                            A0 = d.A * (0.6 + M.Rand() * 0.4), Dust = true, Col = new Color(d.Col.R * k, d.Col.G * k, d.Col.B * k),
                        });
                    }
                }
            }
            foreach (var s in Smoke)
            {
                s.Age += dt;
                s.P = s.P + s.V * dt;
                s.V = s.V * Math.Exp(-dt * 1.2);
                s.V = new V3(s.V.X, s.V.Y + dt * (s.Dust ? 0.08 : 0.25), s.V.Z);
                double t = s.Age / s.Life;
                s.Size = M.Lerp(s.S0, s.S1, Math.Sqrt(t));
                s.A = s.A0 * (1 - t) * Math.Min(1, s.Age * 8);
            }
            Smoke.RemoveAll((s) => s.Age >= s.Life);
        }
    }
}
