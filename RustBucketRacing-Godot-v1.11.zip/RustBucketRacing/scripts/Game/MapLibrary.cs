// The map library. Every map but the proving ground is a download rather than part of the APK: the catalogue
// (maps.json) and the map packs live on the GitHub release "maps", which the build publishes from the
// RustBucketRacing-Maps-<name>.zip files in the repo (each a <id>.bin pack and its <id>.json description). Installed
// maps live in user://maps (the app's own storage), so new maps never need a new APK.
using System;
using System.Collections.Generic;
using System.Text.Json;
using Godot;

namespace RustBucket.Game
{
    public sealed class MapLibrary
    {
        public const string Base = "https://github.com/Jsam54364/Rust-bucket-racing-/releases/download/maps/";
        public const string Dir = "user://maps";
        const string CacheFile = Dir + "/catalogue.json";

        readonly Node host;
        public readonly List<MapDef> Catalogue = new List<MapDef>();
        public string Status = "";
        public bool Fetching;
        public double LastFetch = -1e9;     // Time.GetTicksMsec / 1000 of the last good catalogue
        public event Action Changed;        // installed maps, downloads or the catalogue changed: menus rebuild
        public Func<string, bool> CanReplace = (id) => true;   // the game isn't busy with this map right now
        public Action<string> Replacing = (id) => { };        // the game lets go of a map before its files change
        public string FallbackDir;          // self-test: install from this folder if a download fails

        sealed class Job { public MapDef Def; public HttpRequest Rq; public string Part; public bool Done, Ok; public string Error; }
        readonly Dictionary<string, Job> jobs = new Dictionary<string, Job>();
        readonly Dictionary<string, string> errors = new Dictionary<string, string>();

        public MapLibrary(Node host)
        {
            this.host = host;
            DirAccess.MakeDirRecursiveAbsolute(Dir);
            // a download cut off last time leaves a .part behind
            foreach (var f in DirAccess.GetFilesAt(Dir)) if (f.EndsWith(".part")) DirAccess.RemoveAbsolute(Dir + "/" + f);
            ScanInstalled();
            if (FileAccess.FileExists(CacheFile))
            {
                try { ParseCatalogue(FileAccess.GetFileAsString(CacheFile)); Status = "Showing the list from last time"; }
                catch (Exception e) { GD.PushWarning("map catalogue cache: " + e.Message); }
            }
        }

        public static string PackPath(string id) => Dir + "/" + id + ".bin";
        static string DescPath(string id) => Dir + "/" + id + ".json";

        public bool IsInstalled(string id) => Defs.Maps.TryGetValue(id, out var m) && m.Installable && FileAccess.FileExists(m.Pack);
        public bool IsDownloading(string id) => jobs.ContainsKey(id);
        public bool AnyDownloading => jobs.Count > 0;
        public string Error(string id) => errors.TryGetValue(id, out var e) ? e : null;

        public bool UpdateAvailable(MapDef c) =>
            IsInstalled(c.Id) && c.Sha.Length > 0 && Defs.Maps[c.Id].Sha != c.Sha;

        // a map made for a newer game than this one
        public static bool TooNew(MapDef c) =>
            c.MinGame.Length > 0 && Version.TryParse(DebugLog.Version, out var have) && Version.TryParse(c.MinGame, out var need) && have < need;

        // 0..1 while downloading
        public double Progress(string id)
        {
            if (!jobs.TryGetValue(id, out var j) || j.Rq == null) return 0;
            double total = j.Def.Bytes > 0 ? j.Def.Bytes : j.Rq.GetBodySize();
            return total > 0 ? Math.Clamp(j.Rq.GetDownloadedBytes() / total, 0, 1) : 0;
        }

        // what is on the phone now: every user://maps/<id>.json with its pack next to it
        public void ScanInstalled()
        {
            var seen = new HashSet<string>();
            foreach (var f in DirAccess.GetFilesAt(Dir))
            {
                if (!f.EndsWith(".json") || f == "catalogue.json") continue;
                try
                {
                    using var doc = JsonDocument.Parse(FileAccess.GetFileAsString(Dir + "/" + f));
                    var d = MapDef.FromJson(doc.RootElement);
                    d.Pack = PackPath(d.Id);
                    if (!FileAccess.FileExists(d.Pack)) continue;
                    Defs.Maps[d.Id] = d;
                    seen.Add(d.Id);
                }
                catch (Exception e) { GD.PushWarning("installed map " + f + ": " + e.Message); }
            }
            var gone = new List<string>();
            foreach (var kv in Defs.Maps) if (kv.Value.Installable && !seen.Contains(kv.Key)) gone.Add(kv.Key);
            foreach (var id in gone) Defs.Maps.Remove(id);
            Defs.RefreshMapOrder();
        }

        void ParseCatalogue(string text)
        {
            using var doc = JsonDocument.Parse(text);
            var list = new List<MapDef>();
            foreach (var e in doc.RootElement.GetProperty("maps").EnumerateArray())
            {
                try { list.Add(MapDef.FromJson(e)); }
                catch (Exception ex) { GD.PushWarning("map catalogue entry: " + ex.Message); }
            }
            Catalogue.Clear();
            Catalogue.AddRange(list);
        }

        // self-test: a catalogue from a file instead of the release
        public void UseCatalogue(string text)
        {
            ParseCatalogue(text);
            Status = Catalogue.Count + " maps (local list)";
            Changed?.Invoke();
        }

        // fetch the list of maps from the release
        public void Refresh()
        {
            if (Fetching) return;
            Fetching = true;
            Status = "Checking for maps…";
            var rq = new HttpRequest { Timeout = 25, UseThreads = true, MaxRedirects = 8 };
            host.AddChild(rq);
            rq.RequestCompleted += (result, code, headers, body) =>
            {
                rq.QueueFree();
                Fetching = false;
                if (result == (long)HttpRequest.Result.Success && code == 200)
                {
                    string text = System.Text.Encoding.UTF8.GetString(body);
                    try
                    {
                        ParseCatalogue(text);
                        using (var f = FileAccess.Open(CacheFile, FileAccess.ModeFlags.Write)) f?.StoreString(text);
                        LastFetch = Time.GetTicksMsec() / 1000.0;
                        Status = Catalogue.Count == 0 ? "No maps to download yet" : Catalogue.Count == 1 ? "1 map available" : Catalogue.Count + " maps available";
                    }
                    catch (Exception e) { Status = "The map list didn't make sense (" + e.Message + ")"; }
                }
                else if (code == 404) Status = "No maps have been published yet";
                else Status = Catalogue.Count > 0 ? "Couldn't reach the map list: showing the one from last time" : "Couldn't reach the map list: check the internet connection";
                DebugLog.Trace("map catalogue: " + Status + $" (result {result}, http {code})");
                Changed?.Invoke();
            };
            var err = rq.Request(Base + "maps.json");
            if (err != Godot.Error.Ok)
            {
                rq.QueueFree(); Fetching = false;
                Status = "Couldn't ask for the map list (" + err + ")";
            }
            Changed?.Invoke();
        }

        // download a map (or a newer version of one) from the catalogue
        public void Install(MapDef c)
        {
            if (jobs.ContainsKey(c.Id) || TooNew(c)) return;
            errors.Remove(c.Id);
            var j = new Job { Def = c, Part = Dir + "/" + c.Id + ".bin.part" };
            var rq = new HttpRequest { UseThreads = true, MaxRedirects = 8, DownloadFile = j.Part, DownloadChunkSize = 262144 };
            host.AddChild(rq);
            j.Rq = rq;
            jobs[c.Id] = j;
            rq.RequestCompleted += (result, code, headers, body) =>
            {
                j.Done = true;
                j.Ok = result == (long)HttpRequest.Result.Success && code == 200;
                if (!j.Ok) j.Error = code == 404 ? "Not on the server any more" : result == (long)HttpRequest.Result.Success ? "Server said " + code : "Download failed (" + (HttpRequest.Result)(int)result + ")";
            };
            var err = rq.Request(Base + c.File);
            if (err != Godot.Error.Ok) { j.Done = true; j.Error = "Couldn't start the download (" + err + ")"; }
            DebugLog.Trace("map download: " + c.Id + " " + c.Bytes + " bytes");
            Changed?.Invoke();
        }

        // self-test: install from a folder of packs instead of the internet
        public bool InstallLocal(MapDef c, string dir)
        {
            string src = dir.PathJoin(c.File);
            if (!FileAccess.FileExists(src)) return false;
            var j = new Job { Def = c, Part = Dir + "/" + c.Id + ".bin.part" };
            if (DirAccess.CopyAbsolute(src, j.Part) != Godot.Error.Ok) return false;
            j.Done = true; j.Ok = true;
            jobs[c.Id] = j;
            return true;
        }

        public void Cancel(string id)
        {
            if (!jobs.TryGetValue(id, out var j)) return;
            j.Rq?.CancelRequest();
            Drop(j);
            Changed?.Invoke();
        }

        void Drop(Job j)
        {
            jobs.Remove(j.Def.Id);
            j.Rq?.QueueFree();
            if (FileAccess.FileExists(j.Part)) DirAccess.RemoveAbsolute(j.Part);
        }

        public bool Remove(string id)
        {
            if (!IsInstalled(id) || !CanReplace(id)) return false;
            Replacing(id);
            DirAccess.RemoveAbsolute(PackPath(id));
            DirAccess.RemoveAbsolute(DescPath(id));
            errors.Remove(id);
            ScanInstalled();
            DebugLog.Trace("map removed: " + id);
            Changed?.Invoke();
            return true;
        }

        // each frame: finish downloads that are done (check them, swap them in when the game isn't using the map)
        public void Update()
        {
            if (jobs.Count == 0) return;
            List<Job> done = null;
            foreach (var j in jobs.Values) if (j.Done) (done ??= new List<Job>()).Add(j);
            if (done == null) return;
            bool changed = false;
            foreach (var j in done)
            {
                var c = j.Def;
                if (!j.Ok) { errors[c.Id] = j.Error ?? "Download failed"; Drop(j); changed = true; continue; }
                if (!CanReplace(c.Id)) continue;   // try again next frame
                string err = Check(c, j.Part);
                if (err != null) { errors[c.Id] = err; Drop(j); changed = true; continue; }
                Replacing(c.Id);
                DirAccess.RemoveAbsolute(PackPath(c.Id));
                var rerr = DirAccess.RenameAbsolute(j.Part, PackPath(c.Id));
                if (rerr != Godot.Error.Ok) { errors[c.Id] = "Couldn't save it (" + rerr + ")"; Drop(j); changed = true; continue; }
                using (var f = FileAccess.Open(DescPath(c.Id), FileAccess.ModeFlags.Write)) f?.StoreString(c.Json);
                jobs.Remove(c.Id);
                j.Rq?.QueueFree();
                errors.Remove(c.Id);
                ScanInstalled();
                DebugLog.Trace("map installed: " + c.Id);
                changed = true;
            }
            if (changed) Changed?.Invoke();
        }

        // the download is the size the catalogue said, and the same bytes (sha256)
        static string Check(MapDef c, string path)
        {
            var bytes = FileAccess.GetFileAsBytes(path);
            if (bytes == null || bytes.Length == 0) return "The download was empty";
            if (c.Bytes > 0 && bytes.Length != c.Bytes) return $"The download stopped short ({bytes.Length / 1048576.0:F1} of {c.Bytes / 1048576.0:F1} MB)";
            if (c.Sha.Length > 0)
            {
                string sha = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(bytes)).ToLowerInvariant();
                if (sha != c.Sha.ToLowerInvariant()) return "The download came out damaged: try again";
            }
            if (bytes.Length < 8 || bytes[0] != (byte)'R' || bytes[1] != (byte)'B' || bytes[2] != (byte)'M' || bytes[3] != (byte)'P') return "That isn't a map pack";
            return null;
        }
    }
}
