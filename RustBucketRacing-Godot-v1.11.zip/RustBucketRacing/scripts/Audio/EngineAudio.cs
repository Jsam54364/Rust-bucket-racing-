// Engine sound: granular synthesis from recorded engine cycles, plus tyres, kerbs, wind, shifts and overrun pops.
//
// Each recording (on-throttle "accel" sweep, off-throttle "decel" sweep) is cut into grains at the cycle markers;
// one grain is one full 4-stroke cycle. For a target RPM the core plays the grain recorded closest to that RPM,
// resampled so its pitch lands exactly on target, then either runs on into the next recorded grain (seamless)
// or splices to another nearby grain with a short raised-cosine crossfade. The two layers are blended by engine
// load; each layer's mix settings (gain, distortion, low-pass, parametric EQ) shape it. Everything after that
// mirrors the browser version's Web Audio graph, sample by sample.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using RustBucket.Sim;

namespace RustBucket.Audio
{
    public sealed class LayerData
    {
        public float[] Pcm;
        public double[] Marks, Rpm, Rms;
        public double Rate = 24000, GainDb, Dist, Lp, Doppler = 0.25;
        public List<(double freq, double q, double gain)> Eq = new List<(double, double, double)>();
    }

    public sealed class Profile
    {
        public double IdleFade0 = 900, IdleFade1 = 1700, Rpm0 = 800, Rpm1 = 6600, Level = 1, PopPitch = 1, PopRpm = 3600;
        public double Lowpass, LowpassQ = 0.6, ShelfF, ShelfG;
        public Profile Clone() => (Profile)MemberwiseClone();
    }

    public sealed class EngineData
    {
        public LayerData Accel, Decel;
        public float[] IdlePcm; public double IdleRate = 24000, IdleRpm;
        public Profile Profile = new Profile();
    }

    public sealed class SfxData
    {
        public double Rate = 24000, IdleRpm = 720, RumbleHz = 41.4, RumbleSpacing = 0.4;
        public Dictionary<string, float[]> Sounds = new Dictionary<string, float[]>();
    }

    public static class AudioData
    {
        public static float[] Pcm16(string b64)
        {
            var b = Convert.FromBase64String(b64);
            int n = b.Length >> 1;
            var o = new float[n];
            for (int i = 0; i < n; i++) o[i] = (short)(b[2 * i] | (b[2 * i + 1] << 8)) / 32768f;
            return o;
        }

        static double[] Nums(JsonElement e)
        {
            var o = new double[e.GetArrayLength()];
            int i = 0;
            foreach (var x in e.EnumerateArray()) o[i++] = x.GetDouble();
            return o;
        }
        static double Num(JsonElement e, string k, double def) =>
            e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : def;

        static LayerData Layer(JsonElement l)
        {
            var d = new LayerData
            {
                Rate = Num(l, "rate", 24000), Marks = Nums(l.GetProperty("marks")), Pcm = Pcm16(l.GetProperty("pcm").GetString()),
                GainDb = Num(l, "gainDb", 0), Dist = Num(l, "dist", 0), Lp = Num(l, "lp", 0), Doppler = Num(l, "doppler", 0.25),
            };
            if (l.TryGetProperty("rpm", out var r) && r.ValueKind == JsonValueKind.Array) d.Rpm = Nums(r);
            if (l.TryGetProperty("rms", out var s) && s.ValueKind == JsonValueKind.Array) d.Rms = Nums(s);
            if (l.TryGetProperty("eq", out var eq) && eq.ValueKind == JsonValueKind.Array)
                foreach (var e in eq.EnumerateArray()) d.Eq.Add((Num(e, "freq", 1000), Num(e, "q", 1), Num(e, "gain", 1)));
            return d;
        }

        // packed engine (tools/prep_engine_audio.py): layers.accel / layers.decel, optional idle and profile
        public static EngineData Engine(string json)
        {
            using var doc = JsonDocument.Parse(json);
            var h = doc.RootElement;
            var L = h.GetProperty("layers");
            var d = new EngineData { Accel = Layer(L.GetProperty("accel")), Decel = Layer(L.GetProperty("decel")) };
            if (h.TryGetProperty("idle", out var idle) && idle.ValueKind == JsonValueKind.Object)
            {
                d.IdlePcm = Pcm16(idle.GetProperty("pcm").GetString());
                d.IdleRate = Num(idle, "rate", 24000);
                d.IdleRpm = Num(idle, "rpm", 780);
            }
            if (h.TryGetProperty("profile", out var p) && p.ValueKind == JsonValueKind.Object) ApplyProfile(d.Profile, p);
            return d;
        }

        public static void ApplyProfile(Profile pf, JsonElement p)
        {
            if (p.TryGetProperty("idleFade", out var f) && f.ValueKind == JsonValueKind.Array) { var a = Nums(f); pf.IdleFade0 = a[0]; pf.IdleFade1 = a[1]; }
            if (p.TryGetProperty("rpmRange", out var r) && r.ValueKind == JsonValueKind.Array) { var a = Nums(r); pf.Rpm0 = a[0]; pf.Rpm1 = a[1]; }
            pf.Level = Num(p, "level", pf.Level);
            pf.PopPitch = Num(p, "popPitch", pf.PopPitch);
            pf.PopRpm = Num(p, "popRpm", pf.PopRpm);
            pf.Lowpass = Num(p, "lowpass", pf.Lowpass);
            pf.LowpassQ = Num(p, "lowpassQ", pf.LowpassQ);
            if (p.TryGetProperty("lowshelf", out var s) && s.ValueKind == JsonValueKind.Array) { var a = Nums(s); pf.ShelfF = a[0]; pf.ShelfG = a[1]; }
        }

        public static SfxData Sfx(string json)
        {
            using var doc = JsonDocument.Parse(json);
            var h = doc.RootElement;
            var d = new SfxData { Rate = Num(h, "rate", 24000) };
            if (h.TryGetProperty("meta", out var m))
            {
                d.IdleRpm = Num(m, "idleRpm", 720); d.RumbleHz = Num(m, "rumbleHz", 41.4); d.RumbleSpacing = Num(m, "rumbleSpacing", 0.4);
            }
            foreach (var s in h.GetProperty("sounds").EnumerateObject()) d.Sounds[s.Name] = Pcm16(s.Value.GetProperty("pcm").GetString());
            return d;
        }
    }

    /* ---------------- DSP core ---------------- */
    public sealed class GrainLayer
    {
        readonly float[] x;
        readonly double[] m, rpm, gain, sorted;
        readonly int[] order;
        readonly int n;
        int g = -1;
        double pos, end, rate = 1, fpos, frate, gs = 1, fg = 1;
        int fadeN, fadeI;
        uint seed;
        readonly double srcRate;
        readonly int[] best = new int[9];
        readonly double[] bestD = new double[9];

        public GrainLayer(float[] pcm, double[] marks, double srcRate, double[] rpmTable, double[] rmsTable)
        {
            x = pcm; m = marks; n = marks.Length - 1; this.srcRate = srcRate;
            double K = 120 * srcRate; // frames per minute for 2 revolutions
            var len = new double[n];
            for (int i = 0; i < n; i++) len[i] = marks[i + 1] - marks[i];
            // RPM per grain from the median of 5 neighbouring cycle lengths, so marker jitter doesn't steer pitch
            rpm = new double[n];
            var w = new double[5];
            for (int i = 0; i < n; i++)
            {
                for (int k = -2; k <= 2; k++) w[k + 2] = len[Math.Min(n - 1, Math.Max(0, i + k))];
                Array.Sort(w);
                rpm[i] = rpmTable != null && i < rpmTable.Length ? rpmTable[i] : K / w[2];
            }
            // level each grain to the layer's median loudness; the mixer decides how loud the engine is
            gain = new double[n];
            for (int i = 0; i < n; i++) gain[i] = 1;
            if (rmsTable != null && rmsTable.Length >= n)
            {
                var srt = rmsTable.Take(n).OrderBy((v) => v).ToArray();
                double rf = srt[n >> 1];
                for (int i = 0; i < n; i++) gain[i] = Math.Max(0.25, Math.Min(8, rf / rmsTable[i]));
            }
            order = Enumerable.Range(0, n).OrderBy((i) => rpm[i]).ToArray();
            sorted = order.Select((i) => rpm[i]).ToArray();
            seed = (uint)((ulong)marks.Length * 2654435761UL);
        }

        double Rand() { seed = unchecked(seed * 1664525u + 1013904223u); return seed / 4294967296.0; }

        int Nearest(double r, int exclude)
        {
            int lo = 0, hi = n - 1;
            while (lo < hi) { int mid = (lo + hi) >> 1; if (sorted[mid] < r) lo = mid + 1; else hi = mid; }
            int cnt = 0;
            for (int k = Math.Max(0, lo - 4); k <= Math.Min(n - 1, lo + 4); k++)
            {
                int gi = order[k];
                if (gi == exclude) continue;
                double d = Math.Abs(Math.Log(sorted[k] / r));
                int j = cnt; best[cnt] = gi; bestD[cnt] = d; cnt++;
                while (j > 0 && bestD[j - 1] > d) { bestD[j] = bestD[j - 1]; best[j] = best[j - 1]; bestD[j - 1] = d; best[j - 1] = gi; j--; }
            }
            if (cnt == 0) return Math.Max(0, Math.Min(n - 1, exclude));
            // pick randomly among the closest three so steady RPM doesn't loop one grain
            return best[(int)Math.Floor(Rand() * Math.Min(3, cnt))];
        }

        double Sample(double p)
        {
            int i = (int)Math.Floor(p);
            double t = p - i;
            if (i < 1 || i + 2 >= x.Length) return i >= 0 && i < x.Length ? x[i] : 0;
            double y0 = x[i - 1], y1 = x[i], y2 = x[i + 1], y3 = x[i + 2];
            double c1 = 0.5 * (y2 - y0), c2 = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3, c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);
            return ((c3 * t + c2) * t + c1) * t + y1;
        }

        void Start(int gi, double r, double step)
        {
            double len = m[gi + 1] - m[gi];
            double rt = (r / rpm[gi]) * step;
            if (g >= 0)
            {
                // the old grain keeps playing past its marker (its natural continuation) while fading out
                fpos = pos; frate = rate; fadeI = 0; fg = gs;
                fadeN = Math.Max(32, Math.Min(900, (int)Math.Round((0.18 * len) / rt)));
            }
            g = gi; pos = m[gi]; end = m[gi + 1]; rate = rt; gs = gain[gi];
        }

        public void Render(float[] o, int count, double r, double pitch, double outRate)
        {
            double step = (srcRate / outRate) * pitch;
            if (g < 0) Start(Nearest(r, -1), r, step);
            rate = (r / rpm[g]) * step;
            for (int i = 0; i < count; i++)
            {
                if (pos >= end)
                {
                    int nx = g + 1;
                    if (nx < n && Math.Abs(rpm[nx] / r - 1) < 0.035)
                    {
                        double over = pos - end; // run on into the next recorded cycle: no splice needed
                        g = nx; end = m[nx + 1]; pos = m[nx] + over;
                        rate = (r / rpm[nx]) * step;
                    }
                    else Start(Nearest(r, g), r, step);
                }
                gs += (gain[g] - gs) * 0.002;
                double s = Sample(pos) * gs;
                if (fadeI < fadeN)
                {
                    double wv = 0.5 - 0.5 * Math.Cos((Math.PI * fadeI) / fadeN);
                    s = s * wv + Sample(fpos) * fg * (1 - wv);
                    fpos += frate; fadeI++;
                }
                o[i] = (float)s;
                pos += rate;
            }
        }
    }

    // a recorded loop or one-shot played at a variable rate (linear interpolation, like a buffer source)
    sealed class Player
    {
        readonly float[] b;
        readonly double step0;
        readonly bool loop;
        double pos;
        public Param Gain, Rate;
        public int Delay;
        public bool Done;

        public Player(float[] buf, double srcRate, double outRate, bool loop, double start01, double gain, double rate)
        {
            b = buf; step0 = srcRate / outRate; this.loop = loop;
            pos = loop ? start01 * buf.Length : 0;
            Gain = new Param(gain); Rate = new Param(rate);
        }

        public double Next()
        {
            if (Done) return 0;
            if (Delay > 0) { Delay--; return 0; }
            double g = Gain.Next(), r = Rate.Next();
            double s = 0;
            if (g > 1e-6 || Gain.Target > 1e-6)
            {
                int i = (int)pos;
                double f = pos - i;
                int j = i + 1;
                if (j >= b.Length) j = loop ? 0 : i;
                s = (b[i] + (b[j] - b[i]) * f) * g;
            }
            pos += step0 * r;
            if (pos >= b.Length)
            {
                if (loop) { while (pos >= b.Length) pos -= b.Length; }
                else Done = true;
            }
            return s;
        }
    }

    // per-layer chain from the recording's mix settings: EQ, low-pass, drive into the distortion curve, trim, mix
    sealed class Chain
    {
        readonly Biquad[] eq;
        readonly Biquad lp;
        readonly double k, trim;
        public Param Drive = new Param(1), Mix = new Param(0);

        public Chain(LayerData d, double rate)
        {
            eq = d.Eq.Select((e) => new Biquad(BiquadType.Peaking, rate, e.freq, e.q, 20 * Math.Log10(Math.Max(1e-6, e.gain)))).ToArray();
            lp = d.Lp > 0 ? new Biquad(BiquadType.Lowpass, rate, d.Lp, 0.707) : null;
            k = Shape.DistK(d.Dist);
            trim = Math.Pow(10, d.GainDb / 20);
        }

        public double Process(double x)
        {
            for (int i = 0; i < eq.Length; i++) x = eq[i].Process(x);
            if (lp != null) x = lp.Process(x);
            x *= Drive.Next();
            x = Shape.Dist(x, k) * trim;
            return x * Mix.Next();
        }
    }

    // one engine: two grain layers through their chains, the idle loop, and the exhaust filters of its profile
    sealed class EngineVoice
    {
        public readonly GrainLayer Acc, Dec;
        public readonly Chain AccC, DecC;
        public readonly Profile Pf;
        public readonly Player Idle;
        public readonly double IdleRpm, Doppler;
        readonly Biquad shelf, lp;
        public Param Fade = new Param(1);
        public double Retire = -1; // seconds left once fading out
        readonly float[] a = new float[EngineAudio.BLOCK], d = new float[EngineAudio.BLOCK];

        public EngineVoice(EngineData data, Profile pf, SfxData sfx, double rate)
        {
            Pf = pf;
            Acc = new GrainLayer(data.Accel.Pcm, data.Accel.Marks, data.Accel.Rate, data.Accel.Rpm, data.Accel.Rms);
            Dec = new GrainLayer(data.Decel.Pcm, data.Decel.Marks, data.Decel.Rate, data.Decel.Rpm, data.Decel.Rms);
            AccC = new Chain(data.Accel, rate);
            DecC = new Chain(data.Decel, rate);
            Doppler = data.Accel.Doppler;
            // profile lowpass / lowshelf: the same recordings heard through a different exhaust (muffled)
            if (pf.ShelfF > 0) shelf = new Biquad(BiquadType.Lowshelf, rate, pf.ShelfF, 1, pf.ShelfG);
            if (pf.Lowpass > 0) lp = new Biquad(BiquadType.Lowpass, rate, pf.Lowpass, pf.LowpassQ > 0 ? pf.LowpassQ : 0.6);
            // idle: the engine's own loop, or the shared recording
            if (data.IdlePcm != null) { Idle = new Player(data.IdlePcm, data.IdleRate, rate, true, M.Rand(), 0, 1); IdleRpm = data.IdleRpm; }
            else if (sfx != null && sfx.Sounds.TryGetValue("idle", out var ib)) { Idle = new Player(ib, sfx.Rate, rate, true, M.Rand(), 0, 1); IdleRpm = sfx.IdleRpm; }
            else IdleRpm = 720;
        }

        public void Render(double[] o, int count, double rpm, double pitch, double rate)
        {
            Acc.Render(a, count, rpm, pitch, rate);
            Dec.Render(d, count, rpm, pitch, rate);
            for (int i = 0; i < count; i++)
            {
                double e = AccC.Process(a[i]) + DecC.Process(d[i]);
                if (Idle != null) e += Idle.Next();
                if (shelf != null) e = shelf.Process(e);
                if (lp != null) e = lp.Process(e);
                o[i] += e * Fade.Next();
            }
        }
    }

    // what the sound needs from the game each frame
    public sealed class SoundState
    {
        public double Rpm, Throttle, Speed;
        public bool Limiter, Shifting;
        public int Gear;
        public V3 CamPos, CamVel, CarPos, CarVel;
        public readonly WheelSound[] Wheels = { new WheelSound(), new WheelSound(), new WheelSound(), new WheelSound() };
    }

    public sealed class WheelSound { public bool Contact; public Surf Surface; public double Speed, Slip, Load; }

    public sealed class EngineAudio
    {
        public const int BLOCK = 128;
        public readonly double Rate;
        readonly SfxData sfx;
        EngineVoice eng;
        readonly List<EngineVoice> retiring = new List<EngineVoice>();
        readonly List<Player> shots = new List<Player>(), pops = new List<Player>(), hits = new List<Player>();
        readonly List<float[]> popBufs = new List<float[]>();
        readonly Random rnd = new Random();

        // graph
        Param bus = new Param(0.3), dist = new Param(1), wind = new Param(0), buzzG = new Param(0), masterOn = new Param(1);
        double airFreq = 16000, airTarget = 16000, airTau = 0.08;
        double rpmNow = 900, rpmTarget = 900, pitchNow = 1, pitchTarget = 1;
        double lfoFreq = 40, lfoTarget = 40, lfoPhase;
        readonly Biquad air, rHp1, rHp2, rEq, rLow, buzzBp, windLp;
        readonly double rK;
        readonly Compressor comp, lim;
        Noise noiseA = new Noise(12345), noiseB = new Noise(987654);
        static readonly string[] SURF_AUDIO = { "asphalt", "asphalt", "dirt", "gravel", "grass" }; // by Surf
        static readonly string[] AUDIO_SURF = { "asphalt", "dirt", "gravel", "grass" };
        // Levels balanced at the output (loudest 100 ms, measured by the self-test): full-throttle engine about -9 dB,
        // a big crash -7, a four-wheel slide on tarmac -9.5, a 30 km/h crunch -7, rolling at 100 km/h -16.5, a gear
        // change -13, a hard cone hit -14.5, wind at 160 km/h -24. The engine, tyre squeal and crashes are what you
        // expect to hear; the rest sits underneath.
        static readonly double[] ROLL_GAIN = { 0.42, 0.62, 0.5, 0.62 }, SKID_GAIN = { 0.56, 0.68, 0.65, 0.64 }, SKID_START = { 1.6, 0.8, 0.8, 0.9 };
        readonly Player[] roll = new Player[4], skid = new Player[4];
        readonly Player rumble;
        readonly double[] engBuf = new double[BLOCK];

        // player volume per kind of sound (0..1, set from the settings sliders)
        Param vMaster = new Param(1), vEngine = new Param(1), vTyres = new Param(1), vCrash = new Param(1), vFx = new Param(1);
        public enum Kind { Master, Engine, Tyres, Crashes, Effects }
        public static readonly string[] KindNames = { "Master", "Engine", "Tyres and road", "Crashes and impacts", "Effects" };
        public static readonly string[] KindKeys = { "vol_master", "vol_engine", "vol_tyres", "vol_crash", "vol_fx" };
        public static readonly string[] KindHints = { "everything", "engine, exhaust pops", "tyre roll and squeal, kerbs", "crashes, scrapes, cones", "gear shifts, wind" };
        readonly double[] vols = { 1, 1, 1, 1, 1 };
        // gates for the menus: the paused game is silent except for a preview of the kind of sound being set
        Param gEngine = new Param(1), gTyres = new Param(1), gWind = new Param(1);
        public void SetGates(bool engine, bool tyres, bool wind)
        {
            gEngine.Set(engine ? 1 : 0, 0.06, Rate); gTyres.Set(tyres ? 1 : 0, 0.06, Rate); gWind.Set(wind ? 1 : 0, 0.06, Rate);
        }

        // a gear change clunk on its own (the settings preview for effects)
        public void ShiftSound() => OneShot($"shift_up{1 + (int)Math.Floor(Rand() * 3)}", 0.9, 1);
        public double Volume(Kind k) => vols[(int)k];

        // slider 0..1 -> gain on a squared taper (half way is about -12 dB, which sounds like half as loud)
        public void SetVolume(Kind k, double v)
        {
            v = Clamp01(v); vols[(int)k] = v;
            double g = v * v;
            switch (k)
            {
                case Kind.Master: vMaster.Set(g, 0.05, Rate); break;
                case Kind.Engine: vEngine.Set(g, 0.05, Rate); break;
                case Kind.Tyres: vTyres.Set(g, 0.05, Rate); break;
                case Kind.Crashes: vCrash.Set(g, 0.05, Rate); break;
                default: vFx.Set(g, 0.05, Rate); break;
            }
        }

        // per-frame state
        double load, lastThr, overrun, hiLoadT;
        bool wasLimiter, wasShift;
        int lastGear = int.MinValue;
        public bool Enabled = true;
        public int PopCount;

        public EngineAudio(double rate, SfxData sfx)
        {
            Rate = rate; this.sfx = sfx;
            air = new Biquad(BiquadType.Lowpass, rate, 16000, 0.6);
            comp = new Compressor(rate, -12, 8, 3.5, 0.004, 0.15);
            lim = new Compressor(rate, -3, 0, 20, 0.001, 0.08);
            // overrun pops ride the exhaust side
            var r = new PopRng(7);
            for (int v = 0; v < 6; v++) popBufs.Add(MakePop(r, rate));
            // recorded tyre and rumble-strip loops
            for (int i = 0; i < 4; i++)
            {
                if (sfx.Sounds.TryGetValue(AUDIO_SURF[i] + "_roll", out var rb)) roll[i] = new Player(rb, sfx.Rate, rate, true, M.Rand(), 0, 1);
                if (sfx.Sounds.TryGetValue(AUDIO_SURF[i] + "_skid", out var sb)) skid[i] = new Player(sb, sfx.Rate, rate, true, M.Rand(), 0, 1);
            }
            // Rumble strips: most of the recording sits below 300 Hz, which phone speakers can't reproduce, so it is
            // driven into a saturator (adds audible harmonics) and lifted in the mids; a modest dry low end keeps the thump.
            if (sfx.Sounds.TryGetValue("rumble", out var rum)) rumble = new Player(rum, sfx.Rate, rate, true, M.Rand(), 0, 1);
            rK = Shape.DistK(0.65);
            rHp1 = new Biquad(BiquadType.Highpass, rate, 170, 0.7);
            rHp2 = new Biquad(BiquadType.Highpass, rate, 170, 0.7);
            rEq = new Biquad(BiquadType.Peaking, rate, 520, 0.8, 8);
            rLow = new Biquad(BiquadType.Lowpass, rate, 160, 1);
            // rumble buzz: band-passed noise chopped on and off at the ridge-hit rate; wind: low-passed noise
            buzzBp = new Biquad(BiquadType.Bandpass, rate, 760, 1.1);
            windLp = new Biquad(BiquadType.Lowpass, rate, 520, 1);
        }

        sealed class PopRng
        {
            uint s;
            public PopRng(uint seed) { s = seed; }
            public double Next() { s = unchecked(s * 1664525u + 1013904223u); return s / 4294967296.0; }
        }

        static float[] MakePop(PopRng rnd, double sr)
        {
            double dur = 0.07 + rnd.Next() * 0.08;
            int n = (int)Math.Floor(sr * dur);
            var d = new float[Math.Max(1, n)];
            double f = 65 + rnd.Next() * 70, tauT = 0.014 + rnd.Next() * 0.016, tauN = 0.003 + rnd.Next() * 0.007, lpk = 0.25 + rnd.Next() * 0.5;
            double y = 0, peak = 0;
            var tmp = new double[d.Length];
            for (int i = 0; i < n; i++)
            {
                double t = i / sr;
                y += lpk * ((rnd.Next() * 2 - 1) - y);
                double s = Math.Sin(2 * Math.PI * f * t * (1 - t * 2)) * Math.Exp(-t / tauT) * 0.9 + y * Math.Exp(-t / tauN) * 1.4;
                tmp[i] = s; peak = Math.Max(peak, Math.Abs(s));
            }
            if (!(peak > 0)) peak = 1;
            for (int i = 0; i < d.Length; i++) d[i] = (float)(tmp[i] / peak);
            return d;
        }

        // swap to another engine's recordings; the old one fades out over ~60 ms
        public void SetEngine(EngineData data, Profile pf)
        {
            if (eng != null) { eng.Fade.Set(0, 0.02, Rate); eng.Retire = 0.15; retiring.Add(eng); }
            eng = new EngineVoice(data, pf, sfx, Rate);
        }

        double Rand() => rnd.NextDouble();

        void Pop(double intensity, double pitch)
        {
            PopCount++;
            var b = popBufs[rnd.Next(popBufs.Count)];
            var p = new Player(b, Rate, Rate, false, 0, intensity, (0.85 + Rand() * 0.35) * pitch) { Delay = (int)(Rand() * 0.01 * Rate) };
            pops.Add(p);
        }

        void OneShot(string name, double gain, double rate)
        {
            if (!sfx.Sounds.TryGetValue(name, out var b)) return;
            shots.Add(new Player(b, sfx.Rate, Rate, false, 0, gain, rate));
        }

        static double Clamp01(double x) => x < 0 ? 0 : x > 1 ? 1 : x;

        void Hit(string set, int count, double gain, double rate)
        {
            if (!sfx.Sounds.TryGetValue(set + (1 + rnd.Next(count)), out var b)) return;
            if (hits.Count >= 6) hits.RemoveAt(0);
            hits.Add(new Player(b, sfx.Rate, Rate, false, 0, gain, rate));
        }

        // The car hitting something (closing speed in m/s): a knock below ~18 km/h, a crunch up to ~47 km/h, a crash
        // above that, with the panels rattling on after the big ones.
        public void Impact(double v, double pitch = 1)
        {
            double r = (0.94 + Rand() * 0.12) * pitch;
            if (v < 5) Hit("car_low", 3, 0.35 + 0.75 * Clamp01((v - 1) / 4), r);
            else if (v < 13) Hit("car_med", 4, 1.0 + 0.3 * Clamp01((v - 5) / 8), r);
            else Hit("car_high", 3, 1.4, r);
            if (v > 15 && Rand() < 0.8) Hit("bodyflap", 2, 0.45 + 0.35 * Clamp01((v - 15) / 15), 0.95 + Rand() * 0.1);
        }

        // a traffic cone knocked flying (relative speed in m/s)
        public void ConeHit(double v, double pitch = 1)
        {
            double r = (0.94 + Rand() * 0.12) * pitch;
            if (v < 3.5) Hit("cone_light", 3, 0.09 + 0.09 * Clamp01(v / 3.5), r);
            else if (v < 9) Hit("cone_med", 2, 0.17, r);
            else Hit("cone_hard", 3, 0.2, r);
        }

        public void Update(double dt, SoundState e)
        {
            if (eng == null || dt <= 0) return;
            double R = Rate;
            masterOn.Set(Enabled ? 1 : 0, 0.05, R);
            for (int i = retiring.Count - 1; i >= 0; i--) { retiring[i].Retire -= dt; if (retiring[i].Retire <= 0) retiring.RemoveAt(i); }
            // load the engine is under: fuel cut on the limiter and during shifts
            double target = e.Limiter || e.Shifting ? 0 : e.Throttle;
            double tau = target > load ? 0.035 : (e.Limiter ? 0.01 : 0.07);
            load += (target - load) * (1 - Math.Exp(-dt / tau));
            double L = Clamp01(load);
            var pf = eng.Pf;
            double rpmN = Clamp01((e.Rpm - pf.Rpm0) / (pf.Rpm1 - pf.Rpm0));
            // the idle recording takes over at low revs when the engine isn't pulling
            double idleMix = eng.Idle != null ? M.Smooth01((pf.IdleFade1 - e.Rpm) / (pf.IdleFade1 - pf.IdleFade0)) * (1 - 0.7 * L) : 0;

            // distance and doppler relative to the camera
            V3 d = e.CarPos - e.CamPos;
            double distM = Math.Max(0.5, d.Length());
            double vr = V3.Dot(e.CarVel - e.CamVel, d) / distM;
            double pitch = Math.Max(0.6, Math.Min(1.6, 343 / (343 + eng.Doppler * vr)));
            rpmTarget = Math.Max(100, Math.Min(12000, e.Rpm)); pitchTarget = Math.Max(0.25, Math.Min(4, pitch));

            // layer blend: on-throttle cycles vs exhaust overrun, equal power
            double a = Math.Sin((L * Math.PI) / 2), b = Math.Cos((L * Math.PI) / 2);
            double lvl = (0.55 + 0.45 * L) * (0.72 + 0.28 * rpmN) * pf.Level;
            double duck = 1 - 0.85 * idleMix;
            eng.AccC.Mix.Set(a * lvl * duck, 0.012, R);
            eng.DecC.Mix.Set((0.12 + 0.88 * b) * lvl * 0.9 * duck, 0.012, R);
            if (eng.Idle != null)
            {
                eng.Idle.Gain.Set(idleMix * 0.95 * pf.Level, 0.03, R);
                eng.Idle.Rate.Set(Math.Max(0.8, Math.Min(2.6, e.Rpm / eng.IdleRpm)) * pitch, 0.015, R);
            }
            eng.AccC.Drive.Set(0.85 + 1.1 * L, 0.03, R); // recording is low-load: push it harder under throttle
            dist.Set(Math.Min(1, 7 / distM), 0.05, R);
            airTarget = Math.Max(1400, Math.Min(16000, 16000 * (22 / distM)));

            // overrun pops: lift off at high revs, the limiter cutting in, and loaded upshifts
            if (e.Throttle > 0.6) hiLoadT = Math.Min(2, hiLoadT + dt); else hiLoadT = Math.Max(0, hiLoadT - dt * 0.5);
            if (lastThr > 0.45 && e.Throttle < 0.12 && e.Rpm > pf.PopRpm && hiLoadT > 0.4) overrun = 0.5 + Rand() * 1.1;
            if (overrun > 0)
            {
                overrun -= dt;
                if (e.Throttle > 0.2 || e.Rpm < pf.PopRpm - 1000) overrun = 0;
                else if (Rand() < dt * 11 * Math.Min(1, overrun / 0.8)) Pop(0.35 + Rand() * 0.65, pitch * pf.PopPitch);
            }
            if (e.Limiter && !wasLimiter && Rand() < 0.45) Pop(0.5 + Rand() * 0.4, pitch * pf.PopPitch);
            if (e.Shifting && !wasShift && e.Rpm > pf.Rpm1 - 1400 && hiLoadT > 0.5 && Rand() < 0.6) Pop(0.6 + Rand() * 0.4, pitch * pf.PopPitch);
            wasLimiter = e.Limiter; wasShift = e.Shifting; lastThr = e.Throttle;

            // gear changes
            if (lastGear != int.MinValue && e.Gear != lastGear)
            {
                bool up = e.Gear > lastGear;
                OneShot($"shift_{(up ? "up" : "down")}{1 + (int)Math.Floor(Rand() * 3)}", 0.75 + Rand() * 0.25, 0.95 + Rand() * 0.1);
            }
            lastGear = e.Gear;

            // tyres: each wheel adds roll and skid to the loops for the surface it is on
            double sp = Math.Abs(e.Speed);
            Span<double> rl = stackalloc double[4];
            Span<double> sk = stackalloc double[4];
            Span<double> skV = stackalloc double[4];
            double rumbleAmt = 0;
            foreach (var w in e.Wheels)
            {
                if (!w.Contact) continue;
                string sname = SURF_AUDIO[(int)w.Surface];
                int si = Array.IndexOf(AUDIO_SURF, sname);
                double lf = Math.Sqrt(Math.Max(0, Math.Min(2.5, w.Load)));
                rl[si] += 0.25 * lf * M.Smooth01((w.Speed - 0.3) / 5);
                sk[si] += 0.25 * lf * M.Smooth01((w.Slip - SKID_START[si]) / 5);
                skV[si] = Math.Max(skV[si], w.Slip);
                if (w.Surface == Surf.Rumble) rumbleAmt += 0.25 * lf * M.Smooth01((w.Speed - 0.8) / 4);
            }
            double sN = Clamp01(sp / 30);
            for (int i = 0; i < 4; i++)
            {
                if (roll[i] != null)
                {
                    roll[i].Gain.Set(ROLL_GAIN[i] * rl[i] * (0.3 + 0.7 * sN), 0.06, R);
                    roll[i].Rate.Set((0.7 + 0.55 * Math.Min(1.3, sp / 30)) * pitch, 0.1, R);
                }
                if (skid[i] != null)
                {
                    skid[i].Gain.Set(SKID_GAIN[i] * sk[i], 0.04, R);
                    skid[i].Rate.Set((0.9 + 0.22 * Clamp01((skV[i] - 2) / 12)) * pitch, 0.08, R);
                }
            }
            if (rumble != null)
            {
                // ridge hits per second = speed / ridge spacing; the recording hits at RumbleHz
                double rate = sp / sfx.RumbleSpacing / sfx.RumbleHz;
                double rlvl = rumbleAmt * (0.55 + 0.45 * Clamp01(sp / 20));
                rumble.Gain.Set(rlvl, 0.03, R);
                buzzG.Set(1.35 * rlvl * Clamp01((sp - 1) / 6), 0.03, R);
                // dip the engine a little while the tyres are on the strip so the rumble cuts through
                bus.Set(0.3 * (1 - 0.28 * Clamp01(rumbleAmt * 2)), 0.05, R);
                lfoTarget = Math.Max(2, Math.Min(120, sp / sfx.RumbleSpacing)) * pitch;
                rumble.Rate.Set(Math.Max(0.3, Math.Min(2.4, rate)) * pitch, 0.03, R);
            }
            wind.Set(Math.Min(0.45, Math.Pow(sp / 55, 2) * 0.45), 0.1, R);
        }

        // mono output, count samples
        public void Render(float[] o, int count)
        {
            int done = 0;
            while (done < count)
            {
                int nb = Math.Min(BLOCK, count - done);
                double bdt = nb / Rate;
                // k-rate parameters, once per block
                rpmNow += (rpmTarget - rpmNow) * (1 - Math.Exp(-bdt / 0.012));
                pitchNow += (pitchTarget - pitchNow) * (1 - Math.Exp(-bdt / 0.05));
                airFreq += (airTarget - airFreq) * (1 - Math.Exp(-bdt / airTau));
                lfoFreq += (lfoTarget - lfoFreq) * (1 - Math.Exp(-bdt / 0.03));
                air.Freq = airFreq; air.Update();
                Array.Clear(engBuf, 0, nb);
                if (eng != null) eng.Render(engBuf, nb, rpmNow, pitchNow, Rate);
                for (int i = 0; i < retiring.Count; i++) retiring[i].Render(engBuf, nb, rpmNow, pitchNow, Rate);
                for (int i = 0; i < nb; i++)
                {
                    // pops ride the exhaust side
                    double popSum = 0;
                    for (int k = pops.Count - 1; k >= 0; k--) { popSum += pops[k].Next(); if (pops[k].Done) pops.RemoveAt(k); }
                    double ve = vEngine.Next(), vt = vTyres.Next(), vc = vCrash.Next(), vf = vFx.Next();
                    double busOut = (engBuf[i] + popSum * 1.9) * bus.Next() * ve * gEngine.Next();
                    double x = air.Process(busOut);
                    // tyres
                    double tyres = 0;
                    for (int k = 0; k < 4; k++) { if (roll[k] != null) tyres += roll[k].Next(); if (skid[k] != null) tyres += skid[k].Next(); }
                    double shift = 0, hit = 0;
                    for (int k = shots.Count - 1; k >= 0; k--) { shift += shots[k].Next(); if (shots[k].Done) shots.RemoveAt(k); }
                    for (int k = hits.Count - 1; k >= 0; k--) { hit += hits[k].Next(); if (hits[k].Done) hits.RemoveAt(k); }
                    // rumble strip: saturated, high-passed and mid-lifted buzz plus a little dry low end
                    double rIn = rumble != null ? rumble.Next() : 0;
                    double rWet = rEq.Process(rHp2.Process(rHp1.Process(Shape.Dist(rIn * 2.6, rK)))) * 1.7;
                    double rDry = rLow.Process(rIn) * 0.45;
                    // buzz: band-passed noise through a square-wave VCA (0..1)
                    lfoPhase += lfoFreq / Rate; if (lfoPhase >= 1) lfoPhase -= Math.Floor(lfoPhase);
                    double vca = 0.5 + 0.5 * (lfoPhase < 0.5 ? 1 : -1);
                    double buzz = buzzBp.Process(noiseA.Next()) * vca * buzzG.Next();
                    double dsum = (x + (tyres * 0.9 + rWet + rDry + buzz) * vt * gTyres.Next() + shift * 0.72 * vf + hit * 0.9 * vc) * dist.Next();
                    double w = windLp.Process(noiseB.Next()) * wind.Next() * vf * gWind.Next();
                    double mst = (dsum + w) * 0.72 * masterOn.Next();
                    // master volume after the compressor and limiter, so it turns everything down evenly
                    double y = Shape.Soft(lim.Process(comp.Process(double.IsFinite(mst) ? mst : 0))) * vMaster.Next();
                    o[done + i] = (float)y;
                }
                done += nb;
            }
        }
    }
}
