// The extra timed courses a map pack can carry besides its main circuit (the compound: laps of the club circuit,
// the handling course and the oval; runs down the drag strip and the slaloms), and putting the car back on the
// nearest road.
using System;
using System.Collections.Generic;

namespace RustBucket.Sim
{
    // A sprint from a start line to a finish line (a drag strip, a slalom): the clock starts when the car crosses
    // the start line going the right way inside the lane, and stops at the finish line. Going far out of the lane
    // voids the run; leaving the course altogether, turning back over the start or two minutes stop it.
    public sealed class SprintTimer
    {
        readonly double sx, sz, dx, dz, len, half;
        double prevA; bool hasPrev;
        public bool Running, Valid;
        public double T, Speed;    // the run's time (the final time once finished) and the speed over the finish line

        public SprintTimer(CourseInfo c)
        {
            sx = c.SX; sz = c.SZ;
            double ex = c.FX - c.SX, ez = c.FZ - c.SZ;
            len = Math.Sqrt(ex * ex + ez * ez);
            dx = ex / len; dz = ez / len;
            half = c.Width / 2;
            Reset();
        }

        public void Reset() { hasPrev = false; Running = false; Valid = false; T = 0; Speed = 0; }

        // true on the frame a run starts; onFinish(time, valid, speed) when it reaches the finish line
        public bool Update(double dt, Car car, Action<double, bool, double> onFinish)
        {
            double rx = car.Pos.X - sx, rz = car.Pos.Z - sz;
            double a = rx * dx + rz * dz, l = -rx * dz + rz * dx;   // along the course, and across it
            bool lane = Math.Abs(l) < half + 1.5;
            bool started = false;
            if (Running)
            {
                T += dt;
                if (Math.Abs(l) > half + 4) Valid = false;
                if (Math.Abs(l) > half + 40 || a < -2 || T > 120) Running = false;
            }
            if (hasPrev && lane)
            {
                if (Running && prevA < len && a >= len)
                {
                    // the time at the line itself, between this frame and the last
                    double f = (a - len) / Math.Max(a - prevA, 1e-6);
                    T -= f * dt;
                    Running = false; Speed = Math.Abs(car.Vel.X * dx + car.Vel.Z * dz);
                    onFinish(T, Valid, Speed);
                }
                else if (!Running && prevA < 0 && a >= 0)
                {
                    Running = true; Valid = true; T = a / Math.Max(a - prevA, 1e-6) * dt; Speed = 0; started = true;
                }
            }
            prevA = a; hasPrev = true;
            return started;
        }
    }

    // every extra course of a map, timed side by side: the one being driven is the one shown
    public sealed class CourseSet
    {
        public sealed class Entry
        {
            public CourseInfo Info;
            public LapTimer Lap;
            public SprintTimer Sprint;
            public double Order;   // when it last started: the latest start is the one shown
            public bool Running => Lap != null ? Lap.Running : Sprint.Running;
            public bool Valid => Lap != null ? Lap.Valid : Sprint.Valid;
            public double T => Lap != null ? Lap.T : Sprint.T;
        }

        public readonly List<Entry> All = new List<Entry>();
        double clock;
        readonly List<(Entry e, double t, bool valid)> pending = new List<(Entry, double, bool)>();
        public bool HasMain { get { foreach (var e in All) if (e.Info.Main) return true; return false; } }

        public CourseSet(List<CourseInfo> list)
        {
            foreach (var c in list)
            {
                var e = new Entry { Info = c };
                if (c.Sprint) e.Sprint = new SprintTimer(c);
                else
                {
                    var path = new PolyPath(c.Line, true, c.LineY);
                    e.Lap = new LapTimer(new Circuit { Path = path, Width = c.Width, SLine = 0, Mesh = true, Name = c.Name });
                }
                All.Add(e);
            }
        }

        public void Reset() { foreach (var e in All) { e.Lap?.Reset(); e.Sprint?.Reset(); e.Order = 0; } }

        // the course being timed now: the one started last; of a group started together (a circuit's
        // configurations), the one being driven: still clean, and most of the lap on it
        public Entry Active
        {
            get
            {
                Entry best = null;
                foreach (var e in All)
                {
                    if (!e.Running) continue;
                    if (best == null || e.Order > best.Order + 1e-9) { best = e; continue; }
                    if (e.Order < best.Order - 1e-9) continue;
                    if (e.Valid != best.Valid) { if (e.Valid) best = e; continue; }
                    if (e.Lap != null && best.Lap != null && e.Lap.Coverage > best.Lap.Coverage + 1e-6) best = e;
                }
                return best;
            }
        }

        // onDone(course, time, valid, speed: NaN for a lap); onStart(course) when a sprint starts
        public void Update(double dt, Car car, Action<Entry, double, bool, double> onDone, Action<Entry> onStart)
        {
            clock += dt;
            foreach (var e in All)
            {
                if (e.Lap != null)
                {
                    bool was = e.Lap.Running; double t0 = e.Lap.T;
                    e.Lap.Update(dt, car, (t, v) =>
                    {
                        if (e.Info.Group.Length > 0) pending.Add((e, t, v));
                        else onDone(e, t, v, double.NaN);
                    });
                    if (e.Lap.Running && (!was || e.Lap.T < t0)) e.Order = clock;   // a lap begun
                }
                else if (e.Sprint.Update(dt, car, (t, v, sp) => onDone(e, t, v, sp)))
                {
                    e.Order = clock;
                    onStart(e);
                }
            }
            // a group's laps end together at its shared line: only the configuration actually driven reports (the
            // clean one; with none clean, the one the lap mostly ran on, if it ran on one)
            while (pending.Count > 0)
            {
                string g = pending[0].e.Info.Group;
                int pick = -1; bool anyValid = false;
                for (int i = 0; i < pending.Count; i++)
                {
                    var p = pending[i];
                    if (p.e.Info.Group != g) continue;
                    if (pick < 0) { pick = i; anyValid = p.valid; continue; }
                    var q = pending[pick];
                    if (p.valid && !q.valid) { pick = i; anyValid = true; }
                    else if (p.valid == q.valid && p.e.Lap.LastCoverage > q.e.Lap.LastCoverage) pick = i;
                }
                var best = pending[pick];
                if (anyValid || best.e.Lap.LastCoverage > 0.85) onDone(best.e, best.t, best.valid, double.NaN);
                pending.RemoveAll(x => x.e.Info.Group == g);
            }
        }
    }

    // the roads of a map pack: the nearest point on any of them, for putting the car back on the road
    public static class RoadFinder
    {
        public struct Hit { public double X, Y, Z, Hx, Hz, Dist, Half; public bool Found; }

        // the nearest centreline point to (x, y, z), weighting height so a road passing overhead or underneath
        // doesn't count as near; its heading (hx, hz) points along the road
        public static Hit Nearest(List<RoadLine> roads, double x, double y, double z)
        {
            var h = new Hit();
            double best = double.PositiveInfinity;
            foreach (var r in roads)
            {
                var p = r.Pts; int n = p.Length / 3;
                for (int i = 0; i < n; i++)
                {
                    double ex = p[i * 3] - x, ey = p[i * 3 + 1] - y, ez = p[i * 3 + 2] - z;
                    double d = ex * ex + ez * ez + 4 * ey * ey;
                    if (d >= best) continue;
                    best = d;
                    int a = Math.Max(0, i - 1), b = Math.Min(n - 1, i + 1);
                    if (r.Loop) { a = (i - 1 + n) % n; b = (i + 1) % n; }
                    double tx = p[b * 3] - p[a * 3], tz = p[b * 3 + 2] - p[a * 3 + 2], tl = Math.Sqrt(tx * tx + tz * tz);
                    if (!(tl > 1e-6)) { tx = 1; tz = 0; tl = 1; }
                    h = new Hit { X = p[i * 3], Y = p[i * 3 + 1], Z = p[i * 3 + 2], Hx = tx / tl, Hz = tz / tl, Dist = Math.Sqrt(ex * ex + ez * ez), Half = r.Half, Found = true };
                }
            }
            return h;
        }

        public static bool OnPad(List<(double x0, double z0, double x1, double z1)> pads, double x, double z, double margin = 2)
        {
            foreach (var p in pads) if (x > p.x0 - margin && x < p.x1 + margin && z > p.z0 - margin && z < p.z1 + margin) return true;
            return false;
        }
    }
}
