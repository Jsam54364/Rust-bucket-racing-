#!/usr/bin/env bash
# GitHub Actions build, run by .github/workflows/main.yml:
#   1. download Godot (.NET) and its export templates
#   2. compile the C#
#   3. import the assets
#   4. self-test: run the game on a virtual screen (software OpenGL), drive every car on both maps, take screenshots
#   5. export the Android APK and check the C# code is inside it
#   6. publish: the APK as the release "latest-apk", the logs and screenshots on the branch "ci-logs"
# The job fails (red X) only if the C# build or the export fails; the self-test result is in the summary.
set -uo pipefail

GODOT_VERSION="${GODOT_VERSION:-4.7.2}"
WS="${GITHUB_WORKSPACE:-$PWD}"
PROJ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$WS/out"
rm -rf "$OUT"; mkdir -p "$OUT/shots"
S_BUILD="not run"; S_IMPORT="not run"; S_SMOKE="not run"; S_EXPORT="not run"; S_DOTNET="not checked"
APK="$OUT/RustBucketRacing.apk"
REPO="${GITHUB_REPOSITORY:-}"
DL="https://github.com/$REPO/releases/latest/download/RustBucketRacing.apk"

summary() {
  {
    echo "## Rust Bucket Racing build"
    echo
    echo "| Step | Result |"
    echo "|---|---|"
    echo "| C# build | $S_BUILD |"
    echo "| Asset import | $S_IMPORT |"
    echo "| Self-test (Linux, software OpenGL) | $S_SMOKE |"
    echo "| Android export | $S_EXPORT |"
    echo "| C# code inside the APK | $S_DOTNET |"
    echo
    if [ -s "$APK" ]; then echo "**Download the APK on your phone:** $DL"; else echo "No APK this time."; fi
    echo
    echo "Commit ${GITHUB_SHA:-local} · run ${GITHUB_RUN_ID:-local}"
  } > "$OUT/summary.md"
  [ -n "${GITHUB_STEP_SUMMARY:-}" ] && cat "$OUT/summary.md" >> "$GITHUB_STEP_SUMMARY"
  cat "$OUT/summary.md"
}

publish() {
  local code=$?
  summary
  if [ -n "$REPO" ] && [ -n "${GH_TOKEN:-}" ]; then
    if [ -s "$APK" ]; then
      echo "Publishing the APK to the release latest-apk"
      local notes="Built from ${GITHUB_SHA:0:7} on $(date -u '+%Y-%m-%d %H:%M UTC'). Self-test: $S_SMOKE."
      if gh release view latest-apk --repo "$REPO" >/dev/null 2>&1; then
        gh release upload latest-apk "$APK" --repo "$REPO" --clobber && gh release edit latest-apk --repo "$REPO" --notes "$notes" --latest \
          || echo "::warning::could not update the release"
      else
        gh release create latest-apk "$APK" --repo "$REPO" --target "${GITHUB_SHA}" --title "Latest build" --notes "$notes" --latest \
          || echo "::warning::could not create the release"
      fi
    fi
    echo "Publishing the logs and screenshots to the branch ci-logs"
    local d; d="$(mktemp -d)"
    cp "$OUT"/*.log "$OUT"/*.txt "$OUT"/*.md "$d"/ 2>/dev/null
    cp -r "$OUT/shots" "$d"/ 2>/dev/null
    (
      cd "$d" && git init -q && git checkout -q -b ci-logs && git add -A &&
      git -c user.name="github-actions[bot]" -c user.email="41898282+github-actions[bot]@users.noreply.github.com" \
        commit -q -m "Build logs for ${GITHUB_SHA:0:7} (run ${GITHUB_RUN_ID:-})" &&
      git push -q -f "https://x-access-token:${GH_TOKEN}@github.com/${REPO}.git" ci-logs
    ) || echo "::warning::could not publish the logs"
  fi
  exit $code
}
trap publish EXIT

echo "::group::Download Godot ${GODOT_VERSION} (.NET) and its export templates"
base="https://github.com/godotengine/godot-builds/releases/download/${GODOT_VERSION}-stable"
cd "$HOME"
wget -q "$base/Godot_v${GODOT_VERSION}-stable_mono_linux_x86_64.zip" || { S_BUILD="could not download Godot"; exit 1; }
wget -q "$base/Godot_v${GODOT_VERSION}-stable_mono_export_templates.tpz" || { S_BUILD="could not download the export templates"; exit 1; }
unzip -q "Godot_v${GODOT_VERSION}-stable_mono_linux_x86_64.zip" -d "$HOME/godot"
unzip -q "Godot_v${GODOT_VERSION}-stable_mono_export_templates.tpz" -d "$HOME/tpl"
tdir="$HOME/.local/share/godot/export_templates/${GODOT_VERSION}.stable.mono"
mkdir -p "$tdir" && mv "$HOME"/tpl/templates/* "$tdir/"
rm -f ./*.zip ./*.tpz
GODOT="$HOME/godot/Godot_v${GODOT_VERSION}-stable_mono_linux_x86_64/Godot_v${GODOT_VERSION}-stable_mono_linux.x86_64"
chmod +x "$GODOT"
echo "::endgroup::"

echo "::group::Debug keystore and Android editor settings"
# a fixed debug key (ci/debug.keystore, password "android") so each new APK installs over the last one
if [ -f "$PROJ/ci/debug.keystore" ]; then cp "$PROJ/ci/debug.keystore" "$HOME/debug.keystore"
else keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "$HOME/debug.keystore" \
  -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 >/dev/null 2>&1; fi
mkdir -p "$HOME/.config/godot"
sdk="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
for f in "editor_settings-${GODOT_VERSION%.*}.tres" "editor_settings-4.tres"; do
  {
    echo '[gd_resource type="EditorSettings" format=3]'
    echo ''
    echo '[resource]'
    echo "export/android/java_sdk_path = \"${JAVA_HOME:-}\""
    echo "export/android/android_sdk_path = \"$sdk\""
    echo "export/android/debug_keystore = \"$HOME/debug.keystore\""
    echo 'export/android/debug_keystore_user = "androiddebugkey"'
    echo 'export/android/debug_keystore_pass = "android"'
  } > "$HOME/.config/godot/$f"
done
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$HOME/debug.keystore"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android
echo "::endgroup::"

cd "$PROJ"

echo "::group::Compile the C#"
dotnet build RustBucket.csproj -c Debug -nologo -clp:"ErrorsOnly;Summary" > "$OUT/csharp-build.log" 2>&1
rc=$?
cat "$OUT/csharp-build.log"
echo "::endgroup::"
if [ $rc -ne 0 ]; then S_BUILD="**failed**: see csharp-build.log"; exit 1; fi
S_BUILD="ok"

echo "::group::Import the project (models, textures, shaders)"
timeout 900 "$GODOT" --headless --import > "$OUT/import.log" 2>&1
S_IMPORT="done, $(grep -c 'ERROR' "$OUT/import.log") error lines"
tail -n 40 "$OUT/import.log"
echo "::endgroup::"

echo "::group::Self-test on a virtual screen"
(sudo apt-get update -qq && sudo apt-get install -y -qq xvfb libgl1-mesa-dri libegl1 >/dev/null) > /dev/null 2>&1 || true
timeout 600 xvfb-run -a -s "-screen 0 1600x720x24" "$GODOT" --path "$PROJ" --audio-driver Dummy --resolution 1600x720 \
  -- --smoke --shots="$OUT/shots" > "$OUT/smoke.log" 2>&1
src=$?
errs=$(grep -c 'ERROR' "$OUT/smoke.log")
if grep -q "SMOKE OK" "$OUT/smoke.log"; then S_SMOKE="passed, $errs error lines"
else S_SMOKE="**failed** (exit $src, $errs error lines): see smoke.log"; echo "::warning::self-test failed"; fi
grep -E "\[smoke\]|\[boot\]|\[crash\]|ERROR|Exception|   at " "$OUT/smoke.log" | head -n 300
echo "::endgroup::"

echo "::group::Export the Android APK"
"$GODOT" --headless --export-debug "Android" "$APK" > "$OUT/export.log" 2>&1
erc=$?
cat "$OUT/export.log" | tail -n 80
echo "::endgroup::"
if grep -qiE "no solution file|dotnet publish exited|publish method threw|Failed to build|project assembly not found" "$OUT/export.log"; then
  S_EXPORT="**failed**: the C# code was not published, see export.log"; rm -f "$APK"; exit 1
fi
if [ ! -s "$APK" ]; then S_EXPORT="**failed** (exit $erc): see export.log"; exit 1; fi
S_EXPORT="ok, $(du -h "$APK" | cut -f1)"
unzip -l "$APK" > "$OUT/apk-contents.txt" 2>&1
if grep -q "RustBucket.dll" "$OUT/apk-contents.txt"; then S_DOTNET="yes"
else S_DOTNET="**not found**: see apk-contents.txt"; echo "::warning::RustBucket.dll not found in the APK"; fi
exit 0
