# Rust Bucket Racing (Godot 4.7, C#, mobile)

This is a Godot port of the browser game. It includes all three cars (Rust Bucket, Monte Carlo SS and CTS-V race car) and both maps (the proving ground with its race track, and Spa-Francorchamps 1992). It also includes:

- the 480 Hz suspension, tyre and drivetrain simulation;
- the granular engine sound;
- every camera, including the interior cameras;
- touch controls, the HUD, telemetry, the car setup and controls panels, and the lap timer.

The game is built for phones in landscape. It also runs on desktop with a keyboard or gamepad, which is the quickest way to try it.

> **This project has not been compiled yet.** It was written in a workspace that couldn't download Godot or the .NET SDK. The first time you open it there may be a few C# compile errors or shader warnings. Copy the messages from Godot's **MSBuild** / **Output** panels and send them over. They are usually one-line fixes.

## What you need

| | |
|---|---|
| Godot | **4.7.2, .NET edition** (godotengine.org → Download → "Godot Engine - .NET") |
| .NET SDK | **9.0 or newer** (Android export needs 9; desktop needs 8 or later) |
| Android export | JDK 17, the Android SDK (easiest to get through Android Studio), and Godot's export templates (.NET) |
| iOS export | A Mac with Xcode, and an Apple developer account for signing |

If you use a different 4.7.x editor, change the version on the first line of `RustBucket.csproj` (`Godot.NET.Sdk/4.7.2`) to match it.

## First run (desktop)

1. Unzip the project and open `project.godot` in Godot 4.7 .NET. The first import takes a minute: it imports `models/rust.glb` and compiles the shaders.
2. Press the hammer icon (**Build**) at the top right. If there are errors, the MSBuild panel at the bottom lists them.
3. Press **Run** (F5). The start sheet lets you pick a car and a map; **Drive** starts.

## Build the APK on GitHub (no Godot or .NET needed)

The project includes `.github/workflows/android.yml`. Put the project in a GitHub repository, and every push builds a debug APK on GitHub's servers. The build downloads Godot 4.7.2 .NET, the export templates and the .NET 9 SDK, compiles the C#, imports the assets and exports the APK.

To get the APK, open the repository's **Actions** tab, then the latest run, and download **RustBucketRacing-apk**. Unzip it and install the `.apk` on your phone; Android asks you to allow installs from that app the first time. If a run fails, the **build-logs** artifact has the compiler and export messages.

## Export to Android

1. In **Editor → Manage Export Templates**, download the templates for your Godot version.
2. In **Editor → Editor Settings → Export → Android**, set:
   - **Java SDK Path**, to your JDK 17 folder;
   - **Android SDK Path**, to the folder Android Studio installed the SDK into;
   - a debug keystore. Godot can make one for you; see "Exporting for Android" in the Godot docs.
3. **Project → Export…** already has an **Android** preset, set to arm64 with the package name `com.rustbucket.racing`. Press **Export Project** to get an APK, or plug in a phone with USB debugging enabled and use the one-click deploy icon at the top right of the editor.

The game data under `data/` (maps, car packs and engine recordings) is included through the preset's **Resources → Filters to export non-resource files** = `data/*`. Keep that filter if you make a new preset.

## Export to iOS

On a Mac, add your Apple **Team ID** to the iOS preset (**Project → Export → iOS → App Store Team ID**) and export. This creates an Xcode project; build and sign it in Xcode. Godot's C# support on iOS is still marked experimental.

## Controls

**Touch** (shown automatically on touch screens):

- **Left thumb.** Slide along the steering pad. Flick the gear slider up or down to shift, or tap either end of it.
- **Right thumb.** Use **Gas**, **Brake** and **Hand**. Gas and Brake are pressure-sensitive: press higher on the pedal for more, lower to feather it.
- **Top right.** The camera button cycles chase, orbit, bumper, interior and trackside. The menu button opens the car, map, gearbox, car setup, controls, resets and sound.
- **Orbit camera.** Drag to fly round the car; pinch to zoom.
- **Controls panel.** Switches the steering pad to two buttons, and turns analogue pedals on or off.

**Keyboard:**

| Key | Action |
|---|---|
| W / S | throttle, brake |
| A / D | steer |
| Space | handbrake |
| Q / E | shift down / up |
| C | camera |
| G | telemetry |
| T | car setup |
| K | controls |
| M | gearbox mode |
| V | next car |
| N | next map |
| L | starting grid |
| R | reset (Shift+R: back to the start) |
| H | help |
| + / − or mouse wheel | zoom |
| drag | look around |

**Gamepad:**

| Input | Action |
|---|---|
| left stick | steer |
| RT / LT | throttle / brake |
| A or B | handbrake |
| RB / LB | shift up / down |
| Y | camera |
| X | gearbox mode |
| Start | reset |
| Back | car setup |

## Project layout

```
project.godot, RustBucket.csproj, export_presets.cfg, Main.tscn (one node, scripts/Game/Main.cs)
data/       spa.bin (map pack), monte.bin / cts.bin (car packs), engine_*.json, sfx.json
models/     rust.glb (imported by Godot)
shaders/    surface (proving ground), track, world_* (Spa), skid, smoke, shared includes
scripts/Sim/     the simulation, a line-by-line port of physics.js (pure C#, no Godot types)
scripts/Render/  map chunks, proving-ground meshes, car models, skid marks, smoke
scripts/Audio/   granular engine, tyres, kerbs, wind, shifts, pops; AudioStreamGenerator output
scripts/Game/    main loop, cameras, input, touch controls, HUD, menus, settings
```

The whole scene is built in code at start-up, so there is nothing to wire up in the editor.

## Tuning the look

The browser version had its own lighting. This port uses Godot's sun, sky, shadows, fog and ACES tonemapping instead, so colours won't match exactly. You can adjust them with the constants at the top of `scripts/Game/Main.cs`:

- `SunEnergy`
- `AmbientSky`
- `Exposure`
- `FogGrid`
- `FogMap`

The renderer is **Compatibility** (OpenGL ES 3), which runs on the widest range of phones. The game also lowers its 3D resolution, down to 60 %, if frames run long.

## Credits

All models are CC BY 4.0:

- "Lowpoly Abandoned Simple Car Prop" by Rashad Ibrahimli
- "1987 Chevrolet Monte Carlo SS" by Randomness
- "Circuit de Spa-Francorchamps 1992 layout" by Dave Love (sketchfab.com/Tyler_Dave)
- "2004 Cadillac CTS-V race car" by Dave Love (sketchfab.com/Tyler_Dave)
