// Shared look: one dark HUD theme (it sits over a bright scene) and small widget factories.
// Sizes are in logical pixels of the 1280x720 base canvas (the canvas stretches to fit the screen).
using System;
using Godot;

namespace RustBucket.Game
{
    public static class Ui
    {
        public static readonly Color Bg = Hex(0x0d1013), Panel = Hex(0x12171c), Ink = Hex(0xedf1f4), Muted = Hex(0x95a0aa);
        public static readonly Color Amber = Hex(0xffb01f), Cool = Hex(0x5aa9ff), Hot = Hex(0xff5b3d), Ok = Hex(0x48d38a);
        public static readonly Color Glass = new Color(11 / 255f, 14 / 255f, 18 / 255f, 0.62f);
        public static readonly Color Line = new Color(206 / 255f, 220 / 255f, 234 / 255f, 0.16f);
        public static readonly Color AmberInk = Hex(0x1a1205);

        public const int FontBody = 22, FontSmall = 18, FontTiny = 15, FontTitle = 40;

        public static Color Hex(int rgb) => new Color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f);

        static Font display;
        // condensed bold for numbers and headings, if the system has one; the default font otherwise
        public static Font Display
        {
            get
            {
                if (display == null)
                {
                    var sf = new SystemFont { FontNames = new[] { "Roboto Condensed", "Arial Narrow", "sans-serif-condensed", "Helvetica Neue", "sans-serif" }, FontWeight = 700 };
                    sf.Fallbacks = new Godot.Collections.Array<Font> { ThemeDB.FallbackFont };
                    display = sf;
                }
                return display;
            }
        }
        public static Font Body => ThemeDB.FallbackFont;

        public static StyleBoxFlat Box(Color bg, int radius, Color? border = null, int borderW = 0, float pad = 0)
        {
            var sb = new StyleBoxFlat { BgColor = bg };
            sb.SetCornerRadiusAll(radius);
            if (border.HasValue && borderW > 0) { sb.BorderColor = border.Value; sb.SetBorderWidthAll(borderW); }
            sb.SetContentMarginAll(pad);
            sb.AntiAliasing = true;
            return sb;
        }

        // styleboxes for _Draw calls, made once per look (they are native objects: don't make them every frame)
        static readonly System.Collections.Generic.Dictionary<(Color, int, Color, int), StyleBoxFlat> cache = new System.Collections.Generic.Dictionary<(Color, int, Color, int), StyleBoxFlat>();
        public static StyleBoxFlat Cached(Color bg, int radius, Color? border = null, int borderW = 0)
        {
            var key = (bg, radius, border ?? new Color(0, 0, 0, 0), border.HasValue ? borderW : 0);
            if (!cache.TryGetValue(key, out var sb)) { sb = Box(bg, radius, border, borderW); cache[key] = sb; }
            return sb;
        }

        static Theme theme;
        public static Theme Theme
        {
            get
            {
                if (theme != null) return theme;
                var t = new Theme { DefaultFontSize = FontBody };
                // buttons
                var bn = Box(new Color(1, 1, 1, 0.05f), 10, Line, 1, 10);
                var bh = Box(new Color(1, 1, 1, 0.10f), 10, new Color(Amber, 0.55f), 1, 10);
                var bp = Box(Amber, 10, Amber, 1, 10);
                foreach (var type in new[] { "Button" })
                {
                    t.SetStylebox("normal", type, bn); t.SetStylebox("hover", type, bh); t.SetStylebox("pressed", type, bp);
                    t.SetStylebox("hover_pressed", type, bp); t.SetStylebox("focus", type, new StyleBoxEmpty()); t.SetStylebox("disabled", type, bn);
                    t.SetColor("font_color", type, Ink); t.SetColor("font_hover_color", type, Ink); t.SetColor("font_pressed_color", type, AmberInk);
                    t.SetColor("font_hover_pressed_color", type, AmberInk); t.SetColor("font_focus_color", type, Ink); t.SetColor("font_disabled_color", type, Muted);
                    t.SetFontSize("font_size", type, FontBody);
                }
                t.SetColor("font_color", "Label", Ink);
                t.SetFontSize("font_size", "Label", FontBody);
                t.SetStylebox("panel", "PanelContainer", Box(Panel, 14, Line, 1, 0));
                // sliders: a thick track and a big round grabber for thumbs
                t.SetStylebox("slider", "HSlider", Box(new Color(1, 1, 1, 0.16f), 5, null, 0, 5));
                t.SetStylebox("grabber_area", "HSlider", Box(new Color(Amber, 0.55f), 5, null, 0, 5));
                t.SetStylebox("grabber_area_highlight", "HSlider", Box(new Color(Amber, 0.75f), 5, null, 0, 5));
                var knob = Circle(34, Amber);
                t.SetIcon("grabber", "HSlider", knob); t.SetIcon("grabber_highlight", "HSlider", knob); t.SetIcon("grabber_disabled", "HSlider", knob);
                // scroll bars: thin
                t.SetStylebox("scroll", "VScrollBar", Box(new Color(1, 1, 1, 0.04f), 4, null, 0, 2));
                t.SetStylebox("grabber", "VScrollBar", Box(new Color(1, 1, 1, 0.22f), 4, null, 0, 2));
                t.SetStylebox("grabber_highlight", "VScrollBar", Box(new Color(1, 1, 1, 0.35f), 4, null, 0, 2));
                t.SetStylebox("grabber_pressed", "VScrollBar", Box(new Color(Amber, 0.6f), 4, null, 0, 2));
                theme = t;
                return t;
            }
        }

        public static ImageTexture Circle(int d, Color c)
        {
            var img = Image.CreateEmpty(d, d, false, Image.Format.Rgba8);
            float r = d / 2f;
            for (int y = 0; y < d; y++)
                for (int x = 0; x < d; x++)
                {
                    float dx = x + 0.5f - r, dy = y + 0.5f - r;
                    float a = Mathf.Clamp(r - Mathf.Sqrt(dx * dx + dy * dy), 0, 1);
                    img.SetPixel(x, y, new Color(c, a));
                }
            return ImageTexture.CreateFromImage(img);
        }

        public static Label Text(string s, int size = FontBody, Color? col = null, bool wrap = false)
        {
            var l = new Label { Text = s, MouseFilter = Control.MouseFilterEnum.Ignore };
            l.AddThemeFontSizeOverride("font_size", size);
            if (col.HasValue) l.AddThemeColorOverride("font_color", col.Value);
            if (wrap) { l.AutowrapMode = TextServer.AutowrapMode.WordSmart; l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill; }
            return l;
        }

        // section heading: small caps-ish, muted
        public static Label Heading(string s)
        {
            var l = Text(s.ToUpperInvariant(), FontTiny, Muted);
            return l;
        }

        public static Button Btn(string s, Action onPress, bool toggle = false, int minH = 54)
        {
            var b = new Button { Text = s, ToggleMode = toggle, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, minH) };
            b.Pressed += () => onPress?.Invoke();
            return b;
        }

        // row of equal toggle buttons, one of which is lit
        public static HBoxContainer Seg(string[] labels, Action<int> onPick, out Button[] buttons, int minH = 50)
        {
            var row = new HBoxContainer();
            row.AddThemeConstantOverride("separation", 6);
            var bs = new Button[labels.Length];
            for (int i = 0; i < labels.Length; i++)
            {
                int k = i;
                var b = Btn(labels[i], () => onPick(k), true, minH);
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                b.ClipText = true;
                b.AddThemeFontSizeOverride("font_size", FontSmall);
                bs[i] = b;
                row.AddChild(b);
            }
            buttons = bs;
            return row;
        }

        public static void Light(Button[] bs, int on)
        {
            for (int i = 0; i < bs.Length; i++) bs[i].SetPressedNoSignal(i == on);
        }

        public static VBoxContainer Col(int sep = 8)
        {
            var v = new VBoxContainer();
            v.AddThemeConstantOverride("separation", sep);
            return v;
        }

        public static HBoxContainer Row(int sep = 8)
        {
            var h = new HBoxContainer();
            h.AddThemeConstantOverride("separation", sep);
            return h;
        }

        public static MarginContainer Pad(Control child, int l, int t, int r, int b)
        {
            var m = new MarginContainer { SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
            m.AddThemeConstantOverride("margin_left", l); m.AddThemeConstantOverride("margin_top", t);
            m.AddThemeConstantOverride("margin_right", r); m.AddThemeConstantOverride("margin_bottom", b);
            m.AddChild(child);
            return m;
        }

        public static HSeparator Sep()
        {
            var s = new HSeparator();
            var sb = new StyleBoxLine { Color = Line, Thickness = 1 };
            s.AddThemeStyleboxOverride("separator", sb);
            return s;
        }

        // label + value readout + slider
        public sealed class SliderRow
        {
            public VBoxContainer Root;
            public HSlider Slider;
            public Label Value;
            public Func<double, string> Fmt;

            public void Show(double v) { Slider.SetValueNoSignal(v); Value.Text = Fmt(v); }
        }

        public static SliderRow Slider(string label, double min, double max, double step, Func<double, string> fmt, Action<double> onChange)
        {
            var r = new SliderRow { Root = Col(2), Fmt = fmt };
            var head = Row();
            var l = Text(label, FontSmall);
            l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            r.Value = Text("", FontSmall, Amber);
            head.AddChild(l); head.AddChild(r.Value);
            r.Slider = new HSlider { MinValue = min, MaxValue = max, Step = step, CustomMinimumSize = new Vector2(0, 46), FocusMode = Control.FocusModeEnum.None };
            r.Slider.ValueChanged += (double v) => { r.Value.Text = fmt(v); onChange(v); };
            r.Root.AddChild(head); r.Root.AddChild(r.Slider);
            return r;
        }
    }
}
