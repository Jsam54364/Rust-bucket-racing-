// Start-up breadcrumbs, the "still starting / loading" marker the boot screen checks, and the
// "Copy debug log" menu item. Godot writes its log to user://logs/godot.log (see project.godot).
using System;
using Godot;

namespace RustBucket.Game
{
    public static class DebugLog
    {
        const string STATE = "user://boot_state.txt";

        public static void Trace(string s) => GD.Print("[boot] " + s);

        // "ok" once the game is running; anything else means it was starting or loading. If the app dies before
        // the next "ok", scripts/Boot.gd shows that run's log on the next launch.
        public static void State(string s)
        {
            try
            {
                using var f = FileAccess.Open(STATE, FileAccess.ModeFlags.Write);
                f?.StoreString(s);
            }
            catch (Exception) { }
        }

        public static string DeviceInfo()
        {
            string ver = Engine.GetVersionInfo()["string"].AsString();
            return OS.GetName() + " " + OS.GetVersion() + " · " + OS.GetModelName() + " · " + RenderingServer.GetVideoAdapterVendor() + " " +
                RenderingServer.GetVideoAdapterName() + " · " + RenderingServer.GetVideoAdapterApiVersion() + " · Godot " + ver;
        }

        public static string Tail(int lines = 200)
        {
            try
            {
                string path = ProjectSettings.GetSetting("debug/file_logging/log_path", "user://logs/godot.log").AsString();
                if (!FileAccess.FileExists(path)) return "(no log file)";
                var all = FileAccess.GetFileAsString(path).Split('\n');
                int start = Math.Max(0, all.Length - lines);
                return string.Join("\n", all, start, all.Length - start);
            }
            catch (Exception e) { return "(could not read the log: " + e.Message + ")"; }
        }

        public static void CopyToClipboard()
        {
            DisplayServer.ClipboardSet("Rust Bucket Racing debug log\n" + DeviceInfo() + "\n----\n" + Tail());
        }
    }
}
