// A square button with a drawn icon (camera or menu). Its own file: Godot only calls overrides like _Draw on
// C# classes that live in a file with the same name.
using Godot;

namespace RustBucket.Game
{
    public partial class IconButton : Button
    {
        public int Icon; // 0 camera, 1 menu

        public override void _Draw()
        {
            var s = Size; var c = s / 2; var col = Ui.Ink; float k = s.X * 0.55f / 24f; var o = c - new Vector2(12 * k, 12 * k);
            if (Icon == 1)
            {
                for (int i = -1; i <= 1; i++) DrawLine(c + new Vector2(-7 * k, i * 4.5f * k), c + new Vector2(7 * k, i * 4.5f * k), col, 2.2f, true);
            }
            else
            {
                Vector2 P(float x, float y) => o + new Vector2(x * k, y * k);
                var pts = new[] { P(3.5f, 8.5f), P(6.7f, 8.5f), P(8.5f, 6), P(15.5f, 6), P(17.3f, 8.5f), P(20.5f, 8.5f), P(20.5f, 19), P(3.5f, 19), P(3.5f, 8.5f) };
                DrawPolyline(pts, col, 2f, true);
                DrawArc(P(12, 13.3f), 3.4f * k, 0, Mathf.Tau, 32, col, 2f, true);
            }
        }
    }
}
