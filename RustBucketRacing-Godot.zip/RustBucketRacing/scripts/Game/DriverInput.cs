// Merges keyboard, gamepad and the touch controls into the car's driver inputs.
using System;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public enum GameAction { None, Camera, Reset, ResetStart, Setup, Telemetry, Fullscreen, Help, Escape, Controls, Gearbox, Grid, NextCar, NextMap, ShiftUp, ShiftDown, Touch }

    public sealed class ControlPrefs
    {
        public double Sens = 1;          // steering response curve / key wind-on speed
        public bool ButtonSteer;         // touch: two buttons instead of the slider pad
        public bool AnalogPedals = true; // touch: press higher on Gas / Brake for more
    }

    public sealed class DriverInput
    {
        public readonly DriveInput State = new DriveInput();
        public readonly ControlPrefs Prefs;
        public Action<GameAction> OnAction = (a) => { };
        double dSteer;
        public bool Analog;
        // touch state, written by TouchControls
        public double TouchGas, TouchBrake;
        public bool TouchHand, TouchLeft, TouchRight, TouchSteerActive;
        public double TouchSteerVal;
        readonly bool[] padPrev = new bool[16];

        public DriverInput(ControlPrefs prefs) { Prefs = prefs; }

        static bool K(Key k) => Input.IsPhysicalKeyPressed(k);

        public DriveInput Update(double dt, bool keysEnabled)
        {
            var s = State;
            var c = Prefs;
            double sens = c.Sens > 0 ? c.Sens : 1;
            bool kb = keysEnabled;
            double thr = Math.Max(kb && (K(Key.W) || K(Key.Up)) ? 1 : 0, TouchGas);
            double brk = Math.Max(kb && (K(Key.S) || K(Key.Down)) ? 1 : 0, TouchBrake);
            // analogue steering: response curve (sensitivity > 1 = more lock for a small movement, full lock still at the end)
            double Curve(double x) => M.Sgn(x) * Math.Pow(Math.Min(1, Math.Abs(x)), 1 / sens);
            // keys and touch buttons: holding one winds the steering on; sensitivity sets how quickly
            double dTarget = ((kb && (K(Key.A) || K(Key.Left))) || TouchLeft ? 1 : 0) - ((kb && (K(Key.D) || K(Key.Right))) || TouchRight ? 1 : 0);
            bool winding = dTarget != 0 && (M.Sgn(dTarget) == M.Sgn(dSteer) || dSteer == 0) && Math.Abs(dTarget) > Math.Abs(dSteer);
            double r = (winding ? 6 * sens : 15) * dt;
            dSteer += M.Clamp(dTarget - dSteer, -r, r);
            double steer = dSteer;
            double hb = (kb && K(Key.Space)) || TouchHand ? 1 : 0;
            if (TouchSteerActive) steer = Curve(TouchSteerVal);
            bool analog = false;
            var pads = Input.GetConnectedJoypads();
            if (pads.Count > 0)
            {
                int dev = pads[0];
                double ax = Input.GetJoyAxis(dev, JoyAxis.LeftX);
                const double dz = 0.08;
                if (Math.Abs(ax) > dz) { steer = Curve(-M.Sgn(ax) * ((Math.Abs(ax) - dz) / (1 - dz))); analog = true; }
                double rt = Input.GetJoyAxis(dev, JoyAxis.TriggerRight), lt = Input.GetJoyAxis(dev, JoyAxis.TriggerLeft);
                if (rt > 0.02) { thr = rt; analog = true; }
                if (lt > 0.02) { brk = lt; analog = true; }
                if (Input.IsJoyButtonPressed(dev, JoyButton.A) || Input.IsJoyButtonPressed(dev, JoyButton.B)) hb = 1;
                Edge(dev, JoyButton.RightShoulder, 0, GameAction.ShiftUp);
                Edge(dev, JoyButton.LeftShoulder, 1, GameAction.ShiftDown);
                Edge(dev, JoyButton.Y, 2, GameAction.Camera);
                Edge(dev, JoyButton.Start, 3, GameAction.Reset);
                Edge(dev, JoyButton.Back, 4, GameAction.Setup);
                Edge(dev, JoyButton.X, 5, GameAction.Gearbox);
            }
            double Approach(double v, double target, double up, double down) => v + M.Clamp(target - v, -down * dt, up * dt);
            s.Throttle = analog ? thr : Approach(s.Throttle, thr, 4.5, 9);
            // brake pressure builds like a real pedal: a tap gives a light brush (~30%) for trail braking,
            // holding the key squeezes up to full in about half a second
            s.Brake = analog ? brk : Approach(s.Brake, brk, c.AnalogPedals && s.Brake >= 0.3 ? 1.7 : 7, 12);
            s.Steer = steer;
            s.Handbrake = hb;
            Analog = analog;
            return s;
        }

        void Edge(int dev, JoyButton b, int slot, GameAction a)
        {
            bool down = Input.IsJoyButtonPressed(dev, b);
            if (down && !padPrev[slot]) OnAction(a);
            padPrev[slot] = down;
        }

        public void ClearTouch()
        {
            TouchGas = TouchBrake = 0; TouchHand = TouchLeft = TouchRight = TouchSteerActive = false; TouchSteerVal = 0;
        }
    }
}
