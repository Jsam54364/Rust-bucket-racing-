// The game: builds the scene in code, steps the 480 Hz simulation, and wires cameras, effects, sound,
// HUD, touch controls and menus together.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Godot;
using RustBucket.Audio;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public partial class Main : Node3D, IGame
    {
        const double DT = 1.0 / 480;
        static readonly V3 SpawnPos = new V3(0, 0, 5);

        // look: tweak these to taste on a device
        const float SunEnergy = 1.45f, AmbientSky = 0.85f, Exposure = 0.95f;
        const float FogGrid = 0.0003f, FogMap = 0.00045f;

        Settings store;
        GridTerrain gridTerrain;
        TerrainBase terrain;
        string mapId = "grid", carId = "rust";
        Car car;
        readonly ControlPrefs prefs = new ControlPrefs();
        DriverInput input;
        readonly CameraRig rig = new CameraRig();
        Cones cones;
        LapTimer lap;
        Effects fx;

        Camera3D cam;
        DirectionalLight3D sun;
        Godot.Environment env;
        ProvingGroundView pgView;
        MeshInstance3D ground;
        ShaderMaterial groundMat;
        sealed class MapEntry { public MapPack Pack; public MeshTerrain Terrain; public MapWorldView View; }
        readonly Dictionary<string, MapEntry> maps = new Dictionary<string, MapEntry>();
        ConesView conesView;
        SkidMarks skids;
        SmokeView smoke;
        readonly Dictionary<string, CarView> carViews = new Dictionary<string, CarView>();
        CarView carView;

        AudioOut audioOut;
        EngineAudio audio;
        readonly Dictionary<string, EngineData> engineFiles = new Dictionary<string, EngineData>();
        readonly SoundState snd = new SoundState();
        bool soundOn = true;

        Hud hud;
        TouchControls touch;
        Panels panels;
        bool telemetry, touchDevice;

        double acc, lapFlash, loadingT;
        bool busy;
        // camera drag / pinch
        readonly Dictionary<int, Vector2> camTouches = new Dictionary<int, Vector2>();
        float pinch;
        bool mouseDrag;
        V3 camPrev, camVel; bool hasCamPrev;
        // dynamic resolution: when frames take longer than the display allows, draw fewer pixels (down to 60 %)
        double perfT, perfHold = 3; int perfN; float resScale = 1;
        Vector2 lastSize; float safeL, safeR;
        // start-up marker for the boot screen, and the self-test CI runs (-- --smoke --shots=<dir>)
        bool bootOk, selfTest;
        double bootT, simClock, smokeReal, smokeLog;
        string shotDir = "user://smoke", smokeStep = "";
        int shotN;
        static bool crashHooks;

        public Car Car => car;
        public string CarId => carId;
        public string MapId => mapId;
        public bool SoundOn => soundOn;
        public bool TelemetryOn => telemetry;
        public bool Touch => touchDevice;
        public ControlPrefs Prefs => prefs;
        CarDef Def => Defs.Cars[carId];

        public override void _Ready()
        {
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            DebugLog.Trace("main: start · " + DebugLog.DeviceInfo());
            if (!crashHooks)
            {
                crashHooks = true;
                AppDomain.CurrentDomain.UnhandledException += (s, e) => GD.PrintErr("[crash] unhandled .NET exception: " + e.ExceptionObject);
                TaskScheduler.UnobservedTaskException += (s, e) => { GD.PrintErr("[crash] unobserved task exception: " + e.Exception); e.SetObserved(); };
            }
            var args = OS.GetCmdlineUserArgs();
            selfTest = Array.IndexOf(args, "--smoke") >= 0;
            foreach (var a in args) if (a.StartsWith("--shots=")) shotDir = a.Substring(8);
            GetTree().QuitOnGoBack = false;
            DebugLog.Trace("settings");
            store = new Settings();
            prefs.Sens = store.Num("sens", 1);
            prefs.ButtonSteer = store.Bool("buttonSteer", false);
            prefs.AnalogPedals = store.Bool("analogPedals", true);
            telemetry = store.Bool("telemetry", false);
            soundOn = store.Bool("sound", true);

            DebugLog.Trace("scene");
            BuildScene();

            DebugLog.Trace("proving ground");
            gridTerrain = ProvingGround.BuildGridMap();
            terrain = gridTerrain;
            pgView = new ProvingGroundView(gridTerrain);
            AddChild(pgView.Root);
            groundMat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/surface.gdshader") };
            groundMat.SetShaderParameter("kind", 0);
            ground = new MeshInstance3D { Name = "Ground", Mesh = ProvingGroundView.GroundMesh(28, 250, groundMat), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
            AddChild(ground);
            cones = new Cones(ProvingGround.BuildCones(), terrain);
            conesView = new ConesView(cones.List.Count);
            AddChild(conesView.Node);
            skids = new SkidMarks();
            AddChild(skids.Root);
            smoke = new SmokeView();
            AddChild(smoke.Node);
            fx = new Effects(skids, terrain);

            input = new DriverInput(prefs) { OnAction = OnAction };
            string want = store.Str("car", "rust");
            carId = Defs.Cars.ContainsKey(want) ? want : "rust";
            DebugLog.Trace("car model " + carId);
            try { ShowCarView(carId); }
            catch (Exception e)
            {
                GD.PushError("car model: " + e.Message);
                carId = "rust";
                try { ShowCarView(carId); }
                catch (Exception e2) { GD.PushError("car model: " + e2.Message); carView = CarView.Empty(); carViews[carId] = carView; AddChild(carView.Root); }
            }
            DebugLog.Trace("car physics");
            car = new Car(terrain, store.LoadTune(Def.Spec), Def.Spec);
            car.Reset(SpawnPos, 0);
            ApplyCameraDef();
            rig.Snap(car);
            lap = new LapTimer(terrain.Circuit);

            // sound
            DebugLog.Trace("sound");
            audioOut = new AudioOut { Name = "Audio" };
            AddChild(audioOut);
            try
            {
                var sfx = AudioData.Sfx(FileAccess.GetFileAsString("res://data/sfx.json"));
                audio = new EngineAudio(audioOut.MixRate, sfx) { Enabled = soundOn };
                SetEngineSound(carId);
                audioOut.Engine = audio;
            }
            catch (Exception e) { GD.PushError("engine sound: " + e.Message); audio = null; }

            // HUD, touch controls, menus
            DebugLog.Trace("ui");
            var layer = new CanvasLayer { Name = "UI" };
            AddChild(layer);
            hud = new Hud { Name = "Hud", Theme = Ui.Theme, Kmh = store.Str("units", "kmh") == "kmh", Telemetry = telemetry };
            hud.OnUnits = () => { hud.Kmh = !hud.Kmh; store.Set("units", hud.Kmh ? "kmh" : "mph"); };
            layer.AddChild(hud);
            touchDevice = DisplayServer.IsTouchscreenAvailable() || OS.HasFeature("mobile") || selfTest;
            touch = new TouchControls { Name = "Touch", Drv = input, Visible = touchDevice };
            layer.AddChild(touch);
            panels = new Panels(this);
            layer.AddChild(panels.Root);
            touch.Blocked = (p) => panels.Covers(p);
            panels.ShowHelp(true);

            string startMap = store.Str("map", "grid");
            if (startMap != "grid" && Defs.Maps.ContainsKey(startMap)) Callable.From(() => SwitchMap(startMap)).CallDeferred();
            DebugLog.Trace("ready");
            if (selfTest) Callable.From(() => RunSmoke()).CallDeferred();
        }

        void BuildScene()
        {
            var sky = new ProceduralSkyMaterial
            {
                SkyTopColor = new Color(0.30f, 0.50f, 0.80f),
                SkyHorizonColor = new Color(0.74f, 0.80f, 0.87f),
                SkyCurve = 0.12f,
                GroundHorizonColor = new Color(0.66f, 0.69f, 0.72f),
                GroundBottomColor = new Color(0.36f, 0.37f, 0.40f),
                SunAngleMax = 25,
                SunCurve = 0.12f,
            };
            env = new Godot.Environment
            {
                BackgroundMode = Godot.Environment.BGMode.Sky,
                Sky = new Sky { SkyMaterial = sky },
                AmbientLightSource = Godot.Environment.AmbientSource.Sky,
                AmbientLightSkyContribution = AmbientSky,
                ReflectedLightSource = Godot.Environment.ReflectionSource.Sky,
                TonemapMode = Godot.Environment.ToneMapper.Aces,
                TonemapExposure = Exposure,
                FogEnabled = true,
                FogLightColor = new Color(0.70f, 0.76f, 0.83f),
                FogDensity = FogGrid,
                FogSkyAffect = 0,
            };
            AddChild(new WorldEnvironment { Name = "Environment", Environment = env });
            sun = new DirectionalLight3D
            {
                Name = "Sun",
                ShadowEnabled = true,
                LightEnergy = SunEnergy,
                LightColor = new Color(1f, 0.95f, 0.87f),
                DirectionalShadowMode = DirectionalLight3D.ShadowMode.Parallel2Splits,
                DirectionalShadowMaxDistance = 90,
                ShadowBias = 0.04f,
                ShadowNormalBias = 1.2f,
                ShadowBlur = 1.2f,
            };
            AddChild(sun);
            var L = new Vector3(-0.42f, 0.74f, -0.52f).Normalized(); // towards the sun
            sun.LookAtFromPosition(Vector3.Zero, -L, Vector3.Up);
            cam = new Camera3D { Name = "Camera", Near = 0.1f, Far = 6000, Fov = 60, Current = true };
            AddChild(cam);
        }

        /* ---------------- cars ---------------- */
        void ShowCarView(string id)
        {
            if (!carViews.TryGetValue(id, out var v))
            {
                var d = Defs.Cars[id];
                v = d.Pack ? CarView.FromPack(FileAccess.GetFileAsBytes(d.Model)) : CarView.FromScene(d.Model);
                AddChild(v.Root);
                carViews[id] = v;
            }
            foreach (var kv in carViews) kv.Value.SetVisible(kv.Key == id);
            carView = v;
        }

        void ApplyCameraDef()
        {
            var d = Def;
            rig.ChaseDist = d.Chase; rig.Bumper = d.Bumper; rig.HasCockpit = d.HasCockpit; rig.Cockpit = d.Cockpit;
        }

        void SetEngineSound(string id)
        {
            if (audio == null) return;
            var d = Defs.Cars[id];
            if (!engineFiles.TryGetValue(d.Engine, out var data))
            {
                data = AudioData.Engine(FileAccess.GetFileAsString(d.Engine));
                engineFiles[d.Engine] = data;
            }
            var pf = data.Profile.Clone();
            d.EngineProfile?.Invoke(pf);
            audio.SetEngine(data, pf);
        }

        // driver preferences follow you from car to car; everything else in the setup is per car
        static Tune KeepShared(Tune src, Tune dst)
        {
            dst.Gearbox = src.Gearbox; dst.Abs = src.Abs; dst.Tcs = src.Tcs;
            dst.SteerAssist = src.SteerAssist; dst.CounterSteer = src.CounterSteer; dst.SteerSpeed = src.SteerSpeed;
            return dst;
        }

        // Switch cars in place: the new car drops in where the old one is, facing the same way, at rest.
        public async void SwitchCar(string id)
        {
            if (busy || !Defs.Cars.ContainsKey(id) || (id == carId && carView != null)) return;
            busy = true;
            DebugLog.State("loading car " + id); DebugLog.Trace("loading car " + id);
            try
            {
                if (!carViews.ContainsKey(id)) { SetLoading("Loading car"); await Frames(2); }
                ShowCarView(id);
                store.SaveTune(carId, car.Tune);
                var spec = Defs.Cars[id].Spec;
                var nt = KeepShared(car.Tune, store.LoadTune(spec));
                var next = new Car(terrain, nt, spec);
                V3 f = car.Forward, bas = car.Pos - car.Q.Rotate(car.ComModel);
                next.Reset(new V3(bas.X, 0, bas.Z), Math.Atan2(-f.X, -f.Z));
                if (nt.Gearbox != Gearbox.Auto) next.Engine.Gear = 1;
                car = next; carId = id;
                store.Set("car", id); store.SaveTune(id, car.Tune);
                ApplyCameraDef(); rig.Snap(car);
                bool noInterior = rig.Mode == 4 && !rig.HasCockpit;
                if (noInterior) rig.Mode = 2;
                fx.ResetTrails();
                lap.Reset();
                SetEngineSound(id);
                panels.Sync();
                Toast(Defs.Cars[id].Toast + (noInterior ? " · no interior: bumper cam" : ""));
                SetLoading("");
            }
            catch (Exception e) { SetLoading("Car model failed to load: " + e.Message, 5); GD.PushError(e.ToString()); }
            finally { busy = false; panels.Sync(); DebugLog.State("ok"); }
        }

        /* ---------------- maps ---------------- */
        public async void SwitchMap(string id)
        {
            if (busy || !Defs.Maps.ContainsKey(id) || id == mapId) return;
            busy = true;
            DebugLog.State("loading map " + id); DebugLog.Trace("loading map " + id);
            var md = Defs.Maps[id];
            try
            {
                MapEntry m = null;
                if (id != "grid")
                {
                    if (!maps.TryGetValue(id, out m))
                    {
                        SetLoading("Loading " + md.Name);
                        await Frames(2); // let the label paint before the heavy lifting
                        var bytes = FileAccess.GetFileAsBytes(md.Pack);
                        if (bytes == null || bytes.Length == 0) throw new Exception("map data missing");
                        var pk = await Task.Run(() => MapPack.Load(bytes));
                        var tr = await Task.Run(() => MapPack.BuildTerrain(pk));
                        m = new MapEntry { Pack = pk, Terrain = tr, View = new MapWorldView(pk) };
                        AddChild(m.View.Root);
                        maps[id] = m;
                    }
                }
                foreach (var kv in maps) kv.Value.View.Root.Visible = kv.Key == id;
                bool grid = id == "grid";
                pgView.Root.Visible = grid;
                conesView.Node.Visible = grid;
                terrain = grid ? (TerrainBase)gridTerrain : m.Terrain;
                groundMat.SetShaderParameter("kind", grid ? 0 : 9);
                ground.Position = new Vector3(0, grid ? 0 : m.View.FloorY, 0);
                env.FogDensity = grid ? FogGrid : FogMap;
                mapId = id; store.Set("map", id);
                car.Terrain = terrain;
                lap = new LapTimer(terrain.Circuit);
                cones = new Cones(grid ? ProvingGround.BuildCones() : new List<(double x, double z)>(), terrain);
                fx.Terrain = terrain;
                perfHold = 3; perfT = 0; perfN = 0;
                if (grid) { car.Reset(SpawnPos, 0); fx.Clear(); rig.Snap(car); rig.ClearTrack(); }
                else ToGrid(0, true);
                SetLoading("");
                Toast(md.Toast);
            }
            catch (Exception e) { SetLoading(md.Name + " failed to load: " + e.Message, 5); GD.PushError(e.ToString()); }
            finally { busy = false; panels.Sync(); DebugLog.State("ok"); DebugLog.Trace("map " + mapId + " ready"); }
        }

        async Task Frames(int n)
        {
            for (int i = 0; i < n; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        }

        void SetLoading(string s, double hold = 0) { hud.Loading = s; loadingT = hold; }

        /* ---------------- resets ---------------- */
        public void ResetCar(bool toStart)
        {
            var c = terrain.Circuit;
            if (toStart && mapId != "grid") { ToGrid(); return; }
            if (toStart) { car.Reset(SpawnPos, 0); cones.Reset(); fx.Clear(); Toast("Back at the start line"); }
            else if (c != null && c.Mesh)
            {
                // a real circuit: off the track (or off the edge of the map) puts you back on the racing line
                var n = c.Path.Nearest(car.Pos.X, car.Pos.Z);
                if (n.Dist > c.Width / 2 + 3 || terrain.HeightVis(car.Pos.X, car.Pos.Z) <= terrain.Floor) ToTrack(n.S);
                else { car.ResetUpright(); Toast("Car reset"); }
            }
            else { car.ResetUpright(); Toast("Car reset"); }
            lap.Reset(); rig.Snap(car);
        }

        void ToTrack(double s)
        {
            var p = terrain.Circuit.Path.At(s);
            car.Reset(new V3(p.X, 0, p.Z), Math.Atan2(-Math.Cos(p.H), -Math.Sin(p.H)));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.ResetTrails(); rig.ClearTrack();
            Toast("Back on the track");
        }

        public void ToGrid() => ToGrid(0, false);

        // race track: line up in a grid slot (pole by default), facing down the main straight
        void ToGrid(int slot, bool quiet)
        {
            var c = terrain.Circuit;
            if (c == null || c.Grid.Count == 0) return;
            var gs = c.Grid[Math.Min(slot, c.Grid.Count - 1)];
            var p = c.Path.At(gs.S - 2.6);
            double rx = -Math.Sin(p.H), rz = Math.Cos(p.H);
            car.Reset(new V3(p.X + rx * gs.D, 0, p.Z + rz * gs.D), Math.Atan2(-Math.Cos(p.H), -Math.Sin(p.H)));
            if (car.Tune.Gearbox == Gearbox.Auto) car.Engine.Gear = 1;
            fx.Clear(); lap.Reset(); rig.Snap(car); rig.ClearTrack();
            if (!quiet) Toast("On the grid: the timer starts at the line");
        }

        /* ---------------- settings from the menus ---------------- */
        public void ChangeTune(Action<Tune> change)
        {
            var t = car.Tune.Clone();
            change(t);
            car.SetTune(t);
            store.SaveTune(carId, car.Tune);
            panels.Sync();
        }

        static readonly string[] GearboxName = { "Automatic gearbox", "Semi-automatic gearbox", "Manual gearbox: no protection" };

        public void SetGearbox(Gearbox mode)
        {
            ChangeTune((t) => t.Gearbox = mode);
            if (mode != Gearbox.Auto) store.Set("handMode", mode.ToString());
            if (mode != Gearbox.Manual && car.Engine.Gear == 0 && car.Engine.Shift == null) car.Engine.Gear = 1;
            Toast(GearboxName[(int)mode]);
        }

        public void ToggleTelemetry()
        {
            telemetry = !telemetry; hud.Telemetry = telemetry; store.Set("telemetry", telemetry);
            Toast(telemetry ? "Telemetry on" : "Telemetry off"); panels.Sync();
        }

        public void ToggleSound()
        {
            soundOn = !soundOn; store.Set("sound", soundOn);
            if (audio != null) audio.Enabled = soundOn;
            panels.Sync();
        }

        public void CycleCamera() => Toast(rig.Cycle());
        public void SaveControls() { store.Set("sens", prefs.Sens); store.Set("buttonSteer", prefs.ButtonSteer); store.Set("analogPedals", prefs.AnalogPedals); }
        public void Toast(string s) => hud?.Toast(s);
        public void Go(bool raceTrack) { panels.ShowHelp(false); if (raceTrack) ToGrid(); }
        public void PanelsChanged() { if (touch != null && panels != null && panels.AnyOpen) touch.ReleaseAll(); }

        void OnAction(GameAction a)
        {
            if (a == GameAction.Touch)
            {
                if (panels.HelpOpen) panels.ShowHelp(false);
                if (panels.MenuOpen) panels.ShowMenu(false);
                return;
            }
            switch (a)
            {
                case GameAction.Camera: CycleCamera(); break;
                case GameAction.Reset: ResetCar(false); break;
                case GameAction.ResetStart: ResetCar(true); break;
                case GameAction.Setup: panels.ShowTune(!panels.TuneOpen); break;
                case GameAction.Telemetry: ToggleTelemetry(); break;
                case GameAction.Fullscreen:
                    if (!OS.HasFeature("mobile"))
                        DisplayServer.WindowSetMode(DisplayServer.WindowGetMode() == DisplayServer.WindowMode.Fullscreen ? DisplayServer.WindowMode.Windowed : DisplayServer.WindowMode.Fullscreen);
                    break;
                case GameAction.Help: panels.ShowHelp(!panels.HelpOpen); break;
                case GameAction.Escape: panels.CloseAll(); break;
                case GameAction.Controls: panels.ShowControls(!panels.ControlsOpen); break;
                case GameAction.Gearbox: SetGearbox((Gearbox)(((int)car.Tune.Gearbox + 1) % 3)); break;
                case GameAction.Grid: ToGrid(); break;
                case GameAction.NextCar: SwitchCar(Defs.CarOrder[(Array.IndexOf(Defs.CarOrder, carId) + 1) % Defs.CarOrder.Length]); break;
                case GameAction.NextMap: SwitchMap(Defs.MapOrder[(Array.IndexOf(Defs.MapOrder, mapId) + 1) % Defs.MapOrder.Length]); break;
                case GameAction.ShiftUp:
                case GameAction.ShiftDown:
                    // shifting by hand in automatic switches to the last hand-shift mode used (semi to start with)
                    if (car.Tune.Gearbox == Gearbox.Auto)
                        SetGearbox(Enum.TryParse<Gearbox>(store.Str("handMode", "Semi"), out var hm) && hm != Gearbox.Auto ? hm : Gearbox.Semi);
                    if (a == GameAction.ShiftUp) input.State.ShiftUp = true; else input.State.ShiftDown = true;
                    break;
            }
        }

        /* ---------------- keys, mouse and camera touches ---------------- */
        public override void _UnhandledInput(InputEvent e)
        {
            if (e is InputEventKey k && k.Pressed && !k.Echo)
            {
                var key = k.PhysicalKeycode;
                if (panels.HelpOpen && (key == Key.W || key == Key.S || key == Key.A || key == Key.D || key == Key.Up || key == Key.Down || key == Key.Left || key == Key.Right || key == Key.Space))
                    panels.ShowHelp(false);
                GameAction a = key switch
                {
                    Key.C => GameAction.Camera,
                    Key.R => k.ShiftPressed ? GameAction.ResetStart : GameAction.Reset,
                    Key.T => GameAction.Setup,
                    Key.G => GameAction.Telemetry,
                    Key.F => GameAction.Fullscreen,
                    Key.H => GameAction.Help,
                    Key.Escape => GameAction.Escape,
                    Key.K => GameAction.Controls,
                    Key.M => GameAction.Gearbox,
                    Key.L => GameAction.Grid,
                    Key.V => GameAction.NextCar,
                    Key.N => GameAction.NextMap,
                    Key.E => GameAction.ShiftUp,
                    Key.Q => GameAction.ShiftDown,
                    _ => GameAction.None,
                };
                if (a != GameAction.None) { OnAction(a); GetViewport().SetInputAsHandled(); }
                return;
            }
            if (e is InputEventMouseButton mb && mb.Device != -1)
            {
                if (mb.ButtonIndex == MouseButton.Left) { mouseDrag = mb.Pressed; rig.Dragging = mouseDrag; if (mb.Pressed && panels.MenuOpen) panels.ShowMenu(false); }
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) rig.Zoom(Math.Exp(-0.1));
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) rig.Zoom(Math.Exp(0.1));
                return;
            }
            if (e is InputEventMouseMotion mm && mm.Device != -1)
            {
                if (mouseDrag) rig.Drag(mm.Relative.X * 0.0035, mm.Relative.Y * 0.003);
                return;
            }
            // touch: in the orbit camera one finger flies round the car, two pinch to zoom
            if (e is InputEventScreenTouch st)
            {
                if (st.Pressed)
                {
                    if (panels.MenuOpen) panels.ShowMenu(false);
                    if (rig.Mode != 1) return;
                    camTouches[st.Index] = st.Position;
                    if (camTouches.Count == 2) pinch = Spread();
                }
                else
                {
                    camTouches.Remove(st.Index);
                    if (camTouches.Count < 2) pinch = 0;
                }
                rig.Dragging = camTouches.Count > 0;
                return;
            }
            if (e is InputEventScreenDrag sd && camTouches.ContainsKey(sd.Index))
            {
                camTouches[sd.Index] = sd.Position;
                if (camTouches.Count >= 2)
                {
                    float d = Spread();
                    if (pinch > 0 && d > 0) rig.Zoom(pinch / d);
                    pinch = d;
                }
                else rig.Drag(sd.Relative.X * 0.0035, sd.Relative.Y * 0.003);
            }
        }

        float Spread()
        {
            var e = camTouches.Values.GetEnumerator();
            e.MoveNext(); var a = e.Current; e.MoveNext(); var b = e.Current;
            return a.DistanceTo(b);
        }

        public override void _Notification(int what)
        {
            if (what == NotificationApplicationFocusOut || what == NotificationApplicationPaused)
            {
                touch?.ReleaseAll();
                camTouches.Clear(); rig.Dragging = false; mouseDrag = false;
                store?.Save();
            }
            else if (what == NotificationWMGoBackRequest)
            {
                if (panels == null) return;
                if (panels.AnyOpen) panels.CloseAll(); else panels.ShowHelp(true);
            }
        }

        /* ---------------- frame ---------------- */
        public override void _Process(double delta)
        {
            double raw = delta;
            double dt = Math.Max(0, Math.Min(raw, 0.1));
            if (car == null) return;
            simClock += dt;
            if (!bootOk && (bootT += raw) > 4) { bootOk = true; if (!busy) DebugLog.State("ok"); DebugLog.Trace("running"); }
            if (selfTest) SmokeTick(raw);
            var size = GetViewport().GetVisibleRect().Size;
            if (size != lastSize) { lastSize = size; UpdateSafeArea(size); }
            AutoResolution(raw);

            var st = input.Update(dt, true);
            acc += dt;
            int n = 0;
            while (acc >= DT && n < 60) { car.Step(DT, st); cones.Step(DT, car); acc -= DT; n++; }
            if (n >= 60) acc = 0;
            if (car.Engine.Refused != null)
            {
                Toast(car.Engine.Refused == "overrev" ? "Too fast for that gear" : "Stop the car to change direction");
                car.Engine.Refused = null;
            }
            if (terrain.Circuit != null && terrain.Circuit.Mesh && car.Pos.Y < terrain.BoundsMinY - 25) ResetCar(false);
            fx.Update(dt, car);
            lap.Update(dt, car, OnLap);
            lapFlash = Math.Max(0, lapFlash - dt);

            rig.Aspect = size.X / Math.Max(1, size.Y);
            int zk = (Input.IsPhysicalKeyPressed(Key.Minus) || Input.IsPhysicalKeyPressed(Key.KpSubtract) ? 1 : 0) - (Input.IsPhysicalKeyPressed(Key.Equal) || Input.IsPhysicalKeyPressed(Key.KpAdd) ? 1 : 0);
            if (zk != 0) rig.Zoom(Math.Exp(zk * dt * 1.6));
            rig.Update(dt, car, terrain);
            UpdateSound(dt);
            UpdateHud(dt);
            Render();
            store.Tick(dt);
        }

        void OnLap(double t, bool valid)
        {
            string key = mapId + "_" + carId;
            double best = store.Best(key);
            bool none = double.IsNaN(best);
            if (valid && (none || t < best)) { store.SetBest(key, t); Toast(none ? $"Lap {LapTimer.Fmt(t, 3)}" : $"New best lap {LapTimer.Fmt(t, 3)}"); }
            else Toast(valid ? $"Lap {LapTimer.Fmt(t, 3)} (best {LapTimer.Fmt(best, 3)})" : $"Lap {LapTimer.Fmt(t, 3)}: not counted, cut or off track");
            lapFlash = 3;
        }

        void UpdateSound(double dt)
        {
            V3 cp = rig.Pos;
            if (hasCamPrev && dt > 0)
            {
                V3 v = (cp - camPrev) * (1 / dt);
                double k = 1 - Math.Exp(-dt * 10);
                camVel = new V3(M.Lerp(camVel.X, M.Clamp(v.X, -120, 120), k), M.Lerp(camVel.Y, M.Clamp(v.Y, -120, 120), k), M.Lerp(camVel.Z, M.Clamp(v.Z, -120, 120), k));
            }
            camPrev = cp; hasCamPrev = true;
            if (audio == null) return;
            var e = car.Engine;
            snd.Rpm = e.Rpm; snd.Throttle = e.Load; snd.Limiter = e.LimiterCut;
            snd.Shifting = e.Shift != null && e.Clutch == 0 && !e.Blip;
            snd.Gear = e.Gear; snd.Speed = car.Tel.Speed;
            snd.CamPos = cp; snd.CamVel = camVel; snd.CarPos = car.Pos; snd.CarVel = car.Vel;
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i]; var ws = snd.Wheels[i];
                ws.Contact = w.Contact; ws.Surface = w.Surface; ws.Speed = Math.Abs(w.VLong); ws.Slip = w.SlipVel;
                ws.Load = (w.Contact ? w.Load : w.Fz) / w.StaticLoad;
            }
            audio.Update(dt, snd);
        }

        void UpdateHud(double dt)
        {
            if (loadingT > 0) { loadingT -= dt; if (loadingT <= 0) hud.Loading = ""; }
            hud.Car = car;
            bool show = lap.Running || lapFlash > 0;
            hud.LapShow = show;
            if (show) { hud.LapTime = lap.T; hud.LapValid = lap.Valid; hud.LapBest = store.Best(mapId + "_" + carId); }
            var e = car.Engine;
            int gn = e.Shift != null ? e.Shift.To : e.Gear;
            touch.GearText = gn < 0 ? "R" : gn == 0 ? "N" : gn.ToString();
            touch.ModeText = car.Tune.Gearbox == Gearbox.Auto ? "AUTO" : car.Tune.Gearbox == Gearbox.Semi ? "SEMI" : "MAN";
            // with touch controls on a narrow screen the cluster rises above them
            hud.BottomLift = touch.Visible && touch.RightEdgeOfLeft + 300 > touch.LeftEdgeOfRight - 300 ? 150 : 0;
            panels.Layout(lastSize, safeR);
        }

        void Render()
        {
            carView?.Update(car, Def.SteerRatio);
            carView?.SetInside(rig.Mode == 4, Def.GlassInside);
            if (mapId == "grid") conesView.Update(cones);
            skids.Flush();
            var cp = MeshUtil.V(rig.Pos);
            var ct = MeshUtil.V(rig.Target);
            smoke.Update(fx.Smoke, cp, ct);
            const float T = 250;
            ground.Position = new Vector3(Mathf.Round(cp.X / T) * T, ground.Position.Y, Mathf.Round(cp.Z / T) * T);
            cam.Fov = (float)(rig.Fov * 180 / Math.PI);
            cam.Near = rig.Mode == 4 || rig.Mode == 2 ? 0.05f : 0.1f;
            var up = MeshUtil.V(rig.Up);
            var dir = ct - cp;
            if (dir.LengthSquared() > 1e-8f)
            {
                if (Mathf.Abs(dir.Normalized().Dot(up.Normalized())) > 0.999f) up = Vector3.Forward;
                cam.LookAtFromPosition(cp, ct, up);
            }
            RenderingServer.GlobalShaderParameterSet("main_cam_pos", cp);
        }

        void UpdateSafeArea(Vector2 size)
        {
            safeL = safeR = 0;
            var win = DisplayServer.WindowGetSize();
            var safe = DisplayServer.GetDisplaySafeArea();
            if (win.X > 0 && safe.Size.X > 0)
            {
                float k = size.X / win.X;
                safeL = Math.Max(0, safe.Position.X) * k;
                safeR = Math.Max(0, win.X - safe.End.X) * k;
            }
            if (touch != null) touch.Safe = Math.Max(safeL, safeR);
        }

        void AutoResolution(double raw)
        {
            if (!(raw > 0 && raw < 0.25)) return;
            perfHold -= raw;
            if (perfHold > 0) return;
            perfT += raw;
            if (++perfN >= 90)
            {
                double avg = perfT / perfN; perfT = 0; perfN = 0;
                float old = resScale;
                if (avg > 0.021 && resScale > 0.6f) resScale = Math.Max(0.6f, resScale - 0.1f);
                else if (avg < 0.0175 && resScale < 1) resScale = Math.Min(1, resScale + 0.05f);
                if (resScale != old) GetViewport().Scaling3DScale = resScale;
            }
        }

        /* ---------------- self-test: CI runs the game with  -- --smoke --shots=<dir>  ----------------
           Drives every car on both maps, goes through the cameras and menus, and saves screenshots. Prints
           "SMOKE OK" and quits with 0 when it gets to the end; a different exit code says where it stopped. */
        async void RunSmoke()
        {
            try
            {
                GD.Print("[smoke] start · " + DebugLog.DeviceInfo());
                DirAccess.MakeDirRecursiveAbsolute(shotDir);
                smokeStep = "start sheet"; await Frames(30); Shot("start-sheet");
                Go(false);
                // the touch controls and HUD must fill the screen, and pressing the gas pedal must drive the car
                smokeStep = "touch controls";
                await Frames(3);
                if (touch.Size.X < 100 || hud.Size.X < 100) throw new Exception($"touch controls / HUD have no size ({touch.Size}, {hud.Size})");
                var gp = touch.GasCenter;
                Input.ParseInputEvent(new InputEventScreenTouch { Index = 7, Position = gp, Pressed = true });
                double tg = simClock;
                while (simClock < tg + 1.5) await Frames(1);
                double vg = car.Tel.Speed * 3.6;
                Shot("touch-gas");
                Input.ParseInputEvent(new InputEventScreenTouch { Index = 7, Position = gp, Pressed = false });
                await SmokeDrive(1.5, 0, 0, 1);
                if (vg < 3) throw new Exception($"pressing the touch gas pedal did not move the car ({vg:F1} km/h)");
                GD.Print($"[smoke] touch gas pedal: {vg:F0} km/h after 1.5 s");
                smokeStep = "rust: launch"; await SmokeDrive(3, 1, 0); Shot("rust-chase");
                smokeStep = "rust: turn"; await SmokeDrive(2, 0.7, 0.5); Shot("rust-turn");
                smokeStep = "rust: cameras";
                for (int i = 0; i < 6; i++)
                {
                    CycleCamera();
                    if (rig.Mode == 0) break;
                    await SmokeDrive(0.6, 0.5, 0); Shot("rust-" + Slug(CameraRig.Names[rig.Mode]));
                }
                await SmokeCam(0);
                smokeStep = "rust: brake"; await SmokeDrive(1.5, 0, 0, 1);
                smokeStep = "menus";
                panels.ShowMenu(true); await Frames(4); Shot("menu");
                panels.ShowTune(true); await Frames(4); Shot("car-setup");
                panels.ShowControls(true); await Frames(4); Shot("controls");
                panels.CloseAll(); ToggleTelemetry(); await Frames(4); Shot("telemetry"); ToggleTelemetry();
                foreach (var id in new[] { "monte", "cts" })
                {
                    smokeStep = "switch car " + id; SwitchCar(id); await SmokeIdle();
                    if (carId != id) throw new Exception("car " + id + " did not load");
                    smokeStep = id + ": drive"; await SmokeDrive(3, 1, 0); await SmokeDrive(1.5, 0.6, -0.5); Shot(id + "-chase");
                    if (rig.HasCockpit) { await SmokeCam(4); await SmokeDrive(0.8, 0.6, 0); Shot(id + "-interior"); }
                    await SmokeCam(2); await Frames(3); Shot(id + "-bumper");
                    await SmokeCam(0);
                }
                smokeStep = "load Spa"; SwitchMap("spa"); await SmokeIdle();
                if (mapId != "spa") throw new Exception("Spa did not load");
                Go(true); await Frames(10); Shot("spa-grid");
                smokeStep = "spa: drive"; await SmokeDrive(5, 1, 0); Shot("spa-chase");
                if (rig.HasCockpit) { await SmokeCam(4); await Frames(3); Shot("spa-interior"); }
                await SmokeCam(3); await SmokeDrive(1, 0.8, 0); Shot("spa-trackside");
                await SmokeCam(1); await Frames(3); Shot("spa-orbit");
                await SmokeCam(0);
                smokeStep = "spa: rust bucket"; SwitchCar("rust"); await SmokeIdle(); await SmokeDrive(2, 1, 0); Shot("spa-rust");
                smokeStep = "spa: resets"; ResetCar(false); await Frames(3); ResetCar(true); await Frames(3);
                smokeStep = "back to the proving ground"; SwitchMap("grid"); await SmokeIdle();
                if (mapId != "grid") throw new Exception("could not go back to the proving ground");
                await SmokeDrive(1, 0.5, 0); Shot("grid-again");
                GD.Print($"[smoke] SMOKE OK after {smokeReal:F0} s");
                GetTree().Quit(0);
            }
            catch (Exception e)
            {
                GD.PrintErr("[smoke] SMOKE FAILED during " + smokeStep + ": " + e);
                try { Shot("failed"); } catch (Exception) { }
                GetTree().Quit(3);
            }
        }

        void SmokeTick(double raw)
        {
            smokeReal += raw;
            if (double.IsNaN(car.Pos.X) || double.IsNaN(car.Pos.Y) || double.IsNaN(car.Vel.X))
            {
                GD.PrintErr("[smoke] NaN in the car state during " + smokeStep);
                selfTest = false; GetTree().Quit(4); return;
            }
            if (smokeReal > 480) { GD.PrintErr("[smoke] TIMEOUT during " + smokeStep); selfTest = false; GetTree().Quit(2); return; }
            if (smokeReal - smokeLog < 1) return;
            smokeLog = smokeReal;
            var e = car.Engine;
            GD.Print($"[smoke] {smokeReal,5:F1}s {smokeStep} | {mapId}/{carId} cam {rig.Mode} | pos {car.Pos.X:F1} {car.Pos.Y:F2} {car.Pos.Z:F1} | " +
                $"{car.Tel.Speed * 3.6:F0} km/h {e.Rpm:F0} rpm gear {e.Gear} | {Godot.Engine.GetFramesPerSecond():F0} fps " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalDrawCallsInFrame)} draws " +
                $"{RenderingServer.GetRenderingInfo(RenderingServer.RenderingInfo.TotalPrimitivesInFrame)} tris");
        }

        async Task SmokeDrive(double seconds, double gas, double steer, double brake = 0)
        {
            double end = simClock + seconds;
            while (simClock < end)
            {
                input.TouchGas = gas; input.TouchBrake = brake;
                input.TouchSteerActive = steer != 0; input.TouchSteerVal = steer;
                await Frames(1);
            }
            input.ClearTouch();
        }

        async Task SmokeIdle() { await Frames(1); while (busy) await Frames(1); await Frames(3); }

        async Task SmokeCam(int mode) { for (int i = 0; i < 6 && rig.Mode != mode; i++) rig.Cycle(); await Frames(2); }

        static string Slug(string s) => s.ToLowerInvariant().Replace(' ', '-');

        void Shot(string name)
        {
            var img = GetViewport().GetTexture().GetImage();
            string path = shotDir.PathJoin($"{++shotN:00}-{name}.jpg");
            var err = img.SaveJpg(path, 0.8f);
            GD.Print("[smoke] screenshot " + path + (err == Error.Ok ? "" : " failed: " + err));
        }
    }
}
