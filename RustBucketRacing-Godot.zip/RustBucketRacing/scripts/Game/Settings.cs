// Everything remembered between sessions (user://settings.cfg): car, map, per-car setups, controls, best laps.
using System;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class Settings
    {
        const string PATH = "user://settings.cfg";
        readonly ConfigFile cfg = new ConfigFile();
        bool dirty;
        double saveT;

        public Settings()
        {
            if (FileAccess.FileExists(PATH)) cfg.Load(PATH);
        }

        public string Str(string key, string def) => cfg.GetValue("game", key, def).AsString();
        public bool Bool(string key, bool def) => cfg.GetValue("game", key, def).AsBool();
        public double Num(string key, double def) => cfg.GetValue("game", key, def).AsDouble();
        public void Set(string key, Variant v) { cfg.SetValue("game", key, v); dirty = true; }

        public bool HasBest(string key) => cfg.HasSectionKey("best", key);
        public double Best(string key) => HasBest(key) ? cfg.GetValue("best", key, 0.0).AsDouble() : double.NaN;
        public void SetBest(string key, double t) { cfg.SetValue("best", key, t); Save(); }

        // per-car setup; missing keys fall back to the car's defaults
        public Tune LoadTune(CarSpec spec)
        {
            string s = "tune_" + spec.Id;
            var d = spec.DefaultTune;
            var t = d.Clone();
            if (!cfg.HasSection(s)) return t;
            double N(string k, double def) => cfg.GetValue(s, k, def).AsDouble();
            t.SpringF = N("springF", d.SpringF); t.SpringR = N("springR", d.SpringR);
            t.DampF = N("dampF", d.DampF); t.DampR = N("dampR", d.DampR);
            t.ArbF = N("arbF", d.ArbF); t.ArbR = N("arbR", d.ArbR);
            t.ComHeight = N("comHeight", d.ComHeight); t.ReboundRatio = N("reboundRatio", d.ReboundRatio);
            t.RollCenter = N("rollCenter", d.RollCenter); t.Grip = N("grip", d.Grip); t.BrakeBias = N("brakeBias", d.BrakeBias);
            t.SteerAssist = N("steerAssist", d.SteerAssist); t.CounterSteer = N("counterSteer", d.CounterSteer); t.SteerSpeed = N("steerSpeed", d.SteerSpeed);
            t.Recovery = N("recovery", d.Recovery);
            t.Abs = cfg.GetValue(s, "abs", d.Abs).AsBool(); t.Tcs = cfg.GetValue(s, "tcs", d.Tcs).AsBool();
            if (Enum.TryParse<Drive>(cfg.GetValue(s, "drive", d.Drive.ToString()).AsString(), out var dr)) t.Drive = dr;
            if (Enum.TryParse<Gearbox>(cfg.GetValue(s, "gearbox", d.Gearbox.ToString()).AsString(), out var gb)) t.Gearbox = gb;
            return t;
        }

        public void SaveTune(string carId, Tune t)
        {
            string s = "tune_" + carId;
            cfg.SetValue(s, "springF", t.SpringF); cfg.SetValue(s, "springR", t.SpringR);
            cfg.SetValue(s, "dampF", t.DampF); cfg.SetValue(s, "dampR", t.DampR);
            cfg.SetValue(s, "arbF", t.ArbF); cfg.SetValue(s, "arbR", t.ArbR);
            cfg.SetValue(s, "comHeight", t.ComHeight); cfg.SetValue(s, "reboundRatio", t.ReboundRatio);
            cfg.SetValue(s, "rollCenter", t.RollCenter); cfg.SetValue(s, "grip", t.Grip); cfg.SetValue(s, "brakeBias", t.BrakeBias);
            cfg.SetValue(s, "steerAssist", t.SteerAssist); cfg.SetValue(s, "counterSteer", t.CounterSteer); cfg.SetValue(s, "steerSpeed", t.SteerSpeed);
            cfg.SetValue(s, "recovery", t.Recovery);
            cfg.SetValue(s, "abs", t.Abs); cfg.SetValue(s, "tcs", t.Tcs);
            cfg.SetValue(s, "drive", t.Drive.ToString()); cfg.SetValue(s, "gearbox", t.Gearbox.ToString());
            dirty = true;
        }

        // slider drags change things every frame: write at most twice a second
        public void Tick(double dt)
        {
            saveT += dt;
            if (dirty && saveT > 0.5) Save();
        }

        public void Save()
        {
            dirty = false; saveT = 0;
            cfg.Save(PATH);
        }
    }
}
