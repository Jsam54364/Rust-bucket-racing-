// HUD: speed / gear / rev cluster with assist lamps and the lap timer (bottom centre), optional chassis
// telemetry with the grip map (top left), toasts (top centre) and the loading pill.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public partial class Hud : Control
    {
        public Car Car;
        public bool Kmh = true;
        public bool Telemetry;
        public bool LapShow, LapValid;
        public double LapTime, LapBest = double.NaN;
        public string Loading = "";
        public float BottomLift; // keep the cluster above the touch controls when they crowd the middle
        public Action OnUnits = () => { };
        string toast = ""; double toastT;
        Button unitBtn;
        Rect2 clusterRect, speedRect;

        public override void _Ready()
        {
            MouseFilter = MouseFilterEnum.Ignore;
            SetAnchorsPreset(LayoutPreset.FullRect);
            // tap the speed readout to switch km/h and mph
            unitBtn = new Button { Flat = true, FocusMode = FocusModeEnum.None, MouseFilter = MouseFilterEnum.Stop };
            var empty = new StyleBoxEmpty();
            foreach (var st in new[] { "normal", "hover", "pressed", "hover_pressed", "focus" }) unitBtn.AddThemeStyleboxOverride(st, empty);
            unitBtn.Pressed += () => OnUnits();
            AddChild(unitBtn);
        }

        public void Toast(string msg) { toast = msg; toastT = 1.6; }

        public override void _Process(double delta)
        {
            if (toastT > 0) toastT -= delta;
            QueueRedraw();
        }

        static string Sgn(double v) => (v >= 0 ? "+" : "-") + Math.Abs(v).ToString("0.0") + "°";

        void Text(Font f, string s, Vector2 pos, int size, Color c) => DrawString(f, pos, s, HorizontalAlignment.Left, -1, size, c);
        static float W(Font f, string s, int size) => f.GetStringSize(s, HorizontalAlignment.Left, -1, size).X;

        public override void _Draw()
        {
            var size = Size;
            if (Car != null) DrawCluster(size);
            if (Car != null && Telemetry) DrawTelemetry();
            if (toastT > 0 && toast.Length > 0)
            {
                float a = Mathf.Round((float)Math.Min(1, toastT / 0.25) * 10) / 10f;
                var f = Ui.Body; int fs = 22;
                float w = W(f, toast, fs) + 36;
                float y = Telemetry ? 268 : 20;
                var r = new Rect2(size.X / 2 - w / 2, y, w, 46);
                DrawStyleBox(Ui.Cached(new Color(Ui.Panel, 0.95f * a), 23, new Color(Ui.Line, Ui.Line.A * a), 1), r);
                Text(f, toast, new Vector2(r.Position.X + 18, r.Position.Y + 31), fs, new Color(Ui.Ink, a));
            }
            if (Loading.Length > 0)
            {
                var f = Ui.Body; int fs = 19;
                string s = Loading.ToUpperInvariant();
                float w = W(f, s, fs) + 40;
                var r = new Rect2(size.X / 2 - w / 2, size.Y * 0.5f - 24, w, 48);
                DrawStyleBox(Ui.Cached(Ui.Panel, 24, Ui.Line, 1), r);
                Text(f, s, new Vector2(r.Position.X + 20, r.Position.Y + 31), fs, Ui.Muted);
            }
        }

        void DrawCluster(Vector2 size)
        {
            var car = Car; var tel = car.Tel; var e = car.Engine; var S = car.Spec;
            var fd = Ui.Display; var fb = Ui.Body;
            double sp = Math.Abs(tel.Speed) * (Kmh ? 3.6 : 2.23694);
            string spd = sp < 0.5 ? "0" : sp.ToString("0");
            string unit = Kmh ? "KM/H" : "MPH";
            int gn = e.Shift != null ? e.Shift.To : e.Gear;
            string gear = gn < 0 ? "R" : gn == 0 ? "N" : gn.ToString();
            string mode = car.Tune.Gearbox == Gearbox.Auto ? "AUTO" : car.Tune.Gearbox == Gearbox.Semi ? "SEMI" : "MAN";
            var lamps = new List<string>();
            if (tel.AbsActive) lamps.Add("ABS");
            if (tel.TcsActive) lamps.Add("TCS");
            if (tel.CsActive) lamps.Add("CS");
            const int fsSpd = 58, fsUnit = 17, fsGear = 40, fsMode = 14, fsLamp = 15;
            float wSpd = Math.Max(W(fd, spd, fsSpd), W(fd, "000", fsSpd) * 0.74f), wUnit = W(fb, unit, fsUnit), wGear = Math.Max(W(fd, gear, fsGear), 22), wMode = W(fb, mode, fsMode);
            float wl = 0; foreach (var l in lamps) wl += W(fb, l, fsLamp) + 18;
            float inner = wSpd + 8 + wUnit + 14 + 2 + 14 + wGear + 4 + wMode + wl;
            float w = Math.Max(230, inner + 32);
            bool lap = LapShow;
            float h = lap ? 124 : 92;
            var r = new Rect2(size.X / 2 - w / 2, size.Y - 18 - h - BottomLift, w, h);
            clusterRect = r;
            DrawStyleBox(Ui.Cached(Ui.Glass, 16, Ui.Line, 1), r);
            // revs
            double frac = M.Clamp((e.Rpm - S.IdleRpm) / (S.Redline - S.IdleRpm), 0, 1);
            var bar = new Rect2(r.Position.X + 16, r.Position.Y + 10, w - 32, 6);
            DrawStyleBox(Ui.Cached(new Color(1, 1, 1, 0.12f), 3), bar);
            bool flash = e.LimiterCut && (Time.GetTicksMsec() / 90) % 2 == 0;
            Color rc = e.OverRev ? Ui.Hot : flash ? Ui.Cool : frac > 0.88 ? Ui.Hot : frac > 0.7 ? Ui.Amber : Ui.Ok;
            if (frac > 0.005) DrawStyleBox(Ui.Cached(rc, 3), new Rect2(bar.Position, new Vector2((float)(bar.Size.X * frac), bar.Size.Y)));
            // speed, unit, gear, mode, lamps on one baseline
            float bx = r.Position.X + (w - inner) / 2, by = r.Position.Y + 72;
            Text(fd, spd, new Vector2(bx + wSpd - W(fd, spd, fsSpd), by), fsSpd, Ui.Ink);
            speedRect = new Rect2(bx, by - 52, wSpd + 8 + wUnit, 60);
            bx += wSpd + 8;
            Text(fb, unit, new Vector2(bx, by), fsUnit, Ui.Muted);
            bx += wUnit + 14;
            DrawLine(new Vector2(bx, by - 34), new Vector2(bx, by + 4), Ui.Line, 2);
            bx += 16;
            Text(fd, gear, new Vector2(bx + (wGear - W(fd, gear, fsGear)) / 2, by), fsGear, Ui.Amber);
            bx += wGear + 4;
            Text(fb, mode, new Vector2(bx, by), fsMode, Ui.Muted);
            bx += wMode + 10;
            foreach (var l in lamps)
            {
                float lw = W(fb, l, fsLamp) + 12;
                var lr = new Rect2(bx, by - 22, lw, 24);
                DrawStyleBox(Ui.Cached(Ui.Amber, 5), lr);
                Text(fb, l, new Vector2(bx + 6, by - 4), fsLamp, Ui.AmberInk);
                bx += lw + 6;
            }
            if (lap)
            {
                float ly = r.Position.Y + 92;
                DrawLine(new Vector2(r.Position.X + 14, ly), new Vector2(r.End.X - 14, ly), Ui.Line, 1);
                string lt = LapTimer.Fmt(LapTime), lb = LapTimer.Fmt(LapBest, 2);
                const int fsL = 14, fsT = 21;
                float tw = W(fb, "LAP", fsL) + 8 + W(fd, "0:00.0", fsT) + 22 + W(fb, "BEST", fsL) + 8 + W(fd, "0:00.00", fsT);
                float x = r.Position.X + (w - tw) / 2, y = ly + 25;
                Text(fb, "LAP", new Vector2(x, y), fsL, Ui.Muted); x += W(fb, "LAP", fsL) + 8;
                var lc = LapValid ? Ui.Ink : Ui.Muted;
                Text(fd, lt, new Vector2(x, y), fsT, lc);
                if (!LapValid) DrawLine(new Vector2(x, y - 7), new Vector2(x + W(fd, lt, fsT), y - 7), Ui.Muted, 1.5f);
                x += W(fd, "0:00.0", fsT) + 22;
                Text(fb, "BEST", new Vector2(x, y), fsL, Ui.Muted); x += W(fb, "BEST", fsL) + 8;
                Text(fd, lb, new Vector2(x, y), fsT, Ui.Ink);
            }
            unitBtn.Position = speedRect.Position; unitBtn.Size = speedRect.Size;
        }

        void DrawTelemetry()
        {
            var car = Car; var tel = car.Tel; var S = car.Spec;
            var fb = Ui.Body; var fd = Ui.Display;
            var panel = new Rect2(22, 18, 560, 236);
            DrawStyleBox(Ui.Cached(Ui.Glass, 16, Ui.Line, 1), panel);
            // grip map
            DrawGrip(new Rect2(panel.Position.X + 14, panel.Position.Y + 10, 150, 216));
            // suspension travel bars
            float bx0 = panel.Position.X + 180, top = panel.Position.Y + 30;
            string[] names = { "FL", "FR", "RL", "RR" };
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i];
                float x = bx0 + i * 46;
                Text(fb, names[i], new Vector2(x + 2, top), 15, Ui.Muted);
                var tr = new Rect2(x + 6, top + 10, 20, 72);
                DrawStyleBox(Ui.Cached(new Color(1, 1, 1, 0.08f), 5, Ui.Line, 1), tr);
                double f = M.Clamp(w.X / w.L0, 0, 1);
                double st = M.Clamp((w.L0 - S.MountAbove) / w.L0, 0, 1);
                double over = (f - st) / Math.Max(1e-3, 1 - st);
                Color c = !w.Contact ? new Color(0.29f, 0.33f, 0.38f) : w.Grip > 1.15 ? Ui.Hot : over > 0.4 ? Ui.Amber : Ui.Cool;
                float fh = (float)(tr.Size.Y * f);
                if (fh > 0.5f) DrawRect(new Rect2(tr.Position.X + 1, tr.End.Y - fh, tr.Size.X - 2, fh), c);
                float my = tr.End.Y - (float)(tr.Size.Y * st);
                DrawLine(new Vector2(tr.Position.X - 3, my), new Vector2(tr.End.X + 3, my), new Color(1, 1, 1, 0.85f), 2);
                string load = w.Contact ? (w.Load / 1000).ToString("0.0") : "air";
                Text(fd, load, new Vector2(x + 16 - W(fd, load, 17) / 2, tr.End.Y + 22), 17, Ui.Ink);
            }
            // body attitude silhouette, rolled with the body
            var sc = new Vector2(bx0 + 22, panel.Position.Y + 160);
            DrawSilhouette(sc, tel.Roll * 180 / Math.PI);
            // values
            double rd = tel.Roll * 180 / Math.PI, pd = tel.Pitch * 180 / Math.PI;
            var cnt = new int[5];
            foreach (var w in car.Wheels) if (w.Contact) cnt[(int)w.Surface]++;
            int topS = -1; for (int i = 0; i < 5; i++) if (cnt[i] > 0 && (topS < 0 || cnt[i] > cnt[topS])) topS = i;
            var rows = new (string k, string v)[]
            {
                ("ROLL", Sgn(rd)), ("PITCH", Sgn(pd)), ("G", M.Hypot(tel.GLat, tel.GLong).ToString("0.00") + " g"),
                ("FRONT", tel.HasLoad ? Math.Round(tel.FrontLoad * 100) + "%" : "-"), ("SURFACE", topS >= 0 ? Surfaces.Table[topS].Name : "Air"),
            };
            float vx = panel.Position.X + 380, vy = panel.Position.Y + 50;
            foreach (var (k, v) in rows)
            {
                Text(fb, k, new Vector2(vx, vy), 15, Ui.Muted);
                Text(fd, v, new Vector2(panel.End.X - 16 - W(fd, v, 21), vy), 21, Ui.Ink);
                vy += 40;
            }
        }

        void DrawSilhouette(Vector2 c, double rollDeg)
        {
            float s = 1.25f;
            // ground line and tyres don't roll
            DrawLine(c + new Vector2(-56 * s, 12.5f * s), c + new Vector2(56 * s, 12.5f * s), new Color(1, 1, 1, 0.25f), 1);
            DrawStyleBox(Ui.Cached(new Color(0.165f, 0.192f, 0.22f), 4, new Color(1, 1, 1, 0.18f), 1), new Rect2(c + new Vector2(-43 * s, -5 * s), new Vector2(17 * s, 17 * s)));
            DrawStyleBox(Ui.Cached(new Color(0.165f, 0.192f, 0.22f), 4, new Color(1, 1, 1, 0.18f), 1), new Rect2(c + new Vector2(26 * s, -5 * s), new Vector2(17 * s, 17 * s)));
            float ang = (float)(Math.Clamp(rollDeg * 3, -24, 24) * Math.PI / 180);
            // body outline in the web SVG's coordinates (viewBox 120 x 56, pivot at 60, 40)
            Vector2[] body = { P(14, 26), P(19, 20), P(32, 19), P(40, 6), P(44, 4), P(76, 4), P(80, 6), P(88, 19), P(101, 20), P(106, 26), P(106, 39), P(103, 42), P(17, 42), P(14, 39) };
            Vector2[] glass = { P(44, 8), P(76, 8), P(83, 18), P(37, 18) };
            Vector2 P(float x, float y) => new Vector2(x - 60, y - 40);
            Vector2 Xf(Vector2 p) => c + p.Rotated(ang) * s;
            var b2 = new Vector2[body.Length]; for (int i = 0; i < body.Length; i++) b2[i] = Xf(body[i]);
            var g2 = new Vector2[glass.Length]; for (int i = 0; i < glass.Length; i++) g2[i] = Xf(glass[i]);
            DrawColoredPolygon(b2, new Color(0.722f, 0.278f, 0.18f));
            DrawColoredPolygon(g2, new Color(0.114f, 0.165f, 0.208f));
        }

        // Top-down grip map. Each tyre's circle is its friction circle: it grows and shrinks with the weight on
        // that tyre. The dot is the force the tyre is making now; at the rim the tyre is at its limit, red means
        // it is sliding. The diamond is where the weight sits, the small cross where it sits at rest.
        void DrawGrip(Rect2 area)
        {
            var car = Car; var S = car.Spec;
            float W0 = area.Size.X, H0 = area.Size.Y;
            double halfT = S.Hubs[1].X, zF = S.Hubs[0].Z, zR = S.Hubs[2].Z;
            float sc = (float)Math.Min((W0 - 4) / (2 * halfT + 0.9), (H0 - 4) / (zR - zF + 1.5));
            Vector2 Pt(double x, double z) => new Vector2(area.Position.X + W0 / 2 + (float)x * sc, area.Position.Y + H0 / 2 + (float)(z - (zF + zR) / 2) * sc);
            // body
            var bp = Pt(-halfT - 0.1, zF - 0.72);
            var br = new Rect2(bp, new Vector2((float)(2 * halfT + 0.2) * sc, (float)(zR - zF + 1.44) * sc));
            DrawStyleBox(Ui.Cached(new Color(0, 0, 0, 0), (int)(0.3f * sc), new Color(1, 1, 1, 0.2f), 1), br);
            float R0 = Math.Min(0.4f * sc, 20);
            foreach (var w in car.Wheels)
            {
                var p = Pt(w.HubModel.X, w.HubModel.Z);
                float d = (float)w.Steer;
                // tyre
                DrawSetTransform(p, -d, Vector2.One);
                DrawRect(new Rect2(-0.11f * sc, -0.3f * sc, 0.22f * sc, 0.6f * sc), new Color(0, 0, 0, 0.55f));
                DrawSetTransform(Vector2.Zero, 0, Vector2.One);
                if (!w.Contact || w.Cap <= 0) { DrawArc(p, R0 * 0.5f, 0, Mathf.Tau, 24, new Color(1, 1, 1, 0.18f), 1); continue; }
                // friction circle sized by the load on this tyre
                float r = R0 * (float)M.Clamp(w.Load / w.StaticLoad, 0.15, 1.85);
                DrawCircle(p, r, new Color(90 / 255f, 169 / 255f, 1, 0.22f));
                DrawArc(p, r, 0, Mathf.Tau, 40, new Color(120 / 255f, 186 / 255f, 1, 0.9f), 1.5f, true);
                // force in use
                double u = M.Hypot(w.Fx, w.Fy) / w.Cap, k = r / w.Cap;
                double fx = -Math.Sin(d), fy = -Math.Cos(d), rx = Math.Cos(d), ry = -Math.Sin(d);
                var q = p + new Vector2((float)((w.Fx * fx + w.Fy * rx) * k), (float)((w.Fx * fy + w.Fy * ry) * k));
                Color col = w.Grip > 1.12 ? Ui.Hot : u > 0.85 ? Ui.Amber : Ui.Hex(0xe9eef2);
                DrawLine(p, q, col, 2.5f);
                DrawCircle(q, 4, col);
            }
            // where the weight sits
            var s0 = Pt(0, S.ComZ);
            DrawLine(s0 - new Vector2(4, 0), s0 + new Vector2(4, 0), new Color(1, 1, 1, 0.45f), 1.5f);
            DrawLine(s0 - new Vector2(0, 4), s0 + new Vector2(0, 4), new Color(1, 1, 1, 0.45f), 1.5f);
            if (car.Tel.HasLoad)
            {
                var c = Pt(car.Tel.LoadCx, car.Tel.LoadCz);
                DrawLine(s0, c, new Color(Ui.Amber, 0.6f), 1.5f);
                DrawColoredPolygon(new[] { c + new Vector2(0, -7), c + new Vector2(7, 0), c + new Vector2(0, 7), c + new Vector2(-7, 0) }, Ui.Amber);
            }
        }
    }
}
