// Touch controls laid out for two thumbs (landscape).
// Left thumb: analogue steering pad in the corner (or two steer buttons), gear slider beside it: flick up to
// shift up, down to shift down, or tap either end. Right thumb: Gas in the corner, Brake beside it, Hand above
// Brake. Gas and Brake are pressure-sensitive: press higher on the pedal for more, lower to feather it.
using System;
using System.Collections.Generic;
using Godot;

namespace RustBucket.Game
{
    public partial class TouchControls : Control
    {
        enum Zone { None, Pad, Left, Right, Shifter, Gas, Brake, Hand }

        public DriverInput Drv;
        public Func<Vector2, bool> Blocked = (p) => false;
        public string GearText = "1", ModeText = "AUTO";
        public float Safe = 0; // extra side margin from the display cut-out

        readonly Dictionary<int, Zone> owner = new Dictionary<int, Zone>();
        float u = 120;
        Rect2 pad, left, right, shifter, gas, brake, hand;
        float knobX, shY, gasP, brakeP;
        bool padOn, leftOn, rightOn, shOn, gasOn, brakeOn, handOn;
        // shifter gesture
        float shY0, shMoved; int shFired;

        public override void _Ready()
        {
            MouseFilter = MouseFilterEnum.Ignore;
            SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        }

        void Layout()
        {
            var s = Size;
            u = Mathf.Clamp(0.17f * s.Y, 84, 132);
            float gap = 16, mx = 26 + Safe, my = 22;
            bool buttons = Drv != null && Drv.Prefs.ButtonSteer;
            float padW = Mathf.Min(u * 3.8f, s.X * 0.36f), padH = u * 1.3f;
            pad = new Rect2(mx, s.Y - my - padH, padW, padH);
            float bw = u * 1.5f;
            left = new Rect2(mx, s.Y - my - bw, bw, bw);
            right = new Rect2(mx + bw + gap, s.Y - my - bw, bw, bw);
            float leftEnd = buttons ? right.End.X : pad.End.X;
            shifter = new Rect2(leftEnd + gap, s.Y - my - u * 2.45f, u * 1.05f, u * 2.45f);
            float rx = s.X - mx;
            gas = new Rect2(rx - u * 1.2f, s.Y - my - u * 2f, u * 1.2f, u * 2f);
            brake = new Rect2(rx - u * 1.2f - gap - u * 1.4f, s.Y - my - u * 1.4f, u * 1.4f, u * 1.4f);
            float hx = rx - (u * 1.475f + gap) - u * 0.85f;
            hand = new Rect2(hx, s.Y - my - u * 1.4f - gap - u * 0.85f, u * 0.85f, u * 0.85f);
        }

        Zone Hit(Vector2 p)
        {
            bool buttons = Drv.Prefs.ButtonSteer;
            const float slop = 14;
            if (gas.Grow(slop).HasPoint(p)) return Zone.Gas;
            if (InCircle(brake, p, slop)) return Zone.Brake;
            if (InCircle(hand, p, slop)) return Zone.Hand;
            if (shifter.Grow(slop).HasPoint(p)) return Zone.Shifter;
            if (buttons)
            {
                if (InCircle(left, p, slop)) return Zone.Left;
                if (InCircle(right, p, slop)) return Zone.Right;
            }
            else if (pad.Grow(slop).HasPoint(p)) return Zone.Pad;
            return Zone.None;
        }

        static bool InCircle(Rect2 r, Vector2 p, float slop) => p.DistanceTo(r.GetCenter()) <= r.Size.X / 2 + slop;

        public override void _Input(InputEvent e)
        {
            if (!Visible || Drv == null) return;
            if (e is InputEventScreenTouch t)
            {
                if (t.Pressed)
                {
                    Layout();
                    if (Blocked(t.Position)) return;
                    var zp = Hit(t.Position);
                    if (zp == Zone.None) return;
                    owner[t.Index] = zp;
                    Begin(zp, t.Position);
                    GetViewport().SetInputAsHandled();
                }
                else if (owner.TryGetValue(t.Index, out var zr))
                {
                    owner.Remove(t.Index);
                    End(zr, t.Position, t.Canceled);
                    GetViewport().SetInputAsHandled();
                }
            }
            else if (e is InputEventScreenDrag d && owner.TryGetValue(d.Index, out var zd))
            {
                Move(zd, d.Position);
                GetViewport().SetInputAsHandled();
            }
        }

        float Level(Rect2 r, Vector2 p)
        {
            if (!Drv.Prefs.AnalogPedals) return 1;
            float frac = Mathf.Clamp((r.End.Y - p.Y) / r.Size.Y, 0, 1);
            return Mathf.Clamp(0.25f + 1.25f * frac, 0.25f, 1); // bottom edge 25 %, top 40 % of the pedal = full
        }

        void SetSteer(float x)
        {
            float half = pad.Size.X / 2 - pad.Size.Y * 0.3f;
            float dx = Mathf.Clamp(x - pad.GetCenter().X, -half, half);
            knobX = dx;
            float v = dx / half; const float dz = 0.06f;
            Drv.TouchSteerVal = -Mathf.Sign(v) * Mathf.Max(0, (Mathf.Abs(v) - dz) / (1 - dz));
        }

        void Buzz() { try { Godot.Input.VibrateHandheld(12); } catch (Exception) { } }

        void Begin(Zone z, Vector2 p)
        {
            Drv.OnAction(GameAction.Touch);
            switch (z)
            {
                case Zone.Pad: padOn = true; Drv.TouchSteerActive = true; SetSteer(p.X); break;
                case Zone.Left: leftOn = true; Drv.TouchLeft = true; break;
                case Zone.Right: rightOn = true; Drv.TouchRight = true; break;
                case Zone.Shifter: shOn = true; shY0 = p.Y; shFired = 0; shMoved = 0; shY = 0; break;
                case Zone.Gas: gasOn = true; gasP = Level(gas, p); Drv.TouchGas = gasP; break;
                case Zone.Brake: brakeOn = true; brakeP = Level(brake, p); Drv.TouchBrake = brakeP; break;
                case Zone.Hand: handOn = true; Drv.TouchHand = true; break;
            }
            QueueRedraw();
        }

        void Move(Zone z, Vector2 p)
        {
            switch (z)
            {
                case Zone.Pad: SetSteer(p.X); break;
                case Zone.Gas: gasP = Level(gas, p); Drv.TouchGas = gasP; break;
                case Zone.Brake: brakeP = Level(brake, p); Drv.TouchBrake = brakeP; break;
                case Zone.Shifter:
                {
                    float tr = shifter.Size.Y * 0.3f, dy = p.Y - shY0;
                    shMoved = Mathf.Max(shMoved, Mathf.Abs(dy));
                    shY = Mathf.Clamp(dy, -tr, tr);
                    if (shFired == 0 && dy < -tr * 0.55f) { shFired = -1; Drv.OnAction(GameAction.ShiftUp); Buzz(); }
                    else if (shFired == 0 && dy > tr * 0.55f) { shFired = 1; Drv.OnAction(GameAction.ShiftDown); Buzz(); }
                    else if (shFired != 0 && Mathf.Abs(dy) < tr * 0.2f) shFired = 0; // back near the middle: ready for another shift
                    break;
                }
            }
            QueueRedraw();
        }

        void End(Zone z, Vector2 p, bool canceled)
        {
            switch (z)
            {
                case Zone.Pad: padOn = false; Drv.TouchSteerActive = false; Drv.TouchSteerVal = 0; knobX = 0; break;
                case Zone.Left: leftOn = false; Drv.TouchLeft = false; break;
                case Zone.Right: rightOn = false; Drv.TouchRight = false; break;
                case Zone.Gas: gasOn = false; gasP = 0; Drv.TouchGas = 0; break;
                case Zone.Brake: brakeOn = false; brakeP = 0; Drv.TouchBrake = 0; break;
                case Zone.Hand: handOn = false; Drv.TouchHand = false; break;
                case Zone.Shifter:
                    // a tap (no flick) on the upper or lower half shifts too
                    if (shFired == 0 && shMoved < 14 && !canceled) { Drv.OnAction(p.Y < shifter.GetCenter().Y ? GameAction.ShiftUp : GameAction.ShiftDown); Buzz(); }
                    shOn = false; shY = 0; break;
            }
            QueueRedraw();
        }

        // drop every touch (panels opened, app paused)
        public void ReleaseAll()
        {
            owner.Clear();
            padOn = leftOn = rightOn = shOn = gasOn = brakeOn = handOn = false;
            knobX = shY = gasP = brakeP = 0;
            Drv?.ClearTouch();
            QueueRedraw();
        }

        public override void _Process(double delta) { QueueRedraw(); }

        static readonly Color Fill = new Color(10 / 255f, 13 / 255f, 17 / 255f, 0.3f);
        static readonly Color Edge = new Color(1, 1, 1, 0.42f);
        static readonly Color InkC = new Color(1, 1, 1, 0.92f);

        void Capsule(Rect2 r, Color bg, Color border, float bw = 2.5f)
        {
            var sb = Ui.Cached(bg, (int)(Mathf.Min(r.Size.X, r.Size.Y) / 2), border, (int)bw);
            DrawStyleBox(sb, r);
        }

        void Disc(Rect2 r, Color bg, Color border)
        {
            var c = r.GetCenter(); float rad = r.Size.X / 2;
            DrawCircle(c, rad, bg);
            DrawArc(c, rad - 1.25f, 0, Mathf.Tau, 64, border, 2.5f, true);
        }

        // the part of a circle below a level line (frac of its height from the bottom)
        void DiscFill(Rect2 r, float frac, Color col)
        {
            if (frac <= 0) return;
            var c = r.GetCenter(); float rad = r.Size.X / 2 - 2;
            if (frac >= 0.999f) { DrawCircle(c, rad, col); return; }
            float yl = c.Y + rad - 2 * rad * frac;
            float a0 = Mathf.Asin(Mathf.Clamp((yl - c.Y) / rad, -1, 1));
            var pts = new List<Vector2>();
            int n = 40;
            for (int i = 0; i <= n; i++)
            {
                float a = a0 + (Mathf.Pi - 2 * a0) * i / n;
                pts.Add(new Vector2(c.X + Mathf.Cos(a) * rad, c.Y + Mathf.Sin(a) * rad));
            }
            if (pts.Count >= 3) DrawColoredPolygon(pts.ToArray(), col);
        }

        void Tri(Vector2 c, float s, bool pointLeft, Color col)
        {
            float d = pointLeft ? -1 : 1;
            DrawColoredPolygon(new[] { new Vector2(c.X + d * s, c.Y), new Vector2(c.X - d * s * 0.6f, c.Y - s * 0.8f), new Vector2(c.X - d * s * 0.6f, c.Y + s * 0.8f) }, col);
        }

        void Label(string s, Vector2 center, int size, Color col, Font f = null)
        {
            f ??= Ui.Display;
            var sz = f.GetStringSize(s, HorizontalAlignment.Left, -1, size);
            DrawString(f, new Vector2(center.X - sz.X / 2, center.Y + size * 0.36f), s, HorizontalAlignment.Left, -1, size, col);
        }

        public override void _Draw()
        {
            if (Drv == null) return;
            Layout();
            var amberFill = new Color(Ui.Amber, 0.85f);
            if (Drv.Prefs.ButtonSteer)
            {
                Disc(left, leftOn ? amberFill : Fill, leftOn ? Ui.Amber : Edge);
                Disc(right, rightOn ? amberFill : Fill, rightOn ? Ui.Amber : Edge);
                Tri(left.GetCenter(), u * 0.2f, true, leftOn ? Ui.AmberInk : InkC);
                Tri(right.GetCenter(), u * 0.2f, false, rightOn ? Ui.AmberInk : InkC);
            }
            else
            {
                Capsule(pad, Fill, padOn ? Ui.Amber : Edge);
                float railL = pad.Position.X + pad.Size.X * 0.22f, railR = pad.End.X - pad.Size.X * 0.22f, cy = pad.GetCenter().Y;
                DrawLine(new Vector2(railL, cy), new Vector2(railR, cy), new Color(1, 1, 1, 0.28f), 2);
                Tri(new Vector2(pad.Position.X + 26, cy), 9, true, new Color(1, 1, 1, 0.8f));
                Tri(new Vector2(pad.End.X - 26, cy), 9, false, new Color(1, 1, 1, 0.8f));
                var kc = new Vector2(pad.GetCenter().X + knobX, cy);
                DrawCircle(kc, u / 2, padOn ? new Color(Ui.Amber, 0.8f) : new Color(1, 1, 1, 0.2f));
                DrawArc(kc, u / 2 - 1.25f, 0, Mathf.Tau, 64, padOn ? Ui.Amber : new Color(1, 1, 1, 0.75f), 2.5f, true);
            }
            // gear slider
            Capsule(shifter, Fill, shOn ? Ui.Amber : Edge);
            // + at the top, - at the bottom
            var pc = new Vector2(shifter.GetCenter().X, shifter.Position.Y + 24); var mc = new Vector2(shifter.GetCenter().X, shifter.End.Y - 24);
            var signCol = new Color(1, 1, 1, 0.85f);
            DrawLine(pc - new Vector2(9, 0), pc + new Vector2(9, 0), signCol, 3); DrawLine(pc - new Vector2(0, 9), pc + new Vector2(0, 9), signCol, 3);
            DrawLine(mc - new Vector2(9, 0), mc + new Vector2(9, 0), signCol, 3);
            float ks = u * 0.86f;
            var kr = new Rect2(shifter.GetCenter().X - ks / 2, shifter.GetCenter().Y - ks / 2 + shY, ks, ks);
            DrawStyleBox(Ui.Cached(new Color(12 / 255f, 15 / 255f, 19 / 255f, 0.82f), 18, Ui.Amber, 2), kr);
            Label(GearText, new Vector2(kr.GetCenter().X, kr.GetCenter().Y - ks * 0.1f), (int)(u * 0.42f), Ui.Amber);
            Label(ModeText, new Vector2(kr.GetCenter().X, kr.GetCenter().Y + ks * 0.3f), 14, Ui.Muted, Ui.Body);
            // pedals
            Capsule(gas, Fill, new Color(Ui.Amber, gasOn ? 1 : 0.85f));
            if (gasOn)
            {
                float h = Mathf.Max(gas.Size.X, gas.Size.Y * gasP);
                var fr = new Rect2(gas.Position.X + 2, gas.End.Y - h + 2, gas.Size.X - 4, h - 4);
                DrawStyleBox(Ui.Cached(new Color(Ui.Amber, 0.88f), (int)(gas.Size.X / 2 - 2)), fr);
            }
            Label("GAS", gas.GetCenter(), 24, gasOn && gasP > 0.55f ? Ui.AmberInk : InkC);
            Disc(brake, Fill, brakeOn ? Ui.Amber : Edge);
            if (brakeOn) DiscFill(brake, brakeP, new Color(Ui.Amber, 0.88f));
            Label("BRAKE", brake.GetCenter(), 22, brakeOn && brakeP > 0.55f ? Ui.AmberInk : InkC);
            Disc(hand, handOn ? amberFill : Fill, handOn ? Ui.Amber : Edge);
            Label("HAND", hand.GetCenter(), 17, handOn ? Ui.AmberInk : InkC);
        }

        // where the controls sit, so the HUD can stay clear of them
        public float LeftEdgeOfRight { get { Layout(); return hand.Position.X; } }
        public float RightEdgeOfLeft { get { Layout(); return shifter.End.X; } }
        public Vector2 GasCenter { get { Layout(); return gas.GetCenter(); } }
    }
}
