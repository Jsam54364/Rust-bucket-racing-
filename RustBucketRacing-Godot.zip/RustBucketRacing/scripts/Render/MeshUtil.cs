// Small helpers for building Godot meshes from plain arrays.
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public static class MeshUtil
    {
        public static Vector3 V(V3 v) => new Vector3((float)v.X, (float)v.Y, (float)v.Z);
        public static Vector3 V(double x, double y, double z) => new Vector3((float)x, (float)y, (float)z);

        public static Godot.Collections.Array Arrays(Vector3[] pos, Vector3[] nrm, Vector2[] uv, Color[] col, int[] idx)
        {
            var a = new Godot.Collections.Array();
            a.Resize((int)Mesh.ArrayType.Max);
            a[(int)Mesh.ArrayType.Vertex] = pos;
            if (nrm != null) a[(int)Mesh.ArrayType.Normal] = nrm;
            if (uv != null) a[(int)Mesh.ArrayType.TexUV] = uv;
            if (col != null) a[(int)Mesh.ArrayType.Color] = col;
            if (idx != null) a[(int)Mesh.ArrayType.Index] = idx;
            return a;
        }

        public static ArrayMesh Build(Vector3[] pos, Vector3[] nrm, Vector2[] uv, Color[] col, int[] idx, Material mat = null)
        {
            var m = new ArrayMesh();
            m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, Arrays(pos, nrm, uv, col, idx));
            if (mat != null) m.SurfaceSetMaterial(0, mat);
            return m;
        }

        // Godot draws clockwise triangles as front faces. Make every triangle face the way its vertex normals
        // point, whatever order the source listed it in.
        public static void FixWinding(Vector3[] pos, Vector3[] nrm, int[] idx)
        {
            for (int i = 0; i + 2 < idx.Length; i += 3)
            {
                int a = idx[i], b = idx[i + 1], c = idx[i + 2];
                Vector3 front = (pos[c] - pos[a]).Cross(pos[b] - pos[a]); // the clockwise front normal
                Vector3 n = nrm[a] + nrm[b] + nrm[c];
                if (front.Dot(n) < 0) { idx[i + 1] = c; idx[i + 2] = b; }
            }
        }

        // glTF lists triangles counter-clockwise; Godot wants them clockwise
        public static void Reverse(int[] idx)
        {
            for (int i = 0; i + 2 < idx.Length; i += 3) { int t = idx[i + 1]; idx[i + 1] = idx[i + 2]; idx[i + 2] = t; }
        }

        // index buffer for a grid of nu x nv vertices laid out row by row (v fastest)
        public static int[] GridIndices(int nu, int nv)
        {
            var idx = new int[(nu - 1) * (nv - 1) * 6];
            int k = 0;
            for (int i = 0; i < nu - 1; i++)
                for (int j = 0; j < nv - 1; j++)
                {
                    int a = i * nv + j, b = a + 1, c = a + nv, d = c + 1;
                    idx[k++] = a; idx[k++] = c; idx[k++] = b; idx[k++] = b; idx[k++] = c; idx[k++] = d;
                }
            return idx;
        }

        public static Texture2D LoadImage(byte[] bytes, string mime)
        {
            var img = new Image();
            Error err;
            if (mime != null && mime.Contains("png")) err = img.LoadPngFromBuffer(bytes);
            else if (mime != null && (mime.Contains("jpeg") || mime.Contains("jpg"))) err = img.LoadJpgFromBuffer(bytes);
            else err = img.LoadWebpFromBuffer(bytes);
            if (err != Error.Ok || img.IsEmpty()) return null;
            img.GenerateMipmaps();
            return ImageTexture.CreateFromImage(img);
        }
    }
}
