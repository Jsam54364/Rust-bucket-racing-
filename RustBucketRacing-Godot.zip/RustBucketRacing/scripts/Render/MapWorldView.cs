// A map pack drawn in Godot: one MeshInstance3D per chunk and fade class (a surface per material draw),
// so frustum culling drops chunks out of view and visibility ranges drop small things far away; the shader
// dithers them out over the last 22 % of their range.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class MapWorldView
    {
        public readonly Node3D Root = new Node3D { Name = "MapWorld" };
        public readonly float FloorY;

        // depth bias toward the camera for stacked ground layers: (metres, metres per metre of distance)
        public static readonly Vector2 BiasUnder = new Vector2(-0.006f, -0.0012f);
        public static readonly Vector2 BiasPit = new Vector2(0.004f, 0.0007f);

        public MapWorldView(MapPack pk)
        {
            var shGround = GD.Load<Shader>("res://shaders/world_ground.gdshader");
            var shCut = GD.Load<Shader>("res://shaders/world_cut.gdshader");
            var shBlend = GD.Load<Shader>("res://shaders/world_blend.gdshader");

            var tex = new Texture2D[pk.ImageCount];
            for (int i = 0; i < tex.Length; i++)
            {
                try { tex[i] = MeshUtil.LoadImage(pk.Image(i), "image/webp"); }
                catch (Exception e) { GD.PushWarning($"map texture {i}: {e.Message}"); }
            }

            var mats = new ShaderMaterial[pk.Materials.Length];
            for (int i = 0; i < mats.Length; i++)
            {
                var m = pk.Materials[i];
                Shader sh = m.Mode == 2 ? shBlend : (m.Cat == "ground" && m.Mode == 0 ? shGround : shCut);
                var sm = new ShaderMaterial { Shader = sh };
                bool hasTex = m.Tex >= 0 && m.Tex < tex.Length && tex[m.Tex] != null;
                if (hasTex) sm.SetShaderParameter("tex", tex[m.Tex]);
                sm.SetShaderParameter("has_tex", hasTex);
                var c = m.Color;
                sm.SetShaderParameter("color", new Vector4((float)c[0], (float)c[1], (float)c[2], c.Length > 3 ? (float)c[3] : 1f));
                sm.SetShaderParameter("kind", m.Cat == "ground" ? 0 : m.Cat == "veg" ? 1 : 2);
                sm.SetShaderParameter("mat_mode", m.Mode);
                sm.SetShaderParameter("spec", (float)m.Spec);
                sm.SetShaderParameter("fade", m.Fade > 0 ? new Vector2((float)(m.Fade * 0.78), (float)m.Fade) : Vector2.Zero);
                if (m.UnderTex >= 0 && m.UnderTex < tex.Length && tex[m.UnderTex] != null)
                {
                    sm.SetShaderParameter("under_tex", tex[m.UnderTex]);
                    sm.SetShaderParameter("under_k", new Vector2((float)m.UnderK, 1f));
                }
                else sm.SetShaderParameter("under_k", Vector2.Zero);
                sm.SetShaderParameter("bias", m.Layer > 0 ? BiasPit : m.Layer < 0 ? BiasUnder : Vector2.Zero);
                mats[i] = sm;
            }

            double q = 1 / pk.Qs;
            double floor = double.PositiveInfinity;
            foreach (var ch in pk.Chunks) floor = Math.Min(floor, ch.Min[1]);
            FloorY = (float)(floor - 3);

            int maxVn = 0;
            foreach (var ch in pk.Chunks) maxVn = Math.Max(maxVn, ch.VN);
            var remap = new int[Math.Max(1, maxVn)];
            for (int i = 0; i < remap.Length; i++) remap[i] = -1;
            var touched = new List<int>();
            var pos = new List<Vector3>(); var nrm = new List<Vector3>(); var uv = new List<Vector2>();

            int ci = 0;
            foreach (var ch in pk.Chunks)
            {
                var center = new Vector3((float)((ch.Min[0] + ch.Max[0]) / 2), (float)((ch.Min[1] + ch.Max[1]) / 2), (float)((ch.Min[2] + ch.Max[2]) / 2));
                double rx = (ch.Max[0] - ch.Min[0]) / 2, ry = (ch.Max[1] - ch.Min[1]) / 2, rz = (ch.Max[2] - ch.Min[2]) / 2;
                double radius = Math.Sqrt(rx * rx + ry * ry + rz * rz);
                // group the chunk's draws by (fade distance, casts shadows)
                var groups = new Dictionary<(double, bool), List<MapDraw>>();
                var order = new List<(double, bool)>();
                foreach (var d in ch.Draws)
                {
                    var m = pk.Materials[d.Mat];
                    var key = (m.Fade, m.Shadow);
                    if (!groups.TryGetValue(key, out var list)) { list = new List<MapDraw>(); groups[key] = list; order.Add(key); }
                    list.Add(d);
                }
                foreach (var key in order)
                {
                    var mesh = new ArrayMesh();
                    foreach (var d in groups[key])
                    {
                        if (d.N < 3) continue;
                        pos.Clear(); nrm.Clear(); uv.Clear(); touched.Clear();
                        var idx = new int[d.N - d.N % 3];
                        double ku = 1 / d.Kq;
                        for (int j = 0; j < idx.Length; j++)
                        {
                            int li = pk.Idx[ch.I0 + d.I0 + j];
                            if (li >= remap.Length) { idx[j] = 0; continue; }
                            if (remap[li] < 0)
                            {
                                remap[li] = pos.Count; touched.Add(li);
                                int v = ch.V0 + li;
                                pos.Add(new Vector3(
                                    (float)(ch.O[0] + pk.PosQ(v, 0) * q - center.X),
                                    (float)(ch.O[1] + pk.PosQ(v, 1) * q - center.Y),
                                    (float)(ch.O[2] + pk.PosQ(v, 2) * q - center.Z)));
                                var n = new Vector3(Math.Max(pk.NrmQ(v, 0) / 127f, -1f), Math.Max(pk.NrmQ(v, 1) / 127f, -1f), Math.Max(pk.NrmQ(v, 2) / 127f, -1f));
                                nrm.Add(n.LengthSquared() > 1e-8f ? n.Normalized() : Vector3.Up);
                                uv.Add(new Vector2((float)(pk.UvQ(v, 0) * ku + d.UOff), (float)(pk.UvQ(v, 1) * ku + d.VOff)));
                            }
                            idx[j] = remap[li];
                        }
                        foreach (int li in touched) remap[li] = -1;
                        if (pos.Count == 0) continue;
                        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, MeshUtil.Arrays(pos.ToArray(), nrm.ToArray(), uv.ToArray(), null, idx));
                        mesh.SurfaceSetMaterial(mesh.GetSurfaceCount() - 1, mats[d.Mat]);
                    }
                    if (mesh.GetSurfaceCount() == 0) continue;
                    var mi = new MeshInstance3D
                    {
                        Name = $"chunk{ci}_{(int)key.Item1}{(key.Item2 ? "s" : "")}",
                        Mesh = mesh,
                        Position = center,
                        CastShadow = key.Item2 ? GeometryInstance3D.ShadowCastingSetting.On : GeometryInstance3D.ShadowCastingSetting.Off,
                    };
                    if (key.Item1 > 0) mi.VisibilityRangeEnd = (float)(key.Item1 + radius);
                    Root.AddChild(mi);
                }
                ci++;
            }
        }
    }
}
