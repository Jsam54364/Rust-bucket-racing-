// Skid marks (a ring buffer of quads, uploaded in chunks as they change) and tyre smoke / dust billboards.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Render
{
    public sealed class SkidMarks
    {
        const int CHUNK = 250, CHUNKS = 32, MAX = CHUNK * CHUNKS; // 8000 segments
        public readonly Node3D Root = new Node3D { Name = "SkidMarks" };
        readonly Vector3[] pos = new Vector3[MAX * 4];
        readonly Color[] col = new Color[MAX * 4];
        readonly MeshInstance3D[] chunks = new MeshInstance3D[CHUNKS];
        readonly ArrayMesh[] meshes = new ArrayMesh[CHUNKS];
        readonly bool[] dirty = new bool[CHUNKS], used = new bool[CHUNKS];
        readonly int[] quadIdx;
        readonly ShaderMaterial mat;
        int head;

        public SkidMarks()
        {
            mat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/skid.gdshader") };
            quadIdx = new int[CHUNK * 6];
            for (int i = 0; i < CHUNK; i++)
            {
                int o = i * 4;
                quadIdx[i * 6] = o; quadIdx[i * 6 + 1] = o + 1; quadIdx[i * 6 + 2] = o + 2;
                quadIdx[i * 6 + 3] = o + 1; quadIdx[i * 6 + 4] = o + 3; quadIdx[i * 6 + 5] = o + 2;
            }
            for (int c = 0; c < CHUNKS; c++)
            {
                meshes[c] = new ArrayMesh();
                chunks[c] = new MeshInstance3D { Mesh = meshes[c], CastShadow = GeometryInstance3D.ShadowCastingSetting.Off, Visible = false };
                Root.AddChild(chunks[c]);
            }
        }

        // a, b: segment endpoints on the ground; n: ground normal; w: half width
        public void Add(V3 a, V3 b, V3 n, double w, double alpha, Color c)
        {
            V3 d = b - a;
            V3 s = V3.Cross(d, n);
            double l = s.Length(); if (!(l > 0)) l = 1;
            s = s * (w / l);
            const double lift = 0.012;
            int i = head;
            pos[i * 4] = MeshUtil.V(a.X - s.X, a.Y + lift, a.Z - s.Z);
            pos[i * 4 + 1] = MeshUtil.V(a.X + s.X, a.Y + lift, a.Z + s.Z);
            pos[i * 4 + 2] = MeshUtil.V(b.X - s.X, b.Y + lift, b.Z - s.Z);
            pos[i * 4 + 3] = MeshUtil.V(b.X + s.X, b.Y + lift, b.Z + s.Z);
            var cc = new Color(c.R, c.G, c.B, (float)alpha);
            for (int k = 0; k < 4; k++) col[i * 4 + k] = cc;
            int ch = i / CHUNK;
            dirty[ch] = true; used[ch] = true;
            head = (i + 1) % MAX;
        }

        public void Clear()
        {
            Array.Clear(pos, 0, pos.Length);
            Array.Clear(col, 0, col.Length);
            for (int c = 0; c < CHUNKS; c++) { dirty[c] = false; used[c] = false; meshes[c].ClearSurfaces(); chunks[c].Visible = false; }
            head = 0;
        }

        // upload the chunks that changed this frame
        public void Flush()
        {
            for (int c = 0; c < CHUNKS; c++)
            {
                if (!dirty[c]) continue;
                dirty[c] = false;
                var p = new Vector3[CHUNK * 4]; var k = new Color[CHUNK * 4]; var nrm = new Vector3[CHUNK * 4];
                Array.Copy(pos, c * CHUNK * 4, p, 0, CHUNK * 4);
                Array.Copy(col, c * CHUNK * 4, k, 0, CHUNK * 4);
                for (int i = 0; i < nrm.Length; i++) nrm[i] = Vector3.Up;
                var m = meshes[c];
                m.ClearSurfaces();
                m.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, MeshUtil.Arrays(p, nrm, null, k, quadIdx));
                m.SurfaceSetMaterial(0, mat);
                chunks[c].Visible = used[c];
            }
        }
    }

    public sealed class SmokeView
    {
        public const int MAX = 700;
        public readonly MultiMeshInstance3D Node;
        readonly MultiMesh mm;

        public SmokeView()
        {
            var quadPos = new[] { new Vector3(-0.5f, -0.5f, 0), new Vector3(0.5f, -0.5f, 0), new Vector3(-0.5f, 0.5f, 0), new Vector3(0.5f, 0.5f, 0) };
            var quadUv = new[] { new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(1, 1) };
            var quadN = new[] { Vector3.Back, Vector3.Back, Vector3.Back, Vector3.Back };
            var quadC = new[] { Colors.White, Colors.White, Colors.White, Colors.White };
            var mat = new ShaderMaterial { Shader = GD.Load<Shader>("res://shaders/smoke.gdshader") };
            var mesh = MeshUtil.Build(quadPos, quadN, quadUv, quadC, new[] { 0, 1, 2, 1, 3, 2 }, mat);
            mm = new MultiMesh { TransformFormat = MultiMesh.TransformFormatEnum.Transform3D, UseColors = true, Mesh = mesh };
            mm.InstanceCount = MAX;
            mm.VisibleInstanceCount = 0;
            mm.CustomAabb = new Aabb(new Vector3(-50000, -5000, -50000), new Vector3(100000, 10000, 100000));
            Node = new MultiMeshInstance3D { Name = "Smoke", Multimesh = mm, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
        }

        readonly List<(double d, int i)> order = new List<(double, int)>();

        // far to near so blending reads correctly; quads face the camera
        public void Update(List<Puff> puffs, Vector3 camPos, Vector3 camTarget)
        {
            var fwd = camTarget - camPos;
            var right = new Vector3(-fwd.Z, 0, fwd.X);
            right = right.LengthSquared() > 1e-8f ? right.Normalized() : Vector3.Right;
            var f = fwd.LengthSquared() > 1e-8f ? fwd.Normalized() : Vector3.Forward;
            var up = right.Cross(f);
            int n = Math.Min(puffs.Count, MAX);
            order.Clear();
            for (int i = 0; i < n; i++)
            {
                var p = puffs[i].P;
                double dx = p.X - camPos.X, dy = p.Y - camPos.Y, dz = p.Z - camPos.Z;
                order.Add((dx * dx + dy * dy + dz * dz, i));
            }
            order.Sort((a, b) => b.d.CompareTo(a.d));
            for (int k = 0; k < n; k++)
            {
                var s = puffs[order[k].i];
                float size = (float)s.Size;
                var basis = new Basis(right * size, up * size, -f);
                mm.SetInstanceTransform(k, new Transform3D(basis, MeshUtil.V(s.P)));
                mm.SetInstanceColor(k, new Color(s.Col.R, s.Col.G, s.Col.B, (float)s.A));
            }
            mm.VisibleInstanceCount = n;
        }
    }

    public sealed class Puff
    {
        public V3 P, V;
        public double Age, Life, S0, S1, A0, Size, A;
        public bool Dust;
        public Color Col = new Color(0.78f, 0.78f, 0.8f);
    }
}
