extends Control
## First scene. Normally it just loads the game (Main.tscn). If the game closed while it was starting or
## loading last time, it shows that run's log instead, with a button to copy it, so the crash can be fixed.
## It is GDScript on purpose: it still works if the C# side fails to start.

const STATE_PATH := "user://boot_state.txt"

var report := ""


func _ready() -> void:
	var prev := ""
	if FileAccess.file_exists(STATE_PATH):
		prev = FileAccess.get_file_as_string(STATE_PATH).strip_edges()
	var smoke := OS.get_cmdline_user_args().has("--smoke")
	if prev != "" and prev != "ok" and not smoke:
		_show_report(prev)
	else:
		_start()


func _start() -> void:
	var f := FileAccess.open(STATE_PATH, FileAccess.WRITE)
	if f:
		f.store_string("starting")
		f.close()
	print("[boot] loading the game")
	get_tree().call_deferred("change_scene_to_file", "res://Main.tscn")


# Godot renames the previous run's godot.log to godot<date>.log when it starts, so the newest of those is it.
func _previous_log() -> String:
	var path: String = ProjectSettings.get_setting("debug/file_logging/log_path", "user://logs/godot.log")
	var dir := path.get_base_dir()
	var stem := path.get_file().get_basename()
	var ext := path.get_extension()
	var newest := ""
	if DirAccess.dir_exists_absolute(dir):
		for name in DirAccess.get_files_at(dir):
			if name != path.get_file() and name.begins_with(stem) and name.ends_with("." + ext) and name > newest:
				newest = name
	if newest == "":
		return "(no log from the last run was found)"
	var lines := FileAccess.get_file_as_string(dir.path_join(newest)).split("\n")
	var start := maxi(0, lines.size() - 160)
	return "\n".join(lines.slice(start))


func _show_report(state: String) -> void:
	report = "Rust Bucket Racing closed while: %s\n" % state
	report += "%s %s · %s · %s %s · %s\n" % [OS.get_name(), OS.get_version(), OS.get_model_name(),
		RenderingServer.get_video_adapter_vendor(), RenderingServer.get_video_adapter_name(),
		RenderingServer.get_video_adapter_api_version()]
	report += "----\n" + _previous_log()

	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.08, 0.10)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	var title := Label.new()
	title.text = "The game closed unexpectedly last time"
	title.add_theme_font_size_override("font_size", 30)
	col.add_child(title)
	var info := Label.new()
	info.text = "Tap Copy report and paste it into your chat with Claude so it can be fixed. Then tap Start game to try again."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_font_size_override("font_size", 20)
	col.add_child(info)

	var box := TextEdit.new()
	box.text = report
	box.editable = false
	box.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_font_size_override("font_size", 16)
	col.add_child(box)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	col.add_child(row)
	var copy := Button.new()
	copy.text = "Copy report"
	copy.custom_minimum_size = Vector2(260, 64)
	copy.add_theme_font_size_override("font_size", 22)
	copy.pressed.connect(_on_copy.bind(copy))
	row.add_child(copy)
	var go := Button.new()
	go.text = "Start game"
	go.custom_minimum_size = Vector2(260, 64)
	go.add_theme_font_size_override("font_size", 22)
	go.pressed.connect(_start)
	row.add_child(go)


func _on_copy(button: Button) -> void:
	DisplayServer.clipboard_set(report)
	button.text = "Copied"
