// Feeds EngineAudio's mono mix to Godot through an AudioStreamGenerator.
using System;
using Godot;

namespace RustBucket.Audio
{
    public partial class AudioOut : Node
    {
        const int CHUNK = 256;
        AudioStreamPlayer player;
        AudioStreamGeneratorPlayback playback;
        public EngineAudio Engine;
        readonly float[] mono = new float[CHUNK];
        readonly Vector2[] frames = new Vector2[CHUNK];
        public double MixRate { get; private set; } = 44100;

        public override void _Ready()
        {
            MixRate = AudioServer.GetMixRate();
            if (!(MixRate >= 8000)) MixRate = 44100;
            var gen = new AudioStreamGenerator { MixRate = (float)MixRate, BufferLength = 0.08f };
            player = new AudioStreamPlayer { Stream = gen, VolumeDb = 0 };
            AddChild(player);
            player.Play();
            playback = player.GetStreamPlayback() as AudioStreamGeneratorPlayback;
        }

        public override void _Process(double delta)
        {
            if (playback == null || Engine == null) return;
            // keep the generator topped up; never more than a buffer's worth at once
            int guard = 0;
            while (playback.GetFramesAvailable() >= CHUNK && guard++ < 64)
            {
                Engine.Render(mono, CHUNK);
                for (int i = 0; i < CHUNK; i++) frames[i] = new Vector2(mono[i], mono[i]);
                playback.PushBuffer(frames);
            }
        }
    }
}
