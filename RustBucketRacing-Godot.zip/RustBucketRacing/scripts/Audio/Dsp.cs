// DSP building blocks matching the Web Audio nodes the browser version used: biquads (Web Audio formulas,
// including its Q-in-dB lowpass/highpass), smoothed parameters (setTargetAtTime), the WaveShaper curves and a
// DynamicsCompressor with the same automatic make-up gain.
using System;

namespace RustBucket.Audio
{
    public enum BiquadType { Lowpass, Highpass, Bandpass, Peaking, Lowshelf }

    public sealed class Biquad
    {
        public BiquadType Type;
        public double Freq, Q, GainDb;
        double b0, b1, b2, a1, a2, x1, x2, y1, y2;
        readonly double rate;
        double setFreq = -1, setQ = double.NaN, setGain = double.NaN;

        public Biquad(BiquadType type, double rate, double freq, double q = 1, double gainDb = 0)
        {
            Type = type; this.rate = rate; Freq = freq; Q = q; GainDb = gainDb;
            Update();
        }

        // recompute coefficients if a parameter moved (call once per block)
        public void Update()
        {
            if (Freq == setFreq && Q == setQ && GainDb == setGain) return;
            setFreq = Freq; setQ = Q; setGain = GainDb;
            double nyq = rate / 2;
            double f = Math.Max(1, Math.Min(Freq, nyq * 0.999));
            double w0 = 2 * Math.PI * f / rate, cw = Math.Cos(w0), sw = Math.Sin(w0);
            double B0, B1, B2, A0, A1, A2;
            switch (Type)
            {
                case BiquadType.Lowpass:
                {
                    double alpha = sw / (2 * Math.Pow(10, Q / 20));
                    B0 = (1 - cw) / 2; B1 = 1 - cw; B2 = (1 - cw) / 2; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha;
                    break;
                }
                case BiquadType.Highpass:
                {
                    double alpha = sw / (2 * Math.Pow(10, Q / 20));
                    B0 = (1 + cw) / 2; B1 = -(1 + cw); B2 = (1 + cw) / 2; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha;
                    break;
                }
                case BiquadType.Bandpass:
                {
                    double alpha = sw / (2 * Math.Max(1e-4, Q));
                    B0 = alpha; B1 = 0; B2 = -alpha; A0 = 1 + alpha; A1 = -2 * cw; A2 = 1 - alpha;
                    break;
                }
                case BiquadType.Peaking:
                {
                    double A = Math.Pow(10, GainDb / 40), alpha = sw / (2 * Math.Max(1e-4, Q));
                    B0 = 1 + alpha * A; B1 = -2 * cw; B2 = 1 - alpha * A; A0 = 1 + alpha / A; A1 = -2 * cw; A2 = 1 - alpha / A;
                    break;
                }
                default: // lowshelf, slope 1
                {
                    double A = Math.Pow(10, GainDb / 40), alpha = sw / 2 * Math.Sqrt(2), sa = 2 * Math.Sqrt(A) * alpha;
                    B0 = A * ((A + 1) - (A - 1) * cw + sa); B1 = 2 * A * ((A - 1) - (A + 1) * cw); B2 = A * ((A + 1) - (A - 1) * cw - sa);
                    A0 = (A + 1) + (A - 1) * cw + sa; A1 = -2 * ((A - 1) + (A + 1) * cw); A2 = (A + 1) + (A - 1) * cw - sa;
                    break;
                }
            }
            b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0; a1 = A1 / A0; a2 = A2 / A0;
        }

        public double Process(double x)
        {
            double y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
            x2 = x1; x1 = x; y2 = y1; y1 = y;
            if (Math.Abs(y1) < 1e-20) y1 = 0; // no denormals
            return y;
        }
    }

    // a parameter that follows its target exponentially (Web Audio setTargetAtTime), per sample
    public struct Param
    {
        public double V, Target;
        double c;
        public Param(double v) { V = v; Target = v; c = 1; }
        public void Set(double target, double tau, double rate) { Target = target; c = 1 - Math.Exp(-1 / (Math.Max(1e-5, tau) * rate)); }
        public double Next() { V += (Target - V) * c; return V; }
        public void Jump(double v) { V = v; Target = v; }
    }

    public static class Shape
    {
        // FMOD-style distortion: y = (1+k)x / (1+k|x|), k = 2L/(1-L); the WaveShaper clamps its input to +-1
        public static double DistK(double level) => (2 * level) / Math.Max(1e-3, 1 - level);
        public static double Dist(double x, double k)
        {
            if (x > 1) x = 1; else if (x < -1) x = -1;
            return ((1 + k) * x) / (1 + k * Math.Abs(x));
        }

        // last stage: transparent below 80 % level, rounds off anything above so nothing hard-clips
        public static double Soft(double x)
        {
            if (double.IsNaN(x)) return 0;
            if (x > 1) x = 1; else if (x < -1) x = -1;
            double a = Math.Abs(x);
            return a < 0.8 ? x : (x >= 0 ? 1 : -1) * (0.8 + 0.2 * Math.Tanh((a - 0.8) / 0.2));
        }
    }

    // Web Audio DynamicsCompressorNode, simplified: peak detector with attack / release, soft knee, and the
    // node's automatic make-up gain ((1 / curve(0 dB)) ^ 0.6).
    public sealed class Compressor
    {
        readonly double threshold, knee, ratio, attackC, releaseC, makeup;
        double envDb = -120;

        public Compressor(double rate, double thresholdDb, double kneeDb, double ratio, double attack, double release)
        {
            threshold = thresholdDb; knee = kneeDb; this.ratio = ratio;
            attackC = 1 - Math.Exp(-1 / (attack * rate));
            releaseC = 1 - Math.Exp(-1 / (release * rate));
            double full = Curve(0); // output level for a 0 dB input
            makeup = Math.Pow(Math.Pow(10, -full / 20), 0.6);
        }

        double Curve(double inDb)
        {
            double over = inDb - threshold;
            if (knee > 0 && Math.Abs(over) <= knee / 2)
                return inDb + (1 / ratio - 1) * (over + knee / 2) * (over + knee / 2) / (2 * knee);
            if (over > knee / 2) return threshold + over / ratio;
            return inDb;
        }

        public double Process(double x)
        {
            double lvl = Math.Abs(x);
            double db = lvl > 1e-6 ? 20 * Math.Log10(lvl) : -120;
            envDb += (db - envDb) * (db > envDb ? attackC : releaseC);
            double gainDb = Curve(envDb) - envDb;
            return x * Math.Pow(10, gainDb / 20) * makeup;
        }
    }

    // fast white noise
    public struct Noise
    {
        uint s;
        public Noise(uint seed) { s = seed == 0 ? 1u : seed; }
        public double Next()
        {
            s ^= s << 13; s ^= s >> 17; s ^= s << 5;
            return s / 2147483648.0 - 1.0;
        }
    }
}
