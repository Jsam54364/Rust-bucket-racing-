// Double-precision vector / quaternion helpers for the simulation (no Godot types in here).
// World: +Y up. Car local frame: forward = -Z, right = +X, up = +Y (the same as Godot's).
using System;

namespace RustBucket.Sim
{
    public struct V3
    {
        public double X, Y, Z;
        public V3(double x, double y, double z) { X = x; Y = y; Z = z; }

        public static readonly V3 Zero = new V3(0, 0, 0);
        public static readonly V3 UnitX = new V3(1, 0, 0);
        public static readonly V3 UnitY = new V3(0, 1, 0);
        public static readonly V3 Fwd = new V3(0, 0, -1);

        public static V3 operator +(V3 a, V3 b) => new V3(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        public static V3 operator -(V3 a, V3 b) => new V3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        public static V3 operator -(V3 a) => new V3(-a.X, -a.Y, -a.Z);
        public static V3 operator *(V3 a, double s) => new V3(a.X * s, a.Y * s, a.Z * s);
        public static V3 operator *(double s, V3 a) => new V3(a.X * s, a.Y * s, a.Z * s);

        public static double Dot(V3 a, V3 b) => a.X * b.X + a.Y * b.Y + a.Z * b.Z;
        public static V3 Cross(V3 a, V3 b) => new V3(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X);
        public double Length() => Math.Sqrt(X * X + Y * Y + Z * Z);

        // like the JS nrm(): a zero (or NaN) length divides by 1
        public V3 Normalized()
        {
            double l = Length();
            if (!(l > 0)) l = 1;
            return new V3(X / l, Y / l, Z / l);
        }

        public bool IsFinite() => double.IsFinite(X) && double.IsFinite(Y) && double.IsFinite(Z);
        public override string ToString() => $"({X:0.###}, {Y:0.###}, {Z:0.###})";
    }

    public struct Q4
    {
        public double X, Y, Z, W;
        public Q4(double x, double y, double z, double w) { X = x; Y = y; Z = z; W = w; }

        public static readonly Q4 Identity = new Q4(0, 0, 0, 1);

        public static Q4 Mul(Q4 a, Q4 b) => new Q4(
            a.W * b.X + a.X * b.W + a.Y * b.Z - a.Z * b.Y,
            a.W * b.Y - a.X * b.Z + a.Y * b.W + a.Z * b.X,
            a.W * b.Z + a.X * b.Y - a.Y * b.X + a.Z * b.W,
            a.W * b.W - a.X * b.X - a.Y * b.Y - a.Z * b.Z);

        public V3 Rotate(V3 v)
        {
            double tx = 2 * (Y * v.Z - Z * v.Y), ty = 2 * (Z * v.X - X * v.Z), tz = 2 * (X * v.Y - Y * v.X);
            return new V3(v.X + W * tx + (Y * tz - Z * ty), v.Y + W * ty + (Z * tx - X * tz), v.Z + W * tz + (X * ty - Y * tx));
        }

        public Q4 Conj() => new Q4(-X, -Y, -Z, W);

        public Q4 Normalized()
        {
            double l = Math.Sqrt(X * X + Y * Y + Z * Z + W * W);
            if (!(l > 0)) l = 1;
            return new Q4(X / l, Y / l, Z / l, W / l);
        }

        public static Q4 Axis(V3 ax, double a)
        {
            double s = Math.Sin(a / 2);
            return new Q4(ax.X * s, ax.Y * s, ax.Z * s, Math.Cos(a / 2));
        }
    }

    public static class M
    {
        public const double PI = Math.PI;
        public static double Clamp(double x, double a, double b) => x < a ? a : x > b ? b : x;
        public static int ClampI(int x, int a, int b) => x < a ? a : x > b ? b : x;
        public static double Lerp(double a, double b, double t) => a + (b - a) * t;
        public static double Smooth01(double t) { t = Clamp(t, 0, 1); return t * t * (3 - 2 * t); }
        // Math.Sign throws on NaN; this one doesn't
        public static double Sgn(double x) => x > 0 ? 1 : x < 0 ? -1 : 0;
        public static double WrapA(double a) => Math.Atan2(Math.Sin(a), Math.Cos(a));
        public static double Hypot(double a, double b) => Math.Sqrt(a * a + b * b);
        public static double Hypot(double a, double b, double c) => Math.Sqrt(a * a + b * b + c * c);
        public static double Mod(double a, double n) => ((a % n) + n) % n;
        public static V3 FwdFromYaw(double a) => new V3(-Math.Sin(a), 0, -Math.Cos(a));
        public static V3 RightFromYaw(double a) => new V3(Math.Cos(a), 0, -Math.Sin(a));
        public static double Min3(double a, double b, double c) => Math.Min(a, Math.Min(b, c));
        public static double Max3(double a, double b, double c) => Math.Max(a, Math.Max(b, c));

        static readonly Random rng = new Random();
        public static double Rand() => rng.NextDouble();
    }
}
