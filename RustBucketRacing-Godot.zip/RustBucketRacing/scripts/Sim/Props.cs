// Traffic cones the car can knock flying, and the lap timer.
using System;
using System.Collections.Generic;

namespace RustBucket.Sim
{
    public sealed class Cone
    {
        public double HomeX, HomeZ, Yaw0;
        public V3 Pos, Vel, Axis = V3.UnitX;
        public double Yaw, Spin, Tilt, TiltVel;
        public bool Loose;
    }

    public sealed class Cones
    {
        public readonly List<Cone> List = new List<Cone>();
        public TerrainBase Terrain;

        public Cones(List<(double x, double z)> spots, TerrainBase terrain)
        {
            Terrain = terrain;
            for (int i = 0; i < spots.Count; i++)
                List.Add(new Cone { HomeX = spots[i].x, HomeZ = spots[i].z, Yaw0 = (i * 2.39996) % (Math.PI * 2) });
            Reset();
        }

        public void Reset()
        {
            foreach (var c in List)
            {
                c.Pos = new V3(c.HomeX, Terrain.Height(c.HomeX, c.HomeZ), c.HomeZ);
                c.Vel = V3.Zero; c.Yaw = c.Yaw0; c.Spin = 0; c.Axis = V3.UnitX; c.Tilt = 0; c.TiltVel = 0; c.Loose = false;
            }
        }

        public void Step(double dt, Car car)
        {
            var S = car.Spec;
            V3 com = car.ComModel;
            Q4 qi = car.Q.Conj();
            V3 cp = car.Pos;
            foreach (var c in List)
            {
                double dxw = c.Pos.X - cp.X, dzw = c.Pos.Z - cp.Z;
                if (dxw * dxw + dzw * dzw < 12)
                {
                    V3 mid = new V3(c.Pos.X, c.Pos.Y + 0.3, c.Pos.Z);
                    V3 l = qi.Rotate(mid - cp) + com; // model frame
                    const double r = 0.17;
                    if (l.X > S.HullMinX - r && l.X < S.HullMaxX + r && l.Z > S.HullMinZ - r && l.Z < S.HullMaxZ + r && l.Y > S.HullMinY - 0.35 && l.Y < S.HullMaxY)
                    {
                        // push out through the nearest side of the hull box
                        double best = l.X - (S.HullMinX - r); V3 nl = new V3(-1, 0, 0);
                        double p1 = (S.HullMaxX + r) - l.X; if (p1 < best) { best = p1; nl = new V3(1, 0, 0); }
                        double p2 = l.Z - (S.HullMinZ - r); if (p2 < best) { best = p2; nl = new V3(0, 0, -1); }
                        double p3 = (S.HullMaxZ + r) - l.Z; if (p3 < best) { best = p3; nl = new V3(0, 0, 1); }
                        V3 n = car.Q.Rotate(nl); n = new V3(n.X, 0, n.Z).Normalized();
                        V3 vc = car.PointVel(mid);
                        double rel = V3.Dot(vc - c.Vel, n);
                        c.Pos = c.Pos + n * (best + 0.01);
                        if (rel > 0.3)
                        {
                            double kick = rel * 1.35 + 0.4;
                            V3 v = vc * 0.55 + n * kick;
                            c.Vel = new V3(v.X, 0.8 + rel * 0.22, v.Z);
                            c.Axis = V3.Cross(V3.UnitY, n).Normalized();
                            c.TiltVel = 3 + rel * 0.9;
                            c.Spin = (M.Rand() - 0.5) * rel * 1.5;
                            c.Loose = true;
                            car.Vel = car.Vel + n * (-rel * 4.5 / car.Mass);
                        }
                    }
                }
                if (!c.Loose) continue;
                c.Vel = new V3(c.Vel.X, c.Vel.Y - 9.81 * dt, c.Vel.Z);
                c.Pos = c.Pos + c.Vel * dt;
                double g = Terrain.Height(c.Pos.X, c.Pos.Z);
                if (c.Pos.Y <= g)
                {
                    c.Pos = new V3(c.Pos.X, g, c.Pos.Z);
                    double vy = c.Vel.Y < 0 ? c.Vel.Y * -0.25 : c.Vel.Y;
                    double fr = Math.Exp(-dt * 3.5);
                    c.Vel = new V3(c.Vel.X * fr, vy, c.Vel.Z * fr);
                    c.Spin *= fr;
                    if (c.Tilt >= Math.PI / 2 - 0.01) c.TiltVel = 0;
                }
                c.Tilt = Math.Min(c.Tilt + c.TiltVel * dt, Math.PI / 2);
                c.Yaw += c.Spin * dt;
                if (c.Vel.Length() < 0.05 && c.Pos.Y - g < 0.01 && Math.Abs(c.Vel.Y) < 0.1) c.Vel = V3.Zero;
            }
        }

        // position (with the tip-over lift) and rotation of a cone
        public static void Pose(Cone c, out V3 pos, out Q4 rot)
        {
            double lift = Math.Sin(c.Tilt) * 0.15;
            rot = Q4.Mul(Q4.Axis(c.Axis, c.Tilt), Q4.Axis(V3.UnitY, c.Yaw));
            pos = new V3(c.Pos.X, c.Pos.Y + lift, c.Pos.Z);
        }
    }

    // Starts when you cross the start/finish line the right way. A lap counts when you have been through both
    // sector checkpoints in order and never jumped along the track: cutting across the infield, going far off,
    // a reset or a teleport voids it.
    public sealed class LapTimer
    {
        readonly Circuit c;
        int hint;
        double prev; bool hasPrev;
        public bool Running, Valid;
        int cp;
        public double T;
        double offT;

        public LapTimer(Circuit circuit) { c = circuit; Reset(); }

        public void Reset() { hint = -1; hasPrev = false; Running = false; Valid = false; cp = 0; T = 0; offT = 0; }

        // onLap(time, valid) when a lap is completed
        public void Update(double dt, Car car, Action<double, bool> onLap)
        {
            double L = c.Path.Len;
            var n = c.Path.Nearest(car.Pos.X, car.Pos.Z, hint);
            hint = n.I;
            bool near = n.Dist < c.Width / 2 + 22;
            double p = (n.S - c.SLine + L) % L; // distance travelled from the line
            if (Running) T += dt;
            if (near && hasPrev)
            {
                double dp = p - prev;
                if (dp > L / 2) dp -= L; else if (dp < -L / 2) dp += L;
                if (Math.Abs(dp) > 30) Valid = false; // jumped along the track
                if (cp == 0 && prev < L / 3 && p >= L / 3 && dp > 0) cp = 1;
                if (cp == 1 && prev < (2 * L) / 3 && p >= (2 * L) / 3 && dp > 0) cp = 2;
                if (prev > L - 50 && p < 50 && dp > 0)
                {
                    if (Running) onLap(T, Valid && cp == 2);
                    Running = true; T = 0; Valid = true; cp = 0;
                }
            }
            if (near) offT = 0;
            else { offT += dt; Valid = false; if (offT > 8) Running = false; }
            hasPrev = near;
            if (near) prev = p;
        }

        public static string Fmt(double t, int dp = 1)
        {
            if (double.IsNaN(t)) return "–";
            int m = (int)Math.Floor(t / 60);
            double sec = t - m * 60;
            string s = sec.ToString("F" + dp, System.Globalization.CultureInfo.InvariantCulture);
            return m + ":" + s.PadLeft(dp + 3, '0');
        }
    }
}
