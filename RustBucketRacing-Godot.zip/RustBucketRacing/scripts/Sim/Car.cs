// The vehicle: rigid body on four raycast corners (spring, damper, anti-roll bar, bump stop), a combined-slip
// tyre model with load sensitivity and geometric load transfer, an engine with a torque curve, launch
// converter, clutch slip and limiter, a sequential gearbox (auto / semi / manual), viscous LSD, ABS, TCS,
// speed-sensitive steering assist and counter-steer, aero drag and downforce, and body collision against
// solid boxes, wall segments and the ground. Stepped at 480 Hz.
using System;
using System.Collections.Generic;

namespace RustBucket.Sim
{
    public enum Drive { RWD, FWD, AWD }
    public enum Gearbox { Auto, Semi, Manual }

    public sealed class Preset
    {
        public readonly double SpringF, SpringR, DampF, DampR, ArbF, ArbR, ComHeight;
        public Preset(double springF, double springR, double dampF, double dampR, double arbF, double arbR, double comHeight)
        { SpringF = springF; SpringR = springR; DampF = dampF; DampR = dampR; ArbF = arbF; ArbR = arbR; ComHeight = comHeight; }
    }

    public sealed class Tune
    {
        public double SpringF, SpringR, DampF, DampR, ArbF, ArbR, ComHeight;
        public double ReboundRatio = 1.6, RollCenter = 0.08, Grip = 1.05, BrakeBias = 0.64;
        public Drive Drive = Drive.RWD;
        public bool Abs = true, Tcs = true;
        public Gearbox Gearbox = Gearbox.Auto;
        public double SteerAssist = 1;  // 0..1: how far full lock is held back to the grip limit at speed
        public double CounterSteer = 0.5; // 0..1: how much the assist catches a sliding rear
        public double SteerSpeed = 1;   // multiplier on how fast the front wheels can turn
        public double Recovery = 0.75;  // 0..1: grip a sliding tyre keeps when you are off the throttle and brake

        public Tune Clone() => (Tune)MemberwiseClone();

        public void Apply(Preset p)
        {
            SpringF = p.SpringF; SpringR = p.SpringR; DampF = p.DampF; DampR = p.DampR; ArbF = p.ArbF; ArbR = p.ArbR; ComHeight = p.ComHeight;
        }

        public bool Matches(Preset p) =>
            Math.Abs(SpringF - p.SpringF) < 1e-6 && Math.Abs(SpringR - p.SpringR) < 1e-6 && Math.Abs(DampF - p.DampF) < 1e-6 &&
            Math.Abs(DampR - p.DampR) < 1e-6 && Math.Abs(ArbF - p.ArbF) < 1e-6 && Math.Abs(ArbR - p.ArbR) < 1e-6 && Math.Abs(ComHeight - p.ComHeight) < 1e-6;
    }

    /* Everything the chassis, drivetrain and body collision need, per car (model frame: forward -Z, right +X,
       up +Y, origin on the ground midway between the axles; hubs at static ride height). */
    public sealed class CarSpec
    {
        public string Id, Name;
        public double Mass;
        public V3 Inertia;               // pitch (X), yaw (Y), roll (Z)
        public double ComZ;              // CoM forward/back of the axle midpoint (model frame)
        public double WheelRadius, WheelRadiusF; // WheelRadiusF 0 = same as the rears
        public double WheelWidth, MountAbove;
        public V3[] Hubs;                // FL, FR, RL, RR
        public double WheelInertia, EngineInertia;
        public double[][] Curve;         // rpm, Nm at full throttle
        public double IdleRpm, Redline, Limiter, OverRev, ClutchCap, Stall, EngBrake, Lsd;
        public double[] Gears;
        public double Reverse, FinalDrive, MaxBrake, Handbrake, CdA, ClA;
        public double AeroBalance = double.NaN; // front share of the downforce; NaN = at the CoM
        public V3[] Hull;                // body collision probe points
        public double HullMinX, HullMaxX, HullMinY, HullMaxY, HullMinZ, HullMaxZ;
        public Dictionary<string, Preset> Presets;
        public Tune DefaultTune;

        public static readonly string[] PresetOrder = { "comfort", "street", "sport", "race" };
    }

    public static class Cars
    {
        public const double G = 9.81;

        static V3 P(double x, double y, double z) => new V3(x, y, z);
        static double[][] Curve(params double[] rpmNm)
        {
            var c = new double[rpmNm.Length / 2][];
            for (int i = 0; i < c.Length; i++) c[i] = new[] { rpmNm[i * 2], rpmNm[i * 2 + 1] };
            return c;
        }
        static Dictionary<string, Preset> Presets(Preset comfort, Preset street, Preset sport, Preset race) =>
            new Dictionary<string, Preset> { ["comfort"] = comfort, ["street"] = street, ["sport"] = sport, ["race"] = race };
        static Tune Default(Preset p, double rollCenter, double grip, double brakeBias)
        {
            var t = new Tune { ReboundRatio = 1.6, RollCenter = rollCenter, Grip = grip, Drive = Drive.RWD, BrakeBias = brakeBias, Abs = true, Tcs = true, Gearbox = Gearbox.Auto, SteerAssist = 1, CounterSteer = 0.5, SteerSpeed = 1 };
            t.Apply(p);
            return t;
        }

        // Rust Bucket: 1.4 L-class four, 126 Nm at 4200 rpm, ~69 kW (92 hp) at 6000-6200 rpm, 1.25 t, 5-speed
        public static readonly CarSpec Rust = MakeRust();
        static CarSpec MakeRust()
        {
            var pr = Presets(
                new Preset(19000, 17000, 1450, 1300, 5000, 1000, 0.56),
                new Preset(26000, 23000, 1900, 1700, 10000, 3500, 0.52),
                new Preset(40000, 36000, 2800, 2500, 18000, 8000, 0.49),
                new Preset(68000, 62000, 4100, 3700, 30000, 14000, 0.45));
            return new CarSpec
            {
                Id = "rust", Name = "Rust Bucket",
                Mass = 1250, Inertia = P(2130, 2310, 480), ComZ = -0.12,
                WheelRadius = 0.307, WheelWidth = 0.239, MountAbove = 0.13,
                Hubs = new[] { P(-0.7596, 0.3073, -1.3224), P(0.7596, 0.3073, -1.3224), P(-0.7596, 0.3073, 1.3224), P(0.7596, 0.3073, 1.3224) },
                WheelInertia = 1.15, EngineInertia = 0.13,
                Curve = Curve(800, 78, 1500, 92, 2500, 108, 3500, 120, 4200, 126, 5000, 122, 5800, 112, 6200, 106, 6800, 92, 7200, 80),
                IdleRpm = 800, Redline = 6500, Limiter = 6800, OverRev = 9200, ClutchCap = 340, Stall = 2600, EngBrake = 1, Lsd = 45,
                Gears = new[] { 3.55, 2.04, 1.32, 0.97, 0.78 }, Reverse = 3.5, FinalDrive = 4.06,
                MaxBrake = 5600, Handbrake = 2600, CdA = 0.74, ClA = 0.12,
                Hull = new[]
                {
                    P(-0.8, 0.3, -2.15), P(0.8, 0.3, -2.15), P(-0.8, 0.3, 2.15), P(0.8, 0.3, 2.15),
                    P(-0.85, 0.75, -2.17), P(0.85, 0.75, -2.17), P(-0.85, 0.75, 2.17), P(0.85, 0.75, 2.17),
                    P(-0.88, 0.27, -0.6), P(0.88, 0.27, -0.6), P(-0.88, 0.27, 0.6), P(0.88, 0.27, 0.6), P(0, 0.25, 0),
                    P(-0.88, 0.95, -1.2), P(0.88, 0.95, -1.2), P(-0.88, 0.95, 1.2), P(0.88, 0.95, 1.2),
                    P(-0.66, 1.48, -0.45), P(0.66, 1.48, -0.45), P(-0.66, 1.48, 0.75), P(0.66, 1.48, 0.75),
                },
                HullMinX = -0.89, HullMaxX = 0.89, HullMinY = 0.25, HullMaxY = 1.5, HullMinZ = -2.18, HullMaxZ = 2.18,
                Presets = pr,
                DefaultTune = Default(pr["street"], 0.08, 1.05, 0.64),
            };
        }

        // Monte Carlo SS: a built 5.7 L small-block, 450 Nm at 4000 rpm and ~240 kW (320 hp) at 5800 rpm,
        // 1.55 t, 5-speed with a 3.55 axle.
        public static readonly CarSpec Monte = MakeMonte();
        static CarSpec MakeMonte()
        {
            var pr = Presets(
                new Preset(30000, 26000, 2200, 1900, 9000, 3000, 0.53),
                new Preset(43000, 37500, 3000, 2550, 17000, 7500, 0.5),
                new Preset(60000, 54000, 3900, 3400, 26000, 12000, 0.47),
                new Preset(86000, 78000, 5300, 4700, 38000, 18000, 0.43));
            return new CarSpec
            {
                Id = "monte", Name = "Monte Carlo SS",
                Mass = 1550, Inertia = P(3500, 3800, 620), ComZ = -0.14,
                WheelRadius = 0.3165, WheelWidth = 0.245, MountAbove = 0.13,
                Hubs = new[] { P(-0.7459, 0.3177, -1.3715), P(0.7459, 0.3177, -1.3715), P(-0.7459, 0.3177, 1.3715), P(0.7459, 0.3177, 1.3715) },
                WheelInertia = 1.35, EngineInertia = 0.2,
                Curve = Curve(700, 290, 1500, 360, 2500, 410, 3500, 445, 4000, 450, 4800, 435, 5400, 412, 5800, 392, 6200, 362, 6600, 318, 7000, 270),
                IdleRpm = 780, Redline = 6000, Limiter = 6300, OverRev = 8800, ClutchCap = 640, Stall = 2300, EngBrake = 2.2, Lsd = 130,
                Gears = new[] { 2.95, 1.94, 1.34, 1.0, 0.73 }, Reverse = 2.76, FinalDrive = 3.55,
                MaxBrake = 7400, Handbrake = 3000, CdA = 0.84, ClA = 0.1,
                Hull = new[]
                {
                    P(-0.82, 0.3, -2.45), P(0.82, 0.3, -2.45), P(-0.82, 0.3, 2.6), P(0.82, 0.3, 2.6),
                    P(-0.88, 0.78, -2.4), P(0.88, 0.78, -2.4), P(-0.88, 0.8, 2.48), P(0.88, 0.8, 2.48),
                    P(-0.88, 0.2, -0.75), P(0.88, 0.2, -0.75), P(-0.88, 0.2, 0.75), P(0.88, 0.2, 0.75), P(0, 0.17, 0),
                    P(-0.92, 0.98, -1.2), P(0.92, 0.98, -1.2), P(-0.92, 0.98, 1.6), P(0.92, 0.98, 1.6),
                    P(-0.66, 1.37, -0.3), P(0.66, 1.37, -0.3), P(-0.66, 1.37, 1.2), P(0.66, 1.37, 1.2),
                },
                HullMinX = -0.9, HullMaxX = 0.9, HullMinY = 0.17, HullMaxY = 1.38, HullMinZ = -2.48, HullMaxZ = 2.64,
                Presets = pr,
                DefaultTune = Default(pr["street"], 0.08, 1.12, 0.62),
            };
        }

        // Cadillac CTS-V race car (2004, World Challenge style): race 5.7 L V8, 569 Nm (420 lb-ft) at 5600 rpm,
        // ~375 kW (500+ hp) from 7200 to 7600 rpm, 1.45 t, close-ratio 6-speed, slicks, splitter and wing, big
        // brakes. 1.4-1.6 g sustained cornering, 1.3-1.5 g braking, ~275 km/h. Smaller front tyres than rears.
        public static readonly CarSpec Cts = MakeCts();
        static CarSpec MakeCts()
        {
            var pr = Presets(
                new Preset(55000, 50000, 3600, 3200, 18000, 8000, 0.47),
                new Preset(75000, 68000, 4600, 4100, 26000, 12000, 0.45),
                new Preset(100000, 90000, 5900, 5300, 36000, 17000, 0.44),
                new Preset(130000, 118000, 7300, 6600, 48000, 23000, 0.42));
            return new CarSpec
            {
                Id = "cts", Name = "Cadillac CTS-V race car",
                Mass = 1450, Inertia = P(2900, 3200, 520), ComZ = -0.058,
                WheelRadius = 0.3293, WheelRadiusF = 0.3166, WheelWidth = 0.29, MountAbove = 0.12,
                Hubs = new[] { P(-0.737, 0.3124, -1.44), P(0.737, 0.3124, -1.44), P(-0.7491, 0.3254, 1.44), P(0.7491, 0.3254, 1.44) },
                WheelInertia = 1.2, EngineInertia = 0.17,
                Curve = Curve(1000, 330, 2000, 400, 3000, 455, 4000, 510, 5000, 555, 5600, 569, 6200, 556, 6800, 528, 7200, 500, 7600, 472, 8000, 420, 8400, 360),
                IdleRpm = 1100, Redline = 7600, Limiter = 7800, OverRev = 9600, ClutchCap = 820, Stall = 3200, EngBrake = 2.6, Lsd = 200,
                Gears = new[] { 2.50, 1.93, 1.54, 1.27, 1.06, 0.89 }, Reverse = 2.9, FinalDrive = 3.90,
                MaxBrake = 6900, Handbrake = 3200, CdA = 1.25, ClA = 2.3, AeroBalance = 0.4,
                Hull = new[]
                {
                    P(-0.86, 0.2, -2.4), P(0.86, 0.2, -2.4), P(-0.86, 0.22, 2.5), P(0.86, 0.22, 2.5),
                    P(-0.9, 0.72, -2.3), P(0.9, 0.72, -2.3), P(-0.9, 0.82, 2.42), P(0.9, 0.82, 2.42),
                    P(-0.92, 0.16, -0.75), P(0.92, 0.16, -0.75), P(-0.92, 0.16, 0.75), P(0.92, 0.16, 0.75), P(0, 0.12, 0),
                    P(-0.94, 0.95, -1.2), P(0.94, 0.95, -1.2), P(-0.94, 0.95, 1.6), P(0.94, 0.95, 1.6),
                    P(-0.66, 1.36, -0.35), P(0.66, 1.36, -0.35), P(-0.66, 1.36, 0.95), P(0.66, 1.36, 0.95),
                },
                HullMinX = -0.94, HullMaxX = 0.94, HullMinY = 0.1, HullMaxY = 1.36, HullMinZ = -2.44, HullMaxZ = 2.54,
                Presets = pr,
                DefaultTune = Default(pr["race"], 0.09, 1.58, 0.6),
            };
        }

        public static CarSpec ById(string id) => id == "monte" ? Monte : id == "cts" ? Cts : Rust;

        // full-throttle torque curve lookup
        public static double TorqueAt(double[][] c, double rpm)
        {
            if (rpm <= c[0][0]) return c[0][1];
            for (int i = 1; i < c.Length; i++)
                if (rpm <= c[i][0])
                {
                    double t = (rpm - c[i - 1][0]) / (c[i][0] - c[i - 1][0]);
                    return M.Lerp(c[i - 1][1], c[i][1], t);
                }
            return c[c.Length - 1][1];
        }

        // Normalised tyre curve: rises to 1 at rho = 1 (peak slip), falls to `slide` beyond.
        public static double TyreCurve(double rho, double slide)
        {
            if (rho < 1) return rho * (2 - rho);
            return 1 - (1 - slide) * (1 - Math.Exp(-(rho - 1) / 1.1));
        }
    }

    public sealed class DriveInput
    {
        public double Throttle, Brake, Steer, Handbrake;
        public bool ShiftUp, ShiftDown;
    }

    public sealed class Wheel
    {
        public string Id;
        public bool Front, Left, Driven;
        public V3 HubModel, MountModel, MountBody;
        public double Rad;
        public double X, XPrev, Fz, Load, Omega, Spin, Steer, DVis = 0.2;
        public double SlipRatio, SlipAngle, SlipVel, Grip, Fx, Fy, Cap, Sliding, VLong, Geo;
        public double Kp; // peak slip ratio on the current surface (0 until the first contact)
        public double AbsP = 1; // ABS: share of the brake pressure let through to this wheel
        public bool Contact, AbsActive, HasFw;
        public V3 ContactPt, Normal = V3.UnitY, Head, Mount, Fw;
        public Surf Surface = Surf.Tarmac;
        public double K, CBump, CReb, StaticLoad, L0;
        public double KpOr => Kp != 0 ? Kp : 0.11;
    }

    public sealed class ShiftState { public int From, To; public double T, Sel, Total; public bool Down; }

    public sealed class EngineState
    {
        public double Rpm, ShiftT, Clutch = 1, TcsCut = 1, RevTimer, Load;
        public double UpHold, LimT; // automatic: no kickdown just after changing up; time spent near the limiter
        public int Gear = 1, Queued;
        public bool LimiterCut, Blip, OverRev;
        public ShiftState Shift;
        public string Refused; // "speed" | "overrev" | null
    }

    public sealed class Telemetry
    {
        public double GLat, GLong, Roll, Pitch, Speed, WheelRpm;
        public bool AbsActive, TcsActive, CsActive;
        public bool HasLoad; public double FrontLoad, LoadCx, LoadCz;
    }

    public sealed class Car
    {
        const double G = Cars.G;
        static readonly double[] UF = { -0.7, -0.35, 0, 0.35, 0.7 };

        public TerrainBase Terrain;
        public readonly CarSpec Spec;
        public Tune Tune;
        public readonly double Mass;
        public readonly V3 I;
        public readonly Wheel[] Wheels; // FL, FR, RL, RR
        public readonly EngineState Engine = new EngineState();
        public readonly Telemetry Tel = new Telemetry();
        double recSm; // slide recovery, eased in and out
        public readonly double[] ShiftRpm;
        public V3 Pos, Vel, AngVel, PrevVel;
        public Q4 Q = Q4.Identity;
        public double SteerSm, Cs, AssistW = 1, HitWall;
        V3[] hullBody, hp;
        readonly double[] driveT = new double[4], arbF = new double[4];
        V3 fAcc, tAcc;

        public Car(TerrainBase terrain, Tune tune, CarSpec spec)
        {
            Terrain = terrain; Spec = spec;
            var S = spec;
            Tune = (tune ?? S.DefaultTune).Clone();
            Mass = S.Mass; I = S.Inertia;
            string[] ids = { "FL", "FR", "RL", "RR" };
            Wheels = new Wheel[4];
            for (int i = 0; i < 4; i++)
            {
                bool front = ids[i][0] == 'F';
                Wheels[i] = new Wheel
                {
                    Id = ids[i], Front = front, Left = ids[i][1] == 'L', HubModel = S.Hubs[i],
                    Rad = front && S.WheelRadiusF > 0 ? S.WheelRadiusF : S.WheelRadius,
                };
            }
            Engine.Rpm = S.IdleRpm;
            // automatic under power: change up where the next gear pulls harder at the wheels, which for these
            // engines is right up at the limiter (it changes 60 rpm short of the cut)
            ShiftRpm = new double[S.Gears.Length];
            for (int i = 0; i < S.Gears.Length; i++)
            {
                if (i == S.Gears.Length - 1) { ShiftRpm[i] = S.Limiter; continue; }
                double g = S.Gears[i], g2 = S.Gears[i + 1];
                double found = S.Limiter - 60;
                for (double r = S.Redline * 0.85; r <= S.Limiter - 60; r += 20)
                    if (Cars.TorqueAt(S.Curve, r) * g <= Cars.TorqueAt(S.Curve, (r * g2) / g) * g2) { found = r; break; }
                ShiftRpm[i] = found;
            }
            hp = new V3[S.Hull.Length];
            Recompute();
            Reset(V3.Zero, 0);
        }

        // CoM in model frame
        public V3 ComModel => new V3(0, Tune.ComHeight, Spec.ComZ);

        // new setup values; the visual body stays put when the CoM moves
        public void SetTune(Tune t)
        {
            V3 oldCom = ComModel;
            Tune = t.Clone();
            Recompute();
            V3 d = ComModel - oldCom;
            Pos = Pos + Q.Rotate(d);
        }

        void Recompute()
        {
            var S = Spec; var t = Tune; V3 com = ComModel;
            double wb = S.Hubs[2].Z - S.Hubs[0].Z;
            double frontShare = (S.Hubs[2].Z - com.Z) / wb;
            foreach (var w in Wheels)
            {
                w.K = w.Front ? t.SpringF : t.SpringR;
                w.CBump = w.Front ? t.DampF : t.DampR;
                w.CReb = w.CBump * t.ReboundRatio;
                double load = (Mass * G * (w.Front ? frontShare : 1 - frontShare)) / 2;
                w.StaticLoad = load;
                w.L0 = S.MountAbove + load / w.K; // preload keeps ride height constant
                w.MountModel = new V3(w.HubModel.X, w.HubModel.Y + S.MountAbove, w.HubModel.Z);
                w.MountBody = w.MountModel - com;
                w.Driven = t.Drive == Drive.AWD || (t.Drive == Drive.RWD ? !w.Front : w.Front);
            }
            hullBody = new V3[S.Hull.Length];
            for (int i = 0; i < S.Hull.Length; i++) hullBody[i] = S.Hull[i] - com;
        }

        public void Reset(V3 pos, double yaw)
        {
            var S = Spec;
            V3 com = ComModel;
            double gy = Terrain.Height(pos.X, pos.Z);
            Q = Q4.Axis(V3.UnitY, yaw);
            Pos = new V3(pos.X, gy, pos.Z) + Q.Rotate(com);
            Vel = V3.Zero; AngVel = V3.Zero; PrevVel = V3.Zero;
            foreach (var w in Wheels) { w.Omega = 0; w.X = w.L0 - S.MountAbove; w.XPrev = w.X; w.DVis = S.MountAbove; }
            var e = Engine;
            e.Gear = Tune.Gearbox == Gearbox.Auto ? 1 : (e.Gear != 0 ? e.Gear : 1);
            e.Rpm = S.IdleRpm;
            e.ShiftT = 0; e.Shift = null; e.Queued = 0; e.Blip = false;
            Cs = 0; SteerSm = 0;
        }

        public void ResetUpright()
        {
            V3 f = Q.Rotate(V3.Fwd);
            double yaw = Math.Atan2(-f.X, -f.Z);
            V3 c = Q.Rotate(ComModel);
            Reset(new V3(Pos.X - c.X, 0, Pos.Z - c.Z), yaw);
            Pos = new V3(Pos.X, Pos.Y + 0.25, Pos.Z);
        }

        public V3 Forward => Q.Rotate(V3.Fwd);
        public V3 Up => Q.Rotate(V3.UnitY);
        public V3 Right => Q.Rotate(V3.UnitX);
        public V3 PointVel(V3 p) => Vel + V3.Cross(AngVel, p - Pos);
        public V3 ToWorld(V3 pb) => Pos + Q.Rotate(pb);
        public double Yaw { get { V3 f = Forward; return Math.Atan2(-f.X, -f.Z); } }

        // Sequential gearbox with an automatic clutch.
        // Upshift ~0.26 s: clutch out with an ignition cut, gear in at 0.09 s, clutch closes progressively.
        // Downshift ~0.46 s: clutch out while the throttle blips to the lower gear's revs, gear in at 0.24 s.
        void StartShift(int to)
        {
            var e = Engine;
            bool down = to < e.Gear && to > 0;
            e.Shift = new ShiftState { From = e.Gear, To = to, T = 0, Sel = down ? 0.24 : 0.09, Total = down ? 0.46 : 0.26, Down = down };
            e.ShiftT = e.Shift.Total;
        }

        double DrivenOmega()
        {
            double s = 0; int n = 0;
            foreach (var w in Wheels) if (w.Driven) { s += w.Omega; n++; }
            return n > 0 ? s / n : 0;
        }

        // Driver or auto-logic request. Automatic and semi skip neutral (1 <-> R); every mode refuses reverse while
        // rolling; semi-auto also refuses downshifts that would over-rev. Manual takes any gear: an over-speed
        // downshift slips the clutch, spins the engine past its limit and drags the wheels.
        // Returns false when refused (reason in Engine.Refused).
        public bool Shift(int dir)
        {
            var e = Engine; var S = Spec;
            if (e.Shift != null) { e.Queued = M.ClampI(e.Queued + dir, -4, 4); return true; } // quick flicks stack up
            bool manual = Tune.Gearbox == Gearbox.Manual;
            int ng = M.ClampI(e.Gear + dir, -1, S.Gears.Length);
            if (ng == 0 && !manual) ng = dir > 0 ? 1 : -1; // only manual stops in neutral
            if (ng == e.Gear) return false;
            double vF = V3.Dot(Vel, Q.Rotate(V3.Fwd));
            if ((ng < 0 && vF > 1.5) || (e.Gear < 0 && ng > 0 && vF < -1.5)) { e.Refused = "speed"; return false; }
            if (Tune.Gearbox == Gearbox.Semi && ng > 0 && ng < e.Gear)
            {
                double rpmAfter = Math.Abs(DrivenOmega() * GearRatio(ng) * 60 / (2 * Math.PI));
                if (rpmAfter > S.Limiter - 100) { e.Refused = "overrev"; return false; }
            }
            StartShift(ng);
            return true;
        }

        // Engine turning freely (clutch out): drive torque against friction on the engine's own inertia, so the revs
        // rise quickly and fall back over a second or two. Part throttle settles at part revs; full throttle runs to
        // the limiter. Idle control holds the idle speed.
        double FreeRev(EngineState e, double thr, double dt)
        {
            const double TO_RPM = 60 / (2 * Math.PI);
            var S = Spec;
            double rpm = e.Rpm;
            double want = S.IdleRpm + Math.Pow(M.Clamp(thr, 0, 1), 0.8) * (S.Limiter + 120 - S.IdleRpm);
            double fric = Math.Max(S.EngBrake, 1.5) * (10 + 0.0045 * rpm) + (rpm > S.Limiter ? 0.05 * (rpm - S.Limiter) : 0);
            if (rpm < want && !e.LimiterCut)
            {
                double drv = Cars.TorqueAt(S.Curve, rpm) * Math.Max(thr, 0.12);
                return Math.Min(want, rpm + Math.Max(0, (drv - fric) / S.EngineInertia) * dt * TO_RPM);
            }
            // coming down: settle on the part-throttle speed from above, or fall freely while the limiter cuts
            double down = rpm - (fric / S.EngineInertia) * dt * TO_RPM;
            return rpm > want ? Math.Max(want, down) : Math.Max(S.IdleRpm, down);
        }

        public double GearRatio(int g)
        {
            var S = Spec;
            if (g == 0) return 0;
            if (g < 0) return -S.Reverse * S.FinalDrive;
            return S.Gears[g - 1] * S.FinalDrive;
        }

        void ApplyAt(V3 f, V3 p)
        {
            fAcc = fAcc + f;
            V3 r = p - Pos;
            tAcc = tAcc + V3.Cross(r, f);
        }

        /* ---------------- one fixed physics step ---------------- */
        public void Step(double dt, DriveInput inp)
        {
            var t = Tune; var e = Engine; var W = Wheels; var T = Terrain; var S = Spec;
            Q4 q = Q;
            V3 up = q.Rotate(V3.UnitY);
            V3 down = up * -1;
            V3 fwdB = q.Rotate(V3.Fwd);
            V3 rgtB = q.Rotate(V3.UnitX);
            double vFwd = V3.Dot(Vel, fwdB);
            double speed = Vel.Length();
            V3 pos = Pos;

            fAcc = new V3(0, -G * Mass, 0);
            tAcc = V3.Zero;

            // ----- gearbox: automatic logic and reverse handling -----
            bool auto = t.Gearbox == Gearbox.Auto, semi = t.Gearbox == Gearbox.Semi, manual = t.Gearbox == Gearbox.Manual;
            double throttle = inp.Throttle, brake = inp.Brake;
            if (e.Gear < 0 && auto) { throttle = inp.Brake; brake = inp.Throttle; } // automatic: hold brake to reverse
            if (auto)
            {
                if (e.Gear >= 1 && vFwd < 0.6 && inp.Brake > 0.5 && inp.Throttle < 0.1)
                {
                    e.RevTimer += dt; if (e.RevTimer > 0.3 && e.Shift == null) { StartShift(-1); e.RevTimer = 0; }
                }
                else if (e.Gear < 0 && vFwd > -0.6 && inp.Throttle > 0.5 && inp.Brake < 0.1)
                {
                    e.RevTimer += dt; if (e.RevTimer > 0.15 && e.Shift == null) { StartShift(1); e.RevTimer = 0; }
                }
                else e.RevTimer = 0;
                if (e.Gear == 0 && e.Shift == null) e.Gear = 1;
            }
            if (inp.ShiftUp) Shift(1);
            if (inp.ShiftDown) Shift(-1);
            inp.ShiftUp = inp.ShiftDown = false;

            // ----- steering: rate-limited rack, speed-sensitive assist, counter-steer, Ackermann -----
            double target = M.Clamp(inp.Steer, -1, 1);
            double sp = M.Clamp(t.SteerSpeed != 0 ? t.SteerSpeed : 1, 0.2, 4);
            // turning in at 3.2/s x steering speed; coming back towards centre (or across) at 9/s x steering speed
            double rate = (Math.Abs(target) > Math.Abs(SteerSm) && M.Sgn(target) == M.Sgn(SteerSm) ? 3.2 : 9) * sp;
            SteerSm += M.Clamp(target - SteerSm, -rate * dt, rate * dt);
            double vAbs = Math.Abs(vFwd);
            // assist: full lock tracks the grip limit (kinematic angle for ~1 g plus peak slip), with a little margin.
            // At low speed both assists stand back while you are steering: fully yours below ~35 km/h, back to full
            // assistance by ~65 km/h. Hands off, they work at any speed.
            double steering = M.Smooth01((Math.Abs(target) - 0.08) / 0.17);
            double assistW = 1 - steering * (1 - M.Smooth01((vAbs * 3.6 - 35) / 30));
            AssistW = assistW;
            var Sf = Surfaces.Of(W[0].Surface);
            double assistLock = M.Clamp(1.15 * ((26 * Sf.Mu) / (vAbs * vAbs + 1) + 0.035 * Sf.Ap), 0.06, 0.58);
            double maxLock = M.Lerp(0.58, assistLock, M.Clamp(t.SteerAssist, 0, 1) * assistW);
            double delta = SteerSm * maxLock;
            // Counter-steer: once the rear axle is sliding, steer the fronts toward where they are actually
            // travelling. It only ever adds opposite lock: if you are already countersteering harder, your input wins.
            double csWant = 0;
            if (t.CounterSteer > 0 && vFwd > 4)
            {
                V3 com = ComModel;
                V3 vr = PointVel(ToWorld(new V3(0, 0, S.Hubs[2].Z - com.Z)));
                V3 vf = PointVel(ToWorld(new V3(0, 0, S.Hubs[0].Z - com.Z)));
                double aRear = Math.Atan2(V3.Dot(vr, rgtB), Math.Max(1, V3.Dot(vr, fwdB)));
                double align = -Math.Atan2(V3.Dot(vf, rgtB), Math.Max(1, V3.Dot(vf, fwdB))) * 0.9; // wheel angle along the front's path (+ = left)
                var Sr = Surfaces.Of(W[2].Surface);
                double cs = M.Clamp(t.CounterSteer, 0, 1), gain = 1 - (1 - cs) * (1 - cs), lo = (0.1 - 0.05 * cs) * Sr.Ap;
                double wgt = M.Smooth01((Math.Abs(aRear) - lo) / (0.1 * Sr.Ap)) * gain * assistW;
                double c = M.Sgn(align);
                if (wgt > 0 && c != 0 && c == -M.Sgn(aRear) && delta * c < align * c) csWant = (align - delta) * wgt;
            }
            Cs = Cs + (csWant - Cs) * (1 - Math.Exp(-dt * 18 * sp));
            delta = M.Clamp(delta + Cs, -0.58, 0.58);
            Tel.CsActive = Math.Abs(Cs) > 0.02;
            double wb = S.Hubs[2].Z - S.Hubs[0].Z, track = S.Hubs[1].X - S.Hubs[0].X;
            foreach (var w in W)
            {
                if (!w.Front) { w.Steer = 0; continue; }
                if (Math.Abs(delta) < 1e-4) { w.Steer = delta; continue; }
                double R = wb / Math.Tan(Math.Abs(delta));
                bool inner = (delta > 0) == w.Left; // turning left: left wheel is inner
                w.Steer = M.Sgn(delta) * Math.Atan(wb / (R + (inner ? -track / 2 : track / 2)));
            }

            // ----- suspension geometry: multi-ray tyre footprint vs ground -----
            foreach (var w in W)
            {
                V3 Mw = pos + q.Rotate(w.MountBody);
                V3 head = q.Rotate(new V3(-Math.Sin(w.Steer), 0, -Math.Cos(w.Steer)));
                double best = double.PositiveInfinity; bool hit = false; V3 bestPt = V3.Zero;
                for (int k = 0; k < UF.Length; k++)
                {
                    double u = UF[k] * w.Rad, c = Math.Sqrt(w.Rad * w.Rad - u * u);
                    V3 o = Mw + head * u;
                    double tHit = T.Raycast(o, down, w.L0 + c + 0.02);
                    if (tHit < 0) continue;
                    double d = tHit - c;
                    if (d < best) { best = d; bestPt = o + down * tHit; hit = true; }
                }
                w.Head = head; w.Mount = Mw;
                if (hit && best < w.L0)
                {
                    w.Contact = true;
                    w.X = w.L0 - best;
                    w.ContactPt = bestPt;
                    w.Normal = T.Normal(bestPt.X, bestPt.Z);
                    w.Surface = T.Surface(bestPt.X, bestPt.Z);
                }
                else { w.Contact = false; w.X = 0; }
            }

            // ----- drivetrain -----
            // shift sequence: phase 1 = clutch out, phase 2 = clutch closing on the new gear
            var sh = e.Shift;
            int phase = 0; double clutchC = 1;
            if (sh != null)
            {
                sh.T += dt;
                if (sh.T >= sh.Sel && e.Gear != sh.To) e.Gear = sh.To;
                if (sh.T < sh.Sel) { phase = 1; clutchC = 0; }
                else if (sh.T < sh.Total) { phase = 2; clutchC = (sh.T - sh.Sel) / (sh.Total - sh.Sel); }
                else
                {
                    e.Shift = null;
                    if (e.Queued != 0) { int qd = Math.Sign(e.Queued); e.Queued -= qd; if (!Shift(qd)) e.Queued = 0; }
                }
                e.ShiftT = e.Shift != null ? e.Shift.Total - e.Shift.T : 0;
            }
            e.Blip = phase == 1 && sh.Down;
            double ratio = GearRatio(e.Gear);
            double avgOmega = 0; int nDriven = 0;
            foreach (var w in W) if (w.Driven) { avgOmega += w.Omega; nDriven++; }
            avgOmega /= nDriven;
            double wheelRpm = avgOmega * ratio * 60 / (2 * Math.PI);
            bool shifting = phase > 0;
            // the revs the engine would turn at with the driven wheels rolling at road speed (not spinning, not locked)
            double rDriven = 0; foreach (var w in W) if (w.Driven) rDriven += w.Rad;
            rDriven /= nDriven;
            double roadRpm = Math.Abs(vFwd) / rDriven * Math.Abs(ratio) * 60 / (2 * Math.PI);
            e.UpHold = Math.Max(0, e.UpHold - dt);
            e.LimT = e.Rpm > S.Limiter - 400 ? e.LimT + dt : 0;

            // semi-automatic: the driver picks gears, but it drops a gear rather than bog below ~1000 rpm
            if (semi && e.Shift == null && e.Gear > 1 && roadRpm < 1000) StartShift(e.Gear - 1);

            if (auto && e.Gear >= 1 && !shifting && e.Shift == null)
            {
                // Decisions go on road speed, so wheelspin off the line doesn't change up early (and straight back
                // down once the tyres bite). Accelerating (a third of the pedal or more) it holds each gear to the top,
                // or changes up anyway if the wheels sit spinning on the limiter; floored at low revs it kicks down,
                // but not in the first moments after changing up. Gently on the pedal it changes up early so it
                // cruises in a sensible gear. Slowing down it changes down early: braking from ~72 % of the redline,
                // lifting off from 42 % of it.
                bool slowing = brake > 0.2 || (throttle < 0.25 && Tel.GLong < -0.05);
                bool pulling = throttle >= 0.35 && brake <= 0.2;
                double coastDown = 0.42 * S.Redline;
                int ngears = S.Gears.Length;
                double late = ShiftRpm[e.Gear - 1];
                double up = e.Gear < ngears ? S.Gears[e.Gear] / S.Gears[e.Gear - 1] : 0;
                double dn = e.Gear > 1 ? S.Gears[e.Gear - 2] / S.Gears[e.Gear - 1] : 0;
                double higher = roadRpm * up;
                double lower = Math.Max(roadRpm, Math.Abs(wheelRpm)) * dn; // the higher of the two: never over-rev
                double cruiseUp = S.Redline * (0.5 + 0.47 * M.Clamp(throttle / 0.35, 0, 1));
                bool grip = false;
                foreach (var w in W) if (w.Driven && w.Contact) grip = true;
                bool spinningOnLimiter = e.LimT > 0.35;
                bool changedUp = false;
                if (pulling && e.Gear < ngears && grip && ((e.Rpm > late - 100 && roadRpm > late - 700) || spinningOnLimiter)) changedUp = Shift(1);
                else if (!pulling && e.Gear < ngears && e.Rpm > S.Limiter - 60 && roadRpm > S.Limiter - 700 && grip) changedUp = Shift(1);
                else if (!pulling && !slowing && throttle > 0.02 && e.Gear < ngears && roadRpm > cruiseUp && higher > coastDown + 500 && grip) changedUp = Shift(1);
                else if (e.Gear > 1)
                {
                    bool hold = e.UpHold > 0 && brake <= 0.2 && roadRpm > 1300;
                    if (!hold && throttle > 0.85 && e.Rpm < 0.62 * S.Redline && lower < 0.86 * ShiftRpm[e.Gear - 2]) Shift(-1); // kickdown
                    else if (!hold)
                    {
                        double downAt = brake > 0.2 ? 0.72 * S.Redline : slowing ? coastDown : 2200;
                        if (roadRpm < downAt && lower < S.Redline - 350) Shift(-1);
                    }
                }
                if (changedUp) e.UpHold = 1.6;
            }

            // TCS: cut torque when a driven tyre is past its peak (combined slip) while it is driving
            bool over = false;
            double rs = M.Sgn(ratio != 0 ? ratio : 1);
            foreach (var w in W)
                if (w.Driven && w.Contact && w.SlipRatio * rs > 0.03 && (w.Grip > 1.06 || w.SlipRatio * rs > 1.2 * w.KpOr)) over = true;
            bool tcsActive = t.Tcs && throttle > 0.05 && over && vAbs > 0.5;
            e.TcsCut = tcsActive ? Math.Max(0.15, e.TcsCut - dt * 6) : Math.Min(1, e.TcsCut + dt * 2.5);
            double thr = throttle * (t.Tcs ? e.TcsCut : 1);

            // automatic clutch / torque converter
            double stall = S.IdleRpm + S.Stall * thr;
            bool free = e.Gear == 0 || inp.Handbrake > 0.5;
            double engineRpm;
            bool locked = false, clutchOpen = phase == 1 || free;
            // Clutch slip: when the gearbox side is turning much faster or slower than the engine with the clutch
            // biting (a manual clutch dump into a lower gear), or faster than the engine can physically spin,
            // friction torque spins the engine up and pulls the driven wheels down, hard enough to lock them.
            double mismatch = wheelRpm - e.Rpm;
            bool slipping = !clutchOpen && ((manual && phase == 2 && mismatch > 450) || wheelRpm > S.OverRev);
            double slipT = 0;
            const double TO_RPM = 60 / (2 * Math.PI);
            if (slipping)
            {
                double cap = S.ClutchCap * (phase == 2 ? Math.Max(0.2, clutchC) : 1);
                slipT = M.Sgn(mismatch) * cap; // on the crank; the gearbox gets the reaction
                double fric = -S.EngBrake * (10 + 0.0045 * e.Rpm) - (e.Rpm > S.Limiter ? 0.05 * (e.Rpm - S.Limiter) : 0);
                double drv = !e.LimiterCut ? Cars.TorqueAt(S.Curve, e.Rpm) * thr : 0;
                engineRpm = e.Rpm + ((slipT + fric + drv) / S.EngineInertia) * dt * TO_RPM;
                if (M.Sgn(wheelRpm - engineRpm) != M.Sgn(mismatch)) engineRpm = wheelRpm; // synced this step
                engineRpm = Math.Min(engineRpm, S.OverRev);
            }
            else if (phase == 1)
            {
                // clutch out: blip to the lower gear's revs on a downshift; on an upshift the revs run down on the
                // flywheel's own momentum (never below the new gear's speed) and the clutch brings them the rest of the way
                double tgt = Math.Abs(avgOmega * GearRatio(sh.To) * TO_RPM);
                if (sh.Down) engineRpm = M.Lerp(e.Rpm, M.Clamp(tgt * 1.02, S.IdleRpm, S.Limiter - 50), 1 - Math.Exp(-dt * 16));
                else engineRpm = Math.Max(FreeRev(e, 0, dt), Math.Max(S.IdleRpm, Math.Min(tgt, e.Rpm)));
            }
            else if (free)
            {
                // neutral, or the clutch held out by the handbrake: the engine spins on its own momentum
                engineRpm = FreeRev(e, thr, dt);
            }
            else if (phase == 2)
            {
                // clutch closing: engine and gearbox speeds converge as the clutch bites
                engineRpm = M.Lerp(e.Rpm, Math.Max(Math.Abs(wheelRpm), S.IdleRpm), 1 - Math.Exp(-dt * (6 + 30 * clutchC)));
            }
            else if (Math.Abs(wheelRpm) >= stall - 50)
            {
                engineRpm = Math.Abs(wheelRpm); locked = true;
            }
            else
            {
                engineRpm = M.Lerp(e.Rpm, Math.Max(stall, Math.Abs(wheelRpm)), 1 - Math.Exp(-dt * 10));
            }
            if (engineRpm > S.Limiter) e.LimiterCut = true;
            if (engineRpm < S.Limiter - 350) e.LimiterCut = false;
            e.Rpm = M.Clamp(engineRpm, 600, S.OverRev);
            e.OverRev = e.Rpm > S.Limiter + 150;
            double engT = 0;
            if (slipping)
            {
                engT = -slipT; // clutch friction reaches the gearbox: negative = dragging the wheels
            }
            else if (!clutchOpen)
            {
                if (thr > 0.01 && !e.LimiterCut) engT = Cars.TorqueAt(S.Curve, e.Rpm) * thr;
                // engine braking, much stronger when the wheels force the engine past its limiter
                else if (locked) engT = -S.EngBrake * (10 + 0.0045 * e.Rpm) - (e.Rpm > S.Limiter ? 0.05 * (e.Rpm - S.Limiter) : 0);
                if (!locked && thr > 0.01 && phase == 0)
                {
                    double slip = 1 - Math.Abs(wheelRpm) / Math.Max(stall, 1);
                    engT *= 1 + 0.7 * M.Clamp(slip, 0, 1); // converter torque multiplication
                }
                if (phase == 2) engT *= clutchC;
            }
            e.Load = phase == 1 ? (sh.Down ? 0.7 : 0) : thr;
            e.Clutch = clutchOpen ? 0 : phase == 2 ? clutchC : locked ? 1 : 0.5;
            double axleT = engT * ratio * 0.9;
            double engInertiaShare = locked ? S.EngineInertia * ratio * ratio / nDriven : 0;

            // torque split + viscous LSD per axle, centre coupling for AWD
            Array.Clear(driveT, 0, 4);
            if (t.Drive == Drive.AWD)
            {
                double fAvg = (W[0].Omega + W[1].Omega) / 2, rAvg = (W[2].Omega + W[3].Omega) / 2;
                double cc = 60 * (fAvg - rAvg);
                AxleSplit(axleT * 0.4 - cc, 0, 1);
                AxleSplit(axleT * 0.6 + cc, 2, 3);
            }
            else if (t.Drive == Drive.RWD) AxleSplit(axleT, 2, 3);
            else AxleSplit(axleT, 0, 1);

            // ----- suspension + tyre forces -----
            const double absMinSpeed = 2.5;
            bool absAny = false;
            { double d = W[0].X - W[1].X; arbF[0] = t.ArbF * d; arbF[1] = -t.ArbF * d; }
            { double d = W[2].X - W[3].X; arbF[2] = t.ArbR * d; arbF[3] = -t.ArbR * d; }

            // Geometric (link) load transfer: tyre forces reach the body at roll-centre height through the links, so
            // the springs only react the moment above that height. The rest goes straight onto the tyre loads: more on
            // the outside wheels in a corner, on the fronts under braking, on the rears under power. It nets to zero
            // force and moment on the body. Uses last step's tyre forces.
            double fLong = 0, fLatF = 0, fLatR = 0;
            foreach (var w in W)
                if (w.Contact && w.HasFw)
                {
                    fLong += V3.Dot(w.Fw, fwdB);
                    if (w.Front) fLatF += V3.Dot(w.Fw, rgtB); else fLatR += V3.Dot(w.Fw, rgtB);
                }
            foreach (var w in W)
                w.Geo = (w.Left ? 1 : -1) * (w.Front ? fLatF : fLatR) * t.RollCenter / track // cornering: onto the outside wheels
                      + (w.Front ? -1 : 1) * fLong * t.RollCenter / wb / 2;                // braking: onto the fronts; power: rears

            // slide recovery: full off the throttle and brake, fading out as either goes past about half; never on
            // the handbrake (that is how you start a slide on purpose)
            double recWant = M.Clamp(t.Recovery, 0, 1) * (1 - M.Smooth01((throttle - 0.2) / 0.4)) * (1 - M.Smooth01((brake - 0.25) / 0.4))
                * (inp.Handbrake > 0.1 ? 0 : 1);
            recSm += (recWant - recSm) * (1 - Math.Exp(-dt * 5));
            // auto hold: stopped (or all but) with neither pedal pressed, steering aside, the brakes hold the car
            // where it is; any throttle or brake lets go at once
            double holdK = inp.Throttle < 0.02 && inp.Brake < 0.02 && inp.Handbrake < 0.1 ? 1 - M.Smooth01((speed - 0.25) / 0.5) : 0;

            for (int i = 0; i < 4; i++)
            {
                var w = W[i];
                double kTyre = 0, Fx = 0;
                if (w.Contact)
                {
                    double xdot = (w.X - w.XPrev) / dt;
                    double Fs = w.K * w.X;
                    double bs = w.X - (w.L0 - 0.03);
                    if (bs > 0) Fs += 150000 * bs + 4e6 * bs * bs;
                    double Fd = xdot > 0 ? w.CBump * xdot : w.CReb * xdot;
                    Fd = M.Clamp(Fd, -4 * w.StaticLoad, 6 * w.StaticLoad);
                    double Fz = Fs + Fd + arbF[i];
                    Fz = M.Clamp(Fz, 0, 60000);
                    w.Fz = Fz;                                // through the spring/damper/bar: acts on the body
                    double Fl = M.Clamp(Fz + w.Geo, 0, 60000); // what the tyre is pressed into the ground with
                    w.Load = Fl;

                    V3 n = w.Normal;
                    V3 fw = (w.Head - n * V3.Dot(w.Head, n)).Normalized();
                    V3 side = V3.Cross(fw, n); // points right
                    V3 vc = PointVel(w.ContactPt);
                    double vLong = V3.Dot(vc, fw), vLat = V3.Dot(vc, side);
                    double vRef = Math.Max(Math.Abs(vLong), 3);
                    double slipV = w.Omega * w.Rad - vLong;
                    double kappa = slipV / vRef;
                    double alpha = Math.Atan2(vLat, Math.Max(Math.Abs(vLong), 1));
                    var si = Surfaces.Of(w.Surface);
                    double KP = 0.11 * si.Kp, AP = 0.13 * si.Ap;
                    w.Kp = KP;
                    double sx = kappa / KP, sy = alpha / AP;
                    double rho = M.Hypot(sx, sy);
                    // grip follows load: a tyre pressed harder grips harder, slightly less than in proportion
                    double loadRatio = Fl / w.StaticLoad;
                    double mu = t.Grip * si.Mu * M.Clamp(1 - 0.09 * (loadRatio - 1), 0.75, 1.15);
                    w.Cap = mu * Fl;                          // peak force this tyre can make right now
                    // off the pedals a sliding tyre keeps nearly all of its peak grip, so a slide straightens up
                    double slide = si.Slide < 0.97 ? M.Lerp(si.Slide, 0.97, recSm) : si.Slide;
                    double Ft = w.Cap * Cars.TyreCurve(rho, slide);
                    double Fy = 0;
                    if (rho > 1e-6) { Fx = Ft * sx / rho; Fy = -Ft * sy / rho; }
                    w.SlipRatio = kappa; w.SlipAngle = alpha; w.Grip = rho; w.Fx = Fx; w.Fy = Fy;
                    w.SlipVel = M.Hypot(slipV, vLat);
                    w.Sliding = rho > 1.15 ? M.Clamp((w.SlipVel - 1.5) / 6, 0, 1) : 0;
                    kTyre = mu * Fl * 2 / KP * w.Rad * w.Rad / vRef;

                    double rr = -si.Roll * Fl * Math.Tanh(vLong * 2);
                    V3 pApp = w.ContactPt + up * t.RollCenter;
                    ApplyAt(n * Fz, w.ContactPt);
                    w.Fw = fw * Fx + side * Fy; w.HasFw = true;
                    ApplyAt(w.Fw + fw * rr, pApp);
                    w.VLong = vLong;
                }
                else
                {
                    w.Fz = 0; w.Load = 0; w.Cap = 0; w.HasFw = false; w.Fx = 0; w.Fy = 0; w.Grip = 0; w.SlipVel = 0; w.Sliding = 0; w.SlipRatio = 0; w.SlipAngle = 0;
                }
                w.XPrev = w.X;

                // ----- wheel spin (implicit in the tyre stiffness so it stays stable) -----
                double Ieff = S.WheelInertia + (w.Driven ? engInertiaShare : 0);
                double denom = Ieff + dt * kTyre;
                double om = w.Omega + dt * ((w.Driven ? driveT[i] : 0) - Fx * w.Rad) / denom;
                double bT = brake * S.MaxBrake * (w.Front ? t.BrakeBias : 1 - t.BrakeBias) / 2;
                // ABS: modulates each wheel's pressure to hold its tyre just under the peak, counting the cornering it
                // is doing as well (combined slip), so the car still steers when you stand on the brakes at any
                // speed. Past the peak it lets the pressure go fast; under it, builds it back over a fraction of a second.
                bool absOn = t.Abs && brake > 0.05 && w.Contact && Math.Abs(w.VLong) > absMinSpeed && inp.Handbrake < 0.5;
                if (absOn)
                {
                    bool past = w.SlipRatio < -0.35 * w.KpOr && (w.Grip > 0.98 || w.SlipRatio < -1.05 * w.KpOr);
                    w.AbsP = past ? Math.Max(0.08, w.AbsP - dt * 22) : Math.Min(1, w.AbsP + dt * 8);
                }
                else w.AbsP = Math.Min(1, w.AbsP + dt * 10);
                bT *= w.AbsP;
                w.AbsActive = absOn && w.AbsP < 0.96;
                if (w.AbsActive) absAny = true;
                if (!w.Front) bT += inp.Handbrake * S.Handbrake;
                bT += holdK * S.MaxBrake * 0.08; // auto hold
                double db = dt * bT / denom;
                if (om > db) om -= db; else if (om < -db) om += db; else om = 0;
                w.Omega = M.Clamp(om, -400, 400);
                w.Spin = (w.Spin + w.Omega * dt) % (Math.PI * 2);
                // visual hub position (droops smoothly when airborne)
                double targetD = w.Contact ? M.Clamp(w.L0 - w.X, 0, w.L0) : w.L0;
                w.DVis = w.Contact ? targetD : M.Lerp(w.DVis, targetD, 1 - Math.Exp(-dt * 25));
            }

            // ----- aero -----
            if (speed > 0.1)
            {
                ApplyAt(Vel * (-0.5 * 1.2 * S.CdA * speed), pos);
                // downforce grows with the square of speed; AeroBalance (front share) puts it where the wings are
                double zc = !double.IsNaN(S.AeroBalance) ? S.Hubs[0].Z * S.AeroBalance + S.Hubs[2].Z * (1 - S.AeroBalance) - ComModel.Z : 0;
                ApplyAt(up * (-0.5 * 1.2 * S.ClA * vFwd * vFwd), zc != 0 ? ToWorld(new V3(0, 0, zc)) : pos);
            }

            // ----- body vs solid boxes (pit wall, garages): pushed out through the nearest side -----
            var solids = T.Solids;
            for (int si2 = 0; si2 < solids.Count; si2++)
            {
                var sb = solids[si2];
                if (pos.X < sb.MinX - 4 || pos.X > sb.MaxX + 4 || pos.Z < sb.MinZ - 4 || pos.Z > sb.MaxZ + 4) continue;
                for (int h = 0; h < hullBody.Length; h++)
                {
                    V3 p = pos + q.Rotate(hullBody[h]);
                    if (p.Y > sb.H) continue;
                    double rx = p.X - sb.Cx, rz = p.Z - sb.Cz;
                    double u = rx * sb.AxX + rz * sb.AxZ, v = rx * sb.AzX + rz * sb.AzZ;
                    double pu = sb.Hx - Math.Abs(u), pv = sb.Hz - Math.Abs(v);
                    if (pu <= 0 || pv <= 0) continue;
                    double pt = sb.H - p.Y;
                    V3 n; double pen;
                    if (pt < Math.Min(pu, pv) && pt < 0.25) { n = V3.UnitY; pen = pt; } // resting on top
                    else if (pu < pv) { double sg = u != 0 ? M.Sgn(u) : 1; n = new V3(sb.AxX * sg, 0, sb.AxZ * sg); pen = pu; }
                    else { double sg = v != 0 ? M.Sgn(v) : 1; n = new V3(sb.AzX * sg, 0, sb.AzZ * sg); pen = pv; }
                    V3 vp = PointVel(p); double vn = V3.Dot(vp, n);
                    double Fn = Math.Max(0, 260000 * pen - 9000 * vn);
                    V3 vt = vp - n * vn; double vtl = vt.Length();
                    V3 ft = vtl > 1e-4 ? vt * -Math.Min(0.45 * Fn / vtl, 3000) : V3.Zero;
                    ApplyAt(n * Fn + ft, p);
                    HitWall = Math.Max(HitWall, -vn);
                }
            }

            // ----- body vs wall segments (mesh maps: guardrails, tyre walls, fences, buildings) -----
            // Each wall pushes hull points back to the side the car's centre is on, so a point that got through
            // between two steps is still pushed back out the way it came.
            if (T.WallSeg != null)
            {
                int nW = T.WallsNear(pos.X, pos.Z, 3.4);
                if (nW > 0)
                {
                    var WS = T.WallSeg; var ids = T.WNear;
                    for (int h = 0; h < hullBody.Length; h++) hp[h] = pos + q.Rotate(hullBody[h]);
                    for (int k = 0; k < nW; k++)
                    {
                        int o = ids[k] * 6;
                        double ax = WS[o], az = WS[o + 1], ex = WS[o + 2] - ax, ez = WS[o + 3] - az, y0 = WS[o + 4], y1 = WS[o + 5];
                        double L = M.Hypot(ex, ez);
                        if (L < 1e-4) continue;
                        double nx = -ez / L, nz = ex / L, side = (pos.X - ax) * nx + (pos.Z - az) * nz >= 0 ? 1 : -1;
                        V3 Nw = new V3(nx * side, 0, nz * side);
                        for (int h = 0; h < hp.Length; h++)
                        {
                            V3 p = hp[h];
                            if (p.Y < y0 - 0.6 || p.Y > y1 + 0.05) continue;
                            double u = ((p.X - ax) * ex + (p.Z - az) * ez) / (L * L);
                            if (u < -0.03 / L || u > 1 + 0.03 / L) continue;
                            double pen = 0.05 - ((p.X - ax) * nx + (p.Z - az) * nz) * side;
                            if (pen <= 0 || pen > 1.6) continue;
                            V3 vp = PointVel(p); double vn = V3.Dot(vp, Nw);
                            double Fn = Math.Max(0, 500000 * pen - 14000 * vn);
                            V3 vt = vp - Nw * vn; double vtl = vt.Length();
                            V3 ft = vtl > 1e-4 ? vt * -Math.Min((0.4 * Fn) / vtl, 4000) : V3.Zero;
                            ApplyAt(Nw * Fn + ft, p);
                            HitWall = Math.Max(HitWall, -vn);
                        }
                    }
                }
            }

            // ----- body vs ground (rollovers, bottoming out) -----
            for (int h = 0; h < hullBody.Length; h++)
            {
                V3 p = pos + q.Rotate(hullBody[h]);
                double gh = T.Height(p.X, p.Z);
                double pen = gh - p.Y;
                if (pen <= 0) continue;
                V3 n = T.Normal(p.X, p.Z);
                V3 vp = PointVel(p);
                double vn = V3.Dot(vp, n);
                double Fn = Math.Max(0, 220000 * pen - 7000 * vn);
                V3 vt = vp - n * vn;
                double vtl = vt.Length();
                V3 ft = vtl > 1e-4 ? vt * -Math.Min(0.55 * Fn / vtl, 2500) : V3.Zero;
                ApplyAt(n * Fn + ft, p);
            }

            // ----- integrate rigid body (semi-implicit Euler) -----
            Vel = Vel + fAcc * (dt / Mass);
            Q4 qi = q.Conj();
            V3 wl = qi.Rotate(AngVel);
            V3 tl = qi.Rotate(tAcc);
            V3 Iw = new V3(I.X * wl.X, I.Y * wl.Y, I.Z * wl.Z);
            V3 gyro = V3.Cross(wl, Iw);
            wl = new V3(wl.X + dt * (tl.X - gyro.X) / I.X, wl.Y + dt * (tl.Y - gyro.Y) / I.Y, wl.Z + dt * (tl.Z - gyro.Z) / I.Z);
            AngVel = q.Rotate(wl);
            Pos = Pos + Vel * dt;
            var wq = new Q4(AngVel.X, AngVel.Y, AngVel.Z, 0);
            Q4 dq = Q4.Mul(wq, q);
            Q = new Q4(q.X + 0.5 * dt * dq.X, q.Y + 0.5 * dt * dq.Y, q.Z + 0.5 * dt * dq.Z, q.W + 0.5 * dt * dq.W).Normalized();

            // ----- telemetry -----
            var tel = Tel;
            V3 acc = (Vel - PrevVel) * (1 / dt);
            PrevVel = Vel;
            V3 rgt = Q.Rotate(V3.UnitX);
            double a = 1 - Math.Exp(-dt * 8);
            tel.GLat = M.Lerp(tel.GLat, V3.Dot(acc, rgt) / G, a);
            tel.GLong = M.Lerp(tel.GLong, V3.Dot(acc, fwdB) / G, a);
            double xl = (W[0].X + W[2].X) / 2, xr = (W[1].X + W[3].X) / 2;
            double xf = (W[0].X + W[1].X) / 2, xrr = (W[2].X + W[3].X) / 2;
            bool allDown = W[0].Contact && W[1].Contact && W[2].Contact && W[3].Contact;
            // suspension roll/pitch: body attitude relative to the tyre contact plane
            tel.Roll = allDown ? Math.Atan2(xr - xl, track) : Math.Asin(M.Clamp(-rgt.Y, -1, 1));
            tel.Pitch = allDown ? Math.Atan2(xrr - xf, wb) : Math.Asin(M.Clamp(fwdB.Y, -1, 1));
            tel.Speed = vFwd;
            // where the weight sits: share on the front axle, and the load centre over the wheelbase/track
            double lt = 0, lf = 0, lx = 0, lz = 0;
            foreach (var w in W) { double l = w.Load; lt += l; if (w.Front) lf += l; lx += l * w.HubModel.X; lz += l * w.HubModel.Z; }
            if (lt > 1) { tel.HasLoad = true; tel.FrontLoad = lf / lt; tel.LoadCx = lx / lt; tel.LoadCz = lz / lt; }
            else tel.HasLoad = false;
            tel.AbsActive = absAny;
            tel.TcsActive = tcsActive;
            tel.WheelRpm = wheelRpm;

            if (!double.IsFinite(Pos.X + Pos.Y + Pos.Z + Q.W))
            {
                if (T.HasSpawn) Reset(T.SpawnPos, T.SpawnYaw); else Reset(V3.Zero, 0);
            }
        }

        void AxleSplit(double part, int a, int b)
        {
            double lsd = Spec.Lsd * (Wheels[a].Omega - Wheels[b].Omega);
            driveT[a] = part / 2 - lsd; driveT[b] = part / 2 + lsd;
        }
    }
}
