"""Build the compound map pack: layout -> heights -> ground -> roads, bridges, kerbs, run-off, barriers ->
pits, paddocks, stands, transporters -> trees and scenery -> pack (compound.bin) and its description (compound.json)."""
import os, sys, time, json
import numpy as np
from scipy.spatial import cKDTree
import layout as LY
import terrain as TR
import tin
import trackgen as TG
import objects as OB
import assets as AS
import writer as W
from geom import Mesh, quad

OUT = next((a for a in sys.argv[1:] if not a.startswith('--')), 'compound.bin')
SCR = os.environ.get('SCRATCH', '.') + '/'
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)


def ring_paint(mesh, cx, cz, y, r, w=0.15, n=96, mat='paint'):
    a = np.linspace(0, 2 * np.pi, n + 1)
    for i in range(n):
        p = [(cx + rr * np.cos(a[j]), y, cz + rr * np.sin(a[j])) for rr, j in ((r - w, i), (r - w, i + 1), (r + w, i + 1), (r + w, i))]
        quad(mesh, mat, p[0], p[1], p[2], p[3], phys=True)


SLALOM_Z = (LY.SLALOM['z0'] + 55, LY.SLALOM['z0'] + 105)
SLALOM_X = (LY.SLALOM['x0'] + 50, LY.SLALOM['x1'] - 30)       # start and finish lines


def slalom(mesh, y):
    """cone lines and a skid circle on the slalom pad; cones are the game's own props (positions in the pack)"""
    r = LY.SLALOM
    cones = []
    for z, step in ((SLALOM_Z[0], 18.0), (SLALOM_Z[1], 12.0)):          # a long slalom, a tight one: west to east
        for x in np.arange(SLALOM_X[0] + 30, SLALOM_X[1] - 20, step): cones.append((x, z))
        OB.flat_quad(mesh, 'paint', SLALOM_X[0], z - 4, SLALOM_X[0] + 0.3, z + 4, y, lift=0.012)
        OB.flat_quad(mesh, 'checker', SLALOM_X[1] - 0.6, z - 4, SLALOM_X[1], z + 4, y, lift=0.013)
    cx, cz = (r['x0'] + r['x1']) / 2 + 60, r['z1'] - 62          # a skid circle of 40 m: painted, cones outside it
    ring_paint(mesh, cx, cz, y + 0.012, 40.0)
    ring_paint(mesh, cx, cz, y + 0.012, 30.0, mat='paint_y')
    for a in np.linspace(0, 2 * np.pi, 28, endpoint=False): cones.append((cx + 43 * np.cos(a), cz + 43 * np.sin(a)))
    for dz in (-6, 6):                                            # a lane-change box at the west end
        for x in np.arange(r['x0'] + 25, r['x0'] + 55, 5.0): cones.append((x, cz + dz))
    return np.array(cones)


def check_network(G):
    """every service road must start and end on another road or a pad (the gate road starts at the fence), and
    may only cross a track on a bridge"""
    bad = 0
    for k, rd in G.roads.items():
        if rd.prio < 2: continue
        for end, j in (('start', 0), ('end', len(rd.P) - 1)):
            if k == 'gate' and end == 'start': continue
            p = rd.P[j] + rd.t[j] * (-1.5 if end == 'start' else 1.5)
            nm, _ = G.road_at([p[0]], [p[1]], exclude=k, margin=1.0)
            pn, _ = G.pad_at([p[0]], [p[1]], margin=1.0)
            if nm[0] is None and pn[0] is None:
                log(f'ERROR: {k} {end}s at {rd.P[j].round()} without reaching a road or a pad'); bad += 1
        g = rd.ground.copy(); g[:40] = False; g[-40:] = False
        if g.any():
            ids = np.nonzero(g)[0]
            nm, _ = G.road_at(rd.P[ids, 0], rd.P[ids, 1], exclude=k, margin=0.5, y=rd.y[ids], ytol=3.0)
            hit = [n_ for n_ in nm if n_ is not None and G.roads[n_].prio < 2]
            if hit: log(f'ERROR: {k} crosses {set(hit)} at grade'); bad += 1
    if bad: raise SystemExit(f'{bad} problems in the road network')
    log('road network: every road reaches somewhere; tracks crossed only on bridges')


def main():
    L = LY.build()
    H0, roads, pads = TR.build(L)
    H, T = TR.shape(H0, roads, pads)
    log('terrain shaped')
    G = tin.Ground(H, T, roads, pads)
    log('ground triangulated')
    check_network(G)
    mesh = Mesh()
    G.mesh(mesh)
    # ---- surfaces and bridges
    for rd in roads.values(): TG.road_surface(mesh, G, rd)
    for rd in roads.values():
        if rd.decks: TG.bridges(mesh, G, rd)
    for name, (r, h) in pads.items(): OB.pad_mesh(mesh, G, name, r, h)
    log('roads, bridges and pads', len(roads), len(pads))
    # ---- kerbs (Spa's placement), run-off, barriers
    nk = 0
    for k, skip in (('gp', 0), ('int_link', 40), ('nat_link', 40), ('enduro', 0), ('drift', 0)):
        plan = TG.kerb_plan(roads[k], skip=skip)
        for sd, i0, i1, kind in plan: TG.kerb_mesh(mesh, G, roads[k], sd, i0, i1, kind)
        nk += len(plan)
    TG.gravel_and_walls(mesh, G, roads['gp'], wall_off=14.0)
    for k in ('int_link', 'nat_link'): TG.gravel_and_walls(mesh, G, roads[k], wall_off=14.0, skip=40)
    TG.gravel_and_walls(mesh, G, roads['enduro'], wall_off=18.0)
    TG.oval_walls(mesh, G, roads['oval'])
    nb = sum(TG.brake_boards(mesh, G, roads[k]) for k in ('gp', 'int_link', 'nat_link', 'enduro'))
    TG.speed_sign(mesh, G, roads['pit'], 25, 1); TG.speed_sign(mesh, G, roads['pit'], 25, -1)
    TG.speed_sign(mesh, G, roads['enduro_pit'], 25, -1)
    TG.speed_sign(mesh, G, roads['oval_pit'], 15, -1)
    log(f'kerbs {nk} pieces, run-off, barriers, {nb} brake boards')
    # ---- lines
    TG.start_line(mesh, roads['gp'], 0.0, checker=True)
    grid = TG.grid_boxes(mesh, roads['gp'])
    TG.start_line(mesh, roads['enduro'], 0.0, checker=True)
    TG.start_line(mesh, roads['oval'], 0.0, checker=True, o0=-LY.OVAL_HALF, o1=LY.OVAL_HALF)
    TG.start_line(mesh, roads['drift'], 0.0, checker=True)
    # ---- buildings and facilities
    OB.gp_pits(mesh, G, pads['paddock'][1])
    OB.oval_infield(mesh, G)
    OB.enduro_pits(mesh, G)
    OB.drift_paddock(mesh, G)
    OB.slalom_pad(mesh, G)
    OB.drag_strip(mesh, G, roads['drag'])
    OB.gatehouse(mesh, G)
    OB.perimeter_fence(mesh, G)
    OB.marshal_posts(mesh, G, roads['gp'], every=500)
    OB.marshal_posts(mesh, G, roads['enduro'], every=900)
    cones = slalom(mesh, pads['slalom'][1])
    log('buildings')
    OB.trees(mesh, G)
    OB.far_scenery(mesh, G)
    log('scenery')
    st = mesh.stats()
    tv = sum(v for v, _ in st.values()); tt = sum(t for _, t in st.values())
    log(f'mesh: {tv} vertices, {tt} triangles, {len(mesh.walls)} walls')
    for k, (v, t) in sorted(st.items(), key=lambda kv: -kv[1][1])[:16]: print(f'    {k:14s} {t:8d} tris')
    if '--nowrite' in sys.argv:
        import pickle; pickle.dump(dict(mesh=mesh, grid=grid, cones=cones), open(SCR + 'mesh.pkl', 'wb')); return
    mats, mat_index, images = AS.build_tables(set(mesh.parts))
    gp = roads['gp']
    meta = dict(width=12.0, loop=True, merge=True, grid=grid,
                credit='Textures: Spa-Francorchamps 1992 and Monte Carlo Rally by Dave Love (CC BY 4.0), Irohazaka Slope by sost; '
                       'track furniture: Race Track Assets Pack by Cherk (CC BY 4.0); transporters: DAV NASCAR Hauler by jairobman (CC BY 4.0)',
                tracks=track_meta(L, roads), roads=road_meta(roads), cones=cones.astype(np.float32).ravel(), spots=spots(roads, pads),
                pads=np.array([[r['x0'], r['z0'], r['x1'], r['z1']] for r, h in pads.values()], np.float32).ravel())
    starts = [s['name'] for s in meta['spots']]
    info = W.write_pack(OUT, mesh, mats, mat_index, images, gp.P.astype(np.float32), gp.y.astype(np.float32), meta, 'Motorsport Compound', gp.L)
    write_json(OUT.replace('.bin', '.json'), roads, starts)
    log('done', info)


def config_line(L, roads, c):
    """a GP configuration's centreline and heights: the GP's own where they share it, the link's elsewhere"""
    P = L['gp'][c]
    if c == 'gp': return roads['gp'].P, roads['gp'].y
    gp, lk = roads['gp'], roads[c + '_link']
    dg, jg = cKDTree(gp.P).query(P); dl, jl = cKDTree(lk.P).query(P)
    y = np.where(dg <= dl, gp.y[jg], lk.y[jl])
    return P, y


def track_meta(L, roads):
    """the timed courses: the GP's three configurations (one group: they share the start line), the endurance
    circuit, the oval and the drift track by the lap; the drag strip and the slaloms from line to line"""
    out = []
    for c in ('gp', 'int', 'nat'):
        P, y = config_line(L, roads, c)
        idx = np.arange(0, len(P), 2)
        out.append(dict(id=c if c != 'gp' else 'gp', name=LY.GP_NAMES[c], loop=True, width=12.0, group='gp', main=(c == 'gp'),
                        len=round(float(np.hypot(*np.diff(np.vstack([P, P[:1]]), axis=0).T).sum()), 1),
                        line=P[idx].astype(np.float32).ravel(), lineY=np.asarray(y)[idx].astype(np.float32)))
    for k, name, w in (('enduro', 'Endurance circuit', 13.0), ('oval', 'Oval', 30.0), ('drift', 'Drift track', 18.0)):
        rd = roads[k]
        idx = np.arange(0, len(rd.P), 2)
        out.append(dict(id=k, name=name, loop=True, width=w, len=round(float(rd.L), 1),
                        line=rd.P[idx].astype(np.float32).ravel(), lineY=rd.y[idx].astype(np.float32)))
    xs = LY.DRAG_START; z = LY.DRAG_Z
    out.append(dict(id='drag', name='Drag strip', sprint=True, start=[xs, z], finish=[xs + LY.DRAG_DIR * 402.34, z], width=16.0))
    for i, (zz, nm) in enumerate(zip(SLALOM_Z, ('Slalom', 'Tight slalom'))):
        out.append(dict(id='slalom' if i == 0 else 'slalom2', name=nm, sprint=True, start=[SLALOM_X[0] + 0.15, zz], finish=[SLALOM_X[1] - 0.3, zz], width=8.0))
    return out


def road_meta(roads):
    """every driveable centreline, every 5 m (x, y, z): the reset puts the car back on the nearest one"""
    out = []
    for k, rd in roads.items():
        idx = np.arange(0, len(rd.P), 5)
        if idx[-1] != len(rd.P) - 1: idx = np.r_[idx, len(rd.P) - 1]
        pts = rd.P[idx]                                   # (the oval's line is the middle of its track)
        ys = rd.surface(idx, 0.0)
        out.append(dict(id=k, half=float((rd.hi - rd.lo) / 2), loop=bool(rd.closed),
                        pts=np.c_[pts[:, 0], ys, pts[:, 1]].astype(np.float32).ravel()))
    return out


def spots(roads, pads):
    """starting points for free roam: (name, x, z, heading as a direction)"""
    def on(k, s, back=0.0):
        rd = roads[k]; j = int(s) % len(rd.P)
        p = rd.P[j] - rd.t[j] * back
        return [round(float(p[0]), 2), round(float(p[1]), 2), round(float(rd.t[j, 0]), 4), round(float(rd.t[j, 1]), 4)]
    return [dict(name='GP pit lane', at=on('pit', 150)),
            dict(name='Oval', at=on('oval_pit', 60)),
            dict(name='Endurance pits', at=on('enduro_pit', 150)),
            dict(name='Drift track', at=on('drift_rd', roads['drift_rd'].L - 30)),
            dict(name='Drag strip', at=[LY.DRAG_START + 9.0, LY.DRAG_Z - 4.0, LY.DRAG_DIR, 0.0]),
            dict(name='Slalom pad', at=[SLALOM_X[0] - 20.0, SLALOM_Z[0], 1.0, 0.0]),
            dict(name='Main gate', at=on('gate', 150))]


def write_json(path, roads, starts):
    gp = roads['gp']; en = roads['enduro']
    climb = float(gp.y.max() - gp.y.min())
    km = lambda k: f"{roads[k].L / 1000:.1f} km"
    d = {
        "id": "compound",
        "name": "Motorsport Compound",
        "short": "Compound",
        "sub": f"5 miles square · GP {gp.L / 1000:.1f} km · endurance {en.L / 1000:.1f} km · oval",
        "toast": f"Motorsport Compound · GP {gp.L / 1000:.2f} km",
        "blurb": "Five miles square: a hilly Grand Prix circuit in three configurations round a banked oval, a drift track, drag strip and slalom pad beside its paddock, and an endurance circuit round the edge.",
        "guide": (f"The Grand Prix circuit ({gp.L / 1000:.1f} km, {climb:.0f} m of climb) has three configurations that share the main straight: "
                  f"the full GP up the hill to the north, the International (a short cut across it) and the National (no hill loop). "
                  f"Inside it is a banked oval ({km('oval')}, 20 degrees in the turns, a paved apron inside): its gate is on the back stretch, "
                  f"reached by the service road that bridges the GP. Beside the GP paddock: the drift track ({km('drift')}), the quarter-mile drag "
                  f"strip and the slalom pad. The endurance circuit ({en.L / 1000:.1f} km) runs round the edge of the compound, with its own pits by the main gate. "
                  "Each course times itself from its line (the GP times whichever configuration you drive; the drag strip gives the speed over the line; "
                  "the slaloms add 2 s for every cone knocked over). Go to (in the menu) puts you at any of them; Reset car puts you back on the nearest road if you are off one."),
        "credit": "Built for Rust Bucket Racing. Textures from \"Circuit de Spa-Francorchamps 1992 layout\" and \"Monte Carlo Rally\" by Dave Love, sketchfab.com/Tyler_Dave (CC BY 4.0), and \"Irohazaka Slope\" by sost and its original authors. Track furniture: \"Race Track Assets Pack\" by Cherk, sketchfab.com/alex20010804 (CC BY 4.0). Transporters: \"DAV NASCAR Hauler\" by jairobman, sketchfab.com/jairobman (CC BY 4.0), in liveries of our own",
        "far": 16000,
        "fog": 0.00012,
        "occlude": False,
        "stage": False,
        "starts": starts,
        "minGame": "1.10",
    }
    json.dump(d, open(path, 'w'), indent=1, ensure_ascii=False)


if __name__ == '__main__':
    main()
