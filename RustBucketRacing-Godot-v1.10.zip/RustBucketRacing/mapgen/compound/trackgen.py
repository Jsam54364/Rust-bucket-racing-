"""Road surfaces, bridges, kerbs, run-off, barriers and track furniture.

Kerbs follow the way Spa-Francorchamps has them (measured from its map pack): on every corner tighter than about
250 m, a red and white kerb on the inside from 40-70 m before the apex to 10-80 m after it; one on the outside at
the exit running 50-120 m on (longer for faster corners); one on the outside at turn-in for medium and fast
corners; sausage kerbs behind the apex kerb of hairpins and chicanes; green paint beyond the exit kerb of the
faster corners. They sit across the track edge (0.9 m on the asphalt, 0.7 m over the verge), nearly flush.
Gravel traps lie on the outside of the slower corners, with tyre walls behind the slowest; guardrail runs along
both sides of the circuits beyond the run-off, stopping wherever another road comes through.

Barriers use the race track assets pack (Cherk, CC BY 4.0) as pictures on simple strips (its guardrail, concrete
barrier and tyre barrier rendered from the front and the top), so a kilometre of barrier costs a few hundred
triangles."""
import numpy as np
from scipy.ndimage import gaussian_filter1d, label
from scipy.spatial import cKDTree
from geom import grid_tris, quad, strip, box
import layout as LY
import terrain as TR
import kit

TRACKS = ('gp', 'int_link', 'nat_link', 'pit', 'enduro', 'enduro_pit', 'drift', 'oval_pit')


def wrap_range(i0, i1, n, closed):
    """indices from i0 to i1 inclusive (wrapping on a loop)"""
    if not closed: return np.arange(max(0, i0), min(n - 1, i1) + 1)
    return np.arange(i0, i1 + 1) % n


# ---------------------------------------------------------------- surfaces
def road_surface(mesh, G, rd):
    """the road ribbon across its width (skirts at both sides, down under the ground, or the fascia of a bridge
    deck); sunk 3 cm wherever a more important road or a pad covers it at the same level"""
    idx = G.stations(rd, 2.0, 5.0)
    if rd.closed and idx[-1] == len(rd.P) - 1: idx = idx[:-1]
    if rd.prof is not None:                                   # the oval: outer edge, the track's inner edge, apron
        h, a, out = LY.OVAL_HALF, LY.OVAL_APRON, rd.out
        offs = np.array([h + 0.45, h, 0, -h, -h - a / 2, -h - a, -h - a - 0.45]) * out
        if out < 0: offs = offs[::-1]
        offs = np.sort(offs)[::-1]
    else:
        offs = np.array([rd.hi + 0.5, rd.hi + 0.3, rd.hi, 0, rd.lo, rd.lo - 0.3, rd.lo - 0.5])
    if rd.prof is not None:
        offs = np.r_[offs[0] + 0.05, offs[1] + 0.3, offs[1:-1], offs[-2] - 0.3, offs[-1] - 0.05]
    na, nc = len(idx), len(offs)
    X = rd.P[idx][:, None, :] + rd.n[idx][:, None, :] * offs[None, :, None]
    Y = np.stack([rd.surface(idx, o) for o in offs], 1)
    deck = ~rd.ground[idx]
    # a lip just past each edge, level with the ground's edge row (so wheels always find a surface), then the skirt
    Y[:, 1] -= 0.04; Y[:, -2] -= 0.04
    Y[:, 0] -= np.where(deck, TR.DECK + 0.1, 0.3); Y[:, -1] -= np.where(deck, TR.DECK + 0.1, 0.3)
    # sink under more important surfaces at the same level
    flat = X.reshape(-1, 2); yf = Y.reshape(-1).copy()
    if any(o.prio < rd.prio for k, o in G.roads.items() if k != rd.name):
        nm, yo = G.road_at(flat[:, 0], flat[:, 1], margin=-0.02, y=yf, ytol=1.5)
        sink = np.array([n_ is not None and G.roads[n_].prio < rd.prio for n_ in nm])
        yf = np.where(sink, np.minimum(yf, yo - 0.03), yf)
    if rd.prio > 2:
        pn, yp = G.pad_at(flat[:, 0], flat[:, 1], margin=-0.02)
        yf = np.where((pn != None) & (np.abs(yf - np.nan_to_num(yp)) < 1.5), np.minimum(yf, yp - 0.03), yf)
    Y = yf.reshape(na, nc)
    P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
    s = rd.s[idx]
    if rd.name == 'drag':
        U = np.stack([np.broadcast_to(-offs / 8, (na, nc)), np.broadcast_to(s[:, None] / 8, (na, nc))], -1); mat = 'pad'
    elif rd.prof is not None:
        u = (offs * rd.out + LY.OVAL_HALF + LY.OVAL_APRON) / (2 * LY.OVAL_HALF + LY.OVAL_APRON)
        U = np.stack([np.broadcast_to(np.clip(u, -0.02, 1.02), (na, nc)), np.broadcast_to(s[:, None] / 30.0, (na, nc))], -1); mat = 'oval'
    elif rd.name in TRACKS:
        w = rd.hi - rd.lo
        u = np.clip((rd.hi - offs) / w, -0.03, 1.03)
        U = np.stack([np.broadcast_to(u, (na, nc)), np.broadcast_to(s[:, None] / w, (na, nc))], -1); mat = 'track'
    else:
        w = rd.hi - rd.lo
        u = np.clip((rd.hi - offs) / w, -0.03, 1.03)
        U = np.stack([np.broadcast_to(u, (na, nc)), np.broadcast_to(s[:, None] / 7.5, (na, nc))], -1); mat = 'road'
    U = U.reshape(-1, 2)
    if rd.closed:      # the texture's v must not jump where the loop closes: the last row repeats the first
        vlen = {'pad': 8.0, 'oval': 30.0, 'track': rd.hi - rd.lo, 'road': 7.5}[mat]
        P = np.vstack([P, P[:nc]]); U = np.vstack([U, np.c_[U[:nc, 0], np.full(nc, rd.L / vlen)]])
        na += 1
    I = grid_tris(na, nc)
    col = I % nc
    phys = ~((col == 0).any(1) | (col == nc - 1).any(1))
    mesh.add(mat, P, U, I, phys=phys)
    return idx


# ---------------------------------------------------------------- bridges
def bridges(mesh, G, rd):
    """under each deck: its underside and fascia, concrete parapets (solid), piers either side of the track below,
    and an abutment wall at each end where the embankment stops"""
    for i0, i1, trn in rd.decks:
        tr = G.roads[trn]
        ids = np.arange(i0, i1 + 1)
        y = rd.y[ids]; lo, hi = rd.lo - 0.45, rd.hi + 0.45
        A = rd.P[ids] + rd.n[ids] * hi; B = rd.P[ids] + rd.n[ids] * lo
        yb = y - TR.DECK - 0.1
        n = len(ids)
        P = np.r_[np.c_[A[:, 0], yb, A[:, 1]], np.c_[B[:, 0], yb, B[:, 1]]]
        I = np.array([[i, n + i, i + 1] for i in range(n - 1)] + [[i + 1, n + i, n + i + 1] for i in range(n - 1)])
        U = np.r_[np.c_[rd.s[ids] / 4, np.zeros(n)], np.c_[rd.s[ids] / 4, np.full(n, 2.0)]]
        mesh.add('concrete', P, U, I, N=np.tile([0, -1, 0], (2 * n, 1)), phys=False)
        for o in (rd.hi + 0.25, rd.lo - 0.25):            # parapets
            pts = rd.P[ids] + rd.n[ids] * o
            conc_wall(mesh, pts, y, 1.05)
        # piers: where the deck passes the edges of the track's verges
        d, j = cKDTree(tr.P).query(rd.P[ids])
        for side_d in (tr.half + tr.verge + 3,):
            for k in np.nonzero(np.abs(np.diff(np.sign(d - side_d))) > 0)[0]:
                p = rd.P[ids[k]]; t = rd.t[ids[k]]
                g = float(G.height([p[0]], [p[1]])[0])
                h = float(y[k]) - TR.DECK - g + 0.3
                box(mesh, p[0], p[1], g - 0.3, 1.4, (rd.hi - rd.lo) * 0.8, h, float(np.arctan2(t[1], t[0])), 'concrete', uvm=(2, 3))
        for k in (0, n - 1):                              # abutments: the embankment's end
            p = rd.P[ids[k]]; t = rd.t[ids[k]]
            g = float(G.height([p[0]], [p[1]])[0]) - 2.0
            box(mesh, p[0], p[1], g, 1.0, rd.hi - rd.lo + 1.2, float(y[k]) - g - 0.05, float(np.arctan2(t[1], t[0])), 'concrete', uvm=(3, 3), collide=False)


# ---------------------------------------------------------------- barriers (the assets pack, as pictures on strips)
def conc_wall(mesh, pts, yg, h=1.1, collide=True):
    """a concrete barrier along a polyline: two faces and a top, the asset's front and top pictures"""
    pts = np.asarray(pts, float); yg = np.broadcast_to(np.asarray(yg, float), len(pts))
    if len(pts) < 2: return
    t = np.gradient(pts, axis=0); t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-9)
    nrm = np.c_[-t[:, 1], t[:, 0]]
    for sgn in (1, -1):
        strip(mesh, 'kit_conc', pts + nrm * (0.18 * sgn), yg - 0.05, yg + h, 5.0, 0.0, 1.0)
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(pts, axis=0).T))]
    A = pts + nrm * 0.18; B = pts - nrm * 0.18; n = len(pts)
    P = np.r_[np.c_[A[:, 0], yg + h, A[:, 1]], np.c_[B[:, 0], yg + h, B[:, 1]]]
    I = np.array([[i, i + 1, n + i] for i in range(n - 1)] + [[i + 1, n + i + 1, n + i] for i in range(n - 1)])
    U = np.r_[np.c_[s / 5, np.zeros(n)], np.c_[s / 5, np.ones(n)]]
    mesh.add('kit_conc_top', P, U, I, N=np.tile([0, 1, 0], (2 * n, 1)), phys=False)
    if collide: mesh.wall_line(pts, yg - 0.3, yg + h)


def rail(mesh, pts, yg, collide=True):
    """guardrail: the asset's rails and posts on a strip, front and back pictures"""
    pts = np.asarray(pts, float)
    if len(pts) < 2: return
    yg = np.broadcast_to(np.asarray(yg, float), len(pts))
    strip(mesh, 'kit_rail', pts, yg - 0.05, yg + 1.2, 5.0, 0.0, 1.0)
    strip(mesh, 'kit_rail_b', pts[::-1], yg[::-1] - 0.05, yg[::-1] + 1.2, 5.0, 0.0, 1.0)
    if collide: mesh.wall_line(pts, yg - 0.3, yg + 1.1)


def tyre_wall(mesh, pts, yg, collide=True):
    """the assets pack's tyre barrier (belted): front and back as pictures, its top too"""
    pts = np.asarray(pts, float); yg = np.broadcast_to(np.asarray(yg, float), len(pts))
    if len(pts) < 2: return
    t = np.gradient(pts, axis=0); t /= np.maximum(np.linalg.norm(t, axis=1, keepdims=True), 1e-9)
    nrm = np.c_[-t[:, 1], t[:, 0]]
    for sgn in (1, -1):
        q = pts + nrm * (0.8 * sgn)
        strip(mesh, 'kit_tyres', q if sgn > 0 else q[::-1], (yg if sgn > 0 else yg[::-1]) - 0.05, (yg if sgn > 0 else yg[::-1]) + 1.2, 5.0, 0.0, 1.0)
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(pts, axis=0).T))]
    A = pts + nrm * 0.8; B = pts - nrm * 0.8; n = len(pts)
    P = np.r_[np.c_[A[:, 0], yg + 1.2, A[:, 1]], np.c_[B[:, 0], yg + 1.2, B[:, 1]]]
    I = np.array([[i, i + 1, n + i] for i in range(n - 1)] + [[i + 1, n + i + 1, n + i] for i in range(n - 1)])
    U = np.r_[np.c_[s / 5, np.zeros(n)], np.c_[s / 5, np.ones(n)]]
    mesh.add('kit_tyres_top', P, U, I, N=np.tile([0, 1, 0], (2 * n, 1)), phys=False)
    if collide: mesh.wall_line(pts, yg - 0.3, yg + 1.2)


def fence(mesh, pts, y0, y1):
    strip(mesh, 'fence', pts, y0, y1, 3.0, 0.0, 1.0)


def thin(r, curvy, fine, coarse):
    """indices of run r every `fine` points on curves, `coarse` on straights, always with both ends"""
    out = [r[0]]; acc = 0
    for i in range(1, len(r)):
        acc += 1
        if acc >= (fine if curvy[i] else coarse): out.append(r[i]); acc = 0
    if out[-1] != r[-1]: out.append(r[-1])
    return np.array(out)


def runs(ok, min_len=6):
    """index runs where ok holds"""
    lab, n = label(ok)
    return [np.nonzero(lab == c)[0] for c in range(1, n + 1) if (lab == c).sum() >= min_len]


# ---------------------------------------------------------------- corners and kerbs
def corners(rd, r_max=250.0):
    """corner runs: start, apex, end indices, min radius R, turn side (+1 left, -1 right), length L (m)"""
    closed = rd.closed
    k = gaussian_filter1d(rd.k, 10, mode='wrap' if closed else 'nearest')
    n = len(k)
    on = np.abs(k) > 1 / r_max
    if not on.any() or on.all(): return []
    sh = int(np.argmin(on)) if closed else 0                  # start on a straight
    kk = np.roll(k, -sh); oo = np.roll(on, -sh)
    edges = np.diff(np.r_[0, oo.astype(int), 0])
    starts, ends = np.nonzero(edges == 1)[0], np.nonzero(edges == -1)[0] - 1
    out = []
    for a, b in zip(starts, ends):
        ids = np.arange(a, b + 1)
        sg = np.sign(kk[ids])
        for part in np.split(ids, np.nonzero(np.diff(sg) != 0)[0] + 1):     # esses: one corner per direction
            if len(part) < 6: continue
            ap = part[np.argmax(np.abs(kk[part]))]
            m = lambda i: int((i + sh) % n) if closed else int(i)
            out.append(dict(start=m(part[0]), apex=m(ap), end=m(part[-1]), R=1 / abs(kk[ap]), side=int(np.sign(kk[ap])), L=float(len(part))))
    return out


def kerb_plan(rd, skip=0):
    """pieces: (side, i0, i1, kind) by the Spa rules; on an open path, corners within `skip` points of its ends
    (where it overlaps the road it joins) are left to that road"""
    pieces = []
    n = len(rd.P)
    for c in corners(rd):
        if not rd.closed and (c['apex'] < skip or c['apex'] > n - 1 - skip): continue
        ap, L, R, sd = c['apex'], c['L'], c['R'], c['side']
        a0 = ap - int(min(70, 0.55 * L + 12)); a1 = ap + int(min(80, 0.35 * L + 8))
        if a1 - a0 < 25: a0, a1 = ap - 15, ap + 12
        pieces.append((sd, a0, a1, 'kerb'))
        e0 = ap + int(0.15 * L); e1 = c['end'] + int(25 + min(90, 0.35 * R))
        pieces.append((-sd, e0, max(e1, e0 + 30), 'kerb'))
        if R >= 40:
            pieces.append((-sd, c['start'] - int(30 + min(40, 0.25 * R)), c['start'] + int(0.15 * L), 'kerb'))
        if R < 35:
            pieces.append((sd, ap - 12, ap + 12, 'sausage'))
        if R > 60:
            pieces.append((-sd, e0 + 5, max(e1, e0 + 30) - 5, 'green'))
    merged = []
    for sd, kind in {(p[0], p[3]) for p in pieces}:
        ps = sorted((p[1], p[2]) for p in pieces if p[0] == sd and p[3] == kind)
        cur = list(ps[0])
        for a, b in ps[1:]:
            if a <= cur[1] + 8: cur[1] = max(cur[1], b)
            else: merged.append((sd, cur[0], cur[1], kind)); cur = [a, b]
        merged.append((sd, cur[0], cur[1], kind))
    if not rd.closed: merged = [(sd, max(0, a), min(n - 1, b), k) for sd, a, b, k in merged if b - a > 8]
    return merged


def kerb_mesh(mesh, G, rd, side, i0, i1, kind):
    n = len(rd.P)
    ids = wrap_range(i0, i1, n, rd.closed)[::2]
    if len(ids) < 3: return
    # not where another road joins (its ribbon would cover the kerb, or the kerb would block the way in)
    edge = rd.P[ids] + rd.n[ids] * (side * (rd.half + 0.6))
    nm, _ = G.road_at(edge[:, 0], edge[:, 1], exclude=rd.name, margin=0.5)
    keep = np.array([x is None or x in ('gp', 'int_link', 'nat_link') for x in nm])
    for r in runs(keep, 3):
        _kerb(mesh, G, rd, side, ids[r], kind)


def _kerb(mesh, G, rd, side, ids, kind):
    h = rd.half
    if kind == 'kerb': offs, lift, mat, uvl = [h - 0.9, h - 0.1, h + 0.7], [0.005, 0.045, 0.015], 'kerb', 2.8
    elif kind == 'sausage': offs, lift, mat, uvl = [h + 1.0, h + 1.25, h + 1.6], [0.03, 0.14, 0.03], 'sausage', 3.0
    else: offs, lift, mat, uvl = [h + 0.7, h + 1.9, h + 3.2], [0.03, 0.03, 0.03], 'green', 4.0
    offs = np.array(offs) * side
    na, nc = len(ids), 3
    taper = np.clip(np.minimum(np.arange(na), np.arange(na)[::-1]) / 1.5, 0, 1)
    X = rd.P[ids][:, None, :] + rd.n[ids][:, None, :] * offs[None, :, None]
    Y = np.zeros((na, nc))
    for c in range(nc):
        if abs(offs[c]) <= h: base = rd.surface(ids, offs[c])
        else:            # over the verge: on the ground, and never under the road's edge plane
            gy = G.height(X[:, c, 0], X[:, c, 1])
            base = gy if kind != 'kerb' else np.maximum(gy, rd.surface(ids, np.sign(offs[c]) * h))
        Y[:, c] = base + lift[c] * (taper if kind == 'kerb' or c == 1 else 1)
    P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
    s = np.arange(na) * 2.0
    U = np.stack([np.repeat(s[:, None] / uvl, nc, 1), np.broadcast_to([0.0, 0.55, 1.0], (na, nc))], -1)
    I = grid_tris(na, nc)
    if side < 0: I = I[:, [0, 2, 1]]
    mesh.add(mat, P, U.reshape(-1, 2), I, phys=True)


# ---------------------------------------------------------------- run-off and barriers along a circuit
def gravel_and_walls(mesh, G, rd, plan_traps=True, wall_off=14.0, barriers=True, skip=0, max_off=60.0):
    """gravel traps on the outside of slow corners (tyre walls behind the slowest), guardrail along both sides"""
    n = len(rd.P); h = rd.half
    outer = {1: np.full(n, h + wall_off), -1: np.full(n, h + wall_off)}
    traps = []
    if plan_traps:
        for c in corners(rd):
            if c['R'] > 115: continue
            if not rd.closed and (c['apex'] < skip or c['apex'] > n - 1 - skip): continue
            sd = -c['side']
            a = c['apex'] - int(0.2 * c['L']); b = c['end'] + int(50 + 0.4 * c['R'])
            W = float(np.clip(12 + 0.12 * c['R'], 12, 26))
            traps.append((sd, a, b, W, c['R']))
    for sd, a, b, W, R in traps:
        ids = wrap_range(a, b, n, rd.closed)[::3]
        if len(ids) < 4: continue
        u = np.linspace(0, 1, len(ids))
        wid = W * np.clip(np.minimum(u, 1 - u) / 0.18, 0, 1) ** 0.7
        o0 = h + 3.4
        cols = 6
        frac = np.linspace(0, 1, cols)
        O = o0 + wid[:, None] * frac[None, :]
        X = rd.P[ids][:, None, :] + rd.n[ids][:, None, :] * (O * sd)[:, :, None]
        # not over another road
        nm, _ = G.road_at(X[:, :, 0].ravel(), X[:, :, 1].ravel(), exclude=rd.name, margin=2.0)
        if (nm.reshape(X.shape[:2]) != None).any():
            bad = (nm.reshape(X.shape[:2]) != None).any(1)
            if bad.mean() > 0.3: continue
        Y = G.height(X[:, :, 0].ravel(), X[:, :, 1].ravel()).reshape(X.shape[:2]) + 0.035
        P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
        U = np.dstack([X[:, :, 0] / 6, X[:, :, 1] / 6]).reshape(-1, 2)
        I = grid_tris(len(ids), cols)
        if sd < 0: I = I[:, [0, 2, 1]]
        mesh.add('gravel', P, U, I)
        wall_o = o0 + W + 1.5
        outer[sd][ids] = np.maximum(outer[sd][ids], wall_o + 2.0)
        if R < 60:      # tyre wall along the back of the trap
            k = (wid > W * 0.6)
            seg = ids[k]
            if len(seg) > 2:
                pts = rd.P[seg] + rd.n[seg] * (sd * wall_o)
                yg = G.height(pts[:, 0], pts[:, 1])
                tyre_wall(mesh, pts, yg)
    if not barriers: return
    # guardrail: offsets smoothed, inside the corner's own radius, stopping where it would meet another road or pad
    for sd in (1, -1):
        o = gaussian_filter1d(outer[sd], 25, mode='wrap' if rd.closed else 'nearest')
        o = np.minimum(o, max_off)
        kin = rd.k * sd                                       # > 0: this side is the inside of a turn
        lim = np.where(kin > 1e-4, 0.75 / np.maximum(kin, 1e-9), 1e9)
        o = np.minimum(o, lim)
        pts = rd.P + rd.n * (sd * o[:, None])
        ok = o > h + 4
        nm, _ = G.road_at(pts[:, 0], pts[:, 1], margin=4.0)
        ok &= (nm == None)
        pn, _ = G.pad_at(pts[:, 0], pts[:, 1], margin=4.0)
        ok &= (pn == None)
        # clear of every other track and road near it (where another part of a circuit runs by)
        for k2, r2 in G.roads.items():
            dd, _ = G.trees[k2].query(pts)
            ok &= dd > r2.half + 3.5 if k2 != rd.name else dd > h + 3.5
        if not rd.closed: ok[:skip] = False; ok[n - skip:] = False
        curvy = np.abs(gaussian_filter1d(rd.k, 5, mode='wrap' if rd.closed else 'nearest')) > 1 / 400
        for r in runs(ok, 12):
            seg = thin(r, curvy[r], 4, 14)
            P2 = pts[seg]
            yg = G.height(P2[:, 0], P2[:, 1])
            rail(mesh, P2, yg)


# ---------------------------------------------------------------- the oval: SAFER wall and catch fence, with its gate
def oval_walls(mesh, G, rd):
    n = len(rd.P)
    o = rd.out * (LY.OVAL_HALF + 0.35)
    pts = rd.P + rd.n * o
    x = rd.P[:, 0]; back = rd.P[:, 1] < LY.OVAL_C[1]
    g0, g1 = LY.OVAL_GAP
    gap = back & (x > g0) & (x < g1)
    # the back stretch runs toward -x: the wall after the gate (x < g0) starts flared outward, so nothing hits its end
    flare = back & (x <= g0) & (x > g0 - 40)
    w = np.where(flare, (x - (g0 - 40)) / 40.0, 0.0)
    pts = pts + rd.n * (rd.out * 4.0 * w ** 1.5)[:, None]
    yb = np.array([rd.surface(i, rd.out * LY.OVAL_HALF) for i in range(n)])
    keep = ~gap
    # a loop: start the runs after the gap
    sh = int(np.argmax(gap)) + int(gap.sum())
    order = np.roll(np.arange(n), -sh)
    k2 = keep[order]
    for r in runs(k2, 10):
        ids = order[r][::3]
        if r[-1] == len(order) - 1 and keep[order[0]]: pass
        conc_wall(mesh, pts[ids], yb[ids], 1.2)
        fence(mesh, pts[ids], yb[ids] + 1.2, yb[ids] + 6.0)
        # the fence's posts lean in a little: just a line of posts every 9 m
        for i in ids[::3]:
            box(mesh, pts[i, 0], pts[i, 1], yb[i] + 1.2, 0.12, 0.12, 4.9, 0.0, 'post', collide=False, top=False)
    # the pit wall between the oval's pit lane and the apron
    pit = G.roads['oval_pit']
    mid = (pit.P[:, 1] > LY.OVAL_PIT_Z - 1) & (np.abs(pit.P[:, 0]) < 105)
    ids = np.nonzero(mid)[0][::3]
    if len(ids) > 2:
        side = np.sign((LY.OVAL_R - LY.OVAL_HALF - LY.OVAL_APRON) - LY.OVAL_PIT_Z)
        pts = pit.P[ids] + np.c_[np.zeros(len(ids)), np.full(len(ids), side * (pit.half + 0.7))]
        yb = pit.y[ids]
        conc_wall(mesh, pts, yb, 1.0)
        fence(mesh, pts, yb + 1.0, yb + 3.2)


# ---------------------------------------------------------------- paint
def paint_band(mesh, mat, rd, s0, s1, o0, o1, lift=0.012, uv=None):
    """a painted rectangle on a road between s0..s1 (metres) and lateral o0..o1"""
    n = len(rd.P)
    def at(s, o):
        j = int(round(s)) % n if rd.closed else int(np.clip(round(s), 0, n - 1))
        p = rd.P[j] + rd.n[j] * o
        return (p[0], rd.surface(j, o) + lift, p[1])
    A, B, C, D = at(s0, o1), at(s0, o0), at(s1, o0), at(s1, o1)
    quad(mesh, mat, A, B, C, D, uv=uv or ((0, 0), (1, 0), (1, 1), (0, 1)), phys=True)


def start_line(mesh, rd, s=0.0, checker=False, o0=None, o1=None):
    o0 = rd.lo if o0 is None else o0; o1 = rd.hi if o1 is None else o1
    if checker: paint_band(mesh, 'checker', rd, s - 0.6, s + 0.6, o0, o1, uv=((0, 0), (0, 1), (1, 1), (1, 0)))
    else: paint_band(mesh, 'paint', rd, s - 0.3, s + 0.3, o0, o1)


def grid_boxes(mesh, rd, count=20, s_line=0.0):
    """painted grid boxes behind the line (cars face along +s): returns their centres for the pack (the game puts
    each car 1.5 m ahead of its box centre)"""
    L = rd.L; out = []
    for i in range(count):
        sc = (s_line + L - 9 - 8 * i) % L
        d = -2.9 if i % 2 == 0 else 2.9
        front = sc + 1.5
        paint_band(mesh, 'paint', rd, front - 0.15, front + 0.15, d - 1.1, d + 1.1)
        for e in (d - 1.1, d + 1.1):
            paint_band(mesh, 'paint', rd, front - 1.2, front, e - 0.08, e + 0.08)
        j = int(round(sc)) % len(rd.P)
        p = rd.P[j] + rd.n[j] * d
        out.append([round(float(p[0]), 2), round(float(p[1]), 2)])
    return out


# ---------------------------------------------------------------- track furniture from the assets pack
def facing(t):
    """the kit's yaw that turns a part's front (local -z: the side with the numbers) toward traffic coming along t"""
    return float(np.arctan2(t[0], t[1]))


def brake_boards(mesh, G, rd, min_straight=220.0, max_R=110.0):
    """200/150/100/50 boards on the outside of the approach to each slow corner at the end of a straight"""
    cs = corners(rd)
    n = len(rd.P)
    placed = 0
    for i, c in enumerate(cs):
        if c['R'] > max_R: continue
        prev_end = cs[i - 1]['end'] if i > 0 else (cs[-1]['end'] - n if rd.closed and cs else -10 ** 6)
        gap = (c['start'] - prev_end) % n if rd.closed else c['start'] - prev_end
        if gap < min_straight: continue
        sd = -c['side']                                   # outside of the corner = the side the boards stand on
        for dist, key in ((200, 'board200'), (150, 'board150'), (100, 'board100'), (50, 'board50')):
            j = (c['start'] - dist) % n if rd.closed else c['start'] - dist
            if j < 0: continue
            p = rd.P[j] + rd.n[j] * (sd * (rd.half + 4.0))
            nm, _ = G.road_at([p[0]], [p[1]], margin=1.5)
            if nm[0] is not None: continue
            y = float(G.height([p[0]], [p[1]])[0])
            kit.place(mesh, key, p[0], y + 0.6, p[1], facing(rd.t[j]), scale=1.6)
            box(mesh, p[0], p[1], y - 0.2, 0.08, 0.08, 0.85, 0.0, 'post', collide=False, top=False)
            placed += 1
    return placed


def speed_sign(mesh, G, rd, j, side, key='limit60'):
    for j in range(j, len(rd.P) - 1, 3):                  # the first spot clear of every other road
        p = rd.P[j] + rd.n[j] * (side * (rd.half + 1.5))
        nm, _ = G.road_at([p[0]], [p[1]], margin=1.0)
        if nm[0] is None: break
    y = float(G.height([p[0]], [p[1]])[0])
    box(mesh, p[0], p[1], y, 0.07, 0.07, 1.6, 0.0, 'post', collide=False, top=False)
    kit.place(mesh, key, p[0], y + 1.2, p[1], facing(rd.t[j]), scale=1.3)


def start_gantry(mesh, G, rd, s=0.0, back=8.0):
    """the start lights over the track, facing the grid: two posts and a beam, the assets pack's light panels"""
    n = len(rd.P)
    j = int(round(s + back)) % n
    p = rd.P[j]; t = rd.t[j]; nn = rd.n[j]
    y = float(rd.y[j])
    w = rd.hi - rd.lo + 3.0
    for sd in (1, -1):
        q = p + nn * (sd * w / 2)
        box(mesh, q[0], q[1], y, 0.5, 0.5, 7.5, 0.0, 'metal', uvm=(1, 4))
    yaw = float(np.arctan2(nn[1], nn[0]))
    box(mesh, p[0], p[1], y + 6.6, w, 0.6, 0.9, yaw, 'metal', uvm=(2, 1), collide=False)
    for off in (-1.2, 1.2):
        q = p + nn * off
        kit.place(mesh, 'lights', q[0], y + 5.0, q[1], float(np.arctan2(-t[0], -t[1])))
        kit.place(mesh, 'lights_gl', q[0], y + 5.0, q[1], float(np.arctan2(-t[0], -t[1])))


def masts(mesh, G, pts):
    for x, z in pts:
        y = float(G.surface([x], [z])[0])
        kit.place(mesh, 'mast', x, y, z, 0.0)
        mesh.wall((x - 0.4, z - 0.4), (x + 0.4, z + 0.4), y - 0.3, y + 6)
