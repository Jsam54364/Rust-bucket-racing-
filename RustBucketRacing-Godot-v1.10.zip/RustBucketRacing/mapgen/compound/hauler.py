"""Race transporters from "DAV NASCAR Hauler" by jairobman (CC BY 4.0): the model simplified with Godot's simplifier,
its sponsor logo left off, and the trailer box given new texture coordinates so it can wear liveries of our own
(drawn here: colours, stripes, fictional team names and numbers). The cab is repainted to match each livery.

place(mesh, x, y, z, yaw, k) puts transporter livery k with its front toward (cos yaw, sin yaw) in x-z."""
import os, io
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import glb, kit

HERE = os.path.dirname(os.path.abspath(__file__))
GLB = os.environ.get('HAULER_GLB', os.path.join(HERE, 'dav_nascar_hauler.glb'))
CACHE = os.path.join(HERE, 'hauler_cache.npz')
FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_C = '/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-BoldOblique.ttf'

# object -> (triangle budget, material group, how): 'attr' Godot's simplifier keeping texture seams, 'pos' meshoptimizer
# on positions alone (for parts made of many loose pieces), 'keep', 'wheels' (rebuilt as simple cylinders); None: left off
OBJECTS = {
    'Object_0': (40, 'hl_step', 'attr'), 'Object_1': (90, 'hl_black', 'attr'), 'Object_2': (70, 'hl_dark', 'pos'),
    'Object_3': (70, 'hl_chassis', 'pos'), 'Object_4': (None, 'trailer', 'keep'), 'Object_5': None,   # 5: the sponsor's logo
    'Object_6': (100, 'hl_tank', 'attr'), 'Object_7': (None, 'hl_wheel_r', 'wheels'), 'Object_8': (None, 'hl_wheel_f', 'wheels'),
    'Object_9': (60, 'cab_trim', 'attr'), 'Object_10': (450, 'cab', 'pos'), 'Object_11': (160, 'cab', 'attr'),
    'Object_12': (200, 'cab', 'attr'),
}
IMG = {'hl_step': 4, 'hl_chassis': 2, 'hl_tank': 6, 'hl_wheel_r': 1, 'hl_wheel_f': 0, 'cab': 3, 'cab_trim': 5, 'trailer_lo': 8}

# liveries: base, stripe, pinstripe, lettering, team name, number
LIVERIES = [
    ((0.80, 0.08, 0.06), (0.98, 0.98, 0.98), (0.10, 0.10, 0.12), (1, 1, 1), 'RUST BUCKET RACING', '7'),
    ((0.06, 0.18, 0.55), (0.98, 0.78, 0.10), (0.95, 0.95, 0.95), (1, 1, 1), 'BLUE COMET MOTORSPORT', '24'),
    ((0.10, 0.10, 0.11), (0.20, 0.85, 0.30), (0.95, 0.95, 0.95), (0.20, 0.85, 0.30), 'IRONBARK RACING', '41'),
    ((0.96, 0.96, 0.96), (0.85, 0.30, 0.05), (0.10, 0.20, 0.45), (0.10, 0.20, 0.45), 'SUNRISE FREIGHT RACING', '88'),
    ((0.95, 0.70, 0.05), (0.08, 0.08, 0.08), (0.80, 0.10, 0.08), (0.08, 0.08, 0.08), 'HORNET WORKS', '12'),
    ((0.40, 0.08, 0.45), (0.10, 0.75, 0.85), (0.98, 0.98, 0.98), (1, 1, 1), 'VELVET THUNDER', '3'),
]
N_LIV = len(LIVERIES)


def _to_metres(g):
    """model units (z up, x along the truck, front at +x) to metres (y up, x forward)"""
    P4 = g['meshes']['Object_4'][0]['P']
    s = 2.59 / (P4[:, 1].max() - P4[:, 1].min())
    allP = np.concatenate([p['P'] for k, ps in g['meshes'].items() for p in ps if OBJECTS.get(k)])
    xc = (allP[:, 0].min() + allP[:, 0].max()) / 2; yc = (allP[:, 1].min() + allP[:, 1].max()) / 2
    def conv(P): return np.c_[(P[:, 0] - xc) * s, P[:, 2] * s, -(P[:, 1] - yc) * s]
    def convn(N): return np.c_[N[:, 0], N[:, 2], -N[:, 1]]
    return conv, convn, s


def _face_normals(P, I):
    T = P[I]; n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    return n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)


def _trailer(P, N, U, I):
    """split the trailer: the box gets the livery atlas (unshared vertices, planar coordinates), the rest keeps its own"""
    T = P[I]; C = T.mean(1); fn = _face_normals(P, I)
    box = C[:, 1] > 1.2
    x0, x1 = P[:, 0].min(), P[:, 0].max(); y0, y1 = 1.05, P[:, 1].max(); z0, z1 = P[:, 2].min(), P[:, 2].max()
    Pb = T[box].reshape(-1, 3); Nb = np.repeat(fn[box], 3, 0); Ub = np.zeros((len(Pb), 2))
    f = fn[box]; side = np.repeat(np.where(np.abs(f[:, 2]) > 0.6, np.sign(f[:, 2]), 0), 3)
    top = np.repeat(f[:, 1] > 0.6, 3); end = np.repeat((np.abs(f[:, 0]) > 0.6) & (np.abs(f[:, 2]) <= 0.6), 3)
    other = ~(top | end) & (side == 0)
    side[other] = np.where(Pb[other, 2] >= 0, 1, -1)
    ux = (Pb[:, 0] - x0) / (x1 - x0); vy = np.clip((y1 - Pb[:, 1]) / (y1 - y0), 0, 1)
    # atlas rows (v down): 0-0.39 side +z (front at the right), 0.39-0.78 side -z (front at the left), roof, ends
    plus = (side > 0) & ~top & ~end; minus = (side < 0) & ~top & ~end
    Ub[plus] = np.c_[ux[plus], vy[plus] * 0.39]
    Ub[minus] = np.c_[1 - ux[minus], 0.39 + vy[minus] * 0.39]
    Ub[top] = np.c_[ux[top], 0.79 + (Pb[top, 2] - z0) / (z1 - z0) * 0.1]
    Ub[end] = np.c_[0.02 + (Pb[end, 2] - z0) / (z1 - z0) * 0.46 + np.where(Pb[end, 0] > (x0 + x1) / 2, 0.5, 0), 0.9 + vy[end] * 0.1]
    Ib = np.arange(len(Pb)).reshape(-1, 3)
    lo = ~box
    return (Pb, Nb, Ub, Ib), (P, N, U, I[lo])


def livery_image(k, W=512, H=512):
    base, stripe, pin, letter, name, num = LIVERIES[k]
    c = lambda t: tuple(int(255 * v) for v in t)
    img = Image.new('RGB', (W, H), c(base)); d = ImageDraw.Draw(img)
    sh = int(H * 0.39)                                                  # one side panel: W x sh, front at the right
    def side(y0, mirror):
        S = Image.new('RGB', (W, sh), c(base)); sd = ImageDraw.Draw(S)
        # a sweeping band from low at the rear to high at the front, a pinstripe along its edge
        pts = [(0, sh * 0.78), (W * 0.45, sh * 0.62), (W, sh * 0.18), (W, sh * 0.42), (W * 0.5, sh * 0.8), (0, sh * 0.95)]
        sd.polygon(pts, fill=c(stripe))
        sd.line([(0, sh * 0.74), (W * 0.45, sh * 0.58), (W, sh * 0.13)], fill=c(pin), width=4)
        sd.line([(0, sh * 0.99), (W * 0.5, sh * 0.84), (W, sh * 0.46)], fill=c(pin), width=3)
        sd.rectangle([0, sh * 0.93, W, sh], fill=tuple(int(v * 0.55) for v in c(base)))       # skirt
        if mirror: S = S.transpose(Image.FLIP_LEFT_RIGHT)
        sd = ImageDraw.Draw(S)
        # lettering (never mirrored): team name, number roundel near the front
        fn = ImageFont.truetype(FONT_C, int(sh * 0.2))
        tw = sd.textlength(name, font=fn)
        if tw > W * 0.62: fn = ImageFont.truetype(FONT_C, int(sh * 0.2 * W * 0.62 / tw)); tw = sd.textlength(name, font=fn)
        tx = W * 0.08 if not mirror else W * 0.92 - tw
        sd.text((tx, sh * 0.2), name, font=fn, fill=c(letter), stroke_width=2, stroke_fill=c(pin))
        r = sh * 0.24; cx = W * 0.83 if not mirror else W * 0.17; cy = sh * 0.52
        sd.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(250, 250, 250), outline=c(pin), width=4)
        fnum = ImageFont.truetype(FONT, int(r * 1.25))
        nw = sd.textlength(num, font=fnum)
        sd.text((cx - nw / 2, cy - r * 0.78), num, font=fnum, fill=(15, 15, 18))
        fs = ImageFont.truetype(FONT, int(sh * 0.07))
        sd.text((W * 0.08 if not mirror else W * 0.55, sh * 0.48), 'RACE TEAM TRANSPORT', font=fs, fill=c(letter))
        img.paste(S, (0, y0))
    side(0, False); side(sh, True)
    # roof: plain, a little lighter; ends: base with a stripe and the number
    d.rectangle([0, int(H * 0.78), W, int(H * 0.9)], fill=tuple(min(255, int(v * 0.9 + 25)) for v in c(base)))
    d.rectangle([0, int(H * 0.9), W, H], fill=c(base))
    for x0 in (0, W // 2):
        d.rectangle([x0 + W * 0.02, H * 0.955, x0 + W * 0.48, H * 0.975], fill=c(stripe))
        d.line([(x0 + W * 0.25, H * 0.905), (x0 + W * 0.25, H * 0.995)], fill=(30, 30, 30), width=2)   # the doors' seam
    img = img.filter(ImageFilter.UnsharpMask(1.2, 60, 2))
    # a little grime and panel texture so it isn't flat
    rng = np.random.default_rng(k)
    a = np.asarray(img).astype(np.float32)
    a *= (1 + rng.normal(0, 0.025, (H, W, 1))).astype(np.float32)
    seams = (np.arange(W) % 64 < 1)[None, :, None]
    a[:int(H * 0.78)] *= np.where(seams, 0.85, 1.0)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def cab_image(src, k):
    """repaint the white bodywork of a cab texture in the livery's base colour, keeping its shading"""
    a = np.asarray(src.convert('RGB')).astype(np.float32) / 255
    mx = a.max(2); mn = a.min(2); sat = (mx - mn) / np.maximum(mx, 1e-3)
    paint = np.clip((mx - 0.55) / 0.25, 0, 1) * np.clip((0.18 - sat) / 0.1, 0, 1)
    base = np.array(LIVERIES[k][0], np.float32)
    shade = np.clip(mx / 0.92, 0, 1.1)[..., None]
    out = a * (1 - paint[..., None]) + (base * shade) * paint[..., None]
    img = Image.fromarray(np.clip(out * 255, 0, 255).astype(np.uint8))
    return ImageEnhance.Sharpness(img).enhance(1.4)


def _simplify_pos(meshes):
    """meshoptimizer on positions alone (SurfaceTool.generate_lod via simplify.gd): [(P, I, target)] -> index lists"""
    import struct, subprocess, tempfile, shutil
    tmp = tempfile.mkdtemp(prefix='hlsimp')
    with open(os.path.join(tmp, 'in.bin'), 'wb') as fo:
        fo.write(b'SIMI' + struct.pack('<I', len(meshes)))
        for P, I, t in meshes:
            fo.write(struct.pack('<IIIf', len(P), I.size, t, 1e6)); fo.write(P.astype('<f4').tobytes()); fo.write(I.astype('<u4').tobytes())
    open(os.path.join(tmp, 'project.godot'), 'w').write('config_version=5\n')
    shutil.copy(os.path.join(HERE, 'simplify.gd'), tmp)
    r = subprocess.run([kit.GODOT, '--headless', '--path', tmp, '--script', 'res://simplify.gd', '--', tmp + '/in.bin', tmp + '/out.bin'],
                       capture_output=True, text=True, timeout=1200)
    if r.returncode: print(r.stdout[-1500:], r.stderr[-1500:]); raise SystemExit('hauler: simplify failed')
    d = open(tmp + '/out.bin', 'rb').read(); o = 8; out = []
    for _ in meshes:
        (n,) = struct.unpack('<I', d[o:o + 4]); out.append(np.frombuffer(d[o + 4:o + 4 + n * 4], '<u4').astype(np.int64).reshape(-1, 3)); o += 4 + n * 4
    shutil.rmtree(tmp)
    return out


def _wheels(P, I):
    """wheels from a wheel mesh: its big loose pieces (the tyres) grouped by axle and side -> [(x, z, half width)], radius"""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    k = np.round(P * 500).astype(np.int64); _, first, inv = np.unique(k, axis=0, return_index=True, return_inverse=True); inv = inv.ravel()
    Pw = P[first]; Iw = inv[I]
    e = np.r_[Iw[:, [0, 1]], Iw[:, [1, 2]], Iw[:, [2, 0]]]
    nc, lab = connected_components(coo_matrix((np.ones(len(e)), (e[:, 0], e[:, 1])), shape=(len(Pw), len(Pw))), directed=False)
    tyres = []
    for c in range(nc):
        Q = Pw[lab == c]
        if len(Q) >= 100 and Q[:, 1].max() - Q[:, 1].min() > 0.8: tyres.append(Q)
    r = max(Q[:, 1].max() for Q in tyres) / 2
    groups = []
    for Q in tyres:
        x = (Q[:, 0].min() + Q[:, 0].max()) / 2; sd = np.sign(Q[:, 2].mean())
        for gp in groups:
            if abs(gp['x'] - x) < 0.3 and gp['sd'] == sd: gp['z0'] = min(gp['z0'], Q[:, 2].min()); gp['z1'] = max(gp['z1'], Q[:, 2].max()); break
        else: groups.append(dict(x=x, sd=sd, z0=Q[:, 2].min(), z1=Q[:, 2].max()))
    return [(gp['x'], (gp['z0'] + gp['z1']) / 2, (gp['z1'] - gp['z0']) / 2) for gp in groups], r


def _wheel_mesh(cx, cz, hw, r, n=10):
    """a cylinder across z: tread round the outside (the texture's tread strip), a face on each side (its wheel)"""
    a = np.linspace(0, 2 * np.pi, n + 1)
    P, N, U, I = [], [], [], []
    for side in (-1, 1):                                   # tread: two rings of n+1
        for t in a: P.append((cx + r * np.cos(t), r + r * np.sin(t), cz + side * hw)); N.append((np.cos(t), np.sin(t), 0)); U.append((0.03 if side < 0 else 0.12, t / (2 * np.pi)))
    for i in range(n):
        I += [[i, i + 1, n + 1 + i], [i + 1, n + 2 + i, n + 1 + i]]
    for side in (-1, 1):                                   # faces: a fan
        c0 = len(P); P.append((cx, r, cz + side * hw)); N.append((0, 0, side)); U.append((0.594, 0.625))
        for t in a[:-1]:
            P.append((cx + r * np.cos(t), r + r * np.sin(t), cz + side * hw)); N.append((0, 0, side))
            U.append((0.594 + 0.37 * np.cos(t), 0.625 - 0.37 * np.sin(t)))
        for i in range(n):
            j = c0 + 1 + i; k = c0 + 1 + (i + 1) % n
            I.append([c0, j, k] if side > 0 else [c0, k, j])
    return np.array(P), np.array(N, float), np.array(U), np.array(I)


def build_cache():
    g = glb.load(GLB)
    conv, convn, s = _to_metres(g)
    parts, src = [], []
    for name, spec in OBJECTS.items():
        if spec is None: continue
        p = g['meshes'][name][0]
        P = conv(p['P']); N = convn(p['N']) if p['N'] is not None else np.tile([0, 1, 0], (len(P), 1)); U = p['U']; I = p['I']
        P, N, U, I = kit._weld(P, N, U, I)
        parts.append((name, spec)); src.append((P, N, U, I))
    lods = iter(kit._simplify([x for (n, sp), x in zip(parts, src) if sp[2] == 'attr']))
    posw = []
    for (n, sp), (P, N, U, I) in zip(parts, src):
        if sp[2] != 'pos': continue
        k = np.round(P * 2000).astype(np.int64); _, first, inv = np.unique(k, axis=0, return_index=True, return_inverse=True)
        posw.append((P, first, inv.ravel()[I], sp[0]))
    pres = iter(_simplify_pos([(P[f], I2, t) for P, f, I2, t in posw]))
    posw = iter(posw)
    data = {}; total = 0
    for (name, (budget, grp, how)), (P, N, U, I) in zip(parts, src):
        if how == 'wheels':
            W, r = _wheels(P, I)
            Ps, Ns, Us, Is = [], [], [], []; base = 0
            for cx, cz, hw in W:
                a, b, c, d = _wheel_mesh(cx, cz, hw, r)
                Ps.append(a); Ns.append(b); Us.append(c); Is.append(d + base); base += len(a)
            key = f'{grp}__{name}'
            data[f'{key}_P'] = np.concatenate(Ps); data[f'{key}_N'] = np.concatenate(Ns); data[f'{key}_U'] = np.concatenate(Us); data[f'{key}_I'] = np.concatenate(Is)
            total += len(data[f'{key}_I']); print(f'  hauler {name:10s} {grp:10s} {len(I):5d} -> {len(data[key + "_I"]):4d} triangles ({len(W)} wheels)')
            continue
        if how == 'pos':
            P0, first, Iw, t = next(posw); best_w = next(pres)
            best = first[best_w]                                 # each welded corner takes one of its original vertices
            used = np.unique(best); remap = -np.ones(len(P), np.int64); remap[used] = np.arange(len(used))
            key = f'{grp}__{name}'
            from geom import smooth_normals
            Pk = P[used]; Ik = remap[best]
            data[f'{key}_P'] = Pk; data[f'{key}_N'] = smooth_normals(Pk, Ik); data[f'{key}_U'] = U[used]; data[f'{key}_I'] = Ik
            total += len(Ik); print(f'  hauler {name:10s} {grp:10s} {len(I):5d} -> {len(Ik):4d} triangles (positions)')
            continue
        if how == 'keep':                                   # the trailer: no simplifying, new coordinates for the box
            (Pb, Nb, Ub, Ib), (Pl, Nl, Ul, Il) = _trailer(P, N, U, I)
            for key, arr in (('box', (Pb, Nb, Ub, Ib)), ('trailer_lo', (Pl, Nl, Ul, Il))):
                Pk, Nk, Uk, Ik = arr
                used = np.unique(Ik); remap = -np.ones(len(Pk), np.int64); remap[used] = np.arange(len(used))
                data[f'{key}_P'] = Pk[used]; data[f'{key}_N'] = Nk[used]; data[f'{key}_U'] = Uk[used]; data[f'{key}_I'] = remap[Ik]
                total += len(Ik); print(f'  hauler {key:10s} {len(Ik):5d} triangles')
            continue
        L = next(lods)
        best = I
        for size, ix in L:
            if len(ix) <= budget: best = ix; break
        else:
            if L: best = L[-1][1]
        used = np.unique(best); remap = -np.ones(len(P), np.int64); remap[used] = np.arange(len(used))
        key = f'{grp}__{name}'
        data[f'{key}_P'] = P[used]; data[f'{key}_N'] = N[used]; data[f'{key}_U'] = U[used]; data[f'{key}_I'] = remap[best]
        total += len(best); print(f'  hauler {name:10s} {grp:10s} {len(I):5d} -> {len(best):4d} triangles')
    print(f'  hauler total {total} triangles')
    imgs = [Image.open(io.BytesIO(b)) for b in g['images']]
    for grp, i in IMG.items():
        im = imgs[i].convert('RGB')
        if grp in ('cab', 'cab_trim'):
            for k in range(N_LIV): data[f'tex_{grp}_{k}'] = np.asarray(cab_image(im.resize((512, 512), Image.LANCZOS), k))
            continue
        if grp == 'trailer_lo': im = ImageEnhance.Sharpness(im.resize((512, 512), Image.LANCZOS)).enhance(1.6)
        if grp in ('hl_wheel_f', 'hl_wheel_r'):     # the tyre maker's name on the sidewalls, blurred out
            a = np.asarray(im).copy(); bl = np.asarray(im.filter(ImageFilter.GaussianBlur(6)))
            yy, xx = np.mgrid[0:im.size[1], 0:im.size[0]]
            cx, cy = im.size[0] * 0.58, im.size[1] * 0.45; r = np.hypot(xx - cx, yy - cy) / im.size[0]
            ring = (r > 0.26) & (r < 0.38)
            a[ring] = bl[ring]; im = Image.fromarray(a)
        data[f'tex_{grp}'] = np.asarray(im.resize((min(512, im.size[0]), min(512, im.size[1])), Image.LANCZOS))
    for k in range(N_LIV): data[f'tex_box_{k}'] = np.asarray(livery_image(k))
    np.savez_compressed(CACHE, **data)


_c = None
def _cache():
    global _c
    if _c is None:
        if not os.path.exists(CACHE): build_cache()
        _c = dict(np.load(CACHE))
    return _c


def texture(key):
    a = _cache()['tex_' + key]
    return Image.fromarray(a)


def tex_keys():
    return [k[4:] for k in _cache() if k.startswith('tex_')]


def material_for(key, k):
    """the pack material for one part of a transporter with livery k"""
    grp = key.split('__')[0]
    if grp == 'box': return f'hl_box_{k}'
    if grp in ('cab', 'cab_trim'): return f'hl_{grp}_{k}'
    return grp if grp.startswith('hl_') else 'hl_' + grp


def place(mesh, x, y, z, yaw, k):
    c = _cache()
    keys = sorted({kk[:-2] for kk in c if kk.endswith('_P')})
    cy, sy = np.cos(yaw), np.sin(yaw)
    R = np.array([[cy, 0, -sy], [0, 1, 0], [sy, 0, cy]])          # local +x (the front) to (cos yaw, 0, sin yaw)
    for key in keys:
        P, N, U, I = c[key + '_P'], c[key + '_N'], c[key + '_U'], c[key + '_I']
        mesh.add(material_for(key, k % N_LIV), P @ R.T + [x, y, z], U, I, N=N @ R.T, phys=False)
    # collision: the whole rig as one box
    L, W = 23.4, 2.6
    fx, fz = cy, sy; rx, rz = -sy, cy
    corners = [(x + fx * a + rx * b, z + fz * a + rz * b) for a, b in ((L / 2, W / 2), (L / 2, -W / 2), (-L / 2, -W / 2), (-L / 2, W / 2))]
    for i in range(4): mesh.wall(corners[i], corners[(i + 1) % 4], y - 0.3, y + 4.2)


if __name__ == '__main__':
    if os.path.exists(CACHE): os.remove(CACHE)
    build_cache()
    for k in range(N_LIV): livery_image(k).save(f'/tmp/claude-0/-home-claude/a5a93881-17e7-5b59-ac0b-e6c73be3b830/scratchpad/livery{k}.png')
