"""The racing compound, laid out on an 8 km square (x east, z south, metres; the fence at +-3990).

In the middle, a Grand Prix circuit in three configurations (GP, International, National) wraps a banked oval;
the GP paddock sits behind its pits, with the drift track, drag strip and slalom pad close by. An endurance
circuit runs round the edge of the compound. The ring between them is left open for later. Tracks are fillet
paths (corner points with radii). Access roads never cross a track at grade: where they must, they bridge it."""
import numpy as np
from paths import fillet, smooth, frame, length

HALF = 3990.0                     # the perimeter fence

# ---------------------------------------------------------------- the oval (NASCAR style: wide, banked, an apron)
OVAL_C, OVAL_STRAIGHT, OVAL_R = (0.0, 0.0), 450.0, 190.0
OVAL_HALF, OVAL_APRON = 9.0, 12.0                # track 18 m wide; a 12 m apron inside it
OVAL_BANK_TURN, OVAL_BANK_STRAIGHT = 20.0, 5.0   # degrees
OVAL_GAP = (-55.0, 10.0)                          # the gate in the outside wall on the back stretch (x from, to)
OVAL_PIT_Z = OVAL_R - OVAL_HALF - OVAL_APRON - 2 - 6     # pit lane centre, inside the front stretch

# ---------------------------------------------------------------- the GP circuit: configurations share the main straight
_N = {  # corner points (x, z, fillet radius), clockwise on a map with z down
    'T1': (-640, 560, 55), 'N2': (-720, 250, 160), 'N3': (-560, 10, 120), 'N4': (-760, -300, 170), 'N5': (-620, -560, 70),
    'N6': (300, -480, 420), 'N7': (880, -560, 90), 'N8': (920, -200, 220), 'N9': (760, 90, 45), 'N10': (880, 200, 45),
    'N11': (1080, 430, 90), 'N12': (1060, 560, 70),
    # the GP's loop north, up the hill
    'E1': (-260, -650, 90), 'E2': (-420, -1100, 220), 'E3': (-140, -1530, 160), 'E4': (520, -1590, 210),
    'E5': (930, -1260, 36), 'E6': (560, -1020, 60), 'E7': (640, -740, 110),
    # the International's short cut across the loop
    'I1': (120, -1110, 160),
}
GP_CONFIGS = {
    'gp':  ['T1', 'N2', 'N3', 'N4', 'N5', 'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'N7', 'N8', 'N9', 'N10', 'N11', 'N12'],
    'int': ['T1', 'N2', 'N3', 'N4', 'N5', 'E1', 'E2', 'I1', 'E6', 'E7', 'N7', 'N8', 'N9', 'N10', 'N11', 'N12'],
    'nat': ['T1', 'N2', 'N3', 'N4', 'N5', 'N6', 'N7', 'N8', 'N9', 'N10', 'N11', 'N12'],
}
GP_NAMES = {'gp': 'Grand Prix', 'int': 'International', 'nat': 'National'}
GP_STRAIGHT_Z = 560.0
GP_START_X = 260.0                # start / finish line on the main straight (it runs west, -x)
PIT_Z = GP_STRAIGHT_Z + 24.0      # pit lane centre (south of the straight)

# ---------------------------------------------------------------- the drift track: wide and flowing
DRIFT_V = [(1350, 480, 60), (1760, 430, 95), (1870, 650, 55), (1650, 770, 70), (1830, 960, 65), (1480, 1040, 85),
           (1330, 830, 50), (1460, 650, 60)]
DRIFT_HALF = 9.0

# ---------------------------------------------------------------- the endurance circuit, round the edge
ENDURO_V = [
    (-2900, 3650, 420),                     # onto the start straight (it runs east)
    (2600, 3650, 450), (3500, 3250, 320), (3580, 2000, 1400), (3420, 820, 260), (3640, 380, 220),
    (3600, -1500, 1000), (3300, -2780, 300), (3640, -3250, 200), (2980, -3640, 380),
    (1000, -3540, 1600), (-180, -3700, 300), (-480, -3330, 140), (-860, -3640, 150),
    (-3150, -3600, 420), (-3640, -3000, 320), (-3480, -1000, 1100), (-3690, 600, 420), (-3380, 1220, 260),
    (-3650, 1820, 300), (-3600, 3000, 520),
]
ENDURO_START_X = 0.0
ENDURO_PIT_Z = 3650.0 - 24.0       # pit lane centre (north of the straight, inside the loop)

# ---------------------------------------------------------------- drag strip (cars run west, toward -x)
DRAG_Z = 1000.0
DRAG_X0, DRAG_X1 = -1150.0, -60.0       # the strip from the end of the shut-down to the staging end
DRAG_START = -200.0                     # start line; the finish 402.34 m on, at -602.34
DRAG_DIR = -1.0

# ---------------------------------------------------------------- pads (paved areas)
PADDOCK = dict(x0=-440, x1=840, z0=596, z1=790)            # GP paddock, behind the pit garages
OVAL_PAD = dict(x0=-200, x1=200, z0=-120, z1=130)          # oval infield paddock
SLALOM = dict(x0=-1260, x1=-800, z0=700, z1=930)           # slalom and skid pad
DRAG_PAD = dict(x0=-60, x1=90, z0=962, z1=1090)            # drag strip staging and paddock
DRIFT_PAD = dict(x0=1250, x1=1420, z0=1080, z1=1180)       # drift paddock
ENDURO_PAD = dict(x0=380, x1=1250, z0=3440, z1=3606)       # endurance paddock behind its pits
GATE_X = 200.0                                             # the gate road runs north from the fence here

# ---------------------------------------------------------------- service roads (open paths)
ROADS_V = {
    # main gate north to the GP paddock (bridging the endurance circuit's straight)
    'gate':      [(GATE_X, HALF + 60, 0), (GATE_X, 2400, 0), (GATE_X - 20, 1600, 900), (GATE_X, PADDOCK['z1'] - 10, 0)],
    'enduro_rd': [(GATE_X, 3380, 0), (300, 3390, 60), (ENDURO_PAD['x0'] + 10, 3480, 0)],
    'drag_rd':   [(GATE_X, 1030, 0), (DRAG_PAD['x1'] - 8, 1030, 0)],
    'slalom_rd': [(PADDOCK['x0'] + 10, 760, 0), (-650, 770, 80), (SLALOM['x1'] - 8, 800, 0)],
    'drift_rd':  [(PADDOCK['x1'] - 10, 760, 0), (1150, 820, 120), (1240, 1000, 80), (DRIFT_PAD['x0'] + 12, 1120, 0)],
    # to the GP infield: north along the east side of the circuit, over it on a bridge, on to the oval's gate
    'infield':   [(PADDOCK['x1'] - 10, 660, 0), (1175, 600, 160), (1190, -60, 200), (980, -110, 120), (560, -150, 140),
                  (430, -290, 110), (-25, -300, 70), (-25, -OVAL_R - OVAL_HALF + 2, 0)],
    # from the oval's apron into its infield paddock
    'oval_in':   [(-25, -OVAL_R + OVAL_HALF + OVAL_APRON - 6, 0), (-25, OVAL_PAD['z0'] + 8, 0)],
    # the drag strip's turn at the end of the shut-down and the return road back to the staging area
    'drag_turn':   [(DRAG_X0 + 10, DRAG_Z, 0), (DRAG_X0 - 60, DRAG_Z, 34), (DRAG_X0 - 60, DRAG_Z + 70, 34), (DRAG_X0 + 30, DRAG_Z + 70, 0)],
    'drag_return': [(DRAG_X0 + 30, DRAG_Z + 70, 0), (DRAG_PAD['x0'] + 8, DRAG_Z + 70, 0)],
}
DRAG_V = [(DRAG_X0, DRAG_Z, 0), (DRAG_X1 + 30, DRAG_Z, 0)]   # the strip (16 m: two lanes), into the staging pad


def oval_path(step=1.0):
    cx, cz = OVAL_C; L, R = OVAL_STRAIGHT, OVAL_R
    pts = []
    # front stretch (south) heading +x, the east turn (left, toward -z), back stretch heading -x, the west turn
    for x in np.arange(cx - L / 2, cx + L / 2, step): pts.append((x, cz + R))
    for a in np.arange(np.pi / 2, -np.pi / 2, -step / R): pts.append((cx + L / 2 + R * np.cos(a), cz + R * np.sin(a)))
    for x in np.arange(cx + L / 2, cx - L / 2, -step): pts.append((x, cz - R))
    for a in np.arange(-np.pi / 2, -3 * np.pi / 2, -step / R): pts.append((cx - L / 2 + R * np.cos(a), cz + R * np.sin(a)))
    return np.array(pts)


def roll_to(P, x, z):
    """a closed path started at the point nearest (x, z)"""
    i = int(np.argmin(np.hypot(P[:, 0] - x, P[:, 1] - z)))
    return np.roll(P, -i, axis=0)


def gp_path(cfg):
    return roll_to(smooth(fillet([_N[k] for k in GP_CONFIGS[cfg]], True), 6, True), GP_START_X, GP_STRAIGHT_Z)


def pit_lane():
    # in after the last corner (it leaves the straight on its left: the south side), out before T1
    V = [(960, GP_STRAIGHT_Z, 0), (800, PIT_Z, 300), (-420, PIT_Z, 300), (-580, GP_STRAIGHT_Z, 0)]
    return smooth(fillet(V, False), 6, False)


def oval_pit():
    # off the apron at the start of the front stretch, along it inside the apron, back onto the apron at its end
    a = OVAL_R - OVAL_HALF - OVAL_APRON / 2
    V = [(-OVAL_STRAIGHT / 2 + 10, a, 0), (-120, OVAL_PIT_Z, 80), (120, OVAL_PIT_Z, 80), (OVAL_STRAIGHT / 2 - 10, a, 0)]
    return smooth(fillet(V, False), 5, False)


def enduro_pit():
    V = [(240, 3650, 0), (420, ENDURO_PIT_Z, 300), (1240, ENDURO_PIT_Z, 300), (1440, 3650, 0)]
    return smooth(fillet(V, False), 6, False)


def link_part(P, ref, overlap=30):
    """the part of closed path P that leaves path ref, with `overlap` points of the shared path at each end"""
    from scipy.spatial import cKDTree
    d, _ = cKDTree(ref).query(P)
    off = d > 0.6                                              # (ref is sampled every metre)
    if not off.any(): return None
    n = len(P)
    sh = int(np.argmin(off))                                   # start on a shared point
    o = np.roll(off, -sh)
    i0 = int(np.argmax(o)); i1 = n - 1 - int(np.argmax(o[::-1]))
    idx = (np.arange(i0 - overlap, i1 + overlap + 1) + sh) % n
    return P[idx]


def build():
    gp = {c: gp_path(c) for c in GP_CONFIGS}
    oval = smooth(oval_path(), 30, True)
    oval = roll_to(oval, -OVAL_STRAIGHT / 2 + 40, OVAL_R)        # the line early on the front stretch
    drift = smooth(fillet(DRIFT_V, True), 6, True)
    drift = roll_to(drift, 1550, 470)
    enduro = roll_to(smooth(fillet(ENDURO_V, True), 10, True), ENDURO_START_X, 3650)
    roads = {k: smooth(fillet(v, False), 8, False) for k, v in ROADS_V.items()}
    for k, parent in (('drag_rd', 'gate'), ('enduro_rd', 'gate')):     # branches start on their road's real line
        V = list(ROADS_V[k]); P = roads[parent]
        j = int(np.argmin(np.hypot(P[:, 0] - V[0][0], P[:, 1] - V[0][1])))
        V[0] = (float(P[j, 0]), float(P[j, 1]), 0)
        roads[k] = smooth(fillet(V, False), 8, False)
    links = {c: link_part(gp[c], gp['gp']) for c in ('int', 'nat')}
    drag = fillet(DRAG_V, False)
    return dict(gp=gp, links=links, oval=oval, drift=drift, enduro=enduro, roads=roads, pit=pit_lane(),
                oval_pit=oval_pit(), enduro_pit=enduro_pit(), drag=drag)


PADS = dict(paddock=PADDOCK, oval=OVAL_PAD, slalom=SLALOM, drag=DRAG_PAD, drift=DRIFT_PAD, enduro=ENDURO_PAD)

if __name__ == '__main__':
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    L = build()
    for c, P in L['gp'].items(): print(c, round(length(P, True)), 'm')
    for k in ('oval', 'drift', 'enduro'): print(k, round(length(L[k], True)), 'm')
    for k, P in L['links'].items(): print('link', k, round(length(P, False)), 'm')
    fig, axs = plt.subplots(1, 2, figsize=(22, 11))
    for ax, lim in ((axs[0], 4100), (axs[1], None)):
        for c, col in (('gp', 'r'), ('int', 'm'), ('nat', 'b')):
            P = L['gp'][c]; ax.plot(np.r_[P[:, 0], P[0, 0]], np.r_[P[:, 1], P[0, 1]], col + '-', lw=1.5 if c == 'gp' else 1)
        for k in ('oval', 'drift', 'enduro'):
            P = L[k]; ax.plot(np.r_[P[:, 0], P[0, 0]], np.r_[P[:, 1], P[0, 1]], 'k-', lw=1.5)
        for k, P in L['roads'].items(): ax.plot(P[:, 0], P[:, 1], 'g-', lw=1)
        for k in ('pit', 'oval_pit', 'enduro_pit', 'drag'): ax.plot(L[k][:, 0], L[k][:, 1], 'c-', lw=1)
        for k, r in PADS.items(): ax.add_patch(plt.Rectangle((r['x0'], r['z0']), r['x1'] - r['x0'], r['z1'] - r['z0'], color='orange', alpha=0.5))
        ax.plot(*L['gp']['gp'][0], 'ro')
        ax.add_patch(plt.Rectangle((-HALF, -HALF), 2 * HALF, 2 * HALF, fill=False, ls='--'))
        ax.set_aspect('equal'); ax.grid(True)
        if lim: ax.set_xlim(-lim, lim); ax.set_ylim(lim, -lim)
        else: ax.set_xlim(-1400, 2000); ax.set_ylim(1300, -1750)
    fig.savefig('layout.png', dpi=55)
