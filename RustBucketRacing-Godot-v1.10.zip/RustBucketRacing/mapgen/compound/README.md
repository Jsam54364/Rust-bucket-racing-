# The Motorsport Compound generator

Builds `compound.bin` and `compound.json` (the installable map) from scratch: layout, heights, ground, roads,
kerbs, run-off, barriers, buildings, trees and the scenery beyond the fence. Not part of the game build
(`mapgen/.gdignore` keeps Godot out of this folder).

Needs Python 3 with numpy, scipy, Pillow (webp) and matplotlib, Godot 4.7 (set `GODOT` to its binary: it simplifies
meshes and makes the LODs headless, and renders the barrier pictures under `xvfb-run`), and two models from Sketchfab
(CC BY 4.0) next to the scripts: `race_track_assets_pack.glb` ("Race Track Assets Pack" by Cherk) and
`dav_nascar_hauler.glb` ("DAV NASCAR Hauler" by jairobman).

    python3 extract_textures.py <folder with spa.bin, mcr.bin, iroha.bin>   # the borrowed textures -> tex_src/
    GODOT=/path/to/godot python3 gen.py compound.bin                         # ~1.5 min: compound.bin + compound.json
    python3 check_phys.py compound.bin                                       # holes and steps in the drive surface

- `layout.py`: where everything goes: the GP's corners and its three configurations, the oval, drift track, endurance
  circuit, drag strip, pads, service roads
- `terrain.py`: the heightfield, each road's height profile (the GP's designed corner heights; grade-limited, levelled
  at junctions and pads), the oval's banked cross-section, bridges where a service road crosses a track, cut and fill
- `tin.py`: the ground as one triangulation, dense near the roads, edged by a rounded square
- `trackgen.py`: road surfaces, kerbs placed the way Spa-Francorchamps has them, gravel traps, tyre walls, Armco, lines, grid
- `objects.py`: pits, paddocks, stands, transporters, tents, gate, fences, trees, and the far hills and mountains
- `kit.py`, `bake.gd`, `simplify.gd`: the assets pack simplified, and its barriers rendered to pictures for strips
- `hauler.py`, `glb.py`: the transporter simplified (its wheels rebuilt as cylinders, the sponsor's logo left off), its
  trailer given new texture coordinates and six liveries drawn here, the cab repainted to match
- `writer.py`: the RBMP v2 pack (chunks, LODs, walls, the extra map data the game reads from 1.9; course groups from 1.10)
