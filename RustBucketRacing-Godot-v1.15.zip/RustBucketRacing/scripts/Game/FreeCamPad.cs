// The free camera's own controls, alone on the screen while it flies (the driving controls, the HUD and the
// buttons are hidden): a joystick in the bottom-left corner to fly (up forward along the view, down back, sideways to
// slide), a drag anywhere else to look round, a speed button (slow, fast, super) and a button back to the car.
using System;
using System.Collections.Generic;
using Godot;

namespace RustBucket.Game
{
    public partial class FreeCamPad : Control
    {
        public static readonly string[] SpeedNames = { "SLOW", "FAST", "SUPER" };
        public static readonly double[] Speeds = { 4, 18, 70 };      // metres a second, full stick

        public Vector2 Stick;          // -1..1: x right, y forward
        public int Speed = 1;
        public Action<Vector2> Look;   // drag, in pixels
        public Action Exit;
        public float Safe;

        readonly Dictionary<int, int> owner = new Dictionary<int, int>();    // touch -> 1 stick, 2 look, 3 speed, 4 exit
        Rect2 stick, speedB, exitB;
        Vector2 knob, lastLook;
        float u = 120;

        public override void _Ready()
        {
            MouseFilter = MouseFilterEnum.Ignore;
            SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
        }

        void Layout()
        {
            var s = Size;
            u = Mathf.Clamp(0.17f * s.Y, 84, 132);
            float mx = 30 + Safe, my = 26;
            float d = u * 2.3f;
            stick = new Rect2(mx, s.Y - my - d, d, d);
            speedB = new Rect2(s.X - mx - u * 1.9f, s.Y - my - u * 0.95f, u * 1.9f, u * 0.95f);
            exitB = new Rect2(s.X - mx - u * 1.9f, 22, u * 1.9f, u * 0.7f);
        }

        int Hit(Vector2 p)
        {
            if (p.DistanceTo(stick.GetCenter()) <= stick.Size.X / 2 + 30) return 1;
            if (speedB.Grow(12).HasPoint(p)) return 3;
            if (exitB.Grow(12).HasPoint(p)) return 4;
            return 2;
        }

        public override void _Input(InputEvent e)
        {
            if (!Visible) return;
            if (e is InputEventScreenTouch t)
            {
                Layout();
                if (t.Pressed)
                {
                    int z = Hit(t.Position);
                    if (z == 1 && owner.ContainsValue(1)) z = 2;
                    owner[t.Index] = z;
                    if (z == 1) SetStick(t.Position);
                    else if (z == 2) lastLook = t.Position;
                }
                else if (owner.TryGetValue(t.Index, out int z))
                {
                    owner.Remove(t.Index);
                    if (z == 1) { Stick = Vector2.Zero; knob = Vector2.Zero; }
                    else if (z == 3 && speedB.Grow(12).HasPoint(t.Position)) { Speed = (Speed + 1) % Speeds.Length; Buzz(); }
                    else if (z == 4 && exitB.Grow(12).HasPoint(t.Position)) Exit?.Invoke();
                }
                GetViewport().SetInputAsHandled();
                QueueRedraw();
            }
            else if (e is InputEventScreenDrag dr && owner.TryGetValue(dr.Index, out int zd))
            {
                if (zd == 1) SetStick(dr.Position);
                else if (zd == 2) { Look?.Invoke(dr.Position - lastLook); lastLook = dr.Position; }
                GetViewport().SetInputAsHandled();
                QueueRedraw();
            }
        }

        void SetStick(Vector2 p)
        {
            float r = stick.Size.X / 2;
            var v = p - stick.GetCenter();
            if (v.Length() > r) v = v.Normalized() * r;
            knob = v;
            var n = v / r;
            float l = n.Length(); const float dz = 0.08f;
            n = l < dz ? Vector2.Zero : n * ((l - dz) / (1 - dz) / l);
            Stick = new Vector2(n.X, -n.Y);
        }

        public void ReleaseAll() { owner.Clear(); Stick = Vector2.Zero; knob = Vector2.Zero; QueueRedraw(); }

        void Buzz() { try { Godot.Input.VibrateHandheld(12); } catch (Exception) { } }

        static readonly Color Fill = new Color(10 / 255f, 13 / 255f, 17 / 255f, 0.32f);
        static readonly Color Edge = new Color(1, 1, 1, 0.45f);

        void Label(string s, Vector2 center, int size, Color col, Font f = null)
        {
            f ??= Ui.Display;
            var sz = f.GetStringSize(s, HorizontalAlignment.Left, -1, size);
            DrawString(f, new Vector2(center.X - sz.X / 2, center.Y + size * 0.36f), s, HorizontalAlignment.Left, -1, size, col);
        }

        public override void _Draw()
        {
            Layout();
            bool held = owner.ContainsValue(1);
            var c = stick.GetCenter(); float r = stick.Size.X / 2;
            DrawCircle(c, r, Fill);
            DrawArc(c, r - 1.25f, 0, Mathf.Tau, 72, held ? Ui.Amber : Edge, 2.5f, true);
            // four ticks: forward, back, the sides
            for (int k = 0; k < 4; k++)
            {
                var dir = Vector2.FromAngle(k * Mathf.Pi / 2);
                DrawLine(c + dir * (r - 22), c + dir * (r - 10), new Color(1, 1, 1, 0.6f), 3);
            }
            DrawCircle(c + knob, u * 0.42f, held ? new Color(Ui.Amber, 0.85f) : new Color(1, 1, 1, 0.22f));
            DrawArc(c + knob, u * 0.42f - 1.25f, 0, Mathf.Tau, 48, held ? Ui.Amber : new Color(1, 1, 1, 0.8f), 2.5f, true);
            // speed
            var sb = Ui.Cached(Fill, (int)(speedB.Size.Y / 2), Speed == 2 ? Ui.Amber : Edge, 2);
            DrawStyleBox(sb, speedB);
            Label(SpeedNames[Speed], speedB.GetCenter() + new Vector2(0, -8), (int)(u * 0.26f), Speed == 2 ? Ui.Amber : Colors.White);
            Label("speed", speedB.GetCenter() + new Vector2(0, u * 0.22f), 15, Ui.Muted, Ui.Body);
            // back to the car
            DrawStyleBox(Ui.Cached(Fill, (int)(exitB.Size.Y / 2), Edge, 2), exitB);
            Label("BACK TO CAR", exitB.GetCenter(), (int)(u * 0.17f), Colors.White);
        }
    }
}
