"""The horizon round Mt. Haruna: the land from 12 km out to 90 km (the Kanto plain, Mt. Akagi, Komochi and
Onoko, the Tanigawa and Asama ranges), seen from the middle of the route, drawn from GSI's 10 m elevation (as
120 m cells) and aerial photos (出典：国土地理院), hazed with distance, the sky left clear.

It is drawn as it would show on a ring of cards RING metres from the middle at heights Y_BOT..Y_TOP, in NSEG
pieces of 512 x 256 px (two to a texture layer). Every column is a bearing; down a column, the ray from the eye
through that height on the ring is followed over the ground (the earth's curve and the air's refraction included)
until it meets the ground; the photo's colour there, hazed by the distance, is the pixel."""
import math
import numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates
import source as S
import gsi

R0, RMAX = 12000.0, 90000.0
RING = 13500.0
Y_BOT, Y_TOP = -300.0, 2900.0
NSEG, SW, SH = 16, 512, 256
CLEAR = 10                   # rows of sky at the top of each piece left off its card
EARTH = 6371000.0 / (1 - 0.13)          # the curve, less refraction


def centre():
    c = (S.line.min(0) + S.line.max(0)) / 2
    return float(c[0]), float(c[1]), float(np.median(S.ly)) + 4.0


def horizon_grid():
    return S._grid('horizon', -RMAX - 2000, -RMAX - 2000, RMAX + 2000, RMAX + 2000, 150.0, [('dem_png', 10), ('dem_png', 9)])


def render(haze_lin, fog, far_fog=0.45, far_gain=0.92, far_haze_k=0.3, ss=2):
    """the panorama's pieces (RGBA images), as the backdrop shader (world_far) will show them: it mixes far_haze_k of
    the sky's haze in and scales the rest by far_gain, so the pieces carry the rest of the haze themselves"""
    cx, cz, ey = centre()
    G = horizon_grid()
    S.log(f'panorama: eye at ({cx:.0f}, {ey:.0f}, {cz:.0f}), ring {RING / 1000:.1f} km, ground {G.nx}x{G.nz} cells of {G.res:.0f} m')
    W = NSEG * SW
    az = (np.arange(W) + 0.5) / W * 2 * np.pi                 # bearing: 0 along +x, turning towards +z
    d = np.geomspace(R0, RMAX, 900)
    X = cx + np.cos(az)[:, None] * d[None, :]; Z = cz + np.sin(az)[:, None] * d[None, :]
    h = G(X, Z) - d[None, :] ** 2 / (2 * EARTH)
    slope = (h - ey) / d[None, :]
    run = np.maximum.accumulate(slope, axis=1)                # what the ray clears so far, along each bearing
    # rows: heights on the ring, top first, supersampled down the column
    H = SH * ss
    yv = Y_TOP - (np.arange(H) + 0.5) / H * (Y_TOP - Y_BOT)
    tana = (yv - ey) / RING
    # photos: 50 m near, 120 m beyond 40 km
    lat0, lon0 = S.to_ll(cx + RMAX, cz + RMAX); lat1, lon1 = S.to_ll(cx - RMAX, cz - RMAX)
    near = gsi.Mosaic('seamlessphoto', 11, 'jpg', *S.to_ll(cx - 42000, cz + 42000), *S.to_ll(cx + 42000, cz - 42000))
    far = gsi.Mosaic('seamlessphoto', 10, 'jpg', float(lat0), float(lon1), float(lat1), float(lon0))
    out = np.zeros((H, W, 4), np.float32)
    lin = lambda c: np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
    for c0 in range(0, W, 512):
        c1 = min(W, c0 + 512)
        k = np.empty((c1 - c0, H), np.int64)
        for j in range(c0, c1):
            k[j - c0] = np.searchsorted(run[j], tana)          # the first sample at or above the ray
        hit = k < len(d)
        kk = np.minimum(k, len(d) - 1)
        jj = np.arange(c0, c1)[:, None].repeat(H, 1)
        hx, hz, hd = X[jj, kk], Z[jj, kk], d[kk]
        # rays already under the ground at R0: the nearer land the map itself draws stands in front of these; they
        # take the colour of the ground at R0 on their bearing (blurred along the ring), so nothing streaks there
        low = k == 0
        lat, lon = S.to_ll(hx, hz)
        col = np.zeros(hx.shape + (3,), np.float32)
        for m, sel in ((near, hd < 40000), (far, hd >= 40000)):
            if not sel.any(): continue
            px, py = m.px(lat[sel], lon[sel])
            col[sel] = np.stack([map_coordinates(m.a[..., ch].astype(np.float32), [py - 0.5, px - 0.5], order=1, mode='nearest') for ch in range(3)], -1)
        if low.any():
            from scipy.ndimage import uniform_filter1d
            ring = col[np.arange(c1 - c0), np.argmax(low, 1)]
            for _ in range(3): ring = uniform_filter1d(ring, 41, axis=0, mode='nearest')
            col[low] = np.broadcast_to(ring[:, None, :], col.shape)[low]
            hd[low] = R0
        c = np.clip((col / 255 - 0.06) / 0.9, 0, 1)
        # the low-zoom photos are from late winter: snow below the high peaks becomes the ground beside it
        hh = G(hx, hz)
        snow = (c.min(-1) > 0.55) & (hh < 1900)
        if snow.any(): c[snow] = c[snow] * 0.0 + np.array([0.30, 0.33, 0.27])
        c_lin = lin(c) * 0.9
        # as thick as the map's own fog out to R0, thinner beyond (so the far ranges still show)
        f = (1 - np.exp(-fog * np.minimum(hd, R0) - fog * far_fog * np.maximum(hd - R0, 0)))[..., None]
        want = c_lin * (1 - f) + np.array(haze_lin)[None, None] * f
        tex = np.clip((want - far_haze_k * np.array(haze_lin)) / ((1 - far_haze_k) * far_gain), 0, 1)
        out[:, c0:c1, :3] = np.transpose(tex * hit[..., None], (1, 0, 2))      # (premultiplied, for the averaging)
        out[:, c0:c1, 3] = hit.T
    # back down to size (the silhouette antialiased), to sRGB
    out = out.reshape(SH, ss, W, 4).mean(1)
    a = out[..., 3:4]
    c = out[..., :3] / np.maximum(a, 1e-3)
    rgb = np.where(c <= 0.0031308, c * 12.92, 1.055 * np.power(c, 1 / 2.4) - 0.055)
    img = (np.concatenate([np.clip(rgb, 0, 1), a], -1) * 255 + 0.5).astype(np.uint8)
    pieces = [Image.fromarray(img[:, i * SW:(i + 1) * SW], 'RGBA') for i in range(NSEG)]
    S.log(f'panorama: {NSEG} pieces; ground on {100 * (img[..., 3] > 127).mean():.0f}% of it')
    return pieces, img


def layers(pieces):
    """two pieces to a 512 x 512 layer, one above the other"""
    out = []
    for i in range(0, len(pieces), 2):
        L = Image.new('RGBA', (SW, 2 * SH)); L.paste(pieces[i], (0, 0)); L.paste(pieces[i + 1], (0, SH))
        # (each piece's top rows clear and left off the cards: the filtering would bleed the ground of the piece above
        # it, or of the layer's foot, into a dashed line across the sky)
        a = np.array(L); a[:CLEAR, :, 3] = 0; a[SH:SH + CLEAR, :, 3] = 0
        out.append(Image.fromarray(a))
    return out


def cards(mesh, quads_per_piece=4):
    """the ring: quads facing the middle, each showing its share of a piece"""
    from geom import quad
    cx, cz, ey = centre()
    n = NSEG * quads_per_piece
    for q in range(n):
        a0, a1 = 2 * np.pi * q / n, 2 * np.pi * (q + 1) / n
        A = (cx + RING * np.cos(a0), Y_BOT, cz + RING * np.sin(a0)); B = (cx + RING * np.cos(a1), Y_BOT, cz + RING * np.sin(a1))
        piece = q // quads_per_piece; sub = q % quads_per_piece
        u0, u1 = sub / quads_per_piece, (sub + 1) / quads_per_piece
        v0, v1 = (piece % 2) * 0.5 + CLEAR / (2 * SH), (piece % 2) * 0.5 + 0.5          # v 0 at the top of the layer
        top = Y_TOP - (Y_TOP - Y_BOT) * CLEAR / SH
        quad(mesh, f'pano_{piece // 2}', A, B, (B[0], top, B[2]), (A[0], top, A[2]),
             uv=((u0, v1), (u1, v1), (u1, v0), (u0, v0)), split=None)
