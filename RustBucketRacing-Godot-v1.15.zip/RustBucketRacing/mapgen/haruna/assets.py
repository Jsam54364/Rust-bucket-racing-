"""Textures and materials for Mt. Haruna.

  * the road, its gutters and verges, the walls and rock cuttings, the trees, the forest edge, bushes, reflector
    posts and a few road signs (sharp-bend chevrons, "sharp bends, slow down", winding road): textures from
    "Irohazaka Slope" (an Assetto Corsa track by sost and its original authors; free, credited), another Japanese
    mountain road, read from its KN5 ($IROHA_KN5)
  * the guardrail: drawn here
  * the ground beyond the verges, near and far: GSI's aerial photos (出典：国土地理院), resampled onto the map's plane
  * the horizon: a panorama of the land beyond 12 km, drawn here from GSI's elevation and photos (panorama.py)"""
import io, os, sys
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import map_coordinates

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(HERE, '..', 'iroha'))        # (for kn5 only: this folder's source.py comes first)
import kn5
import source as S
import gsi

KN5 = os.environ.get('IROHA_KN5', os.path.join(HERE, '..', 'iroha', 'sost_irohazaka.kn5'))
if not os.path.exists(KN5): KN5 = '/home/claude/game/iroha/sost_irohazaka.kn5'
_tex = None


def src(name, rgba=False):
    global _tex
    if _tex is None: _tex = {t['name']: t for t in kn5.load(KN5)[1]}
    im = Image.open(io.BytesIO(_tex[name]['data'])); im.load()
    return im.convert('RGBA' if rgba else 'RGB')


T_ASPHALT = 'image04178800_0931ef50.dds'
T_GUTTER = 'image0418b400_092e9c50.dds'
T_VERGE = 'image041b3000_092fb850.dds'
T_GRASS = 'image092f8e80_092faed0.dds'
T_KIKKO = 'image0418e800_09376bd0.dds'
T_STONES = 'image0418c000_09374a50.dds'
T_ROCK = 'image041c3c00_093728d0.dds'
T_ROCK2 = 'image041b7e00_09371750.dds'
T_TREES = ['image041a8800_0936bc50.dds', 'image0419e000_092fe5d0.dds', 'image041c4c00_0935b950.dds', 'image04196000_09363ad0.dds']
T_TREEFAR = 'image041a0800_093597d0.dds'
T_FOREST = 'image0417c800_092e5fd0.dds'
T_BUSH = 'image09329b80_0932dbd0.dds'
T_DELINEATOR = 'image04190800_0931a550.dds'
SIGNS = {'chevron': 'image0937b880_0937bad0.dds',       # the orange sharp-bend arrow (線形誘導標)
         'bends': 'image0930cf80_0930d3d0.dds',         # 急カーブ多し 速度落せ
         'winding': 'image092fc300_092fc450.dds',       # winding road ahead
         'slow': 'image0936ed00_0936f150.dds'}          # 速度落せ, use the engine brake


def tex_guardrail():
    """a Japanese guardrail seen from the road: a white W-beam on white posts, 4 m to the picture (two posts),
    1 m tall (v 0 at the top), clear round it"""
    W, H = 512, 128
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    px = lambda m: int(round(m / 4.0 * W))
    py = lambda m: int(round((1.0 - m) * H))
    for x0 in (0.15, 2.15):
        d.rectangle([px(x0), py(0.9), px(x0 + 0.14), py(0.0)], fill=(226, 228, 226, 255))
        d.rectangle([px(x0 + 0.1), py(0.9), px(x0 + 0.14), py(0.0)], fill=(186, 188, 186, 255))
    for y0, y1, c in ((0.60, 0.65, 200), (0.65, 0.72, 242), (0.72, 0.76, 205), (0.76, 0.80, 225), (0.80, 0.87, 246), (0.87, 0.92, 205)):
        d.rectangle([0, py(y1), W - 1, py(y0)], fill=(c, c, c - 3, 255))
    for x0 in (0.15, 2.15):
        for yb in (0.68, 0.84):
            d.ellipse([px(x0) - 2, py(yb) - 2, px(x0) + 6, py(yb) + 6], fill=(150, 150, 150, 255))
    a = np.asarray(im, np.float32)
    a[..., :3] *= 0.92 + 0.08 * np.random.default_rng(2).random((H, W, 1))
    return Image.fromarray(a.clip(0, 255).astype(np.uint8), 'RGBA')


def tex_facade(wall, frame, glass, seed):
    """a building's wall, one floor (3 m) high and 4 m across: two windows in it"""
    rng = np.random.default_rng(seed)
    W = H = 256
    a = np.ones((H, W, 3), np.float32) * np.array(wall, np.float32)
    a *= 0.94 + 0.06 * rng.random((H, W, 1))
    px = lambda m: int(round(m / 4.0 * W)); py = lambda m: int(round((1 - m / 3.0) * H))
    im = Image.fromarray(a.clip(0, 255).astype(np.uint8)); d = ImageDraw.Draw(im)
    for x0 in (0.45, 2.45):
        d.rectangle([px(x0) - 3, py(2.25) - 3, px(x0 + 1.1) + 3, py(0.95) + 3], fill=tuple(frame))
        d.rectangle([px(x0), py(2.25), px(x0 + 1.1), py(0.95)], fill=tuple(glass))
        d.line([px(x0 + 0.55), py(2.25), px(x0 + 0.55), py(0.95)], fill=tuple(frame), width=2)
    d.rectangle([0, py(0.12), W, py(0.0)], fill=tuple(int(c * 0.8) for c in wall))
    return im


def tex_regulatory(kind):
    """Japanese regulatory signs, drawn: a 30 km/h limit (blue figures in a red ring), no overtaking (a red ring
    and slash over two arrows), no parking (a red ring and slash on blue)"""
    from PIL import ImageFont
    S_ = 256
    im = Image.new('RGBA', (S_, S_), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    red, blue, white = (206, 28, 36, 255), (24, 74, 160, 255), (246, 246, 242, 255)
    d.ellipse([4, 4, S_ - 5, S_ - 5], fill=red)
    inner = blue if kind == 'nopark' else white
    d.ellipse([30, 30, S_ - 31, S_ - 31], fill=inner)
    if kind == '30':
        try: f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 112)
        except OSError: f = ImageFont.load_default()
        w = d.textlength('30', font=f); d.text(((S_ - w) / 2 - 2, 60), '30', fill=blue, font=f)
    elif kind == 'nopass':
        for x0, col in ((92, (30, 30, 30, 255)), (152, red)):
            d.polygon([(x0, 70), (x0 - 22, 104), (x0 - 9, 104), (x0 - 9, 190), (x0 + 9, 190), (x0 + 9, 104), (x0 + 22, 104)], fill=col)
        d.line([(62, 62), (194, 194)], fill=red, width=22)
    else:
        d.line([(60, 60), (196, 196)], fill=red, width=26)
    return im


def tex_solar():
    """solar panels, four deep across the row (v) and one wide (u, 1 m): blue-black cells, silver frames"""
    W, H = 64, 256
    a = np.zeros((H, W, 3), np.float32)
    a[:] = (150, 156, 162)                                  # (the frame)
    for k in range(4):
        y0 = k * 64
        for i in range(6):
            for j in range(10):
                cx0 = 3 + i * 10; cy0 = y0 + 3 + j * 6
                a[cy0:cy0 + 5, cx0:cx0 + 9] = (22, 32, 62)
    a[::64, :] = (180, 184, 188)
    return Image.fromarray(a.astype(np.uint8))


def tex_ground(base, seed):
    """bare ground drawn here, tileable: gravel or earth, small stones in it"""
    from scipy.ndimage import gaussian_filter
    r = np.random.default_rng(seed)
    n1 = gaussian_filter(r.normal(size=(256, 256)), 0.8, mode='wrap'); n1 /= n1.std()
    n2 = gaussian_filter(r.normal(size=(256, 256)), 7.0, mode='wrap'); n2 /= n2.std()
    st = gaussian_filter(r.random((256, 256)), 1.3, mode='wrap'); st = (st - st.mean()) / st.std()
    stones = np.clip((st - 0.9) * 1.4, 0, 1)
    pits = np.clip((-st - 1.2) * 1.2, 0, 1)
    L = 1 + 0.09 * n1 + 0.07 * n2 + 0.16 * stones - 0.2 * pits
    a = np.array(base, np.float32)[None, None, :] * L[..., None]
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def tex_tinted(name, gain, tint=(1, 1, 1)):
    a = np.asarray(src(name), np.float32) * gain * np.array(tint, np.float32)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


# ---------------------------------------------------------------- the aerial photos on the ground
# A layer is 512 px: 480 px of its own square and 16 px of its neighbours' round it (so a triangle that reaches a
# little over the edge still finds its own ground there).
LAYER, MARGIN = 512, 16


class Drape:
    """aerial photos over a square of the map's plane, in layers of LAYER px at `res` metres a pixel"""
    def __init__(self, name, x0, z0, nx, nz, res, zoom):
        self.name, self.x0, self.z0, self.nx, self.nz, self.res, self.zoom = name, x0, z0, nx, nz, res, zoom
        self.span = (LAYER - 2 * MARGIN) * res

    def key(self, i, j): return f'{self.name}_{i}_{j}'

    def keys(self): return [self.key(i, j) for j in range(self.nz) for i in range(self.nx)]

    def cell(self, x, z):
        i = np.clip(np.floor((np.asarray(x) - self.x0) / self.span).astype(int), 0, self.nx - 1)
        j = np.clip(np.floor((np.asarray(z) - self.z0) / self.span).astype(int), 0, self.nz - 1)
        return i, j

    def uv(self, i, j, x, z):
        """texture coordinates of points (x, z) in layer (i, j)"""
        ox = self.x0 + i * self.span - MARGIN * self.res; oz = self.z0 + j * self.span - MARGIN * self.res
        return np.c_[(np.asarray(x) - ox) / (LAYER * self.res), (np.asarray(z) - oz) / (LAYER * self.res)]

    def image(self, i, j):
        ox = self.x0 + i * self.span - MARGIN * self.res; oz = self.z0 + j * self.span - MARGIN * self.res
        c = (np.arange(LAYER) + 0.5) * self.res
        X, Z = np.meshgrid(ox + c, oz + c)
        lat, lon = S.to_ll(X, Z)
        m = gsi.Mosaic('seamlessphoto', self.zoom, 'jpg', float(lat.min()) - 0.001, float(lon.min()) - 0.001, float(lat.max()) + 0.001, float(lon.max()) + 0.001)
        px, py = m.px(lat, lon)
        # a box filter the size of a texel first (the photo's pixels are smaller), then bilinear
        k = max(1, int(round(self.res / (40075016 * np.cos(np.radians(S.LAT0)) / 2 ** self.zoom / 256))))
        a = m.a.astype(np.float32)
        if k > 1:
            from scipy.ndimage import uniform_filter
            a = uniform_filter(a, size=(k, k, 1), mode='nearest')
        out = np.stack([map_coordinates(a[..., ch], [py - 0.5, px - 0.5], order=1, mode='nearest') for ch in range(3)], -1)
        if DRAPE_HOOK is not None and self.name == 'near': out = DRAPE_HOOK(X, Z, out)
        return Image.fromarray(grade(out))


DRAPE_HOOK = None          # (x, z, rgb 0-255) -> rgb: gen.py's own corrections to the near photos


def grade(a):
    """an aerial photo as ground colour: a little of the haze taken out, the greens a little livelier"""
    a = np.asarray(a, np.float32) / 255
    lo = np.percentile(a.reshape(-1, 3), 1, axis=0)
    a = np.clip((a - lo * 0.7) / (1 - lo * 0.7), 0, 1)
    # the shade in the photos is lit by the blue sky alone: seen from the road it would read as dark blue patches
    # on the ground, so the bluish shade is turned to the woods' own dark green
    L = a.mean(-1)
    blu = np.clip((a[..., 2] - a[..., 1]) / 0.08 + 0.6, 0, 1)
    w = (np.clip((0.45 - L) / 0.25, 0, 1) * blu)[..., None]
    tint = np.array([0.84, 1.0, 0.56], np.float32); tint /= tint.mean()
    a = a * (1 - w) + (L * 1.12)[..., None] * tint * w
    m = a.mean(-1, keepdims=True)
    a = np.clip(m + (a - m) * 1.18, 0, 1)
    return (np.clip(a ** 1.02 * 1.02, 0, 1) * 255).astype(np.uint8)


TEXTURES = {
    # (lighter than the Irohazaka source: Route 33's asphalt is old and pale, its verges sunlit weeds)
    'asphalt': lambda: tex_tinted(T_ASPHALT, 1.22, (1.0, 1.0, 0.98)),
    'gutter': lambda: tex_tinted(T_GUTTER, 0.95), 'verge': lambda: tex_tinted(T_VERGE, 1.75, (1.02, 1.0, 0.92)),
    'grass': lambda: tex_tinted(T_GRASS, 1.45, (0.94, 1.04, 0.82)),
    'wall_kikko': lambda: src(T_KIKKO), 'wall_stones': lambda: src(T_STONES), 'rock': lambda: src(T_ROCK),
    'rock_bare': lambda: src(T_ROCK2), 'guardrail': tex_guardrail,
    'forest': lambda: src(T_FOREST, True), 'bush': lambda: src(T_BUSH, True), 'delineator': lambda: src(T_DELINEATOR, True),
    'tree_far': lambda: src(T_TREEFAR, True),
    'solar': tex_solar,
    'gravel': lambda: tex_ground((172, 168, 156), 1), 'dirt': lambda: tex_ground((166, 140, 108), 2),
    'sign_30': lambda: tex_regulatory('30'), 'sign_nopass': lambda: tex_regulatory('nopass'), 'sign_nopark': lambda: tex_regulatory('nopark'),
    'facade_white': lambda: tex_facade((198, 194, 184), (120, 118, 112), (60, 66, 74), 1),
    'facade_cream': lambda: tex_facade((200, 186, 160), (96, 82, 66), (48, 54, 62), 2),
    'facade_wood': lambda: tex_facade((132, 100, 72), (70, 52, 38), (40, 44, 50), 3),
    'facade_grey': lambda: tex_facade((168, 168, 164), (90, 90, 88), (44, 52, 62), 4),
}
for _i, _t in enumerate(T_TREES): TEXTURES[f'tree_{_i}'] = (lambda t: lambda: src(t, True))(_t)
for _k, _t in SIGNS.items(): TEXTURES[f'sign_{_k}'] = (lambda t: lambda: src(t, True))(_t)


def bleed(img):
    a = np.array(img, dtype=np.float32)
    rgb, al = a[:, :, :3], a[:, :, 3]
    known = al > 8
    if known.all() or not known.any(): return img
    out = np.where(known[:, :, None], rgb, 0); filled = known.copy()
    for _ in range(64):
        if filled.all(): break
        s = sum(np.roll(np.roll(out * filled[:, :, None], dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        w = sum(np.roll(np.roll(filled.astype(np.float32), dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        new = (~filled) & (w > 0)
        out[new] = s[new] / w[new][:, None]; filled |= new
    out[~filled] = rgb[known].mean(0)
    return Image.fromarray(np.dstack([out, al]).clip(0, 255).astype(np.uint8), 'RGBA')


def webp(img, q=82):
    has_a = img.mode == 'RGBA' and (np.asarray(img)[..., 3] < 250).any()
    img = img.convert('RGBA' if has_a else 'RGB')
    if has_a: img = bleed(img)
    w, h = img.size
    sc = min(1.0, 512 / max(w, h))
    if sc < 1: img = img.resize((max(4, int(w * sc)), max(4, int(h * sc))), Image.LANCZOS)
    bio = io.BytesIO(); img.save(bio, 'WEBP', quality=q, method=6)
    return bio.getvalue()


def M(tex, cat, surf=0, mode=0, fade=0, shadow=False, layer=0, spec=0.1, color=(1, 1, 1, 1), fog=True):
    d = dict(tex=tex, cat=cat, surf=surf, mode=mode, fade=fade, shadow=shadow, layer=layer, spec=spec, color=list(color))
    if not fog: d['fog'] = False
    return d


# material key -> settings (surf: 1 tarmac, 2 kerb, 3 gravel, 4 grass, 0 none)
MATERIALS = {
    'road':        M('asphalt', 'ground', 1, spec=0.25),
    'pave':        M('asphalt', 'ground', 1, spec=0.22),          # the car parks
    'gutter':      M('gutter', 'ground', 1, spec=0.12),
    'paint':       M(None, 'ground', 1, layer=1, spec=0.2, color=(0.86, 0.86, 0.84, 1)),
    'paint_y':     M(None, 'ground', 1, layer=1, spec=0.2, color=(0.93, 0.52, 0.12, 1)),     # (Japan's "yellow" line is orange)
    'verge':       M('verge', 'ground', 4, spec=0.03),
    'grass':       M('grass', 'ground', 4, spec=0.03),
    'gravel':      M('gravel', 'ground', 3, spec=0.04),          # (open ground by the road the photos show bare)
    'dirt':        M('dirt', 'ground', 3, spec=0.03),
    'wall_kikko':  M('wall_kikko', 'wall', shadow=True, spec=0.08),
    'wall_stones': M('wall_stones', 'wall', shadow=True, spec=0.08),
    'rock':        M('rock', 'wall', shadow=True, spec=0.05),
    'rock_bare':   M('rock_bare', 'wall', shadow=True, spec=0.05),
    'guardrail':   M('guardrail', 'small', mode=1, fade=900, shadow=True, spec=0.45),
    'pole':        M(None, 'small', fade=450, spec=0.3, color=(0.62, 0.63, 0.64, 1)),
    'post':        M(None, 'small', fade=300, spec=0.3, color=(0.58, 0.6, 0.62, 1)),       # (steel: the fence posts)
    'reflector':   M('delineator', 'small', mode=1, fade=250, spec=0.3),
    'mirror_pole': M(None, 'small', fade=500, spec=0.3, color=(0.93, 0.42, 0.1, 1)),
    'mirror':      M(None, 'small', fade=500, spec=0.9, color=(0.7, 0.74, 0.78, 1)),
    'mirror_back': M(None, 'small', fade=500, spec=0.2, color=(0.35, 0.36, 0.37, 1)),
    'pole_concrete': M(None, 'small', fade=900, spec=0.1, color=(0.66, 0.65, 0.62, 1)),
    'wire':        M(None, 'small', fade=300, spec=0.1, color=(0.12, 0.12, 0.13, 1)),
    'cable':       M(None, 'small', fade=200, spec=0.3, color=(0.42, 0.43, 0.44, 1)),
    'solar':       M('solar', 'wall', shadow=True, spec=0.7),
    'solar_back':  M(None, 'wall', shadow=True, spec=0.1, color=(0.5, 0.51, 0.52, 1)),
    'sign_30':     M('sign_30', 'small', mode=1, fade=450, spec=0.2),
    'sign_nopass': M('sign_nopass', 'small', mode=1, fade=450, spec=0.2),
    'sign_nopark': M('sign_nopark', 'small', mode=1, fade=450, spec=0.2),
    'sign_back':   M(None, 'small', fade=450, spec=0.2, color=(0.55, 0.56, 0.57, 1)),
    'forest':      M('forest', 'veg', mode=1, shadow=True),
    'delineator':  M('delineator', 'small', mode=1, fade=350, spec=0.3),
    'tree_far':    M('tree_far', 'veg', mode=1, fade=1600, shadow=True),
    'facade_white': M('facade_white', 'wall', shadow=True, spec=0.12),
    'facade_cream': M('facade_cream', 'wall', shadow=True, spec=0.12),
    'facade_wood':  M('facade_wood', 'wall', shadow=True, spec=0.08),
    'facade_grey':  M('facade_grey', 'wall', shadow=True, spec=0.12),
}
for _i in range(len(T_TREES)): MATERIALS[f'tree_{_i}'] = M(f'tree_{_i}', 'veg', mode=1, fade=900, shadow=True)
for _k in SIGNS: MATERIALS[f'sign_{_k}'] = M(f'sign_{_k}', 'small', mode=1, fade=450, spec=0.2)


def add_drape(d, cat):
    for k in d.keys():
        TEXTURES[k] = (lambda d, k: lambda: d.image(*map(int, k.rsplit('_', 2)[1:])))(d, k)
        MATERIALS[k] = M(k, cat, 4 if d.name == 'near' else 0, spec=0.02)     # (the near ground is solid: grass)


def add_panorama(images):
    """the horizon: layers of the panorama (alpha: the sky), drawn unlit with their own haze"""
    for i, im in enumerate(images):
        TEXTURES[f'pano_{i}'] = (lambda im: lambda: im)(im)
        MATERIALS[f'pano_{i}'] = M(f'pano_{i}', 'far', mode=1, fog=False)


def build_tables(used):
    tex_keys, mats, mat_index = [], [], {}
    for k in sorted(used, key=lambda k: list(MATERIALS).index(k)):
        m = dict(MATERIALS[k]); t = m.pop('tex')
        if t is not None:
            if t not in tex_keys: tex_keys.append(t)
            m['tex'] = tex_keys.index(t)
        m['name'] = k
        mat_index[k] = len(mats); mats.append(m)
    images = [webp(TEXTURES[t](), q=78 if t.startswith(('near_', 'mid_', 'far_', 'pano_')) else 82) for t in tex_keys]
    return mats, mat_index, images
