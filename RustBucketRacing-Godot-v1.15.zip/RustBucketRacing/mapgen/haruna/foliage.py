"""Foliage from LOLIPOP's game-ready packs (sketchfab.com/lolipop_1707, CC BY 4.0): "Oak trees pack (17var, LODs,
seasons, gameready)", "Maple trees pack (lowpoly, game ready, LODs)", "Realistic fir trees pack (LODS, gameready)",
"Bush models pack (gameready, LODs)" and "Grass (pack of 9 vars, lowpoly, game ready)". Set $FOLIAGE to the folder
with them (oak.glb, maple.glb, fir.glb, bush.glb, grass.glb).

  * trees and the bigger bushes as impostors: each model's own billboard (its far LOD: the tree rendered from the
    sides and from above, in an atlas) taken apart into two upright planes crossed at their own angle and a level
    crown on top, four views to a 512 px texture layer (the two sides, the top, and a third side for the mirror
    image); 4-6 triangles a tree, each exactly as wide and tall as the model
  * by the road, real meshes: grass clumps, small bushes (their middle LOD) and young oaks and maples (their low
    LOD), each a few dozen to a few hundred triangles, faded out with distance"""
import os
import numpy as np
from PIL import Image
from gltf import Glb

DIR = os.environ.get('FOLIAGE', '/home/claude/game/foliage/src')
CELL = 256

# impostors: name -> (pack, model). Mt. Haruna's woods: oak and maple, conifer plantations (the firs, grown taller)
TREES = {
    'oak_big1': ('oak', 'Big_oak_tree__001'), 'oak_big3': ('oak', 'Big_oak_tree__003'),
    'oak_large1': ('oak', 'Large_oak_tree_001'), 'oak_large2': ('oak', 'Large_oak_tree_002'), 'oak_large4': ('oak', 'Large_oak_tree_004'),
    'oak_med2': ('oak', 'Medium_oak_tree__002'),
    'maple_large1': ('maple', 'Acer_large_1'), 'maple_large3': ('maple', 'Acer_large_3'), 'maple_med1': ('maple', 'Acer_medium_1'),
    'fir1': ('fir', 'Christmas tree'), 'fir3': ('fir', 'Christmas tree_3'), 'fir6': ('fir', 'Christmas tree_6'),
    'bush_big1': ('bush', 'Bush_big_001'), 'bush_big3': ('bush', 'Bush_big_003'),
}
# real meshes by the road: name -> (pack, model, LOD)
MESHES = {
    'grass_l1': ('grass', 'Grass large 1', None), 'grass_l2': ('grass', 'Grass large 2', None), 'grass_l3': ('grass', 'Grass large 3', None),
    'grass_m1': ('grass', 'Grass medium 1', None), 'grass_m3': ('grass', 'Grass medium 3', None),
    'bush_m1': ('bush', 'Bush_medium_001', 'LOD1'), 'bush_m2': ('bush', 'Bush_medium_002', 'LOD1'), 'bush_m3': ('bush', 'Bush_medium_003', 'LOD2'),
    'bush_s1': ('bush', 'Bush_small_001', 'LOD1'), 'bush_s3': ('bush', 'Bush_small_003', 'LOD1'),
    'oak_small1': ('oak', 'Small_oak_tree__001', 'LOD2'), 'oak_small2': ('oak', 'Small_oak_tree__002', 'LOD2'), 'oak_small3': ('oak', 'Small_oak_tree__003', 'LOD2'),
    'oak_sap1': ('oak', 'Sapling_oak_tree_001', 'LOD1'), 'oak_sap2': ('oak', 'Sapling_oak_tree_002', 'LOD1'),
    'maple_sap2': ('maple', 'Acer_Sapling_2', 'LOD2'), 'maple_small3': ('maple', 'Acer_small_3', 'LOD2'),
}
_packs = {}


def pack(name):
    if name not in _packs: _packs[name] = Glb(os.path.join(DIR, name + '.glb'))
    return _packs[name]


def _instances(g, model, part):
    """the mesh instances of a model whose mesh name has `part` in it"""
    out = []
    for mi, nn, W in g.inst:
        mn = g.meshes[mi]['name']
        if mn.split('_LOD')[0].split('_Billboard')[0].split('_GrassAtlas')[0] != model: continue
        if part in mn: out.append((mi, W))
    return out


# each pack's leaves brought to one summer green, the sunlit yellow-green of Mt. Haruna's woods in August (the maple
# billboards are olive, the oak ones grey-green, the grass lime): only the leaves' pixels, never the trunks and branches, and a little more
# contrast (the billboards were drawn under flat light)
GREEN = {'oak': (92, 116, 54), 'maple': (98, 120, 48), 'fir': (66, 90, 50), 'bush': (90, 114, 52), 'grass': (104, 120, 58)}


def grade(im, packname, contrast=2.2):
    a = np.asarray(im, np.float32)
    rgb, al = a[..., :3], a[..., 3]
    leaf = (al > 128) & (rgb[..., 1] >= 0.95 * rgb[..., 0]) & (rgb[..., 1] >= rgb[..., 2])
    if packname in GREEN and leaf.any():
        mean = rgb[leaf].mean(0)
        gain = np.clip(np.array(GREEN[packname], np.float32) / np.maximum(mean, 1), 0.5, 3.5)
        out = rgb[leaf] * gain
        lum = out.mean(1, keepdims=True); lm = float(lum.mean())
        out = out * ((lum - lm) * contrast + lm) / np.maximum(lum, 1)      # the brightness spread out, the hue kept
        rgb = rgb.copy(); rgb[leaf] = out
    return Image.fromarray(np.dstack([np.clip(rgb, 0, 255), al]).astype(np.uint8), 'RGBA')


def shade(im, sides, top_cell):
    """light the flat billboards a little: each side view darker towards the foot of its crown, the view from above
    darker towards its rim"""
    a = np.asarray(im, np.float32).copy()
    r = (np.arange(CELL) + 0.5) / CELL
    for f, (cx, cy) in sides:
        up = r if f['cv'][1] > 0 else 1 - r              # 0 at the foot, 1 at the top, down the cell's rows
        k = 0.74 + 0.34 * up
        a[cy:cy + CELL, cx:cx + CELL, :3] *= k[:, None, None]
    cx, cy = top_cell
    yy, xx = np.mgrid[0:CELL, 0:CELL]
    d = np.hypot(xx - CELL / 2, yy - CELL / 2) / (CELL / 2)
    a[cy:cy + CELL, cx:cx + CELL, :3] *= np.clip(1.08 - 0.3 * d, 0.7, 1.08)[..., None]
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA')


class Impostor:
    """a model's billboard taken apart: the side views and the top, in model space with the trunk at the origin"""
    def __init__(self, key, packname, model):
        g = pack(packname)
        (mi, W), = _instances(g, model, 'Billboard') or _instances(g, model, 'LOD3')
        p = g.parts(mi, W)[0]
        P, U, I = p['P'], p['U'], p['I']
        atlas = g.base_image(p['mat']).convert('RGBA')
        T = P[I]; fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); fn /= np.linalg.norm(fn, axis=1, keepdims=True)
        groups = {}
        for t in range(len(I)): groups.setdefault(tuple(np.round(fn[t] * 4) / 4), []).append(t)
        # the trunk: the middle of the top view's plane, on the ground
        top_k = max(groups, key=lambda k: k[1])
        tp = P[I[groups[top_k]]].reshape(-1, 3)
        self.axis = np.array([(tp[:, 0].min() + tp[:, 0].max()) / 2, P[:, 1].min(), (tp[:, 2].min() + tp[:, 2].max()) / 2])
        faces = []
        for k, ts in groups.items():
            q = P[I[ts]].reshape(-1, 3) - self.axis; uv = U[I[ts]].reshape(-1, 2)
            n = np.array(k, float); n /= np.linalg.norm(n)
            if abs(n[1]) > 0.7:
                # level: u, v against x, z
                A = np.c_[q[:, 0], q[:, 2], np.ones(len(q))]
                cu = np.linalg.lstsq(A, uv[:, 0], rcond=None)[0]; cv = np.linalg.lstsq(A, uv[:, 1], rcond=None)[0]
                faces.append(dict(kind='top', n=n, y=float(q[:, 1].mean()), x0=q[:, 0].min(), x1=q[:, 0].max(), z0=q[:, 2].min(), z1=q[:, 2].max(),
                                  cu=cu, cv=cv, uv0=uv.min(0), uv1=uv.max(0)))
            else:
                h = np.array([-n[2], n[0]])                     # across the plane (x, z)
                s = q[:, [0, 2]] @ h
                off = float(np.mean(q[:, [0, 2]] @ n[[0, 2]]))  # (the plane's distance from the trunk)
                A = np.c_[s, q[:, 1], np.ones(len(q))]
                cu = np.linalg.lstsq(A, uv[:, 0], rcond=None)[0]; cv = np.linalg.lstsq(A, uv[:, 1], rcond=None)[0]
                faces.append(dict(kind='side', n=n, h=h, off=off, s0=s.min(), s1=s.max(), y0=q[:, 1].min(), y1=q[:, 1].max(),
                                  cu=cu, cv=cv, uv0=uv.min(0), uv1=uv.max(0)))
        sides = [f for f in faces if f['kind'] == 'side']
        top = [f for f in faces if f['kind'] == 'top'][0]
        a = min(sides, key=lambda f: abs(abs(f['n'][2]) - 0) + (f['n'][0] < 0))      # facing +x
        b = min(sides, key=lambda f: abs(np.dot(f['n'][[0, 2]], a['n'][[0, 2]])) + (f['n'][2] < 0) * 0.01)   # most across it
        c = max(sides, key=lambda f: -np.dot(f['n'][[0, 2]], a['n'][[0, 2]]))         # the back of a
        self.key, self.sides, self.top = key, [a, b], top
        self.height = float(P[:, 1].max() - P[:, 1].min())
        self.half_width = max(max(abs(f['s0']), abs(f['s1'])) for f in (a, b))
        # the layer: [a | b] over [top | c], each CELL px
        L = Image.new('RGBA', (2 * CELL, 2 * CELL), (0, 0, 0, 0))
        W_, H_ = atlas.size
        for f, (cx, cy) in ((a, (0, 0)), (b, (CELL, 0)), (top, (0, CELL)), (c, (CELL, CELL))):
            box = (int(f['uv0'][0] * W_), int(f['uv0'][1] * H_), int(np.ceil(f['uv1'][0] * W_)), int(np.ceil(f['uv1'][1] * H_)))
            L.paste(atlas.crop(box).resize((CELL, CELL), Image.LANCZOS), (cx, cy))
            f['cell'] = (cx / (2 * CELL), cy / (2 * CELL))
        self.image = shade(grade(L, packname), [(a, (0, 0)), (b, (CELL, 0)), (c, (CELL, CELL))], (0, CELL))

    def _uv(self, f, s_or_x, y_or_z):
        """atlas uv -> layer uv for a face, from its in-plane coordinates"""
        u = f['cu'][0] * s_or_x + f['cu'][1] * y_or_z + f['cu'][2]
        v = f['cv'][0] * s_or_x + f['cv'][1] * y_or_z + f['cv'][2]
        lu = (u - f['uv0'][0]) / (f['uv1'][0] - f['uv0'][0]); lv = (v - f['uv0'][1]) / (f['uv1'][1] - f['uv0'][1])
        return np.c_[f['cell'][0] + np.clip(lu, 0.002, 0.998) * 0.5, f['cell'][1] + np.clip(lv, 0.002, 0.998) * 0.5]

    def add(self, mesh, X, Y, Z, S, YAW, crown):
        """trees at (X, Y, Z) (the trunk's foot), scaled by S, turned by YAW; crowns where `crown`"""
        n = len(X)
        if not n: return
        c, s_ = np.cos(YAW), np.sin(YAW)
        def place(q):                                          # (n, k, 3) model -> world
            x = q[..., 0] * c[:, None] - q[..., 2] * s_[:, None]; z = q[..., 0] * s_[:, None] + q[..., 2] * c[:, None]
            return np.stack([X[:, None] + x * S[:, None], Y[:, None] + q[..., 1] * S[:, None], Z[:, None] + z * S[:, None]], -1)
        Ps, UVs, Is, base = [], [], [], 0
        for f in self.sides:
            h = f['h']
            corners = np.array([[f['s0'], f['y0']], [f['s1'], f['y0']], [f['s1'], f['y1']], [f['s0'], f['y1']]])
            q = np.stack([corners[:, 0] * h[0] + f['n'][0] * f['off'], corners[:, 1], corners[:, 0] * h[1] + f['n'][2] * f['off']], -1)
            Ps.append(place(np.broadcast_to(q, (n, 4, 3))).reshape(-1, 3))
            UVs.append(np.tile(self._uv(f, corners[:, 0], corners[:, 1]), (n, 1)))
            o = base + 4 * np.arange(n)[:, None]
            Is.append(np.concatenate([o + [0, 1, 2], o + [0, 2, 3]])); base += 4 * n
        m = int(np.sum(crown))
        if m:
            t = self.top; sel = np.nonzero(crown)[0]
            corners = np.array([[t['x0'], t['z0']], [t['x1'], t['z0']], [t['x1'], t['z1']], [t['x0'], t['z1']]])
            q = np.stack([corners[:, 0], np.full(4, t['y']), corners[:, 1]], -1)
            cc, ss = c[sel], s_[sel]
            x = q[None, :, 0] * cc[:, None] - q[None, :, 2] * ss[:, None]; z = q[None, :, 0] * ss[:, None] + q[None, :, 2] * cc[:, None]
            PP = np.stack([X[sel, None] + x * S[sel, None], Y[sel, None] + q[None, :, 1] * S[sel, None], Z[sel, None] + z * S[sel, None]], -1)
            Ps.append(PP.reshape(-1, 3)); UVs.append(np.tile(self._uv(t, corners[:, 0], corners[:, 1]), (m, 1)))
            o = base + 4 * np.arange(m)[:, None]
            Is.append(np.concatenate([o + [0, 1, 2], o + [0, 2, 3]])); base += 4 * m
        P = np.concatenate(Ps)
        mesh.add('fol_' + self.key, P, np.concatenate(UVs), np.concatenate(Is), N=np.tile([0.0, 1.0, 0.0], (len(P), 1)), phys=False)


class Model:
    """a real mesh (one LOD of a model): leaves and bark, trunk at the origin"""
    def __init__(self, key, packname, model, lod):
        g = pack(packname)
        inst = _instances(g, model, lod) if lod else _instances(g, model, '')
        self.key, self.parts = key, []
        allp = []
        for mi, W in inst:
            for p in g.parts(mi, W):
                name = g.materials[p['mat']]['name']
                kind = 'bark' if 'Bark' in name else 'leaf'
                self.parts.append(dict(P=p['P'], U=p['U'], I=p['I'], N=p['N'], tex=(packname, p['mat']), kind=kind))
                allp.append(p['P'])
        A = np.concatenate(allp)
        bark = [q['P'] for q in self.parts if q['kind'] == 'bark']
        ref = np.concatenate(bark) if bark else A
        self.axis = np.array([np.median(ref[:, 0]), A[:, 1].min(), np.median(ref[:, 2])])
        for q in self.parts: q['P'] = q['P'] - self.axis
        self.height = float(A[:, 1].max() - A[:, 1].min())
        self.tris = sum(len(q['I']) for q in self.parts)

    def add(self, mesh, X, Y, Z, S, YAW):
        n = len(X)
        if not n: return
        c, s_ = np.cos(YAW), np.sin(YAW)
        for q in self.parts:
            P = q['P']
            x = P[None, :, 0] * c[:, None] - P[None, :, 2] * s_[:, None]; z = P[None, :, 0] * s_[:, None] + P[None, :, 2] * c[:, None]
            W = np.stack([X[:, None] + x * S[:, None], Y[:, None] + P[None, :, 1] * S[:, None], Z[:, None] + z * S[:, None]], -1).reshape(-1, 3)
            I = (q['I'][None] + len(P) * np.arange(n)[:, None, None]).reshape(-1, 3)
            if q['kind'] == 'leaf' and q['tex'][0] == 'grass':
                N = np.tile([0.0, 1.0, 0.0], (len(W), 1))           # grass lights like the ground under it
            elif q['kind'] == 'leaf':
                # leaves: their own normals leaning well up (the crown shades round, and is never black underneath)
                Nm = q['N'] * 0.55 + np.array([0.0, 1.0, 0.0]); Nm /= np.linalg.norm(Nm, axis=1, keepdims=True)
                nx = Nm[None, :, 0] * c[:, None] - Nm[None, :, 2] * s_[:, None]; nz = Nm[None, :, 0] * s_[:, None] + Nm[None, :, 2] * c[:, None]
                N = np.stack([nx, np.broadcast_to(Nm[None, :, 1], nx.shape), nz], -1).reshape(-1, 3)
            else:
                Nm = q['N']
                nx = Nm[None, :, 0] * c[:, None] - Nm[None, :, 2] * s_[:, None]; nz = Nm[None, :, 0] * s_[:, None] + Nm[None, :, 2] * c[:, None]
                N = np.stack([nx, np.broadcast_to(Nm[None, :, 1], nx.shape), nz], -1).reshape(-1, 3)
            mesh.add(material_of(q['tex'], q['kind']), W, np.tile(q['U'], (n, 1)), I, N=N, phys=False)


_mat_names = {}


def material_of(tex, kind):
    """one material per source texture: fol_<pack>_<material>"""
    if tex not in _mat_names:
        g = pack(tex[0])
        nm = g.materials[tex[1]]['name'].lower().replace(' ', '_')
        _mat_names[tex] = (f'fol_{tex[0]}_{nm}', kind)
    return _mat_names[tex][0]


def textures_and_materials(M):
    """(textures, materials) for everything made: impostor layers and the meshes' own textures (at most 512 px)"""
    tex, mats = {}, {}
    for k, imp in IMPOSTORS.items():
        tex['fol_' + k] = (lambda im: lambda: im)(imp.image)
        big = imp.height > 6
        mats['fol_' + k] = M('fol_' + k, 'veg', mode=1, fade=900 if big else 350, shadow=True)
    for (pk, mi), (name, kind) in _mat_names.items():
        tex[name] = (lambda pk, mi, kind: lambda: (grade(pack(pk).base_image(mi).convert('RGBA'), pk) if kind == 'leaf' else pack(pk).base_image(mi).convert('RGBA')))(pk, mi, kind)
        fade = {'grass': 140, 'bush': 300}.get(pk, 450)
        if kind == 'bark': mats[name] = M(name, 'small', mode=0, fade=fade, shadow=True, spec=0.05)
        else: mats[name] = M(name, 'veg', mode=1, fade=fade, shadow=pk != 'grass')
    return tex, mats


IMPOSTORS = {}
MODELS = {}


def load():
    for k, (pk, m) in TREES.items(): IMPOSTORS[k] = Impostor(k, pk, m)
    for k, (pk, m, lod) in MESHES.items(): MODELS[k] = Model(k, pk, m, lod)
    return IMPOSTORS, MODELS
