// The front end (alpha): the main menu, the free roam map select, the garage, settings, how to play and credits.
// Free Roam is the one mode open so far; Time Trial, Career and Multiplayer each have a page of their own waiting
// for them. It sits over the garage studio, or over the paused drive when settings are opened from it.
using System;
using System.Collections.Generic;
using System.Globalization;
using Godot;
using RustBucket.Audio;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class FrontEnd
    {
        public enum Page { None, Main, FreeRoam, Garage, Settings, TimeTrial, Career, Online, HowTo, Credits }
        public static readonly string[] TabNames = { "Audio", "Display", "Driving", "Controls", "Other" };

        readonly Main g;
        public readonly Control Root;
        public readonly Showroom Room;
        readonly TextureRect shade;
        readonly ColorRect dim;
        readonly Control dragArea;
        readonly Texture2D shadeLeft, shadeSides;
        readonly Dictionary<Page, Control> pages = new Dictionary<Page, Control>();
        readonly List<MarginContainer> frames = new List<MarginContainer>();
        Page page = Page.None, entry = Page.None, garageBack = Page.Main;
        bool overGame;

        public bool IsOpen => page != Page.None;
        public Page Current => page;
        // opened over the drive (settings or how to play): the paused game shows behind, dimmed
        public bool OverGame => IsOpen && overGame;

        public FrontEnd(Main game)
        {
            g = game;
            Root = new Control { Name = "FrontEnd", Theme = Ui.Theme, Visible = false, MouseFilter = Control.MouseFilterEnum.Ignore };
            Root.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Room = new Showroom(game, game.BorrowCarView, game.ReturnCarView);
            Root.AddChild(Room.View);
            shadeLeft = Grad(new[] { 0f, 0.36f, 0.62f, 1f }, new[] { 0.9f, 0.72f, 0f, 0f });
            shadeSides = Grad(new[] { 0f, 0.27f, 0.73f, 1f }, new[] { 0.78f, 0f, 0f, 0.78f });
            shade = new TextureRect { ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.Scale, MouseFilter = Control.MouseFilterEnum.Ignore };
            shade.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Root.AddChild(shade);
            dim = new ColorRect { Color = new Color(0.03f, 0.035f, 0.045f, 0.6f), MouseFilter = Control.MouseFilterEnum.Stop };
            dim.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Root.AddChild(dim);
            // the garage: drag anywhere off the panels to turn the car
            dragArea = new Control { Name = "TurnArea", MouseFilter = Control.MouseFilterEnum.Stop, Visible = false };
            dragArea.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            dragArea.GuiInput += OnDrag;
            Root.AddChild(dragArea);
            BuildMain();
            BuildFreeRoam();
            BuildGarage();
            BuildSettings();
            BuildLocked(Page.TimeTrial, "TIME TRIAL", "Race the clock on every map, against your own ghost.",
                "Your best laps and stage times from Free Roam are already being kept, and they are listed below. The Time Trial mode will set proper runs with a countdown, a ghost of your best run to chase, sector splits and medal times for each car on each map.",
                new[] { "Countdown starts and clean-run rules", "Ghost car of your best run", "Sector splits and a delta bar", "Bronze, silver and gold medal times", "Leaderboards" });
            BuildLocked(Page.Career, "CAREER", "Start with a rust bucket. Work your way up.",
                "Buy cheap cars, fix them up and tune them, enter events on the maps you know, and earn your way to faster machinery.",
                new[] { "Money, a car lot and a parts shop", "Repairs and upgrades: engine, suspension, tyres, brakes", "Events: time attacks, hill climbs and races", "Championships across the maps", "A garage that fills up with your cars" });
            BuildLocked(Page.Online, "MULTIPLAYER", "Drive together.",
                "Share the road with friends: free roam together, race head to head on the circuits, and run the mountain stages against each other's times.",
                new[] { "Free roam lobbies", "Head-to-head races", "Shared stage leaderboards", "Your garage cars online" });
            BuildHowTo();
            BuildCredits();
            foreach (var kv in pages) Quiet(kv.Value);
        }

        static Texture2D Grad(float[] at, float[] alpha)
        {
            var cols = new Color[alpha.Length];
            for (int i = 0; i < alpha.Length; i++) cols[i] = new Color(0.03f, 0.035f, 0.045f, alpha[i]);
            var gr = new Gradient { Colors = cols, Offsets = at };
            return new GradientTexture2D { Gradient = gr, Width = 256, Height = 4, FillFrom = new Vector2(0, 0), FillTo = new Vector2(1, 0) };
        }

        // containers let touches through to what is behind them (the garage turn area); panels and buttons keep them
        static void Quiet(Control c)
        {
            if (c is Container && !(c is PanelContainer) && !(c is ScrollContainer)) c.MouseFilter = Control.MouseFilterEnum.Ignore;
            foreach (var ch in c.GetChildren()) if (ch is Control cc) Quiet(cc);
        }

        static void NoMouse(Control c)
        {
            c.MouseFilter = Control.MouseFilterEnum.Ignore;
            foreach (var ch in c.GetChildren()) if (ch is Control cc) NoMouse(cc);
        }

        static string F(double v, int dp) => v.ToString("F" + dp, CultureInfo.InvariantCulture);

        /* ---------------- navigation ---------------- */
        public void Open(Page p, bool fromGame)
        {
            overGame = fromGame && (p == Page.Settings || p == Page.HowTo);
            entry = p;
            if (p == Page.Garage) garageBack = Page.Main;
            Go(p);
        }

        public void Go(Page p)
        {
            if (p == Page.None) { Close(); return; }
            if (p == Page.Garage && page != Page.Garage && page != Page.None) garageBack = page == Page.FreeRoam ? Page.FreeRoam : Page.Main;
            page = p;
            Root.Visible = true;
            foreach (var kv in pages) kv.Value.Visible = kv.Key == p;
            dragArea.Visible = p == Page.Garage;
            bool studio = !overGame;
            Room.SetActive(studio);
            if (studio)
            {
                if (p != Page.Garage) Room.Show(g.CarId);
                Room.Shift = p == Page.Main ? 0.36f : p == Page.Garage ? -0.02f : 0.42f;
                Room.AutoSpin = p != Page.Garage || autoSpin;
                Room.SpinSpeed = p == Page.Garage ? 0.22 : 0.16;
                Room.Back = p == Page.Garage ? 1.2 : 1;
            }
            shade.Visible = studio && (p == Page.Main || p == Page.Garage);
            shade.Texture = p == Page.Garage ? shadeSides : shadeLeft;
            dim.Visible = overGame || (p != Page.Main && p != Page.Garage);
            dim.Color = new Color(0.03f, 0.035f, 0.045f, overGame ? 0.62f : p == Page.FreeRoam ? 0.55f : 0.74f);
            if (p == Page.Garage) Inspect(inspect ?? g.CarId, true);
            if (p == Page.TimeTrial) FillBests();
            Sync();
        }

        public void Back()
        {
            if (!IsOpen) return;
            if (page == entry && overGame) { Close(); return; }
            switch (page)
            {
                case Page.Main: if (g.HasSession && !g.Busy) Close(); break;
                case Page.Garage: Go(garageBack); break;
                default: Go(Page.Main); break;
            }
        }

        public void Close()
        {
            page = Page.None;
            Root.Visible = false;
            dragArea.Visible = false;
            Room.SetActive(false);
            inspect = null;
            overGame = false;
        }

        float lastL = -1, lastR = -1;
        public void Layout(Vector2 size, float safeL, float safeR)
        {
            if (safeL == lastL && safeR == lastR) return;
            lastL = safeL; lastR = safeR;
            foreach (var m in frames)
            {
                m.AddThemeConstantOverride("margin_left", (int)(40 + safeL));
                m.AddThemeConstantOverride("margin_right", (int)(40 + safeR));
            }
        }

        public void Update(double dt, Vector2 size) => Room.Update(dt, size);

        /* ---------------- building blocks ---------------- */
        MarginContainer Frame(Page p)
        {
            var m = new MarginContainer { Visible = false, Name = p.ToString() };
            m.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            m.AddThemeConstantOverride("margin_left", 40); m.AddThemeConstantOverride("margin_right", 40);
            m.AddThemeConstantOverride("margin_top", 24); m.AddThemeConstantOverride("margin_bottom", 22);
            Root.AddChild(m);
            pages[p] = m; frames.Add(m);
            return m;
        }

        static Label Big(string s, int size, Color? c = null)
        {
            var l = Ui.Text(s, size, c);
            l.AddThemeFontOverride("font", Ui.Display);
            return l;
        }

        static Control Gap(float h) => new Control { CustomMinimumSize = new Vector2(0, h), MouseFilter = Control.MouseFilterEnum.Ignore };
        static Control Fill(bool vertical = true)
        {
            var c = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
            if (vertical) c.SizeFlagsVertical = Control.SizeFlags.ExpandFill; else c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            return c;
        }

        static PanelContainer Card(float pad = 22, float alpha = 0.86f)
        {
            var p = new PanelContainer();
            p.AddThemeStyleboxOverride("panel", Ui.Box(new Color(0.07f, 0.085f, 0.1f, alpha), 16, Ui.Line, 1, pad));
            return p;
        }

        static Control Pill(string s, Color c)
        {
            var p = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Ignore, SizeFlagsVertical = Control.SizeFlags.ShrinkCenter };
            var sb = Ui.Box(new Color(c, 0.12f), 14, c, 2, 0);
            sb.ContentMarginLeft = 12; sb.ContentMarginRight = 12; sb.ContentMarginTop = 3; sb.ContentMarginBottom = 3;
            p.AddThemeStyleboxOverride("panel", sb);
            var l = Ui.Text(s, Ui.FontTiny, c);
            l.AddThemeFontOverride("font", Ui.Display);
            p.AddChild(l);
            return p;
        }

        static Button Primary(string s, Action a, float w, float h, int font = 28)
        {
            var b = Ui.Btn(s, a, false, (int)h);
            b.CustomMinimumSize = new Vector2(w, h);
            b.AddThemeStyleboxOverride("normal", Ui.Box(Ui.Amber, 12, null, 0, 12));
            b.AddThemeStyleboxOverride("hover", Ui.Box(Ui.Amber.Lightened(0.1f), 12, null, 0, 12));
            b.AddThemeStyleboxOverride("pressed", Ui.Box(Ui.Amber.Darkened(0.1f), 12, null, 0, 12));
            b.AddThemeStyleboxOverride("disabled", Ui.Box(new Color(Ui.Amber, 0.45f), 12, null, 0, 12));
            b.AddThemeColorOverride("font_color", Ui.AmberInk); b.AddThemeColorOverride("font_hover_color", Ui.AmberInk);
            b.AddThemeColorOverride("font_pressed_color", Ui.AmberInk); b.AddThemeColorOverride("font_disabled_color", Ui.AmberInk);
            b.AddThemeFontSizeOverride("font_size", font);
            b.AddThemeFontOverride("font", Ui.Display);
            return b;
        }

        static Button Plain(string s, Action a, float w = 0, float h = 54, int font = 20)
        {
            var b = Ui.Btn(s, a, false, (int)h);
            if (w > 0) b.CustomMinimumSize = new Vector2(w, h);
            b.AddThemeStyleboxOverride("normal", Ui.Box(new Color(0.07f, 0.085f, 0.1f, 0.82f), 12, Ui.Line, 1, 12));
            b.AddThemeStyleboxOverride("hover", Ui.Box(new Color(0.1f, 0.12f, 0.14f, 0.9f), 12, new Color(Ui.Amber, 0.6f), 1, 12));
            b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(0.1f, 0.12f, 0.14f, 0.9f), 12, Ui.Amber, 2, 12));
            b.AddThemeColorOverride("font_pressed_color", Ui.Amber);
            b.AddThemeColorOverride("font_hover_pressed_color", Ui.Amber);
            b.AddThemeFontSizeOverride("font_size", font);
            b.AddThemeFontOverride("font", Ui.Display);
            return b;
        }

        // a big two-line choice: title, a line under it, and a tag on the right
        static Button Tile(string title, string sub, string tag, bool live, Action a, float h = 66)
        {
            var b = new Button { FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, h) };
            b.Pressed += () => a();
            var edge = live ? new Color(Ui.Amber, 0.7f) : Ui.Line;
            b.AddThemeStyleboxOverride("normal", Ui.Box(new Color(0.07f, 0.085f, 0.1f, live ? 0.9f : 0.72f), 14, edge, live ? 2 : 1, 0));
            b.AddThemeStyleboxOverride("hover", Ui.Box(new Color(0.1f, 0.12f, 0.14f, 0.92f), 14, Ui.Amber, 2, 0));
            b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(Ui.Amber, 0.16f), 14, Ui.Amber, 2, 0));
            var m = new MarginContainer();
            m.AddThemeConstantOverride("margin_left", 22); m.AddThemeConstantOverride("margin_right", 18);
            m.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            var row = Ui.Row(14);
            var col = Ui.Col(0);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill; col.Alignment = BoxContainer.AlignmentMode.Center;
            col.AddChild(Big(title, 28, live ? Ui.Ink : new Color(0.72f, 0.76f, 0.8f)));
            col.AddChild(Ui.Text(sub, Ui.FontSmall - 2, Ui.Muted));
            row.AddChild(col);
            var tagC = live ? Big(tag + "  ›", 22, Ui.Amber) : Pill(tag, Ui.Muted);
            tagC.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
            row.AddChild(tagC);
            m.AddChild(row);
            b.AddChild(m);
            NoMouse(m);
            return b;
        }

        HBoxContainer TopBar(string title, Control right = null)
        {
            var row = Ui.Row(18);
            var back = Plain("‹  BACK", Back, 150, 54, 20);
            row.AddChild(back);
            var t = Big(title, 36);
            t.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
            row.AddChild(t);
            row.AddChild(Fill(false));
            if (right != null) row.AddChild(right);
            return row;
        }

        /* ---------------- main menu ---------------- */
        Button bResume;
        Label carName, carSub;

        void BuildMain()
        {
            var m = Frame(Page.Main);
            var row = Ui.Row(0);
            m.AddChild(row);
            var col = Ui.Col(10);
            col.CustomMinimumSize = new Vector2(520, 0);
            row.AddChild(col);
            col.AddChild(Big("RUST BUCKET", 58));
            var r2 = Ui.Row(16);
            r2.AddChild(Big("RACING", 58, Ui.Amber));
            r2.AddChild(Pill("ALPHA  ·  v" + DebugLog.Version, Ui.Amber));
            col.AddChild(r2);
            col.AddChild(Gap(4));
            bResume = Primary("RESUME DRIVE", Close, 0, 58, 26);
            col.AddChild(bResume);
            col.AddChild(Tile("FREE ROAM", "Four maps, no rules: drive anywhere, any way you like", "PLAY", true, () => Go(Page.FreeRoam)));
            col.AddChild(Tile("TIME TRIAL", "Race the clock and your own ghost", "SOON", false, () => Go(Page.TimeTrial)));
            col.AddChild(Tile("CAREER", "Buy, fix up and race your way up", "SOON", false, () => Go(Page.Career)));
            col.AddChild(Tile("MULTIPLAYER", "Drive with your friends online", "SOON", false, () => Go(Page.Online)));
            col.AddChild(Fill());
            var small = Ui.Row(8);
            foreach (var (label, p) in new[] { ("GARAGE", Page.Garage), ("SETTINGS", Page.Settings), ("HOW TO PLAY", Page.HowTo), ("CREDITS", Page.Credits) })
            {
                var pp = p;
                var b = Plain(label, () => Go(pp), 0, 54, 18);
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                small.AddChild(b);
            }
            col.AddChild(small);
            // the car on the turntable, named bottom right
            var right = Ui.Col(2);
            right.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            right.AddChild(Fill());
            carName = Big("", 34);
            carName.HorizontalAlignment = HorizontalAlignment.Right;
            carSub = Ui.Text("", Ui.FontSmall, Ui.Muted);
            carSub.HorizontalAlignment = HorizontalAlignment.Right;
            right.AddChild(carName); right.AddChild(carSub);
            var gb = Plain("IN THE GARAGE  ›", () => Go(Page.Garage), 0, 48, 18);
            gb.SizeFlagsHorizontal = Control.SizeFlags.ShrinkEnd;
            right.AddChild(Gap(6));
            right.AddChild(gb);
            row.AddChild(right);
        }

        /* ---------------- free roam ---------------- */
        Button[] mapCards;
        Label frCar, frCarSub, frStartNote, frStatus;
        Button[] frStart;
        HBoxContainer frStartRow;
        Button bDrive;
        string selMap;
        readonly Dictionary<string, int> startPick = new Dictionary<string, int>();
        static readonly Dictionary<string, string> Blurb = new Dictionary<string, string>
        {
            ["grid"] = "Runway, slalom, jumps, a skid pad, test strips of dirt and gravel, and a 3.2 km circuit with 16 corners.",
            ["spa"] = "The Grand Prix circuit as it was in 1992: La Source, Eau Rouge, Kemmel, Pouhon, Blanchimont.",
            ["mcr"] = "A narrow mountain road through rock cuttings, forest and a village, up or down.",
            ["iroha"] = "The First Irohazaka at Nikko, Japan: hairpin after hairpin, down the mountain or back up.",
        };

        void BuildFreeRoam()
        {
            var m = Frame(Page.FreeRoam);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(TopBar("FREE ROAM", Pill("NO RULES  ·  NO CLOCK UNLESS YOU WANT ONE", Ui.Muted)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var grid = new GridContainer { Columns = 2, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
            grid.AddThemeConstantOverride("h_separation", 12); grid.AddThemeConstantOverride("v_separation", 12);
            row.AddChild(grid);
            mapCards = new Button[Defs.MapOrder.Length];
            for (int i = 0; i < Defs.MapOrder.Length; i++)
            {
                var d = Defs.Maps[Defs.MapOrder[i]];
                string id = d.Id;
                var b = new Button { ToggleMode = true, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, 168), SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
                b.Pressed += () => { selMap = id; Sync(); };
                b.AddThemeStyleboxOverride("normal", Ui.Box(new Color(0.07f, 0.085f, 0.1f, 0.88f), 14, Ui.Line, 1, 0));
                b.AddThemeStyleboxOverride("hover", Ui.Box(new Color(0.1f, 0.12f, 0.14f, 0.92f), 14, new Color(Ui.Amber, 0.6f), 1, 0));
                b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(0.16f, 0.13f, 0.07f, 0.95f), 14, Ui.Amber, 2, 0));
                b.AddThemeStyleboxOverride("hover_pressed", Ui.Box(new Color(0.18f, 0.145f, 0.08f, 0.95f), 14, Ui.Amber, 2, 0));
                b.AddThemeStyleboxOverride("disabled", Ui.Box(new Color(0.07f, 0.085f, 0.1f, 0.6f), 14, Ui.Line, 1, 0));
                var inner = Ui.Col(4);
                var pad = Ui.Pad(inner, 20, 16, 18, 14);
                pad.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                inner.AddChild(Big(d.Name.ToUpperInvariant(), 26));
                bool have = !d.Extra || FileAccess.FileExists(d.Pack);
                inner.AddChild(Ui.Text(have ? d.Sub : "Not in this build: its map pack wasn't uploaded", Ui.FontSmall - 1, have ? Ui.Amber : Ui.Hot));
                inner.AddChild(Ui.Text(Blurb.TryGetValue(id, out var bl) ? bl : "", Ui.FontTiny, new Color(0.78f, 0.81f, 0.84f), true));
                b.AddChild(pad);
                NoMouse(pad);
                b.Disabled = !have;
                mapCards[i] = b;
                grid.AddChild(b);
            }
            // the car and how to start, then go
            var side = Card(22);
            side.CustomMinimumSize = new Vector2(360, 0);
            row.AddChild(side);
            var sc = Ui.Col(8);
            side.AddChild(sc);
            sc.AddChild(Ui.Heading("Car"));
            frCar = Big("", 30); sc.AddChild(frCar);
            frCarSub = Ui.Text("", Ui.FontSmall, Ui.Muted); sc.AddChild(frCarSub);
            sc.AddChild(Plain("CHANGE CAR  ›", () => Go(Page.Garage), 0, 50, 18));
            sc.AddChild(Gap(6));
            sc.AddChild(Ui.Sep());
            sc.AddChild(Ui.Heading("Start"));
            frStartRow = Ui.Seg(new[] { "A", "B" }, (k) => { if (selMap != null) startPick[selMap] = k; Sync(); }, out frStart, 52);
            sc.AddChild(frStartRow);
            frStartNote = Ui.Text("", Ui.FontTiny, Ui.Muted, true);
            sc.AddChild(frStartNote);
            sc.AddChild(Fill());
            frStatus = Ui.Text("", Ui.FontSmall, Ui.Hot, true);
            sc.AddChild(frStatus);
            bDrive = Primary("DRIVE", DriveNow, 0, 72, 34);
            sc.AddChild(bDrive);
        }

        int StartFor(string map)
        {
            if (startPick.TryGetValue(map, out int k)) return k;
            return Defs.Maps[map].Stage ? (g.StageDown ? 1 : 0) : 0;
        }

        void DriveNow()
        {
            if (g.Busy || selMap == null) return;
            bDrive.Text = "LOADING…"; bDrive.Disabled = true; frStatus.Text = "";
            g.StartFreeRoam(selMap, StartFor(selMap));
        }

        // the map didn't load (a missing pack, or an error): say so and stay on the page
        public void DriveFailed(string msg)
        {
            bDrive.Text = "DRIVE"; bDrive.Disabled = false;
            frStatus.Text = msg;
        }

        /* ---------------- garage ---------------- */
        string inspect;
        bool autoSpin = true;
        Button[] carCards;
        Label gName, gSub, gLoading, gBest;
        readonly List<(Label key, Label val)> gRows = new List<(Label, Label)>();
        readonly ColorRect[] gBar = new ColorRect[3];
        readonly Label[] gBarVal = new Label[3];
        Button bSelect, bSpin;
        static readonly string[] RowKeys = { "Power", "Torque", "Weight", "Drive", "Gearbox", "Redline", "Size", "Wheelbase" };

        void BuildGarage()
        {
            var m = Frame(Page.Garage);
            var col = Ui.Col(12);
            m.AddChild(col);
            col.AddChild(TopBar("GARAGE", Pill("DRAG TO TURN THE CAR", Ui.Muted)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            // cars
            var list = Ui.Col(10);
            list.CustomMinimumSize = new Vector2(290, 0);
            row.AddChild(list);
            carCards = new Button[Defs.CarOrder.Length];
            for (int i = 0; i < Defs.CarOrder.Length; i++)
            {
                var d = Defs.Cars[Defs.CarOrder[i]];
                string id = d.Id;
                var b = new Button { ToggleMode = true, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, 80) };
                b.Pressed += () => Inspect(id, false);
                b.AddThemeStyleboxOverride("normal", Ui.Box(new Color(0.07f, 0.085f, 0.1f, 0.85f), 12, Ui.Line, 1, 0));
                b.AddThemeStyleboxOverride("hover", Ui.Box(new Color(0.1f, 0.12f, 0.14f, 0.92f), 12, new Color(Ui.Amber, 0.6f), 1, 0));
                b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(0.16f, 0.13f, 0.07f, 0.95f), 12, Ui.Amber, 2, 0));
                b.AddThemeStyleboxOverride("hover_pressed", Ui.Box(new Color(0.18f, 0.145f, 0.08f, 0.95f), 12, Ui.Amber, 2, 0));
                var inner = Ui.Col(2);
                inner.Alignment = BoxContainer.AlignmentMode.Center;
                var pad = Ui.Pad(inner, 18, 8, 14, 8);
                pad.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                inner.AddChild(Big(d.Title.ToUpperInvariant(), 24));
                inner.AddChild(Ui.Text(d.Sub, Ui.FontSmall - 2, Ui.Muted));
                b.AddChild(pad);
                NoMouse(pad);
                carCards[i] = b;
                list.AddChild(b);
            }
            gLoading = Ui.Text("", Ui.FontSmall, Ui.Amber);
            list.AddChild(gLoading);
            list.AddChild(Fill());
            list.AddChild(Ui.Text("Drag sideways to turn the platform, up and down to look from higher or lower. Pinch or scroll to zoom.", Ui.FontTiny, new Color(0.8f, 0.83f, 0.86f), true));
            var ctl = Ui.Row(8);
            bSpin = Plain("AUTO SPIN", () => { autoSpin = !autoSpin; Room.AutoSpin = autoSpin; Sync(); }, 0, 50, 17);
            bSpin.ToggleMode = true;
            bSpin.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            var rv = Plain("RESET VIEW", () => Room.ResetView(), 0, 50, 17);
            rv.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            ctl.AddChild(bSpin); ctl.AddChild(rv);
            list.AddChild(ctl);
            row.AddChild(Fill(false));
            // stats
            var side = Card(20, 0.84f);
            side.CustomMinimumSize = new Vector2(350, 0);
            row.AddChild(side);
            var sc = Ui.Col(6);
            side.AddChild(sc);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            var body = Ui.Col(6);
            body.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(body);
            sc.AddChild(scroll);
            gName = Big("", 32); body.AddChild(gName);
            gSub = Ui.Text("", Ui.FontSmall, Ui.Muted); body.AddChild(gSub);
            body.AddChild(Gap(4));
            string[] bars = { "Power", "Torque", "Power to weight" };
            for (int i = 0; i < 3; i++) body.AddChild(Bar(bars[i], out gBar[i], out gBarVal[i]));
            body.AddChild(Gap(4));
            body.AddChild(Ui.Sep());
            var grid = new GridContainer { Columns = 2 };
            grid.AddThemeConstantOverride("h_separation", 14); grid.AddThemeConstantOverride("v_separation", 4);
            foreach (var k in RowKeys)
            {
                var kl = Ui.Text(k, Ui.FontSmall - 2, Ui.Muted);
                var vl = Ui.Text("", Ui.FontSmall - 2);
                vl.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                grid.AddChild(kl); grid.AddChild(vl);
                gRows.Add((kl, vl));
            }
            body.AddChild(grid);
            body.AddChild(Ui.Sep());
            body.AddChild(Ui.Heading("Best times"));
            gBest = Ui.Text("", Ui.FontTiny, new Color(0.8f, 0.83f, 0.86f), true);
            body.AddChild(gBest);
            bSelect = Primary("SELECT", () => { if (inspect != null && inspect != g.CarId) { g.SwitchCar(inspect); Sync(); } }, 0, 64, 28);
            sc.AddChild(bSelect);
        }

        static Control Bar(string label, out ColorRect fill, out Label val)
        {
            var c = Ui.Col(3);
            var h = Ui.Row();
            var l = Ui.Text(label, Ui.FontTiny, Ui.Muted);
            l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            val = Ui.Text("", Ui.FontTiny, Ui.Amber);
            h.AddChild(l); h.AddChild(val);
            c.AddChild(h);
            var track = new ColorRect { Color = new Color(1, 1, 1, 0.1f), CustomMinimumSize = new Vector2(0, 8), MouseFilter = Control.MouseFilterEnum.Ignore };
            fill = new ColorRect { Color = Ui.Amber, MouseFilter = Control.MouseFilterEnum.Ignore };
            fill.AnchorLeft = 0; fill.AnchorTop = 0; fill.AnchorBottom = 1; fill.AnchorRight = 0.5f;
            fill.OffsetLeft = 0; fill.OffsetTop = 0; fill.OffsetRight = 0; fill.OffsetBottom = 0;
            track.AddChild(fill);
            c.AddChild(track);
            return c;
        }

        // peak power (hp, rpm) and torque (Nm, rpm) along the full-throttle curve, up to the limiter
        public static (double hp, double hpRpm, double nm, double nmRpm) Peaks(CarSpec s)
        {
            double hp = 0, hpR = 0, nm = 0, nmR = 0;
            var c = s.Curve;
            for (double r = c[0][0]; r <= Math.Min(s.Limiter, c[c.Length - 1][0]); r += 25)
            {
                double t = c[c.Length - 1][1];
                for (int i = 0; i + 1 < c.Length; i++)
                    if (r <= c[i + 1][0]) { t = c[i][1] + (c[i + 1][1] - c[i][1]) * (r - c[i][0]) / (c[i + 1][0] - c[i][0]); break; }
                double p = t * r * Math.PI / 30 / 745.7;
                if (p > hp) { hp = p; hpR = r; }
                if (t > nm) { nm = t; nmR = r; }
            }
            return (hp, hpR, nm, nmR);
        }

        static string Rpm(double r) => (Math.Round(r / 100) * 100).ToString("F0", CultureInfo.InvariantCulture);

        async void Inspect(string id, bool quietly)
        {
            inspect = id;
            Sync();
            if (page != Page.Garage) return;
            if (!g.HasCarView(id))
            {
                gLoading.Text = "Loading the car…";
                await Root.ToSignal(Root.GetTree(), SceneTree.SignalName.ProcessFrame);
                await Root.ToSignal(Root.GetTree(), SceneTree.SignalName.ProcessFrame);
                if (inspect != id || page != Page.Garage) return;
            }
            try { Room.Show(id); }
            catch (Exception e) { GD.PushError("garage: " + e.Message); }
            gLoading.Text = "";
        }

        void SyncGarage()
        {
            string id = inspect ?? g.CarId;
            if (id == null || !Defs.Cars.ContainsKey(id)) return;
            var d = Defs.Cars[id];
            var s = d.Spec;
            Ui.Light(carCards, Array.IndexOf(Defs.CarOrder, id));
            gName.Text = d.Title.ToUpperInvariant();
            gSub.Text = d.Sub + (id == g.CarId ? "  ·  driving" : "");
            var pk = Peaks(s);
            double maxHp = 0, maxNm = 0, maxPw = 0;
            foreach (var cid in Defs.CarOrder)
            {
                var o = Defs.Cars[cid].Spec; var q = Peaks(o);
                maxHp = Math.Max(maxHp, q.hp); maxNm = Math.Max(maxNm, q.nm); maxPw = Math.Max(maxPw, q.hp / o.Mass * 1000);
            }
            double pw = pk.hp / s.Mass * 1000;
            double[] frac = { pk.hp / maxHp, pk.nm / maxNm, pw / maxPw };
            string[] vals = { F(pk.hp, 0) + " hp", F(pk.nm, 0) + " Nm", F(pw, 0) + " hp/t" };
            for (int i = 0; i < 3; i++) { gBar[i].AnchorRight = (float)Math.Clamp(frac[i], 0.04, 1); gBarVal[i].Text = vals[i]; }
            var drive = s.DefaultTune.Drive;
            string[] rows =
            {
                $"{F(pk.hp, 0)} hp ({F(pk.hp * 0.7457, 0)} kW) at {Rpm(pk.hpRpm)} rpm",
                $"{F(pk.nm, 0)} Nm at {Rpm(pk.nmRpm)} rpm",
                $"{F(s.Mass, 0)} kg",
                drive == Drive.RWD ? "Rear-wheel drive" : drive == Drive.FWD ? "Front-wheel drive" : "All-wheel drive",
                $"{s.Gears.Length}-speed",
                $"{F(s.Redline, 0)} rpm",
                $"{F(s.HullMaxZ - s.HullMinZ, 2)} × {F(s.HullMaxX - s.HullMinX, 2)} × {F(s.HullMaxY, 2)} m",
                $"{F(Math.Abs(s.Hubs[2].Z - s.Hubs[0].Z), 2)} m",
            };
            for (int i = 0; i < gRows.Count; i++) gRows[i].val.Text = rows[i];
            // best times with this car, from free roam
            var lines = new List<string>();
            foreach (var mid in Defs.MapOrder)
            {
                var md = Defs.Maps[mid];
                foreach (var (suffix, what) in new[] { ("", "lap"), ("_up", "uphill"), ("_down", "downhill") })
                {
                    double t = g.Store.Best(mid + "_" + id + suffix);
                    if (!double.IsNaN(t)) lines.Add($"{md.Short} {what}: {LapTimer.Fmt(t, 3)}");
                }
            }
            gBest.Text = lines.Count > 0 ? string.Join("\n", lines) : "None yet: set some in Free Roam.";
            bool current = id == g.CarId;
            bSelect.Text = current ? "SELECTED" : "SELECT";
            bSelect.Disabled = current || g.Busy;
            bSpin.SetPressedNoSignal(autoSpin);
            bSpin.Text = autoSpin ? "AUTO SPIN  ·  ON" : "AUTO SPIN  ·  OFF";
        }

        // turning the car: one finger or the mouse turns the platform and tilts the view; two fingers zoom
        readonly Dictionary<int, Vector2> touches = new Dictionary<int, Vector2>();
        float pinch;
        bool mouseDown;

        void OnDrag(InputEvent e)
        {
            if (e is InputEventMouseButton mb && mb.Device != -1)
            {
                if (mb.ButtonIndex == MouseButton.Left) mouseDown = mb.Pressed;
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) Room.Zoom(Math.Exp(-0.1));
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) Room.Zoom(Math.Exp(0.1));
            }
            else if (e is InputEventMouseMotion mm && mm.Device != -1)
            {
                if (mouseDown) Room.Turn(mm.Relative.X * 0.0065, mm.Relative.Y * 0.004);
            }
            else if (e is InputEventScreenTouch st)
            {
                if (st.Pressed) touches[st.Index] = st.Position; else touches.Remove(st.Index);
                pinch = touches.Count == 2 ? Spread() : 0;
            }
            else if (e is InputEventScreenDrag sd)
            {
                touches[sd.Index] = sd.Position;
                if (touches.Count >= 2)
                {
                    float d = Spread();
                    if (pinch > 0 && d > 0) Room.Zoom(pinch / d);
                    pinch = d;
                }
                else Room.Turn(sd.Relative.X * 0.0065, sd.Relative.Y * 0.004);
            }
        }

        float Spread()
        {
            var it = touches.Values.GetEnumerator();
            it.MoveNext(); var a = it.Current; it.MoveNext(); var b = it.Current;
            return a.DistanceTo(b);
        }

        // for the self-test: turn the platform as a drag would
        public void TestTurn(double dx, double dy) => Room.Turn(dx, dy);
        public void TestInspect(string id) => Inspect(id, false);

        /* ---------------- settings ---------------- */
        Button[] tabBtns;
        readonly List<Control> tabs = new List<Control>();
        int tab;
        Button sSound, sTele, sAnalog;
        Button[] sGfx, sUnits, sGear, sSteerSeg;
        readonly Ui.SliderRow[] sVol = new Ui.SliderRow[5];
        Ui.SliderRow sSens, sSpeed, sAssist, sCs, sRec;
        Label sRef;

        public void ShowTab(int i)
        {
            tab = Math.Clamp(i, 0, tabs.Count - 1);
            for (int k = 0; k < tabs.Count; k++) tabs[k].Visible = k == tab;
            Ui.Light(tabBtns, tab);
        }

        VBoxContainer Tab(PanelContainer host)
        {
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill, Visible = false };
            var col = Ui.Col(8);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(col, 26, 20, 30, 24));
            host.AddChild(scroll);
            tabs.Add(scroll);
            return col;
        }

        static Label Note(string s) => Ui.Text(s, Ui.FontTiny, Ui.Muted, true);

        static void Head(VBoxContainer c, string s, bool first = false)
        {
            if (!first) { c.AddChild(Gap(6)); c.AddChild(Ui.Sep()); }
            c.AddChild(Ui.Heading(s));
        }

        static Button Toggle(string s, Action a)
        {
            var b = Ui.Btn(s, a, true, 54);
            b.Alignment = HorizontalAlignment.Left;
            return b;
        }

        void BuildSettings()
        {
            var m = Frame(Page.Settings);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(TopBar("SETTINGS", Pill("SAVED ON THIS DEVICE", Ui.Muted)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var tcol = Ui.Col(8);
            tcol.CustomMinimumSize = new Vector2(220, 0);
            row.AddChild(tcol);
            tabBtns = new Button[TabNames.Length];
            for (int i = 0; i < TabNames.Length; i++)
            {
                int k = i;
                var b = Plain(TabNames[i].ToUpperInvariant(), () => ShowTab(k), 0, 58, 20);
                b.ToggleMode = true;
                b.Alignment = HorizontalAlignment.Left;
                b.AddThemeStyleboxOverride("pressed", Ui.Box(new Color(Ui.Amber, 0.14f), 12, Ui.Amber, 2, 14));
                b.AddThemeStyleboxOverride("hover_pressed", Ui.Box(new Color(Ui.Amber, 0.18f), 12, Ui.Amber, 2, 14));
                tabBtns[i] = b;
                tcol.AddChild(b);
            }
            tcol.AddChild(Fill());
            tcol.AddChild(Ui.Text("Rust Bucket Racing\nv" + DebugLog.Version + " alpha", Ui.FontTiny, Ui.Muted));
            var host = Card(0, 0.9f);
            host.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            row.AddChild(host);

            // audio
            var a = Tab(host);
            Head(a, "Sound", true);
            sSound = Toggle("Sound", () => { g.ToggleSound(); Sync(); });
            a.AddChild(sSound);
            Head(a, "Volume");
            a.AddChild(Note("The engine, tyre squeal and crashes are mixed to stand out, with the rest underneath. Set each kind of sound to suit your speaker or headphones; moving a slider plays a sample of it."));
            for (int i = 0; i < 5; i++)
            {
                int k = i;
                sVol[i] = Ui.Slider(EngineAudio.KindNames[i], 0, 100, 1, (v) => v > 0 ? F(v, 0) + " %" : "Off", (v) => g.SetVolume(k, v / 100));
                a.AddChild(sVol[i].Root);
                a.AddChild(Note(char.ToUpperInvariant(EngineAudio.KindHints[i][0]) + EngineAudio.KindHints[i].Substring(1)));
            }
            var rl = Plain("RESET LEVELS", () => { for (int i = 0; i < 5; i++) g.SetVolume(i, 1, false); Sync(); }, 0, 52, 18);
            a.AddChild(Gap(4));
            a.AddChild(rl);

            // display
            var d = Tab(host);
            Head(d, "Graphics", true);
            d.AddChild(Ui.Seg(new[] { "High", "Medium", "Low" }, (i) => { g.SetQuality(i); Sync(); }, out sGfx));
            d.AddChild(Note("High: four shadow splits out to 120 m. Medium (phones start here): two splits, sharp shadows close to the car. Low: no shadow maps, a soft shadow under the car, 70 % resolution."));
            Head(d, "Speed units");
            d.AddChild(Ui.Seg(new[] { "km/h", "mph" }, (i) => { g.SetUnits(i == 0); Sync(); }, out sUnits));
            Head(d, "Telemetry");
            sTele = Toggle("Telemetry", () => { g.ToggleTelemetry(); Sync(); });
            d.AddChild(sTele);
            d.AddChild(Note("Live readouts over the drive: each tyre's load and slip, the suspension, and what the assists are doing."));
            if (!OS.HasFeature("mobile"))
            {
                Head(d, "Window");
                d.AddChild(Plain("FULL SCREEN", () =>
                {
                    var wm = DisplayServer.WindowGetMode();
                    DisplayServer.WindowSetMode(wm == DisplayServer.WindowMode.Fullscreen ? DisplayServer.WindowMode.Windowed : DisplayServer.WindowMode.Fullscreen);
                }, 0, 52, 18));
            }

            // driving
            var dr = Tab(host);
            Head(dr, "Gearbox", true);
            dr.AddChild(Ui.Seg(new[] { "Auto", "Semi", "Manual" }, (i) => { g.SetGearbox((Gearbox)i); Sync(); }, out sGear));
            dr.AddChild(Note("Auto shifts for you and reverses when you hold Brake at a stop. Semi lets you shift but protects the engine. Manual takes any gear you ask for. Shifting by hand in Auto switches to Semi."));
            Head(dr, "Steering");
            sSpeed = Ui.Slider("Steering speed", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => g.ChangeTune((t) => t.SteerSpeed = v));
            dr.AddChild(sSpeed.Root);
            dr.AddChild(Note("How fast the front wheels can turn, lock to lock. Letting go, they come back to centre almost three times as fast."));
            Head(dr, "Assists");
            sAssist = Ui.Slider("Steering assist", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.SteerAssist = v));
            dr.AddChild(sAssist.Root);
            dr.AddChild(Note("Holds full lock back to what the front tyres can use at speed, so stabbing the steering doesn't just scrub them. 0 gives you the whole rack at any speed. Below about 50 km/h both assists stand back while you are steering."));
            sCs = Ui.Slider("Counter-steer", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.CounterSteer = v));
            dr.AddChild(sCs.Root);
            dr.AddChild(Note("When the rear starts to slide, steers into the slide for you to catch it. Higher steps in earlier and harder; lower leaves room for drifts and handbrake turns. The CS light shows when it acts."));
            sRec = Ui.Slider("Slide recovery", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.Recovery = v));
            dr.AddChild(sRec.Root);
            dr.AddChild(Note("How much grip sliding tyres get back when you ease off the throttle and brake, so a slide straightens up. On the pedals (past about half) or the handbrake it stays out of the way. 0 is the raw tyre."));
            dr.AddChild(Note("ABS, traction control and the suspension are in Car setup, in the menu while you drive."));

            // controls
            var c = Tab(host);
            Head(c, "Steering", true);
            sSens = Ui.Slider("Sensitivity", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => { g.Prefs.Sens = v; g.SaveControls(); });
            c.AddChild(sSens.Root);
            c.AddChild(Note("Higher turns more for a small movement of the slider or stick (full lock stays at the end). With buttons or keys, how quickly holding one winds the steering on."));
            c.AddChild(Ui.Heading("Touch steering"));
            c.AddChild(Ui.Seg(new[] { "Slider", "Buttons" }, (i) => { g.Prefs.ButtonSteer = i == 1; g.SaveControls(); Sync(); }, out sSteerSeg));
            Head(c, "Pedals");
            sAnalog = Toggle("Analogue pedals", () => { g.Prefs.AnalogPedals = !g.Prefs.AnalogPedals; g.SaveControls(); Sync(); });
            c.AddChild(sAnalog);
            c.AddChild(Note("On: Gas and Brake press harder the higher you press them, and a tap of the brake gives a light brush. Off: every press is full on."));
            var reset = Plain("RESET CONTROLS TO DEFAULTS", () =>
            {
                g.Prefs.Sens = 1; g.Prefs.ButtonSteer = false; g.Prefs.AnalogPedals = true; g.SaveControls();
                g.ChangeTune((t) => { t.SteerSpeed = 1; t.SteerAssist = 1; t.CounterSteer = 0.5; t.Recovery = 0.75; });
                Sync();
            }, 0, 52, 18);
            c.AddChild(Gap(4));
            c.AddChild(reset);
            Head(c, "Reference");
            sRef = Note("");
            c.AddChild(sRef);

            // other
            var o = Tab(host);
            Head(o, "Bug reports", true);
            Button copyBtn = null;
            copyBtn = Plain("COPY DEBUG LOG", () => { DebugLog.CopyToClipboard(); copyBtn.Text = "COPIED"; }, 0, 52, 18);
            o.AddChild(copyBtn);
            o.AddChild(Note("Copies the game's log (device, frame rate, anything that went wrong) so you can paste it into a message."));
            Head(o, "About");
            o.AddChild(Note("Rust Bucket Racing v" + DebugLog.Version + ", an alpha. Free Roam is the one mode so far; Time Trial, Career and Multiplayer are on the way."));
            ShowTab(0);
        }

        /* ---------------- locked modes ---------------- */
        Label bestList;

        void BuildLocked(Page p, string title, string line, string text, string[] planned)
        {
            var m = Frame(p);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(TopBar(title, Pill("IN DEVELOPMENT", Ui.Amber)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var card = Card(26);
            card.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            row.AddChild(card);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            card.AddChild(scroll);
            var c = Ui.Col(10);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(c);
            c.AddChild(Big(line, 30));
            c.AddChild(Ui.Text(text, Ui.FontSmall, new Color(0.8f, 0.83f, 0.86f), true));
            if (p == Page.TimeTrial)
            {
                c.AddChild(Gap(4));
                c.AddChild(Ui.Heading("Your best times so far"));
                bestList = Ui.Text("", Ui.FontSmall - 2, Ui.Ink, true);
                c.AddChild(bestList);
            }
            c.AddChild(Fill());
            c.AddChild(Plain("DRIVE IN FREE ROAM  ›", () => Go(Page.FreeRoam), 300, 54, 20));
            // what it will have: empty slots for now
            var plan = Card(22, 0.8f);
            plan.CustomMinimumSize = new Vector2(380, 0);
            row.AddChild(plan);
            var pc = Ui.Col(8);
            plan.AddChild(pc);
            pc.AddChild(Ui.Heading("Planned"));
            foreach (var s in planned)
            {
                var slot = new PanelContainer();
                var sb = Ui.Box(new Color(1, 1, 1, 0.03f), 10, new Color(1, 1, 1, 0.1f), 1, 0);
                sb.ContentMarginLeft = 14; sb.ContentMarginRight = 10; sb.ContentMarginTop = 10; sb.ContentMarginBottom = 10;
                slot.AddThemeStyleboxOverride("panel", sb);
                var r = Ui.Row(10);
                var lk = Ui.Text("•", Ui.FontSmall, Ui.Muted);
                r.AddChild(lk);
                r.AddChild(Ui.Text(s, Ui.FontSmall - 2, new Color(0.72f, 0.76f, 0.8f), true));
                slot.AddChild(r);
                pc.AddChild(slot);
            }
        }

        void FillBests()
        {
            if (bestList == null) return;
            var lines = new List<string>();
            foreach (var mid in Defs.MapOrder)
                foreach (var cid in Defs.CarOrder)
                    foreach (var (suffix, what) in new[] { ("", "lap"), ("_up", "uphill"), ("_down", "downhill") })
                    {
                        double t = g.Store.Best(mid + "_" + cid + suffix);
                        if (!double.IsNaN(t)) lines.Add($"{Defs.Maps[mid].Name} {what}  ·  {Defs.Cars[cid].Title}  ·  {LapTimer.Fmt(t, 3)}");
                    }
            bestList.Text = lines.Count > 0 ? string.Join("\n", lines) : "None yet. Laps of the circuits and runs of the stages in Free Roam are timed and the best are kept.";
        }

        /* ---------------- how to play, credits ---------------- */
        Label howControls;

        void BuildHowTo()
        {
            var m = Frame(Page.HowTo);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(TopBar("HOW TO PLAY"));
            var card = Card(26);
            card.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(card);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            card.AddChild(scroll);
            var c = Ui.Col(10);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(c);
            c.AddChild(Ui.Heading("Controls"));
            howControls = Ui.Text("", Ui.FontSmall, new Color(0.84f, 0.87f, 0.89f), true);
            c.AddChild(howControls);
            c.AddChild(Ui.Heading("The cars"));
            c.AddChild(Ui.Text("Three rear-drive cars. Each corner has its own spring, damper and tyre, so the body rolls, pitches and squats for real, and grip follows the weight: brake into a corner to load the front tyres and sharpen the turn-in, feed in throttle to shift it back to the rears. The menu's Car setup changes springs, dampers, anti-roll bars, grip, brake bias, the drivetrain and the assists.", Ui.FontSmall - 1, new Color(0.8f, 0.83f, 0.86f), true));
            c.AddChild(Ui.Heading("The maps"));
            c.AddChild(Ui.Text(
                "PROVING GROUND  a 1.5 km runway with rumble strips, a tabletop and warning strips; speed bumps, an articulation strip, moguls and a gap jump that needs 100 km/h; a cone slalom, kickers, a skid-pad ring and a banked bowl; test strips of dirt, gravel and grass; and a 3.2 km race track around it all, with kerbs, gravel traps and a 10-car grid. The lap timer starts at the line.\n\n" +
                "SPA-FRANCORCHAMPS  the 1992 Grand Prix layout, 6.97 km clockwise. Guardrails and tyre walls are solid; gravel and grass slow you down. Reset puts you back on the track if you leave it.\n\n" +
                "MONTE CARLO RALLY  a 4.9 km mountain stage on a narrow road, 263 m of climb. Race it uphill from the START gantry to the FINISH, or downhill the other way: the clock starts when you drive through your start gantry.\n\n" +
                "IROHAZAKA  4.6 km of mountain road and its hairpins at Nikko, 339 m from top to bottom. Downhill is the classic way; the clock runs from the line at the top to the line at the bottom (or race it back up).",
                Ui.FontSmall - 1, new Color(0.8f, 0.83f, 0.86f), true));
        }

        void BuildCredits()
        {
            var m = Frame(Page.Credits);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(TopBar("CREDITS"));
            var card = Card(26);
            card.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(card);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            card.AddChild(scroll);
            var c = Ui.Col(12);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(c);
            c.AddChild(Big("RUST BUCKET RACING", 34));
            c.AddChild(Ui.Text("v" + DebugLog.Version + " alpha · made with Godot", Ui.FontSmall, Ui.Muted));
            c.AddChild(Ui.Heading("Cars"));
            c.AddChild(Ui.Text("\"Lowpoly Abandoned Simple Car Prop\" by Rashad Ibrahimli (CC BY 4.0)\n\"1987 Chevrolet Monte Carlo SS\" by Randomness (CC BY 4.0)\n\"2004 Cadillac CTS-V race car\" by Dave Love, sketchfab.com/Tyler_Dave (CC BY 4.0)", Ui.FontSmall - 1, new Color(0.84f, 0.87f, 0.89f), true));
            c.AddChild(Ui.Heading("Maps"));
            c.AddChild(Ui.Text("\"Circuit de Spa-Francorchamps 1992 layout\" and \"Monte Carlo Rally\" by Dave Love, sketchfab.com/Tyler_Dave (CC BY 4.0)\n\"Irohazaka Slope\" Assetto Corsa track by sost and its original authors (free, not for sale)", Ui.FontSmall - 1, new Color(0.84f, 0.87f, 0.89f), true));
        }

        /* ---------------- sync every control to the game ---------------- */
        public void Sync()
        {
            if (!IsOpen) return;
            var car = g.Car;
            // main
            bResume.Visible = g.HasSession;
            string rid = Room.CarId ?? g.CarId;
            if (rid != null && Defs.Cars.ContainsKey(rid)) { carName.Text = Defs.Cars[rid].Title.ToUpperInvariant(); carSub.Text = Defs.Cars[rid].Sub; }
            // free roam
            if (selMap == null || !Defs.Maps.ContainsKey(selMap))
            {
                // the map last driven, if this build has it
                selMap = g.Store.Str("map", g.MapId);
                if (!Defs.Maps.ContainsKey(selMap) || (Defs.Maps[selMap].Extra && !FileAccess.FileExists(Defs.Maps[selMap].Pack))) selMap = g.MapId;
            }
            Ui.Light(mapCards, Array.IndexOf(Defs.MapOrder, selMap));
            var cd = Defs.Cars[g.CarId];
            frCar.Text = cd.Title.ToUpperInvariant(); frCarSub.Text = cd.Sub;
            bool stage = Defs.Maps[selMap].Stage;
            string[] opts = selMap == "grid" ? new[] { "Test areas", "Race track" } : stage ? new[] { "Uphill", "Downhill" } : new[] { "Starting grid" };
            for (int i = 0; i < frStart.Length; i++)
            {
                frStart[i].Visible = i < opts.Length;
                if (i < opts.Length) frStart[i].Text = opts[i];
            }
            int sp = Math.Min(StartFor(selMap), opts.Length - 1);
            Ui.Light(frStart, sp);
            frStartNote.Text = selMap == "grid"
                ? (sp == 0 ? "On the runway, with every test area around you." : "On pole on the race track grid: the lap timer starts at the line.")
                : stage ? (sp == 0 ? "From the bottom: the clock starts at " + Defs.Maps[selMap].BottomLine + "." : "From the top: the clock starts at " + Defs.Maps[selMap].TopLine + ".")
                : "On the grid on the main straight: the lap timer starts at the line.";
            if (!g.Busy && page != Page.None) { bDrive.Text = "DRIVE"; bDrive.Disabled = false; }
            // garage
            SyncGarage();
            // settings
            if (car == null) return;
            var t = car.Tune;
            sSound.SetPressedNoSignal(g.SoundOn); sSound.Text = g.SoundOn ? "Sound  ·  on" : "Sound  ·  off";
            for (int i = 0; i < 5; i++) sVol[i].Show(Math.Round(g.Volume(i) * 100));
            Ui.Light(sGfx, g.Quality);
            Ui.Light(sUnits, g.Kmh ? 0 : 1);
            sTele.SetPressedNoSignal(g.TelemetryOn); sTele.Text = g.TelemetryOn ? "Telemetry  ·  on" : "Telemetry  ·  off";
            Ui.Light(sGear, (int)t.Gearbox);
            sSpeed.Show(t.SteerSpeed); sAssist.Show(t.SteerAssist); sCs.Show(t.CounterSteer); sRec.Show(t.Recovery);
            sSens.Show(g.Prefs.Sens);
            Ui.Light(sSteerSeg, g.Prefs.ButtonSteer ? 1 : 0);
            sAnalog.SetPressedNoSignal(g.Prefs.AnalogPedals); sAnalog.Text = g.Prefs.AnalogPedals ? "Analogue pedals  ·  on" : "Analogue pedals  ·  off";
            sRef.Text = ControlsText(g.Touch);
            howControls.Text = ControlsText(g.Touch);
        }

        public static string ControlsText(bool touch) => touch
            ? "Left thumb: slide along the steering pad, and flick the gear slider up or down (or tap its ends) to shift. Right thumb: Gas, Brake and Hand. Gas and Brake are pressure-sensitive: press higher for more, lower (or slide down) to feather. Camera and menu are top right; drag in the orbit camera to fly round the car, pinch to zoom. The phone's back button pauses to the main menu."
            : "W S throttle, brake (tap S to feather)  ·  A D steer  ·  Space handbrake  ·  Q E shift down, up  ·  C camera  ·  M gearbox  ·  T car setup  ·  K controls  ·  G telemetry  ·  V car  ·  N map  ·  L starting grid  ·  R reset (Shift+R start)  ·  H how to play  ·  Esc main menu  ·  drag to look, wheel or + - to zoom. A gamepad works too.";
    }
}
