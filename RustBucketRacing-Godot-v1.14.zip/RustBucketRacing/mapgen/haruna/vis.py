"""Which ground the cameras can see (viewshed.c): from the road at the heights the chase and orbit cameras reach."""
import ctypes, os, subprocess
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def _lib():
    src = os.path.join(HERE, 'viewshed.c'); so = os.path.join(HERE, 'libviewshed.so')
    if not os.path.exists(so) or os.path.getmtime(so) < os.path.getmtime(src):
        subprocess.check_call(['gcc', '-O3', '-march=native', '-fopenmp', '-shared', '-fPIC', src, '-o', so, '-lm'])
    lib = ctypes.CDLL(so)
    P = np.ctypeslib.ndpointer
    f32, u8 = P(dtype=np.float32, flags='C_CONTIGUOUS'), P(dtype=np.uint8, flags='C_CONTIGUOUS')
    I, F = ctypes.c_int, ctypes.c_float
    lib.viewshed.argtypes = [I, I, F, F, F, f32, I, f32, I, F, F, u8]
    return lib


def viewshed(grid, eyes, rays=1440, maxd=12000.0, lift=18.0):
    """grid: a source.Grid; eyes: (n, 3) x, y, z. Returns uint8 per cell: 1 the ground seen, 2 a tree's crown seen."""
    vis = np.zeros(grid.h.shape, np.uint8)
    _lib().viewshed(grid.nx, grid.nz, float(grid.x0), float(grid.z0), float(grid.res), np.ascontiguousarray(grid.h, np.float32),
                    len(eyes), np.ascontiguousarray(eyes, np.float32), rays, float(maxd), float(lift), vis)
    return vis
