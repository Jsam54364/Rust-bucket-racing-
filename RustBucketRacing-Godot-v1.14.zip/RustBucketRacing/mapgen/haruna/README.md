# The Mt. Haruna generator

Builds `haruna.bin` (the installable map; its description is `maps/haruna.json` next to the pack in the map zips): Gunma
prefectural road 33 (Shibukawa-Matsuida line) from the Yaseone Pass parking down to the Tokutomi Roka museum's car park
(P1) above Ikaho, 7.6 km and 449 m lower, rebuilt from GSI Japan's open map data (出典：国土地理院). Not part of the game
build (`mapgen/.gdignore` keeps Godot out of this folder).

Needs Python 3 with numpy, scipy, scikit-image, matplotlib and Pillow (webp), gcc (the viewshed here and the ray tracer
in `../bake`), Godot 4.7 (set `GODOT` to its binary: it makes the LODs headless), internet access to
cyberjapandata.gsi.go.jp the first time (the tiles are cached in `gsi/`, about 40 MB), and the Irohazaka source model's
`sost_irohazaka.kn5` (set `IROHA_KN5`) for the road, wall and sign textures, and LOLIPOP's foliage packs from
Sketchfab (CC BY 4.0; set `FOLIAGE` to the folder holding them as `oak.glb`, `maple.glb`, `fir.glb`, `bush.glb` and
`grass.glb`): "Oak trees pack (17var, LODs, seasons, gameready)", "Maple trees pack (lowpoly, game ready, LODs)",
"Realistic fir trees pack (LODS, gameready)", "Bush models pack (gameready, LODs)", "Grass (pack of 9 vars, lowpoly,
game ready)".

    GODOT=/path/to/godot python3 gen.py haruna.bin                                  # ~2 min (more the first time: the tiles)
    python3 check_phys.py haruna.bin                                                # holes and steps in the drive surface
    python3 ../bake/bake_light.py haruna.bin --sky kloofendal_48d_partly_cloudy_puresky   # shadows, sky light, bounce

- `gsi.py`: the tiles: road centrelines (z16 GeoJSON), elevation (5 m laser, 10 m), aerial photos; cached
- `source.py`: the road's line (the prefectural road's centrelines between the two car parks, carried on past both),
  its heights (the 5 m model across the road, with the dips where the laser model has no culvert taken out), the
  ground everywhere (5 m model near, 30 m to 12 km), the stage's two lines, the two car parks (traced from the 0.5 m
  photos), and the outline of the area of full detail (`outline.json`, drawn round the road on the route preview)
- `gen.py`: the road (6.8 m, widened inside tight bends, crowned and banked), its paint, the car parks, the ground
  (one triangulation: dense by the road, full inside the outline; past it coarse and only where the cameras can see),
  guardrails, collisions, trees where the photos show forest, grass, bushes and young trees by the road, the base
  map's buildings (walls with windows, roofs from the photos), chevrons and warning signs; the pack
- `vis.py`, `viewshed.c`: what the cameras can see: rays over the ground from the road at 2, 22 and 60 m up and 40 m to
  either side (the chase and orbit cameras' reach)
- `panorama.py`: the horizon past 12 km (the Kanto plain, Akagi, Komochi, Onoko, Asama, the Tanigawa range): drawn from
  the elevation and photos, hazed, on a ring of cards 13.5 km out
- `foliage.py`, `gltf.py`: the foliage packs: each tree's own billboard taken apart into two crossed planes and a
  level crown (four views to a texture layer, recoloured to one green), and the real meshes of the grass clumps, small
  bushes and young trees placed by the road
- `assets.py`: textures (the Irohazaka model's, a guardrail and building walls drawn here, the aerial photos as
  ground) and materials
