"""glTF 2.0 binary (.glb) reading with the node tree applied: every mesh instance in world space (metres, y up)."""
import io, json, struct
import numpy as np
from PIL import Image
CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def _mat(n):
    if 'matrix' in n: return np.array(n['matrix'], np.float64).reshape(4, 4).T
    M = np.eye(4)
    if 'scale' in n: M = np.diag(list(n['scale']) + [1.0]) @ M
    if 'rotation' in n:
        x, y, z, w = n['rotation']
        R = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                      [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                      [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
        R4 = np.eye(4); R4[:3, :3] = R; M = R4 @ M
    if 'translation' in n:
        T = np.eye(4); T[:3, 3] = n['translation']; M = T @ M
    return M


class Glb:
    def __init__(self, path):
        b = open(path, 'rb').read()
        cl = struct.unpack('<I', b[12:16])[0]; self.j = j = json.loads(b[20:20 + cl])
        off = 20 + cl; bl = struct.unpack('<I', b[off:off + 4])[0]; self.bin = b[off + 8: off + 8 + bl]
        self.meshes = j.get('meshes', []); self.materials = j.get('materials', [])
        # world matrix of every node that holds a mesh
        self.inst = []                                   # (mesh index, node name, world matrix)
        def walk(i, M):
            n = j['nodes'][i]; W = M @ _mat(n)
            if 'mesh' in n: self.inst.append((n['mesh'], n.get('name', ''), W))
            for c in n.get('children', []): walk(c, W)
        for r in j['scenes'][j.get('scene', 0)]['nodes']: walk(r, np.eye(4))

    def acc(self, i):
        a = self.j['accessors'][i]; bv = self.j['bufferViews'][a['bufferView']]
        dt = np.dtype(CT[a['componentType']]); n = NC[a['type']]
        start = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        stride = bv.get('byteStride', 0) or dt.itemsize * n
        raw = np.frombuffer(self.bin, np.uint8, count=stride * (a['count'] - 1) + dt.itemsize * n, offset=start)
        out = np.lib.stride_tricks.as_strided(raw, (a['count'], n * dt.itemsize), (stride, 1)).copy().view(dt).reshape(a['count'], n)
        if a.get('normalized') and dt.kind in 'iu': out = out.astype(np.float64) / np.iinfo(dt).max
        return out if n > 1 else out[:, 0]

    def parts(self, mesh_index, W):
        """the mesh's primitives in world space: P, N, UV, I, material index"""
        out = []
        for p in self.meshes[mesh_index]['primitives']:
            at = p['attributes']
            P = self.acc(at['POSITION']).astype(np.float64)
            P = (np.c_[P, np.ones(len(P))] @ W.T)[:, :3]
            N = self.acc(at['NORMAL']).astype(np.float64) if 'NORMAL' in at else np.tile([0, 1.0, 0], (len(P), 1))
            N = N @ np.linalg.inv(W[:3, :3]).T if 'NORMAL' in at else N
            N /= np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-12)
            U = self.acc(at['TEXCOORD_0']).astype(np.float64) if 'TEXCOORD_0' in at else np.zeros((len(P), 2))
            I = self.acc(p['indices']).astype(np.int64).reshape(-1, 3) if 'indices' in p else np.arange(len(P)).reshape(-1, 3)
            if np.linalg.det(W[:3, :3]) < 0: I = I[:, [0, 2, 1]]
            out.append(dict(P=P, N=N, U=U, I=I, mat=p.get('material', -1)))
        return out

    def image(self, tex_index):
        src = self.j['textures'][tex_index]['source']
        bv = self.j['bufferViews'][self.j['images'][src]['bufferView']]
        im = Image.open(io.BytesIO(self.bin[bv.get('byteOffset', 0): bv.get('byteOffset', 0) + bv['byteLength']])); im.load()
        return im

    def base_image(self, mat_index):
        pbr = self.materials[mat_index].get('pbrMetallicRoughness', {})
        t = pbr.get('baseColorTexture', {}).get('index')
        return None if t is None else self.image(t)
