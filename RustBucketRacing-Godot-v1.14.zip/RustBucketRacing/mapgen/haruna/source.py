"""Where the Mt. Haruna map comes from: GSI Japan's open map data (gsi.py; 出典：国土地理院).

  * the road: Gunma prefectural road 33 (Shibukawa-Matsuida line) as GSI draws it, traced along the prefectural
    road centrelines from the Yaseone Pass parking down to the Tokutomi Roka museum's car park (P1) above Ikaho,
    carried on a little past both; smoothed; in metres on a local plane (x east, z south, y up)
  * its heights: the 5 m elevation model (airborne laser), smoothed along the road
  * the ground: the same 5 m model round the road, 10 m (from 30 m cells) out to 12 km, 150 m to the horizon
  * the area of full detail: the outline drawn round the road (outline.json)

Importing it does the work (a few seconds once the tiles are cached)."""
import heapq, json, math, os, time
import numpy as np
from scipy.ndimage import gaussian_filter1d, median_filter, map_coordinates
import gsi

HERE = os.path.dirname(os.path.abspath(__file__))
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)

START_LOT = (36.48367, 138.89658)        # Yaseone Pass parking: the lay-by on the west side of the road
TOP_LINE = (36.48419, 138.89677)         # ...its north end, where it rejoins the road: the stage's top line
FINISH_LOT = (36.498434, 138.914850)     # Tokutomi Roka museum's car park P1, inside the last hairpin above Ikaho
SEARCH = (36.470, 138.880, 36.514, 138.935)
LAT0, LON0 = 36.4930, 138.9058           # the local plane's origin (the middle of the route)
_p = math.radians(LAT0)
M_LAT = 111132.954 - 559.822 * math.cos(2 * _p) + 1.175 * math.cos(4 * _p)
M_LON = 111412.84 * math.cos(_p) - 93.5 * math.cos(3 * _p)


def to_xz(lat, lon):
    return (np.asarray(lon) - LON0) * M_LON, -(np.asarray(lat) - LAT0) * M_LAT


def to_ll(x, z):
    return LAT0 - np.asarray(z) / M_LAT, LON0 + np.asarray(x) / M_LON


# ---------------------------------------------------------------- the road's line
def _route():
    """prefectural road centrelines between the two car parks (a shortest path; other roads cost 100x), carried on
    along the prefectural road past both ends; bottom (Ikaho) first"""
    key = lambda q: (round(q[1], 6), round(q[0], 6))
    g = {}
    for p, c in gsi.roads(*SEARCH):
        if p['rdCtg'] != '都道府県道': continue
        pts = [key(q) for q in c]
        for a, b in zip(pts, pts[1:]):
            if a == b: continue
            d = float(np.hypot((a[0] - b[0]) * M_LAT, (a[1] - b[1]) * M_LON))
            g.setdefault(a, []).append((b, d)); g.setdefault(b, []).append((a, d))
    dist = lambda a, b: float(np.hypot((a[0] - b[0]) * M_LAT, (a[1] - b[1]) * M_LON))
    near = lambda p: min(g, key=lambda a: dist(a, p))
    s, t = near(FINISH_LOT), near(START_LOT)
    q = [(0.0, s)]; prev = {s: None}; best = {s: 0.0}
    while q:
        d, a = heapq.heappop(q)
        if a == t: break
        if d > best[a]: continue
        for b, l in g[a]:
            if d + l < best.get(b, 1e18): best[b] = d + l; prev[b] = a; heapq.heappush(q, (d + l, b))
    path = [t]
    while prev[path[-1]] is not None: path.append(prev[path[-1]])
    path = path[::-1]

    def carry(path, L):
        """on along the road from the path's last node for L metres (the branch that turns least)"""
        out = list(path); run = 0.0
        while run < L:
            a, b = out[-2], out[-1]
            h0 = math.atan2((b[0] - a[0]) * M_LAT, (b[1] - a[1]) * M_LON)
            nxt = [(c, l) for c, l in g[b] if c != a and c not in out[-6:]]
            if not nxt: break
            def turn(c):
                h1 = math.atan2((c[0] - b[0]) * M_LAT, (c[1] - b[1]) * M_LON)
                return abs((h1 - h0 + math.pi) % (2 * math.pi) - math.pi)
            c, l = min(nxt, key=lambda cl: turn(cl[0]))
            out.append(c); run += l
        return out
    path = carry(path, 220)                               # past the Yaseone parking, towards the lake
    path = carry(path[::-1], 160)[::-1]                   # into Ikaho, past the museum
    return np.array(path)                                 # (lat, lon)


def _resample(P, step):
    s = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
    u = np.arange(0, s[-1] + 1e-9, step)
    return np.c_[np.interp(u, s, P[:, 0]), np.interp(u, s, P[:, 1])]


def normals(line):
    t = np.gradient(line, axis=0); t /= np.linalg.norm(t, axis=1, keepdims=True)
    return t, np.stack([-t[:, 1], t[:, 0]], 1)


# ---------------------------------------------------------------- elevation
class Grid:
    """heights on a square grid of the local plane (cell centres at x0 + (i + 0.5) res); bilinear"""
    def __init__(self, x0, z0, res, h):
        self.x0, self.z0, self.res, self.h = x0, z0, res, h.astype(np.float32)
        self.nz, self.nx = h.shape
        self.x1 = x0 + self.nx * res; self.z1 = z0 + self.nz * res

    def __call__(self, x, z):
        x = np.asarray(x, np.float64); z = np.asarray(z, np.float64)
        c = (x - self.x0) / self.res - 0.5; r = (z - self.z0) / self.res - 0.5
        return map_coordinates(self.h, [r.ravel(), c.ravel()], order=1, mode='nearest').reshape(x.shape)

    def inside(self, x, z, margin=0.0):
        return (x >= self.x0 + margin) & (x <= self.x1 - margin) & (z >= self.z0 + margin) & (z <= self.z1 - margin)


def _grid(name, x0, z0, x1, z1, res, sources):
    """a Grid over a box from GSI elevation tiles, the first source that has a height at each point"""
    cache = os.path.join(gsi.CACHE, f'grid_{name}.npz')
    if os.path.exists(cache):
        c = np.load(cache)
        if c['spec'].tolist() == [x0, z0, x1, z1, res]: return Grid(x0, z0, res, c['h'])
    nx, nz = int(round((x1 - x0) / res)), int(round((z1 - z0) / res))
    X, Z = np.meshgrid(x0 + (np.arange(nx) + 0.5) * res, z0 + (np.arange(nz) + 0.5) * res)
    lat, lon = to_ll(X, Z)
    h = np.full(X.shape, np.nan)
    for layer, z in sources:
        todo = np.isnan(h)
        if not todo.any(): break
        m = gsi.Mosaic(layer, z, 'png', float(lat[todo].min()) - 0.002, float(lon[todo].min()) - 0.002,
                       float(lat[todo].max()) + 0.002, float(lon[todo].max()) + 0.002)
        px, py = m.px(lat[todo], lon[todo])
        v = map_coordinates(m.a, [py - 0.5, px - 0.5], order=1, mode='nearest', cval=np.nan)
        h[todo] = v
        log(f'  {name}: {layer} z{z}: {np.isfinite(v).sum()} of {todo.sum()} points')
    if np.isnan(h).any():
        from scipy.ndimage import distance_transform_edt
        idx = distance_transform_edt(np.isnan(h), return_distances=False, return_indices=True)
        h = h[tuple(idx)]
    np.savez(cache, h=h.astype(np.float32), spec=np.array([x0, z0, x1, z1, res]))
    return Grid(x0, z0, res, h)


# ---------------------------------------------------------------- build
RAW = _route()
_x, _z = to_xz(RAW[:, 0], RAW[:, 1])
_P = _resample(np.c_[_x, _z], 1.0)
_P = np.c_[gaussian_filter1d(_P[:, 0], 3.5, mode='nearest'), gaussian_filter1d(_P[:, 1], 3.5, mode='nearest')]
line = _resample(_P, 2.0)                                 # the road's centreline, bottom first, 2 m steps
line_len = float(np.hypot(*np.diff(line, axis=0).T).sum())
sl = np.r_[0, np.cumsum(np.hypot(*np.diff(line, axis=0).T))]

_bx0, _bz0 = line.min(0) - 900; _bx1, _bz1 = line.max(0) + 900
_bx0, _bz0, _bx1, _bz1 = [float(np.floor(v / 50) * 50) for v in (_bx0, _bz0)] + [float(np.ceil(v / 50) * 50) for v in (_bx1, _bz1)]
dem = _grid('near', _bx0, _bz0, _bx1, _bz1, 5.0, [('dem5a_png', 15), ('dem5b_png', 15), ('dem10b_png', 14), ('dem_png', 14)])
dem_far = _grid('far', -12000.0, -12000.0, 12000.0, 12000.0, 30.0, [('dem_png', 13), ('dem_png', 12)])
log(f'elevation: near {dem.nx}x{dem.nz} at {dem.res:.0f} m ({dem.h.min():.0f}-{dem.h.max():.0f} m), far {dem_far.nx}x{dem_far.nz} at {dem_far.res:.0f} m '
    f'({dem_far.h.min():.0f}-{dem_far.h.max():.0f} m)')


def ground(x, z):
    """the bare ground's height anywhere: the 5 m model where it reaches, the coarse one beyond"""
    x = np.asarray(x, np.float64); z = np.asarray(z, np.float64)
    out = dem_far(x, z)
    ins = dem.inside(x, z, 10.0)
    if np.any(ins): out = np.where(ins, dem(np.where(ins, x, dem.x0 + 20), np.where(ins, z, dem.z0 + 20)), out)
    return out


def _heights():
    """the road's height: the ground model across the middle of the road (the median of five points over 4 m),
    smoothed"""
    t, n = normals(line)
    h = np.median(np.stack([dem(line[:, 0] + n[:, 0] * o, line[:, 1] + n[:, 1] * o) for o in (-2, -1, 0, 1, 2)]), 0)
    # (the laser model has no bridges or culverts: where the road crosses a gully it dips; a wide median and a
    # second pass that drops what stands out more than 0.6 m from the first take them out)
    h1 = gaussian_filter1d(median_filter(h, 21, mode='nearest'), 5, mode='nearest')
    ok = np.abs(h - h1) < 0.6
    h2 = np.interp(sl, sl[ok], h[ok])
    h2 = gaussian_filter1d(median_filter(h2, 9, mode='nearest'), 4, mode='nearest')
    return h2, dem(line[:, 0], line[:, 1])
ly, ly_raw = _heights()


def s_of(lat, lon):
    x, z = to_xz(lat, lon)
    return float(sl[int(np.argmin(np.hypot(line[:, 0] - x, line[:, 1] - z)))])


S_START = s_of(*FINISH_LOT)          # the bottom line, by the museum's car park
S_FINISH = s_of(*TOP_LINE)           # the top line, at the end of the Yaseone parking
assert S_FINISH > S_START

# the area of full detail, as drawn round the road
OUTLINE = np.array(json.load(open(os.path.join(HERE, 'outline.json'))))
OUT_XZ = np.c_[to_xz(OUTLINE[:, 0], OUTLINE[:, 1])]


def in_outline(x, z):
    from matplotlib.path import Path
    return Path(OUT_XZ).contains_points(np.c_[np.ravel(x), np.ravel(z)]).reshape(np.shape(x))


_g = np.gradient(ly, sl)
log(f'road: {line_len:.0f} m, {len(line)} points, {ly[0]:.0f} m to {ly[-1]:.0f} m; stage {S_START:.0f}-{S_FINISH:.0f} m '
    f'({S_FINISH - S_START:.0f} m, {np.interp(S_FINISH, sl, ly) - np.interp(S_START, sl, ly):.0f} m climb), steepest '
    f'{100 * np.abs(_g).max():.1f} %; road vs ground model at its middle: {np.abs(ly - ly_raw).mean():.2f} m mean')


# ---------------------------------------------------------------- the two car parks, from the aerial photos
def _road_score(a):
    """0..1: how much a pixel of an aerial photo looks like tarmac (grey, not green, not in deep shadow)"""
    a = a.astype(np.float32) / 255
    mx = a.max(-1); mn = a.min(-1)
    sat = (mx - mn) / np.maximum(mx, 1e-3)
    green = a[..., 1] - np.maximum(a[..., 0], a[..., 2])
    return np.clip(1 - sat / 0.25, 0, 1) * np.clip(1 - green / 0.04, 0, 1) * np.clip((mx - 0.2) / 0.12, 0, 1)


def _lot(seed, reach, road_half):
    """the paved area within `reach` m of `seed` (lat, lon) in the 0.5 m photos, without the road itself: an outline
    (local x, z) and its area"""
    from scipy import ndimage
    from skimage import measure
    la, lo = seed
    d = reach / M_LAT
    m = gsi.Mosaic('seamlessphoto', 18, 'jpg', la - d, lo - d * M_LAT / M_LON, la + d, lo + d * M_LAT / M_LON)
    sc = _road_score(m.a) > 0.45
    sc = ndimage.binary_closing(sc, structure=np.ones((5, 5)))          # white bay lines, cars, little shadows
    sc = ndimage.binary_opening(sc, structure=np.ones((5, 5)))
    # the road's own strip is not the car park
    H, W = sc.shape
    py, px = np.mgrid[0:H, 0:W]
    lat, lon = m.ll(px + 0.5, py + 0.5)
    X, Z = to_xz(lat, lon)
    from scipy.spatial import cKDTree
    dr, _ = cKDTree(line).query(np.c_[X.ravel(), Z.ravel()])
    sx, sz = to_xz(*seed)
    k = np.hypot(X - sx, Z - sz)
    sc &= (dr.reshape(H, W) > road_half) & (k < reach)
    lab, n = ndimage.label(sc)
    cand = [(np.sum(lab == i), i) for i in range(1, n + 1) if (k[lab == i] < 12).any()]
    i = max(cand)[1]
    mask = ndimage.binary_fill_holes(lab == i)
    c = max(measure.find_contours(mask.astype(float), 0.5), key=len)
    c = measure.approximate_polygon(c, 1.5)
    lat, lon = m.ll(c[:, 1] + 0.5, c[:, 0] + 0.5)
    return np.c_[to_xz(lat, lon)], float(mask.sum() * (0.48 ** 2))


LOTS = {name: _lot(seed, reach, 4.6)[0] for name, seed, reach in (('yaseone', START_LOT, 60.0), ('p1', FINISH_LOT, 46.0))}
log('car parks: ' + ', '.join(f'{k} {0.5 * abs(np.dot(v[:, 0], np.roll(v[:, 1], 1)) - np.dot(v[:, 1], np.roll(v[:, 0], 1))):.0f} m2' for k, v in LOTS.items()))


# ---------------------------------------------------------------- buildings
def _buildings():
    """building outlines (GSI's base map) inside the outline's box and round Ikaho below the finish: (kind, outline
    in local x, z); 'solid' are concrete (堅ろう建物), the rest ordinary"""
    la, lo = OUTLINE[:, 0], OUTLINE[:, 1]
    fl, fo = FINISH_LOT
    found = gsi.buildings(la.min(), lo.min(), la.max(), lo.max()) + gsi.buildings(fl - 0.0045, fo - 0.002, fl + 0.004, fo + 0.0075)
    out, seen = [], set()
    for t, ring in found:
        c = np.array(ring[:-1])
        k = (round(c[:, 0].mean(), 6), round(c[:, 1].mean(), 6))
        if k in seen: continue
        seen.add(k)
        x, z = to_xz(c[:, 1], c[:, 0])
        P = np.c_[x, z]
        a = 0.5 * (np.dot(P[:, 0], np.roll(P[:, 1], 1)) - np.dot(P[:, 1], np.roll(P[:, 0], 1)))
        if not (8 < abs(a) < 4000): continue
        if a < 0: P = P[::-1]                       # one way round (counter-clockwise seen from above, x east z south)
        out.append(('solid' if '堅ろう' in t else 'house', P))
    return out


BUILDINGS = _buildings()
log(f'buildings: {len(BUILDINGS)} outlines')
