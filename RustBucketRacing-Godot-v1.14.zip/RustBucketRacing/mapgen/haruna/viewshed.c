// What can be seen from a set of camera positions over a heightfield (cells of `res` metres, centres at
// x0 + (i + 0.5) res): from each eye, rays out in every direction over the ground; a cell is seen when its ground
// (bit 1) or the top of what stands on it, `lift` metres up (bit 2), rises above everything nearer on that ray.
// Built by vis.py with gcc and OpenMP.
#include <math.h>
#include <stdint.h>

void viewshed(int nx, int nz, float x0, float z0, float res, const float *h, int nv, const float *eye,
              int nr, float maxd, float lift, uint8_t *vis)
{
    #pragma omp parallel for schedule(dynamic, 4)
    for (int v = 0; v < nv; v++) {
        const float ex = eye[3 * v], ey = eye[3 * v + 1], ez = eye[3 * v + 2];
        for (int r = 0; r < nr; r++) {
            float a = 6.2831853f * (r + 0.37f * (v % 3)) / nr;
            float dx = cosf(a), dz = sinf(a);
            float best = -1e9f, t = 0.6f * res;
            while (t < maxd) {
                float fc = (ex + dx * t - x0) / res - 0.5f, fr = (ez + dz * t - z0) / res - 0.5f;
                if (fc < 0 || fr < 0 || fc >= nx - 1 || fr >= nz - 1) break;
                int c = (int)fc, w = (int)fr;
                float u = fc - c, q = fr - w;
                const float *p = h + (long)w * nx + c;
                float hh = (p[0] * (1 - u) + p[1] * u) * (1 - q) + (p[nx] * (1 - u) + p[nx + 1] * u) * q;
                float sg = (hh - ey) / t, st = (hh + lift - ey) / t;
                long cell = (long)(int)(fr + 0.5f) * nx + (int)(fc + 0.5f);
                if (sg >= best) vis[cell] |= 1;
                if (st >= best) vis[cell] |= 2;
                if (sg > best) best = sg;
                t += fmaxf(0.5f * res, t * 0.004f);
            }
        }
    }
}
