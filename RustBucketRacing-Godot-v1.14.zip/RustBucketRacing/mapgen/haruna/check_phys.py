"""drive-surface check of the Mt. Haruna pack: along the centreline and across the road, the highest physics triangle
at or under each probe (like the game's MeshTerrain): holes, and steps the road's own profile doesn't have"""
import json, struct, gzip, sys, numpy as np
from collections import defaultdict
path = sys.argv[1] if len(sys.argv) > 1 else 'haruna.bin'
d = open(path, 'rb').read()
n = struct.unpack('<I', d[4:8])[0]; h = json.loads(d[8:8 + n]); bas = 8 + n
g = h['geo']; geo = gzip.decompress(d[bas + g[0]: bas + g[0] + g[1]])
V = np.frombuffer(geo[:g[2]], dtype=[('p', '<i2', 3), ('pad', '<i2'), ('n', 'i1', 4), ('uv', '<i2', 2)])
I = np.frombuffer(geo[g[2]:g[2] + g[3]], '<u2')
mats = h['materials']
T, S = [], []
for ch in h['chunks']:
    qs = ch.get('qs', h['qs']); o = np.array(ch['o'])
    V0, VN = ch['v']; I0, IN = ch['i']
    P = V['p'][V0:V0 + VN].astype(np.float64) / qs + o
    for dd in ch['d']:
        m = mats[dd[0]]
        if m['surf'] <= 0 or m['mode'] == 2: continue
        idx = I[I0 + dd[1]: I0 + dd[1] + dd[4]].astype(np.int64)
        T.append(P[idx].reshape(-1, 3, 3)); S.append(np.full(len(idx) // 3, m['surf']))
T = np.concatenate(T); S = np.concatenate(S)
print(f'{len(T)} physics triangles')
C = 8.0
x0, z0 = T[:, :, 0].min(), T[:, :, 2].min()
cells = defaultdict(list)
ix0 = np.floor((T[:, :, 0].min(1) - x0) / C).astype(int); ix1 = np.floor((T[:, :, 0].max(1) - x0) / C).astype(int)
iz0 = np.floor((T[:, :, 2].min(1) - z0) / C).astype(int); iz1 = np.floor((T[:, :, 2].max(1) - z0) / C).astype(int)
for t in range(len(T)):
    for a in range(ix0[t], ix1[t] + 1):
        for b in range(iz0[t], iz1[t] + 1): cells[(a, b)].append(t)
def top(x, z, ymax):
    best = -1e9; bs = 0
    for t in cells.get((int(np.floor((x - x0) / C)), int(np.floor((z - z0) / C))), ()):
        A, B, Cc = T[t]
        d = (B[2] - Cc[2]) * (A[0] - Cc[0]) + (Cc[0] - B[0]) * (A[2] - Cc[2])
        if abs(d) < 1e-12: continue
        l1 = ((B[2] - Cc[2]) * (x - Cc[0]) + (Cc[0] - B[0]) * (z - Cc[2])) / d
        l2 = ((Cc[2] - A[2]) * (x - Cc[0]) + (A[0] - Cc[0]) * (z - Cc[2])) / d
        l3 = 1 - l1 - l2
        if min(l1, l2, l3) < -1e-6: continue
        y = l1 * A[1] + l2 * B[1] + l3 * Cc[1]
        if y <= ymax and y > best: best = y; bs = S[t]
    return best, bs
def blob(r, n): return np.frombuffer(d[bas + r[0]: bas + r[0] + n * 4], '<f4')
L = blob(h['line'], h['line'][2] * 2).reshape(-1, 2).astype(np.float64); Ly = blob(h['lineY'], h['lineY'][2]).astype(np.float64)
half = h['meta']['width'] / 2
holes = 0; offp = 0; mx = 0
for i in range(len(L)):
    a = max(i - 1, 0); b = min(i + 1, len(L) - 1)
    t = L[b] - L[a]; t /= max(np.linalg.norm(t), 1e-9); nn = np.array([-t[1], t[0]])
    for o in (0.0, half * 0.85, -half * 0.85):
        x, z = L[i] + nn * o
        y, s = top(x, z, Ly[i] + 1.5)
        if y < -1e8:
            holes += 1
            if holes <= 5: print(f"    hole at ({x:.1f}, {z:.1f}), probe {i} of {len(L)}, offset {o:.1f}")
            continue
        if o == 0:
            dev = abs(y - Ly[i]); mx = max(mx, dev)
            if dev > 0.12: offp += 1
print(f"centreline {len(L)} probes x3: holes {holes}, centre off the line's height by >12 cm {offp}, max {mx:.2f} m")
s = np.r_[0, np.cumsum(np.hypot(*np.diff(L, axis=0).T))]
ss = np.arange(0, s[-1], 0.5)
X = np.interp(ss, s, L[:, 0]); Z = np.interp(ss, s, L[:, 1]); Y = np.interp(ss, s, Ly)
ys = np.array([top(X[i], Z[i], Y[i] + 2.5)[0] for i in range(len(ss))])
dy = np.abs(np.diff(ys) - np.diff(Y))
bad = np.nonzero(dy > 0.04)[0]
print(f"steps along the centre (> 4 cm beyond the profile between probes 0.5 m apart): {len(bad)}" +
      (f", worst {dy.max():.2f} m at {ss[np.argmax(dy)]:.1f} m of {s[-1]:.1f} ({X[np.argmax(dy)]:.1f}, {Z[np.argmax(dy)]:.1f})" if len(bad) else ''))
