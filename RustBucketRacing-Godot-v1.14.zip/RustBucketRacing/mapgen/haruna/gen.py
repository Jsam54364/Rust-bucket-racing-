"""Build the Mt. Haruna map: Gunma prefectural road 33 from the Yaseone Pass parking down the hairpins to the
Tokutomi Roka museum's car park above Ikaho, from GSI Japan's open data (source.py; 出典：国土地理院).

  * the road: a ribbon along the centreline (1 m steps in the bends, 2 m on the straights), 6.8 m of tarmac
    widened on the inside of tight bends, a 2 % crown on the straights, banked up to 6 % in the bends; white edge
    lines, a yellow centre line, the stage's two lines; the two car parks as they are in the photos
  * the ground, in full inside the outline drawn round the road: one triangulation, dense rows beside the road,
    coarser out to the outline; the verges, gutters, walls and cuttings textured by their slope, the rest wearing
    the aerial photo of that ground
  * beyond the outline, out to 12 km: the same ground, coarse, only where a camera on the road (up to the orbit
    camera's 60 m) can see it, in the aerial photos; past that, the horizon on a ring of cards (panorama.py)
  * guardrails where the ground drops away, collisions along them, along the walls and round the car parks
  * trees: cards on the forested ground (from the photos), dense by the road, thinning outwards, carried on past
    the outline where the cameras can see their crowns; forest-edge cards along the road
  * chevrons round the hairpins, a few warning signs
  * chunks, LODs, one texture array (../compound/writer.py); then the light baked in (../bake/bake_light.py)

    GODOT=/path/to/godot python3 gen.py haruna.bin
"""
import os, sys, time, json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d, median_filter
from scipy.spatial import cKDTree, Delaunay

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(1, os.path.join(HERE, '..', 'compound')); sys.path.insert(2, os.path.join(HERE, '..', 'bake'))
import source as S
import assets as AS
import panorama as PANO
import foliage as FOL
import vis as VIS
from geom import Mesh, strip, grid_tris, quad, cards

OUT = next((a for a in sys.argv[1:] if not a.startswith('--')), 'haruna.bin')
log = S.log
rng = np.random.default_rng(33)
SKY = 'kloofendal_48d_partly_cloudy_puresky'
FOG = 0.00006
MID_R = 12000.0                  # the coarse ground reaches this far from the middle; the horizon's cards beyond


# ---------------------------------------------------------------- the road
def stations():
    P = S.line; s0 = S.sl
    t, _ = S.normals(P)
    ang = np.unwrap(np.arctan2(t[:, 1], t[:, 0]))
    kap = np.abs(np.gradient(gaussian_filter1d(ang, 2), s0))
    s, out = 0.0, [0.0]
    while s < s0[-1] - 0.5:
        s += 1.0 if np.interp(s, s0, kap) > 1 / 45 else 2.0
        out.append(min(s, s0[-1]))
    s = np.array(out)
    Q = np.c_[np.interp(s, s0, P[:, 0]), np.interp(s, s0, P[:, 1])]
    return s, Q, np.interp(s, s0, S.ly)


ST_S, ST_P, ST_Y = stations()
ST_T, ST_N = S.normals(ST_P)
NS = len(ST_P)
_ang = np.unwrap(np.arctan2(ST_T[:, 1], ST_T[:, 0]))
ST_K = np.gradient(gaussian_filter1d(_ang, 3), ST_S)          # curvature, + turning towards +normal (right)
ST_R = 1 / np.maximum(np.abs(ST_K), 1e-4)
log(f'road: {NS} stations over {ST_S[-1]:.0f} m; {int((ST_R < 25).sum())} stations in bends under 25 m')


def road_edges():
    """the tarmac's edges (offsets along the normal: lo < 0 < hi): 3.4 m each side, the inside of a tight bend
    widened (up to 2.6 m at a 10 m hairpin), never past the bend's own centre, never running backwards"""
    widen = np.clip(30.0 / ST_R - 0.35, 0, 2.6)
    widen = gaussian_filter1d(ndimage.maximum_filter1d(widen, 9), 4, mode='nearest')
    hi = 3.4 + widen * (ST_K > 0); lo = -3.4 - widen * (ST_K < 0)
    hi = gaussian_filter1d(hi, 3, mode='nearest'); lo = gaussian_filter1d(lo, 3, mode='nearest')
    inner_hi = ST_K > 0
    lim = 0.92 * ST_R
    for it in range(3):
        hi = np.where(inner_hi, np.minimum(hi, lim), hi); lo = np.where(~inner_hi, np.maximum(lo, -lim), lo)
        if it < 2: hi = gaussian_filter1d(hi, 3, mode='nearest'); lo = gaussian_filter1d(lo, 3, mode='nearest')
    hi = np.maximum(hi, 2.6); lo = np.minimum(lo, -2.6)
    for side, E in ((1, hi), (-1, lo)):
        for it in range(60):
            e = ST_P + ST_N * E[:, None]
            fwd = np.einsum('ij,ij->i', np.diff(e, axis=0), (ST_T[:-1] + ST_T[1:]) / 2)
            bad = np.nonzero(fwd < 0.25 * np.diff(ST_S))[0]
            if not len(bad): break
            for b in bad:
                for j in (b, b + 1):
                    if abs(E[j]) > 2.0: E[j] -= side * 0.15
            E[:] = np.where(side > 0, np.maximum(gaussian_filter1d(E, 1.0, mode='nearest'), 2.0), np.minimum(gaussian_filter1d(E, 1.0, mode='nearest'), -2.0))
    log(f'road width: median {np.median(hi - lo):.2f} m, {np.percentile(hi - lo, 5):.1f}-{np.max(hi - lo):.1f} m')
    return lo, hi


ED_LO, ED_HI = road_edges()
FRAC = np.array([-1.0, -2 / 3, -1 / 3, 0.0, 1 / 3, 2 / 3, 1.0])


def offsets_of(idx=slice(None)):
    return np.where(FRAC[None, :] < 0, -FRAC[None, :] * ED_LO[idx, None], FRAC[None, :] * ED_HI[idx, None])


def road_mesh(mesh):
    """the surface: a 2 % crown, turning into one slope across (up to 6 %, the inside low) in the bends"""
    off = offsets_of()
    bank = np.clip(2.6 / ST_R, 0, 0.06)
    b = np.clip((bank - 0.015) / 0.015, 0, 1)
    crown = -0.02 * np.abs(off)
    banked = -bank[:, None] * np.sign(ST_K)[:, None] * off
    dy = (1 - b[:, None]) * crown + b[:, None] * banked
    dy = gaussian_filter1d(dy, 6, axis=0, mode='nearest')
    xz = ST_P[:, None, :] + ST_N[:, None, :] * off[..., None]
    P = np.dstack([xz[..., 0], ST_Y[:, None] + dy, xz[..., 1]])
    UV = np.dstack([off / 3.0, np.repeat(ST_S[:, None], len(FRAC), 1) / 3.0])
    I = grid_tris(NS, len(FRAC))
    A = P.reshape(-1, 3)
    up = np.cross(A[I[:, 1]] - A[I[:, 0]], A[I[:, 2]] - A[I[:, 0]])[:, 1]
    I = np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)
    mesh.add('road', A, UV.reshape(-1, 2), I, phys=True)
    log(f'road surface: {len(I)} triangles, banked up to {100 * bank.max():.0f} %')
    return P


def road_y(idx, d):
    """the road surface's height at offsets d across stations idx"""
    off = offsets_of(idx)
    return np.array([np.interp(d[k], off[k], ROAD_P[i, :, 1]) for k, i in enumerate(idx)])


# ---------------------------------------------------------------- paint
def band(mesh, mat, idx, d0, d1, lift=0.012):
    """a painted band over stations idx between offsets d0 and d1 (arrays or scalars) across the road"""
    if len(idx) < 2: return
    d0 = np.broadcast_to(d0, len(idx)); d1 = np.broadcast_to(d1, len(idx))
    def at(d):
        xz = ST_P[idx] + ST_N[idx] * d[:, None]
        return np.c_[xz[:, 0], road_y(idx, d) + lift, xz[:, 1]]
    P = np.stack([at(d0), at(d1)], 1).reshape(-1, 3)
    s = ST_S[idx]
    UV = np.stack([np.c_[np.zeros(len(idx)), s], np.c_[np.ones(len(idx)), s]], 1).reshape(-1, 2)
    I = grid_tris(len(idx), 2)
    up = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])[:, 1]
    I = np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)
    mesh.add(mat, P, UV, I, N=np.tile([0.0, 1.0, 0.0], (len(P), 1)), phys=True)


def runs_of(flags):
    out, i = [], 0
    while i < len(flags):
        if flags[i]:
            j = i
            while j + 1 < len(flags) and flags[j + 1]: j += 1
            out.append((i, j)); i = j + 1
        else: i += 1
    return out


def lot_stations():
    """stations where a car park opens off the road (no edge line, no wall there): side -1 / +1 flags"""
    near = {-1: np.zeros(NS, bool), 1: np.zeros(NS, bool)}
    from matplotlib.path import Path
    for poly in S.LOTS.values():
        pth = Path(poly)
        for side, E in ((-1, ED_LO), (1, ED_HI)):
            p = ST_P + ST_N * (E + side * 1.5)[:, None]
            near[side] |= pth.contains_points(p)
    for side in near: near[side] = ndimage.binary_dilation(near[side], iterations=2)
    return near


def paint(mesh):
    """white edge lines 25 cm in from the edges (not across the car parks' mouths), a yellow centre line (none
    round the hairpins), the stage's two lines"""
    LOT = lot_stations()
    for side, E in ((-1, ED_LO), (1, ED_HI)):
        for i0, i1 in runs_of(~LOT[side]):
            idx = np.arange(i0, i1 + 1)
            if side < 0: band(mesh, 'paint', idx, ED_LO[idx] + 0.25, ED_LO[idx] + 0.40)
            else: band(mesh, 'paint', idx, ED_HI[idx] - 0.40, ED_HI[idx] - 0.25)
    mid = (ED_LO + ED_HI) / 2
    centre = ndimage.binary_erosion(ST_R > 18, iterations=4)
    for i0, i1 in runs_of(centre):
        idx = np.arange(i0, i1 + 1)
        band(mesh, 'paint_y', idx, mid[idx] - 0.075, mid[idx] + 0.075)
    for s_line in (S.S_START, S.S_FINISH):
        i = min(max(int(np.searchsorted(ST_S, s_line)), 1), NS - 2)
        A = ST_P[i]; t = ST_T[i]; n_ = ST_N[i]
        y = ROAD_P[i, 3, 1] + 0.014
        a0, a1 = ED_LO[i] + 0.1, ED_HI[i] - 0.1
        pts = [A + n_ * a0 - t * 0.2, A + n_ * a1 - t * 0.2, A + n_ * a1 + t * 0.2, A + n_ * a0 + t * 0.2]
        P = np.array([[p[0], y, p[1]] for p in pts])
        I = np.array([[0, 1, 2], [0, 2, 3]])
        if np.cross(P[1] - P[0], P[2] - P[0])[1] < 0: I = I[:, [0, 2, 1]]
        mesh.add('paint', P, np.zeros((4, 2)), I, N=np.tile([0.0, 1.0, 0.0], (4, 1)), phys=True)


# ---------------------------------------------------------------- the ground
OFFS = np.array([0.5, 0.9, 1.4, 2.0, 2.8, 3.8, 5.0, 6.5, 8.5, 11.0, 14.0, 18.0])


def corridor_mask(R=0.25):
    """the road's own area on a raster (the ground leaves it out)"""
    E0 = ST_P + ST_N * ED_LO[:, None]; E1 = ST_P + ST_N * ED_HI[:, None]
    allp = np.vstack([E0, E1])
    x0, z0 = allp.min(0) - 30; x1, z1 = allp.max(0) + 30
    W_, H_ = int((x1 - x0) / R) + 1, int((z1 - z0) / R) + 1
    im = Image.new('L', (W_, H_), 0); d = ImageDraw.Draw(im)
    for i in range(NS - 1):
        poly = [E0[i], E1[i], E1[i + 1], E0[i + 1]]
        d.polygon([((p[0] - x0) / R, (p[1] - z0) / R) for p in poly], fill=255)
    return dict(m=np.array(im) > 0, x0=x0, z0=z0, R=R)


def in_corridor(C, xz, shrink=0):
    m = C['m']
    if shrink: m = ndimage.binary_erosion(m, iterations=shrink)
    c = ((xz[:, 0] - C['x0']) / C['R']).astype(int); r = ((xz[:, 1] - C['z0']) / C['R']).astype(int)
    ok = (c >= 0) & (r >= 0) & (c < m.shape[1]) & (r < m.shape[0])
    out = np.zeros(len(xz), bool)
    out[ok] = m[r[ok], c[ok]]
    return out


def in_lots(x, z):
    from matplotlib.path import Path
    out = np.zeros(np.size(x), bool)
    for poly in S.LOTS.values(): out |= Path(poly).contains_points(np.c_[np.ravel(x), np.ravel(z)])
    return out


EDGE_TREE = None


def edge_dist(xz):
    return EDGE_TREE.query(xz)


# the ground model's height at the middle of the road against the road's own: its offset, carried onto the ground
# beside the road (so the rows meet the road whatever the model makes of the road's bench)
_bias = gaussian_filter1d(ST_Y - S.dem(ST_P[:, 0], ST_P[:, 1]), 5, mode='nearest')


def ground_y(xz, stn=None, dR=None):
    """the ground's height at points: the ground model, with the road's bias near the road (full within 6 m of an
    edge, none past 20 m)"""
    y = S.ground(xz[:, 0], xz[:, 1])
    if dR is None or stn is None:
        dR, j = edge_dist(xz); stn = j % NS
    w = np.clip((20.0 - dR) / 14.0, 0, 1)
    return y + _bias[stn] * w


def visible_cells():
    """what the cameras see beyond the outline (vis.py): from the road every ~24 m at 2, 22 and 60 m up (the chase
    and orbit cameras' reach) and 40 m to either side at 15 m up; a 15 m grid out to MID_R, the seen cells grown by
    45 m"""
    res = 15.0
    xs = np.arange(-MID_R - 300, MID_R + 300, res) + res / 2
    X, Z = np.meshgrid(xs, xs)
    G = S.Grid(float(xs[0] - res / 2), float(xs[0] - res / 2), res, S.ground(X, Z).astype(np.float32))
    t, n = S.normals(S.line)
    E = []
    for i in range(0, len(S.line), 12):
        x, z = S.line[i]; y = S.ly[i]
        for dh in (2.0, 22.0, 60.0): E.append((x, y + dh, z))
        for side in (-1, 1): E.append((x + n[i, 0] * 40 * side, y + 15, z + n[i, 1] * 40 * side))
    V = VIS.viewshed(G, np.array(E), rays=1440, maxd=MID_R + 500)
    seen = ndimage.binary_dilation((V & 1) > 0, iterations=3)
    crowns = ndimage.binary_dilation((V & 2) > 0, iterations=1)
    log(f'cameras: {len(E)} positions; ground seen on {100 * seen.mean():.0f}% of the {2 * MID_R / 1000:.0f} km square, crowns on {100 * crowns.mean():.0f}%')
    def look(M):
        def f(x, z):
            c = np.clip(((np.asarray(x) - G.x0) / res).astype(int), 0, G.nx - 1); r = np.clip(((np.asarray(z) - G.z0) / res).astype(int), 0, G.nz - 1)
            return M[r, c]
        return f
    return look(seen), look(crowns)


SEEN = CROWN_SEEN = None


def ground_points(C):
    """the triangulation's points: road edges, rows beside them, the car parks, then coarser with distance from
    the road, and beyond the outline where the cameras see it"""
    pts, kind, stn = [], [], []           # kind: 0 road edge, 1 gutter row, 2 rows, 3 detail, 4 mid
    for side, E in ((-1, ED_LO), (+1, ED_HI)):
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        jy = 0 if side < 0 else -1
        pts.append(np.c_[edge[:, 0], ROAD_P[:, jy, 1], edge[:, 1]]); kind.append(np.zeros(NS, int)); stn.append(np.arange(NS))
        inner = (ST_K * side) > 0
        room = np.where(inner, ST_R - np.abs(E), 1e9)
        for k in OFFS:
            sel = (k < 0.7 * room) & (~inner | (ST_R > 15) | (k > 1.0))
            if k > 3.0: sel &= (np.arange(NS) % (2 if k < 9 else 4)) == 0
            xz = edge[sel] + o[sel] * k
            pts.append(np.c_[xz[:, 0], np.full(sel.sum(), np.nan), xz[:, 1]]); kind.append(np.full(sel.sum(), 1 if k == OFFS[0] else 2))
            stn.append(np.nonzero(sel)[0])
    # the car parks: their outlines and a 2 m grid inside
    from matplotlib.path import Path
    for poly in S.LOTS.values():
        seg = np.diff(np.vstack([poly, poly[:1]]), axis=0); L = np.hypot(*seg.T)
        B = np.vstack([poly[k] + seg[k] * f for k in range(len(poly)) for f in np.arange(0, 1, 1.5 / max(L[k], 1.5))])
        x0, z0 = poly.min(0); x1, z1 = poly.max(0)
        gx, gz = np.meshgrid(np.arange(x0, x1, 2.0), np.arange(z0, z1, 2.0))
        Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.3, 0.3, (gx.size, 2))
        Q = Q[Path(poly).contains_points(Q)]
        A = np.vstack([B, Q])
        pts.append(np.c_[A[:, 0], np.full(len(A), np.nan), A[:, 1]]); kind.append(np.full(len(A), 3)); stn.append(np.full(len(A), -1))
    # beyond the rows: jittered grids, coarser with distance from the road; inside the outline in full, beyond it
    # coarse and only what the cameras see
    m = C['m']; step = 8
    dist = ndimage.distance_transform_edt(~m[::step, ::step]) * C['R'] * step
    def road_dist(Q):
        c = ((Q[:, 0] - C['x0']) / (C['R'] * step)).astype(int); r = ((Q[:, 1] - C['z0']) / (C['R'] * step)).astype(int)
        ins = (c >= 0) & (r >= 0) & (c < dist.shape[1]) & (r < dist.shape[0])
        dd = np.full(len(Q), 1e9); dd[ins] = dist[r[ins], c[ins]]
        far = ~ins
        if far.any(): dd[far] = cKDTree(ST_P[::4]).query(Q[far])[0]
        return dd
    ox0, oz0 = S.OUT_XZ.min(0) - 40; ox1, oz1 = S.OUT_XZ.max(0) + 40
    det = []
    for d0, d1, sp in ((18, 40, 3.0), (40, 100, 6.0), (100, 250, 12.0), (250, 1e9, 20.0)):
        gx, gz = np.meshgrid(np.arange(ox0, ox1, sp), np.arange(oz0, oz1, sp))
        Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.35, 0.35, (gx.size, 2)) * sp
        dd = road_dist(Q)
        Q = Q[(dd >= d0) & (dd < d1)]
        det.append(Q[S.in_outline(Q[:, 0], Q[:, 1])])
    # the outline itself, every 8 m
    o = S.OUT_XZ; seg = np.diff(np.vstack([o, o[:1]]), axis=0); L = np.hypot(*seg.T)
    ring = np.vstack([o[k] + seg[k] * f for k in range(len(o)) for f in np.arange(0, 1, 8.0 / max(L[k], 8.0))])
    keep = np.ones(len(ring), bool); last = None
    for k in range(len(ring)):
        if last is not None and np.hypot(*(ring[k] - last)) < 6.0: keep[k] = False
        else: last = ring[k]
    det.append(ring[keep])
    D = np.vstack(det)
    pts.append(np.c_[D[:, 0], np.full(len(D), np.nan), D[:, 1]]); kind.append(np.full(len(D), 3)); stn.append(np.full(len(D), -1))
    mid = []
    for d0, d1, sp in ((0, 600, 25.0), (600, 1500, 50.0), (1500, 4000, 100.0), (4000, 1e9, 200.0)):
        lim = min(MID_R, 5000.0 + d1) if d1 < 1e9 else MID_R
        gx, gz = np.meshgrid(np.arange(-lim, lim, sp), np.arange(-lim, lim, sp))
        Q = np.c_[gx.ravel(), gz.ravel()] + rng.uniform(-0.3, 0.3, (gx.size, 2)) * sp
        Q = Q[(np.hypot(Q[:, 0], Q[:, 1]) < MID_R)]
        dd = road_dist(Q)
        Q = Q[(dd >= d0) & (dd < d1)]
        Q = Q[~S.in_outline(Q[:, 0], Q[:, 1])]
        Q = Q[SEEN(Q[:, 0], Q[:, 1])]
        mid.append(Q)
    # (and a ring at MID_R, so the coarse ground ends in a circle)
    a = np.linspace(0, 2 * np.pi, 400, endpoint=False)
    rq = np.c_[MID_R * np.cos(a), MID_R * np.sin(a)]
    mid.append(rq[SEEN(rq[:, 0], rq[:, 1])])
    Mq = np.vstack(mid)
    pts.append(np.c_[Mq[:, 0], np.full(len(Mq), np.nan), Mq[:, 1]]); kind.append(np.full(len(Mq), 4)); stn.append(np.full(len(Mq), -1))
    P = np.concatenate(pts); K = np.concatenate(kind); STN = np.concatenate(stn)
    log(f'ground points: {int((K <= 2).sum())} by the road, {int((K == 3).sum())} inside the outline, {int((K == 4).sum())} beyond')
    return P, K, STN


def build_ground(mesh, C):
    P, K, STN = ground_points(C)
    need = np.isnan(P[:, 1])
    dR, j = edge_dist(P[:, [0, 2]])
    stn_near = j % NS
    P[need, 1] = ground_y(P[need][:, [0, 2]], stn_near[need], dR[need])
    # the gutter row: just under the road's edge
    g = K == 1
    rel = P[:, [0, 2]] - ST_P[np.maximum(STN, 0)]
    sd = np.sign(np.einsum('ij,ij->i', rel, ST_N[np.maximum(STN, 0)]))
    gy = np.where(sd < 0, ROAD_P[np.maximum(STN, 0), 0, 1], ROAD_P[np.maximum(STN, 0), -1, 1]) - 0.12
    P[g, 1] = gy[g]
    # the car parks: level with the road where they meet it
    lot = (K == 3) & in_lots(P[:, 0], P[:, 2])
    if lot.any():
        ry = np.r_[ROAD_P[:, 0, 1], ROAD_P[:, -1, 1]][j[lot]]
        w = np.clip((dR[lot] - 1.0) / 6.0, 0, 1)
        P[lot, 1] = ry * (1 - w) + P[lot, 1] * w
    # rows reaching over the road (the other legs of a hairpin) go; the road's edges stay
    inside = in_corridor(C, P[:, [0, 2]], shrink=1) & (K != 0)
    P, K, STN, sd = P[~inside], K[~inside], STN[~inside], sd[~inside]
    tree = cKDTree(P[:, [0, 2]])
    pairs = tree.query_pairs(0.12, output_type='ndarray')
    drop = np.zeros(len(P), bool)
    for a, b in pairs:
        if drop[a] or drop[b]: continue
        drop[b if K[b] >= K[a] else a] = True
    P, K, STN, sd = P[~drop], K[~drop], STN[~drop], sd[~drop]
    tri = Delaunay(P[:, [0, 2]]).simplices
    T = P[tri]
    cen = T.mean(1)
    longest = np.max([np.hypot(*(T[:, a, [0, 2]] - T[:, b, [0, 2]]).T) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    keep = ~in_corridor(C, cen[:, [0, 2]])
    det = S.in_outline(cen[:, 0], cen[:, 2])
    keep &= np.where(det, longest < 60, longest < 450)
    keep &= det | SEEN(cen[:, 0], cen[:, 2]) | (K[tri] != 4).any(1)
    tri, det = tri[keep], det[keep]
    T = P[tri]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    flip = fn[:, 1] < 0
    tri[flip] = tri[flip][:, [0, 2, 1]]; fn[flip] *= -1
    area = np.linalg.norm(fn, axis=1) / 2
    fu = fn / np.maximum(2 * area, 1e-9)[:, None]
    VN = np.zeros_like(P)
    for k in range(3): np.add.at(VN, tri[:, k], fn)
    VN /= np.maximum(np.linalg.norm(VN, axis=1, keepdims=True), 1e-9)
    cen = P[tri].mean(1)
    dR, jj = edge_dist(cen[:, [0, 2]])
    road_yy = np.r_[ROAD_P[:, 0, 1], ROAD_P[:, -1, 1]][jj]
    above = cen[:, 1] > road_yy + 0.3
    st3 = STN[tri]
    gutter = np.all(K[tri] <= 1, axis=1) & (np.ptp(st3, axis=1) <= 3) & (np.ptp(sd[tri], axis=1) == 0)
    paved = in_lots(cen[:, 0], cen[:, 2])
    steep = fu[:, 1] < 0.5
    slope = (fu[:, 1] >= 0.5) & (fu[:, 1] < 0.8)
    longest = np.max([np.hypot(*(P[tri][:, a, [0, 2]] - P[tri][:, b, [0, 2]]).T) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    mat = np.full(len(tri), 'drape', object)
    mat[dR < 14] = 'verge'
    mat[slope & (dR < 14)] = 'grass'
    mat[steep & (dR < 14)] = np.where(above[steep & (dR < 14)], 'rock', 'wall_kikko')
    mat[steep & (dR >= 14) & (dR < 25) & above] = 'rock'
    mat[paved] = 'pave'
    mat[gutter] = 'gutter'
    mat[~det] = 'drape'
    coarse = (~det) & (longest > 130)                  # past ~1.5 km: the backdrop's own chunk
    # (all the ground inside the outline but the walls is solid: the cameras come in short of it, and a car that gets
    # over a wall lands on it)
    phys = ((dR < 7.0) & (fu[:, 1] > 0.6) | gutter | paved | (mat == 'drape') | np.isin(mat, ['verge', 'grass']) & (fu[:, 1] > 0.5)) & det
    # the aerial photos: near (3 m a texel) where they reach, then 25 m, then 52 m
    nd, md, fd = DRAPES
    for sel_all, cat in ((mat == 'drape') & ~coarse, 'ground'), ((mat == 'drape') & coarse, 'far'):
        for d in (nd, md, fd):
            span_ok = (cen[:, 0] >= d.x0) & (cen[:, 0] < d.x0 + d.nx * d.span) & (cen[:, 2] >= d.z0) & (cen[:, 2] < d.z0 + d.nz * d.span)
            sel = np.nonzero(sel_all & span_ok)[0]
            sel_all = sel_all & ~span_ok
            if not len(sel): continue
            ci, cj = d.cell(cen[sel, 0], cen[sel, 2])
            for key in sorted(set(zip(ci.tolist(), cj.tolist()))):
                ss = sel[(ci == key[0]) & (cj == key[1])]
                I = tri[ss]; C3 = P[I].reshape(-1, 3)
                name = d.key(*key) + ('' if cat == 'ground' else '_f')
                if name not in AS.MATERIALS:
                    AS.MATERIALS[name] = AS.M(d.key(*key), cat, 0, spec=0.02)
                # (the coarse ground: dipped 0.4 m where it meets the finer, so their seam never opens)
                if cat == 'far':
                    C3 = C3.copy(); C3[:, 1] -= 0.4
                UV = d.uv(key[0], key[1], C3[:, 0], C3[:, 2])
                mesh.add(name, C3, UV, np.arange(len(C3)).reshape(-1, 3), N=VN[I].reshape(-1, 3), phys=det[ss] & (cat == 'ground') & (d is nd))
    for mname in sorted(set(mat) - {'drape'}):
        sel = np.nonzero(mat == mname)[0]
        I = tri[sel]; C3 = P[I].reshape(-1, 3)
        if mname in ('wall_kikko', 'wall_stones', 'rock', 'rock_bare'):
            fx = np.abs(fu[sel, 0]) > np.abs(fu[sel, 2])
            u = np.where(np.repeat(fx, 3), C3[:, 2], C3[:, 0]) / 3.0
            UV = np.c_[u, -C3[:, 1] / 3.0]
            N = np.repeat(fu[sel], 3, 0)
        elif mname == 'gutter':
            st = np.maximum(STN[I].reshape(-1), 0)
            UV = np.c_[ST_S[st] / 2.0, np.where(K[I].reshape(-1) == 0, 0.0, 1.0)]
            N = VN[I].reshape(-1, 3)
        else:
            sc = {'grass': 5.0, 'verge': 3.0, 'pave': 3.0}.get(mname, 5.0)
            UV = np.c_[C3[:, 0], C3[:, 2]] / sc
            N = VN[I].reshape(-1, 3)
        mesh.add(mname, C3, UV, np.arange(len(C3)).reshape(-1, 3), N=N, phys=phys[sel])
    log(f'ground: {len(tri)} triangles ({int(det.sum())} inside the outline, {int((~det & ~coarse).sum())} beyond it, '
        f'{int(coarse.sum())} coarse); ' + ', '.join(f'{k} {int((mat == k).sum())}' for k in sorted(set(mat))))
    return P, tri, mat, det


# ---------------------------------------------------------------- guardrails and collisions
def runs(flags, min_len=4, gap=4):
    f = ndimage.binary_closing(flags, structure=np.ones(gap * 2 + 1)) | flags
    lab, n = ndimage.label(f)
    out = []
    for k in range(1, n + 1):
        idx = np.nonzero(lab == k)[0]
        if len(idx) >= min_len: out.append((idx[0], idx[-1]))
    return out


def barriers(mesh):
    """guardrails where the ground drops away from the road (or round the outside of a tight bend over any
    drop); collisions along them, along the walls where the ground rises, 5 m out over level verges, round the
    car parks, and across both ends"""
    LOT = lot_stations()
    total = 0.0
    RAIL = {}
    for side, E in ((-1, ED_LO), (+1, ED_HI)):
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        jy = 0 if side < 0 else -1
        ey = ROAD_P[:, jy, 1]
        samples = np.array([1.2, 2.0, 3.0, 4.5, 6.0])
        xz = (edge[:, None, :] + o[:, None, :] * samples[None, :, None]).reshape(-1, 2)
        stn = np.repeat(np.arange(NS), len(samples))
        y = ground_y(xz, stn, np.tile(samples, NS)).reshape(NS, len(samples))
        dy = y - ey[:, None]
        outside = (ST_K * side) < 0
        drop = (dy[:, :3].min(1) < -0.7) | (outside & (ST_R < 40) & (dy[:, :3].min(1) < -0.25))
        drop &= ~LOT[side]
        rise_at = np.full(NS, np.nan)
        for i in range(NS):
            k = np.nonzero(dy[i] > 0.6)[0]
            if len(k): rise_at[i] = samples[k[0]]
        rail = ndimage.binary_opening(drop, structure=np.ones(3))
        RAIL[side] = rail
        for i0, i1 in runs(rail):
            idx = np.arange(i0, i1 + 1)
            pts = edge[idx] + o[idx] * 0.62
            base = ey[idx] - 0.02
            strip(mesh, 'guardrail', pts, base, base + 1.0, 4.0, face=-o[idx], tilt=0.15)
            mesh.wall_line(pts, base - 0.6, base + 1.2)
            total += float(np.hypot(*np.diff(pts, axis=0).T).sum())
        rest = ~ndimage.binary_dilation(rail, structure=np.ones(3)) & ~LOT[side]
        off = np.where(np.isfinite(rise_at), np.minimum(rise_at, 5.0), 5.0)
        off = gaussian_filter1d(median_filter(off, 7, mode='nearest'), 1.5, mode='nearest')
        for i0, i1 in runs(rest, min_len=2, gap=0):
            idx = np.arange(max(i0 - 1, 0), min(i1 + 2, NS))
            pts = edge[idx] + o[idx] * off[idx, None]
            ok = ~in_lots(pts[:, 0], pts[:, 1])
            for a, b in runs_of(ok):
                if b > a: mesh.wall_line(pts[a:b + 1], ey[idx][a:b + 1] - 1.0, ey[idx][a:b + 1] + 3.0)
    # round the car parks, except where they open onto the road
    for poly in S.LOTS.values():
        ring = np.vstack([poly, poly[:1]])
        seg = np.diff(ring, axis=0); L = np.hypot(*seg.T)
        dense = np.vstack([ring[k] + seg[k] * f for k in range(len(poly)) for f in np.arange(0, 1, 1.0 / max(L[k], 1.0))] + [ring[-1:]])
        d, jj = edge_dist(dense)
        open_ = d < 2.5
        y = ground_y(dense)
        for a, b in runs_of(~open_):
            if b > a: mesh.wall_line(dense[a:b + 1], y[a:b + 1] - 1.0, y[a:b + 1] + 3.0)
    for i in (0, NS - 1):
        a = ST_P[i] + ST_N[i] * (ED_LO[i] - 6); b = ST_P[i] + ST_N[i] * (ED_HI[i] + 6)
        mesh.wall(a, b, ST_Y[i] - 2, ST_Y[i] + 4)
    log(f'guardrail {total / 1000:.2f} km; {len(mesh.walls)} wall segments')
    return RAIL


# ---------------------------------------------------------------- trees
def forest_mask():
    """forest on the 3 m near photos and the 25 m one beyond: dark and green"""
    out = {}
    for d in DRAPES:
        for k in d.keys():
            i, j = map(int, k.rsplit('_', 2)[1:])
            a = np.asarray(AS.TEXTURES[k](), np.float32) / 255 if k in AS.TEXTURES else None
            if a is None: continue
            green = a[..., 1] - np.maximum(a[..., 0], a[..., 2])
            out[k] = (green > 0.012) & (a.max(-1) < 0.5)
    def f(x, z):
        res = np.zeros(len(x), bool)
        todo = np.ones(len(x), bool)
        for d in DRAPES:
            inside = todo & (x >= d.x0) & (x < d.x0 + d.nx * d.span) & (z >= d.z0) & (z < d.z0 + d.nz * d.span)
            if not inside.any(): continue
            ci, cj = d.cell(x[inside], z[inside])
            uv = d.uv(ci, cj, x[inside], z[inside])
            px = np.clip((uv[:, 0] * AS.LAYER).astype(int), 0, AS.LAYER - 1); py = np.clip((uv[:, 1] * AS.LAYER).astype(int), 0, AS.LAYER - 1)
            v = np.zeros(inside.sum(), bool)
            for key in set(zip(ci.tolist(), cj.tolist())):
                sel = (ci == key[0]) & (cj == key[1])
                v[sel] = out[d.key(*key)][py[sel], px[sel]]
            res[inside] = v; todo &= ~inside
        return res
    return f


def near_poly(Q, P, d):
    """points Q (n, 2) inside polygon P or within d of its edges"""
    from matplotlib.path import Path
    inside = Path(P).contains_points(Q)
    A = P; B = np.roll(P, -1, axis=0); AB = B - A
    t = np.clip(np.einsum('qkj,kj->qk', Q[:, None, :] - A[None], AB) / np.maximum(np.einsum('kj,kj->k', AB, AB), 1e-9), 0, 1)
    D = np.linalg.norm(Q[:, None, :] - (A[None] + t[..., None] * AB[None]), axis=2).min(1)
    return inside | (D < d)


def sample_on(T, area, dens):
    """random points over triangles T (n, 3, 3) at `dens` per m2 each; the triangle each came from"""
    cnt = rng.poisson(area * dens)
    kk = np.repeat(np.arange(len(T)), cnt)
    r1, r2 = rng.random(len(kk)), rng.random(len(kk))
    fl = r1 + r2 > 1; r1[fl], r2[fl] = 1 - r1[fl], 1 - r2[fl]
    return T[kk, 0] + (T[kk, 1] - T[kk, 0]) * r1[:, None] + (T[kk, 2] - T[kk, 0]) * r2[:, None], kk


def clear_of(X, C, edge_min):
    """points (x, y, z) off the road (edge_min m from its edges at least), the car parks and the buildings"""
    dd, _ = edge_dist(X[:, [0, 2]])
    ok = (dd > edge_min) & ~in_corridor(C, X[:, [0, 2]]) & ~in_lots(X[:, 0], X[:, 2])
    for kind, P in S.BUILDINGS:
        lo_, hi_ = P.min(0) - 4, P.max(0) + 4
        sel = ok & (X[:, 0] > lo_[0]) & (X[:, 0] < hi_[0]) & (X[:, 2] > lo_[1]) & (X[:, 2] < hi_[1])
        if sel.any(): ok[np.nonzero(sel)[0]] = ~near_poly(X[sel][:, [0, 2]], P, 3.0)
    return ok, dd


# the woods on Mt. Haruna: oaks and maples, conifer plantations; (impostor, its share, scale range)
SPECIES = [('oak_big1', 0.10, (0.85, 1.1)), ('oak_big3', 0.10, (0.85, 1.1)), ('oak_large1', 0.08, (0.7, 0.9)), ('oak_large2', 0.08, (0.7, 0.9)),
           ('oak_large4', 0.07, (0.75, 0.95)), ('oak_med2', 0.07, (1.1, 1.6)),
           ('maple_large1', 0.09, (0.75, 1.0)), ('maple_large3', 0.08, (0.8, 1.05)), ('maple_med1', 0.08, (1.0, 1.4)),
           ('fir1', 0.09, (1.8, 2.4)), ('fir3', 0.08, (2.0, 2.6)), ('fir6', 0.08, (2.4, 3.2))]


def vegetation(mesh, GP, GT, GM, det, C, RAIL):
    """trees where the photos show forest (the foliage packs' impostors): dense by the road, thinning out to the
    outline, sparse beyond it where the cameras see their crowns; by the road, real grass clumps on the verges,
    small bushes, young oaks and maples, and big bushes at the forest's edge"""
    FOREST = forest_mask()
    T = GP[GT]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); area = np.linalg.norm(fn, axis=1) / 2
    ny = fn[:, 1] / np.maximum(2 * area, 1e-9)
    cen = T.mean(1)
    dR, _ = edge_dist(cen[:, [0, 2]])
    # trees
    dens = np.where(dR < 7, 0.0, np.where(dR < 60, 1 / 30, np.where(dR < 200, 1 / 60, np.where(dR < 600, 1 / 140, 0.0))))
    dens = np.where(det, dens, np.where(dR < 450, 1 / 240, 0.0))
    dens = np.where(ny > 0.45, dens, 0.0)
    X, _ = sample_on(T, area, dens)
    ok, dd = clear_of(X, C, 6.0)
    ok &= FOREST(X[:, 0], X[:, 2])
    ok &= S.in_outline(X[:, 0], X[:, 2]) | CROWN_SEEN(X[:, 0], X[:, 2])
    X = X[ok]; dd = dd[ok]
    shares = np.array([w for _, w, _ in SPECIES]); shares /= shares.sum()
    pick = rng.choice(len(SPECIES), len(X), p=shares)
    for i_, (name, _, (s0, s1)) in enumerate(SPECIES):
        q = np.nonzero(pick == i_)[0]
        if not len(q): continue
        FOL.IMPOSTORS[name].add(mesh, X[q, 0], X[q, 1] - 0.3, X[q, 2], rng.uniform(s0, s1, len(q)), rng.uniform(0, 2 * np.pi, len(q)), dd[q] < 70)
    log(f'trees: {len(X)} ({int((dd < 70).sum())} with their crowns, by the road)')
    def place(models, X, scale, sink=0.05):
        pick = rng.integers(0, len(models), len(X))
        for i_, name in enumerate(models):
            q = np.nonzero(pick == i_)[0]
            if len(q): FOL.MODELS[name].add(mesh, X[q, 0], X[q, 1] - sink, X[q, 2], rng.uniform(*scale, len(q)), rng.uniform(0, 2 * np.pi, len(q)))
        return len(X)
    verge = np.isin(GM, ['verge', 'grass']) & det & (ny > 0.55)
    # grass clumps on the verges, thick by the road's edge
    g_d = np.where(verge & (dR < 4.5), 1 / 7.0, np.where(verge & (dR < 10), 1 / 40.0, 0.0))
    Xg, _ = sample_on(T, area, g_d)
    okg, _ = clear_of(Xg, C, 0.9)
    ng = place(['grass_l1', 'grass_l2', 'grass_l3', 'grass_m1', 'grass_m3'], Xg[okg], (1.1, 2.0))
    # small bushes on the verges and slopes
    b_d = np.where(verge & (dR > 2.5) & (dR < 12), 1 / 250.0, 0.0)
    Xb, _ = sample_on(T, area, b_d)
    okb, _ = clear_of(Xb, C, 2.2)
    nb = place(['bush_m1', 'bush_m2', 'bush_m3', 'bush_s1', 'bush_s3'], Xb[okb], (1.0, 1.8))
    # young trees in front of the woods
    y_d = np.where((dR > 4) & (dR < 14) & (ny > 0.5) & det, 1 / 500.0, 0.0)
    Xy, _ = sample_on(T, area, y_d)
    oky, _ = clear_of(Xy, C, 4.0)
    ny_ = place(['oak_small1', 'oak_small2', 'oak_small3', 'maple_sap2', 'maple_small3', 'oak_sap1', 'oak_sap2'], Xy[oky], (0.9, 1.4))
    # big bushes along the edge of the woods (impostors)
    e_d = np.where((dR > 6) & (dR < 18) & (ny > 0.45) & det, 1 / 35.0, 0.0)
    Xe, _ = sample_on(T, area, e_d)
    oke, dde = clear_of(Xe, C, 6.0)
    oke &= FOREST(Xe[:, 0], Xe[:, 2])
    Xe = Xe[oke]
    pick = rng.integers(0, 2, len(Xe))
    for i_, name in enumerate(['bush_big1', 'bush_big3']):
        q = np.nonzero(pick == i_)[0]
        FOL.IMPOSTORS[name].add(mesh, Xe[q, 0], Xe[q, 1] - 0.1, Xe[q, 2], rng.uniform(1.4, 2.6, len(q)), rng.uniform(0, 2 * np.pi, len(q)), np.ones(len(q), bool))
    log(f'by the road: {ng} grass clumps, {nb} bushes, {ny_} young trees, {len(Xe)} big bushes at the edge of the woods')


# ---------------------------------------------------------------- buildings
def ear_clip(P):
    """triangles over a simple polygon (counter-clockwise or not): ear clipping"""
    n = len(P)
    idx = list(range(n))
    area = 0.5 * np.sum(P[:, 0] * np.roll(P[:, 1], -1) - np.roll(P[:, 0], -1) * P[:, 1])
    sgn = 1.0 if area > 0 else -1.0
    cross = lambda a, b, c: sgn * ((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))
    out = []
    guard = 0
    while len(idx) > 3 and guard < 4 * n * n:
        guard += 1
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[(k - 1) % m], idx[k], idx[(k + 1) % m]
            a, b, c = P[i0], P[i1], P[i2]
            if cross(a, b, c) <= 1e-9: continue
            ok = True
            for j in idx:
                if j in (i0, i1, i2): continue
                p = P[j]
                if cross(a, b, p) >= 0 and cross(b, c, p) >= 0 and cross(c, a, p) >= 0: ok = False; break
            if ok:
                out.append((i0, i1, i2)); idx.pop(k); break
        else:
            break
    if len(idx) == 3: out.append(tuple(idx))
    return out


def buildings(mesh, C):
    """the base map's buildings: walls up from the lowest ground at their corners to eaves 6-9 m up (concrete ones
    10-14 m), wearing a plain wall with windows; the roof flat, coloured from the aerial photo of it; collisions
    round the ones near the road. Only those in the outline or where the cameras see them, none on the road"""
    n = 0
    near_d = DRAPES[0]
    facades = ['facade_white', 'facade_cream', 'facade_wood', 'facade_grey']
    for kind, P in S.BUILDINGS:
        cx, cz = P.mean(0)
        if not (S.in_outline(np.array([cx]), np.array([cz]))[0] or SEEN(np.array([cx]), np.array([cz]))[0]): continue
        if in_corridor(C, P).any() or in_corridor(C, np.array([[cx, cz]])).any(): continue
        if in_lots(P[:, 0], P[:, 1]).any(): continue
        if edge_dist(P)[0].min() < 1.0: continue
        g = S.ground(P[:, 0], P[:, 1])
        base = float(g.min()) - 0.4
        h = rng.uniform(10, 14) if kind == 'solid' else rng.uniform(5.8, 8.5)
        top = float(g.max()) + h
        fac = facades[rng.integers(0, 4)] if kind == 'house' else ('facade_white' if rng.random() < 0.6 else 'facade_grey')
        ring = np.vstack([P, P[:1]])
        seg = np.diff(ring, axis=0); L = np.hypot(*seg.T)
        u = np.r_[0, np.cumsum(L)] / 4.0
        Q, UV, I, N = [], [], [], []
        for k in range(len(P)):
            a, b = ring[k], ring[k + 1]
            if L[k] < 0.05: continue
            nrm = np.array([seg[k, 1], -seg[k, 0]]) / L[k]
            if np.dot(nrm, (a + b) / 2 - (cx, cz)) < 0: nrm = -nrm
            o = len(Q)
            Q += [(a[0], base, a[1]), (b[0], base, b[1]), (b[0], top, b[1]), (a[0], top, a[1])]
            v0, v1 = 0.0, (top - base) / 3.0
            UV += [(u[k], v1), (u[k + 1], v1), (u[k + 1], v0), (u[k], v0)]
            I += [(o, o + 1, o + 2), (o, o + 2, o + 3)]
            N += [(nrm[0], 0.0, nrm[1])] * 4
        if not I: continue
        mesh.add(fac, np.array(Q), np.array(UV), np.array(I), N=np.array(N), phys=False)
        tris = ear_clip(P)
        if tris:
            R = np.c_[P[:, 0], np.full(len(P), top), P[:, 1]]
            ci, cj = near_d.cell(np.array([cx]), np.array([cz]))
            inside = (cx >= near_d.x0) & (cx < near_d.x0 + near_d.nx * near_d.span) & (cz >= near_d.z0) & (cz < near_d.z0 + near_d.nz * near_d.span)
            d = near_d if inside else DRAPES[1]
            ci, cj = d.cell(np.array([cx]), np.array([cz]))
            key = d.key(int(ci[0]), int(cj[0]))
            mesh.add(key, R, d.uv(int(ci[0]), int(cj[0]), R[:, 0], R[:, 2]), np.array(tris), N=np.tile([0.0, 1.0, 0.0], (len(R), 1)), phys=False)
        if edge_dist(P)[0].min() < 30:
            mesh.wall_line(ring, base, top)
        n += 1
    log(f'buildings: {n}')


# ---------------------------------------------------------------- signs
def sign(mesh, mat, p, y, face, w, h, top, flip=False):
    """a board w x h with its top `top` m above the ground, facing `face` (unit x, z), on a pole; a grey back"""
    fx, fz = face; rx, rz = fz, -fx                      # the board's right, seen from the front
    c = np.array([p[0], p[1]])
    A = (c[0] - rx * w / 2, y + top - h, c[1] - rz * w / 2); B = (c[0] + rx * w / 2, y + top - h, c[1] + rz * w / 2)
    Cc = (B[0], y + top, B[2]); D = (A[0], y + top, A[2])
    u0, u1 = (1, 0) if flip else (0, 1)
    quad(mesh, mat, A, B, Cc, D, uv=((u0, 1), (u1, 1), (u1, 0), (u0, 0)), split=None)
    bk = lambda q: (q[0] - fx * 0.02, q[1], q[2] - fz * 0.02)
    quad(mesh, 'sign_back', bk(B), bk(A), bk(D), bk(Cc), split=None)
    r = 0.035
    x, z = c[0] - fx * 0.05, c[1] - fz * 0.05
    for a in (0, np.pi / 2):
        cs, sn = np.cos(a) * r, np.sin(a) * r
        quad(mesh, 'pole', (x - cs, y - 0.1, z - sn), (x + cs, y - 0.1, z + sn), (x + cs, y + top - h, z + sn), (x - cs, y + top - h, z - sn), split=None)


def signs(mesh, RAIL):
    """orange chevrons round the outside of every bend under 30 m (pointing the way it turns), and the warning
    boards near both ends of the stage"""
    n = 0
    tight = ST_R < 30
    for i0, i1 in runs(tight, min_len=3, gap=2):
        side = -int(np.sign(np.mean(ST_K[i0:i1 + 1])))  # the outside
        L = ST_S[i1] - ST_S[i0]
        for s in np.linspace(ST_S[i0] - 4, ST_S[i1] + 4, max(3, int(L / 7) + 1)):
            i = int(np.clip(np.searchsorted(ST_S, s), 0, NS - 1))
            E = ED_HI[i] if side > 0 else ED_LO[i]
            p = ST_P[i] + ST_N[i] * (E + side * (1.25 if RAIL[side][i] else 0.9))
            y = ground_y(p[None])[0] if not RAIL[side][i] else ROAD_P[i, 0 if side < 0 else -1, 1]
            face = -ST_N[i] * side
            # the arrow points the way the road turns: the texture's arrow points left
            turns_right = ST_K[i] > 0
            sign(mesh, 'sign_chevron', p, y, face, 0.6, 0.75, 1.75, flip=turns_right)
            n += 1
    for s, back in ((S.S_FINISH - 60, -1), (S.S_START + 60, 1)):
        i = int(np.searchsorted(ST_S, s))
        side = -1
        p = ST_P[i] + ST_N[i] * (ED_LO[i] - 1.6)
        face = ST_T[i] * back                             # facing the traffic that reads it
        sign(mesh, 'sign_bends', p, ground_y(p[None])[0], face, 1.4, 0.9, 2.4)
        n += 1
    log(f'signs: {n}')


# ---------------------------------------------------------------- pack
DRAPES = None


def main():
    global ROAD_P, EDGE_TREE, SEEN, CROWN_SEEN, DRAPES
    import writer as W
    C = corridor_mask()
    mesh = Mesh()
    ROAD_P = road_mesh(mesh)
    EDGE_TREE = cKDTree(np.vstack([ST_P + ST_N * ED_LO[:, None], ST_P + ST_N * ED_HI[:, None]]))
    SEEN, CROWN_SEEN = visible_cells()
    # the aerial photos: 3 m texels round the outline, 25 m out to 6 km, 52 m out to 12.5 km
    ox0, oz0 = S.OUT_XZ.min(0) - 300; ox1, oz1 = S.OUT_XZ.max(0) + 300
    span = 480 * 3.0
    near = AS.Drape('near', float(ox0), float(oz0), int(np.ceil((ox1 - ox0) / span)), int(np.ceil((oz1 - oz0) / span)), 3.0, 16)
    mid = AS.Drape('mid', -6000.0, -6000.0, 1, 1, 12000.0 / 480, 13)
    far = AS.Drape('far', -12600.0, -12600.0, 1, 1, 25200.0 / 480, 12)
    DRAPES = (near, mid, far)
    for d in DRAPES:
        AS.add_drape(d, 'ground')
        for k in d.keys(): AS.TEXTURES[k] = (lambda f: (lambda c=[]: c[0] if c else (c.append(f()) or c[0])))(AS.TEXTURES[k])
    log(f'aerial photos: {len(near.keys())} near layers of {near.span:.0f} m, mid and far one each')
    FOL.load()
    paint(mesh)
    GP, GT, GM, det = build_ground(mesh, C)
    RAIL = barriers(mesh)
    vegetation(mesh, GP, GT, GM, det, C, RAIL)
    buildings(mesh, C)
    signs(mesh, RAIL)
    # the horizon
    sky = json.load(open(os.path.join(HERE, '..', '..', 'data', 'skies', 'skies.json')))[SKY]
    r = min(2.6, sky['sunE'] * np.sin(np.radians(sky['sunElev'])) / max(sky['skyE'], 1e-6))
    pe = min(1.3 / (1 + r) * np.pi / max(sky['skyE'], 1e-6), 1.3)
    pieces, _ = PANO.render(np.array(sky['horizon']) * pe, FOG)
    AS.add_panorama(PANO.layers(pieces))
    PANO.cards(mesh)
    st = mesh.stats()
    tv = sum(v for v, _ in st.values()); tt = sum(t for _, t in st.values())
    log(f'mesh: {tv} vertices, {tt} triangles, {len(mesh.walls)} walls')
    for k, (v, t) in sorted(st.items(), key=lambda kv: -kv[1][1])[:16]: print(f'    {k:16s} {t:8d} tris')
    ftex, fmats = FOL.textures_and_materials(AS.M)
    AS.TEXTURES.update(ftex); AS.MATERIALS.update(fmats)
    mats, mat_index, images = AS.build_tables(set(mesh.parts))
    stage = dict(start=round(float(S.S_START), 2), finish=round(float(S.S_FINISH), 2))
    meta = dict(width=round(float(np.median(ED_HI - ED_LO)), 2), loop=False, merge=True, stage=stage,
                credit='Gunma Route 33 rebuilt for Rust Bucket Racing from GSI Japan open data (出典：国土地理院: road centrelines, '
                       '5 m elevation, aerial photos); trees, bushes and grass from LOLIPOP\'s oak, maple, fir, bush and grass packs (CC BY 4.0); '
                       'road, wall and sign textures from "Irohazaka Slope" by sost (free, non-commercial)')
    info = W.write_pack(OUT, mesh, mats, mat_index, images, S.line.astype(np.float32), S.ly.astype(np.float32), meta, 'Mt. Haruna', S.line_len)
    log('done', info)


if __name__ == '__main__':
    main()
