"""The source model for the Irohazaka map: "Irohazaka Slope", an Assetto Corsa track by sost and its original
authors (free, non-commercial, with credit). The map is rebuilt from it (gen.py): this reads the model, sorts its
meshes (road, gutters, grass, walls, trees, the land round the valley), and finds the road's centreline, its
heights and the stage's two lines, as tools/convert_iroha.py did for the converted map (routed along the middle of
the tarmac on a half-metre raster cut along the walls, then centred across the lanes).

Importing it does the work (about a minute); the result is cached next to the model (<model>.src.pkl)."""
import sys, os, io, time, pickle
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import cKDTree
from skimage.graph import route_through_array

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import kn5

SRC = os.environ.get('IROHA_KN5', os.path.join(HERE, 'sost_irohazaka.kn5'))
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)

ver, ktex, kmats, kmeshes = kn5.load(SRC)
log(f'kn5 v{ver}: {len(kmeshes)} meshes, {sum(len(m["I"]) for m in kmeshes)} triangles, {len(kmats)} materials, {len(ktex)} textures')
ktex_by_name = {t['name']: t for t in ktex}


def klass(m):
    n = m['name']; nl = n.lower(); km = kmats[m['mat']]
    at = km['alphatest'] == 1 or 'AT' in km['shader']
    if n.startswith('AC_'): return None
    if nl.startswith('treesland'): return 'treefar'
    if nl.startswith('trees'): return 'tree'
    if nl == 'land': return 'far'
    if 'paint' in nl: return 'decal'
    if nl.startswith('cone'): return 'obj'
    if 'ROAD' in n: return 'road'
    if 'CURB' in n: return 'curb'
    if 'GRASS' in n: return 'bush' if at else 'grass'
    if 'WALL' in n: return 'wallveg' if at else 'wall'
    return 'obj'

def centre_of(prefix):
    P = np.concatenate([m['P'] for m in kmeshes if m['name'].startswith(prefix)])
    return P.mean(0)
AB_START = (centre_of('AC_AB_START_L') + centre_of('AC_AB_START_R')) / 2       # the top line (the run starts here)
AB_FINISH = (centre_of('AC_AB_FINISH_L') + centre_of('AC_AB_FINISH_R')) / 2    # the bottom line
log(f'lines: top {AB_START.round(1)}, bottom {AB_FINISH.round(1)}')

groups = {}
for m in kmeshes:
    c = klass(m)
    if c is None or not len(m['I']): continue
    groups.setdefault((c, m['mat']), []).append(m)
meshes, cls = [], []
for (c, km), ms in sorted(groups.items(), key=lambda kv: (kv[0][0], kv[0][1])):
    P, N, UV, I = [], [], [], []; o = 0
    for m in ms:
        P.append(m['P']); N.append(m['N']); UV.append(m['UV']); I.append(m['I'] + o); o += len(m['P'])
    meshes.append(dict(P=np.concatenate(P), N=np.concatenate(N), UV=np.concatenate(UV), I=np.concatenate(I), mat=km))
    cls.append(c)
def of(*cs): return [i for i, c in enumerate(cls) if c in cs]
log('classes: ' + ', '.join(f'{c} {sum(len(meshes[i]["I"]) for i in of(c))}' for c in sorted(set(cls))))

def tex_name(mi): return kmats[meshes[mi]['mat']]['maps'].get('txDiffuse')
def has_nm(mi): return 'txNormal' in kmats[meshes[mi]['mat']]['maps']

# ---------------------------------------------------------------- double-sided cards: draw each once
def drop_twins(m):
    vid = np.unique(np.round(m['P'] * 1000).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    key = np.sort(vid[m['I']], axis=1)
    _, first = np.unique(key, axis=0, return_index=True)
    keep = np.zeros(len(key), bool); keep[first] = True
    return dict(m, I=m['I'][keep]), int((~keep).sum())
n_twin = 0
for mi in of('tree', 'treefar', 'bush', 'wallveg', 'decal'):
    meshes[mi], k = drop_twins(meshes[mi]); n_twin += k
log(f'double-sided cards: {n_twin} back faces dropped')

# ---------------------------------------------------------------- weld (the model is flat shaded) and smooth
def smooth_weld(m, crease_deg):
    P, I = m['P'], m['I']
    if not len(I): return m
    pid = np.unique(np.round(P * 1000).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    T = P[I]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    st = m['N'][I].sum(1)
    fn[np.einsum('ij,ij->i', fn, st) < 0] *= -1
    fu = fn / np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-12)
    corners_p = pid[I].ravel(); corners_f = np.repeat(np.arange(len(I)), 3)
    order = np.argsort(corners_p, kind='stable'); cp, cf = corners_p[order], corners_f[order]
    starts = np.flatnonzero(np.r_[True, cp[1:] != cp[:-1]]); ends_ = np.r_[starts[1:], len(cp)]
    cosc = np.cos(np.radians(crease_deg)); cn = np.zeros((len(cp), 3))
    for a, b in zip(starts, ends_):
        F = cf[a:b]
        if b - a == 1: cn[a] = fn[F[0]]; continue
        U = fu[F]; G = U @ U.T >= cosc
        cn[a:b] = G.astype(float) @ fn[F]
    N = np.zeros((len(cp), 3)); N[order] = cn
    N /= np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-12)
    UVc = m['UV'][I.ravel()]
    key = np.c_[corners_p, np.round(N * 200).astype(np.int64), np.round(UVc * 4096).astype(np.int64)]
    _, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    inv = inv.ravel()
    return dict(m, P=P[I.ravel()][first], N=N[first], UV=UVc[first], I=inv.reshape(-1, 3))
nv0 = sum(len(m['P']) for m in meshes)
for mi in range(len(meshes)):
    if cls[mi] in ('road', 'curb', 'grass'): meshes[mi] = smooth_weld(meshes[mi], 40)
    elif cls[mi] in ('wall', 'far'): meshes[mi] = smooth_weld(meshes[mi], 35)
log(f'welded: {nv0} vertices -> {sum(len(m["P"]) for m in meshes)}')

# The car park at the top wears a flat salmon swatch (a 16 px placeholder): give it the plain tarmac of the
# road at the road's own texture scale.
def kmat_with(tex):
    return next(i for i, km in enumerate(kmats) if km['maps'].get('txDiffuse') == tex)
def uv_scale(mi):
    m = meshes[mi]; T = m['P'][m['I']]; U = m['UV'][m['I']]
    e = np.linalg.norm(T[:, 1] - T[:, 0], axis=1); du = np.linalg.norm(U[:, 1] - U[:, 0], axis=1); ok = e > 0.5
    return float(np.median(du[ok] / e[ok])) if ok.any() else 0.1
tarmac_k = kmat_with('image04176000_093210d0.dds')
tm = next(i for i in range(len(meshes)) if cls[i] == 'road' and meshes[i]['mat'] == tarmac_k)
for i in range(len(meshes)):
    if tex_name(i) == 'image09308900_09308b50.dds':
        k = uv_scale(tm)
        meshes[i] = dict(meshes[i], UV=meshes[i]['P'][:, [0, 2]] * k, mat=tarmac_k)
        log(f'car park retextured with the road tarmac ({len(meshes[i]["I"])} triangles, {k:.3f} uv/m)')

ROAD = of('road'); CURB = of('curb'); GRASS = of('grass')
GROUND = ROAD + CURB + GRASS
FAR = of('far')

# ---------------------------------------------------------------- top surface sampling
class Sampler:
    """highest triangle under (x, z) for a set of meshes, through a grid of triangle lists"""
    def __init__(self, ids, cell=4.0):
        T = [meshes[mi]['P'][meshes[mi]['I']] for mi in ids]
        self.T = np.concatenate(T); self.cell = cell; self.idx = {}
        mn = np.floor(self.T[:, :, [0, 2]].min(1) / cell).astype(int); mx = np.floor(self.T[:, :, [0, 2]].max(1) / cell).astype(int)
        for i in range(len(self.T)):
            for gx in range(mn[i, 0], mx[i, 0] + 1):
                for gz in range(mn[i, 1], mx[i, 1] + 1): self.idx.setdefault((gx, gz), []).append(i)
    def all(self, x, z):
        out = []
        for i in self.idx.get((int(np.floor(x / self.cell)), int(np.floor(z / self.cell))), ()):
            a, b, c = self.T[i]
            e0x, e0z, e1x, e1z = b[0] - a[0], b[2] - a[2], c[0] - a[0], c[2] - a[2]
            d = e0x * e1z - e1x * e0z
            if abs(d) < 1e-12: continue
            u = ((x - a[0]) * e1z - e1x * (z - a[2])) / d; v = (e0x * (z - a[2]) - (x - a[0]) * e0z) / d
            if u < -1e-6 or v < -1e-6 or u + v > 1 + 1e-6: continue
            out.append(a[1] + u * (b[1] - a[1]) + v * (c[1] - a[1]))
        return out
    def top(self, x, z, below=np.inf):
        hs = [h for h in self.all(x, z) if h <= below]
        return max(hs) if hs else -np.inf
road_s = Sampler(ROAD)
tar_s = Sampler(ROAD + CURB)
lane_s = Sampler([mi for mi in ROAD if tex_name(mi) != 'image092eee80_092ef6d0.dds'])   # the road without the forecourt

# ---------------------------------------------------------------- centreline
def centreline():
    # Half-metre raster of the tarmac. Switchback legs lie only a few metres apart across, so the mask is not
    # closed up much (1 m at a 1 m raster joins neighbouring legs and the route cuts whole hairpins off): small
    # holes are filled instead, then the cheapest route along the middle from the bottom end to the top.
    from skimage.morphology import remove_small_holes
    R = 0.5
    P = np.concatenate([meshes[mi]['P'][meshes[mi]['I']].reshape(-1, 3) for mi in ROAD])
    x0, z0 = P[:, 0].min() - 20, P[:, 2].min() - 20; x1, z1 = P[:, 0].max() + 20, P[:, 2].max() + 20
    W, H = int((x1 - x0) / R), int((z1 - z0) / R)
    im = Image.new('L', (W, H), 0); dr = ImageDraw.Draw(im)
    for mi in ROAD:
        Q = meshes[mi]['P']
        for t in meshes[mi]['I']: dr.polygon([((Q[k, 0] - x0) / R, (Q[k, 2] - z0) / R) for k in t], fill=255)
    mask = remove_small_holes(np.array(im) > 0, max_size=int(16 / R / R))
    mask = ndimage.binary_closing(mask, iterations=1)
    # the forecourt of the filling station at the top is road too: leave it out, or the middle of road and
    # forecourt together runs through the pumps
    im2 = Image.new('L', (W, H), 0); dr2 = ImageDraw.Draw(im2)
    for mi in ROAD:
        if tex_name(mi) != 'image092eee80_092ef6d0.dds': continue
        Q = meshes[mi]['P']
        for t in meshes[mi]['I']: dr2.polygon([((Q[k, 0] - x0) / R, (Q[k, 2] - z0) / R) for k in t], fill=255)
    mask &= ~(np.array(im2) > 0)
    # Where a hairpin's two legs meet across its retaining wall they touch from above: cut the mask along every
    # wall that stands at car height over the road there (or off the road), so the route can't step over one.
    wim = Image.new('L', (W, H), 0); wd = ImageDraw.Draw(wim); nb = 0
    for mi in of('wall', 'wallveg'):
        T = meshes[mi]['P'][meshes[mi]['I']]
        if not len(T): continue
        n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); a = np.linalg.norm(n, axis=1)
        ok = (a > 2e-3) & (np.abs(n[:, 1]) / np.maximum(a, 1e-12) <= 0.45) & (np.ptp(T[:, :, 1], axis=1) >= 0.25)
        for t in T[ok]:
            p2 = t[:, [0, 2]]; y0, y1 = t[:, 1].min(), t[:, 1].max()
            i, j = max(((0, 1), (0, 2), (1, 2)), key=lambda ij: np.sum((p2[ij[0]] - p2[ij[1]]) ** 2))
            A, B = p2[i], p2[j]; L = np.hypot(*(B - A))
            k = max(1, int(np.ceil(L / 0.5)))
            pts = [A + (B - A) * f for f in np.linspace(0, 1, k + 1)]
            for a_, b_ in zip(pts[:-1], pts[1:]):
                m_ = (a_ + b_) / 2; hs = road_s.all(*m_)
                if not hs or any(y0 < h + 1.2 and y1 > h + 0.2 for h in hs):
                    wd.line([((a_[0] - x0) / R, (a_[1] - z0) / R), ((b_[0] - x0) / R, (b_[1] - z0) / R)], fill=255, width=2); nb += 1
    cut = np.array(wim) > 0
    log(f'  walls cut the road mask in {(cut & mask).sum() * R * R:.0f} m2 ({nb} pieces of wall)')
    mask &= ~cut
    lab, nl = ndimage.label(mask)
    big = np.bincount(lab.ravel())[1:].argmax() + 1
    log(f'  road mask: {nl} pieces, using the biggest ({(lab == big).sum() * R * R:.0f} of {mask.sum() * R * R:.0f} m2)')
    mask = lab == big
    dt = ndimage.distance_transform_edt(mask) * R
    cost = np.where(mask, 1.0 + 40.0 / (dt + 1.0) ** 2, 1e4)
    rr, cc = np.nonzero(mask)
    kb = np.argmax(rr); kt = np.argmin(cc)                         # bottom end (south), top end (west)
    path, _ = route_through_array(cost, (rr[kb] - int(6 / R), cc[kb]), (rr[kt], cc[kt] + int(6 / R)), fully_connected=True, geometric=True)
    pts = np.array([[x0 + (c + 0.5) * R, z0 + (r + 0.5) * R] for r, c in path])
    d = np.hypot(*np.diff(pts, axis=0).T); cs = np.concatenate([[0], np.cumsum(d)])
    u = np.arange(0, cs[-1], 0.5); p = np.stack([np.interp(u, cs, pts[:, 0]), np.interp(u, cs, pts[:, 1])], 1)
    p = np.stack([gaussian_filter1d(p[:, 0], 3, mode='nearest'), gaussian_filter1d(p[:, 1], 3, mode='nearest')], 1)
    r_ = ((p[:, 1] - z0) / R).astype(int); c_ = ((p[:, 0] - x0) / R).astype(int)
    e = dt[r_, c_]
    log(f'  route: {u[-1]:.0f} m, closest to a tarmac edge {e.min():.2f} m, {np.sum(e < 1.5) * 0.5:.0f} m of it within 1.5 m of one')
    return p

def resample(line, step=2.0):
    seg = np.hypot(*np.diff(line, axis=0).T); s = np.concatenate([[0], np.cumsum(seg)]); L = s[-1]
    n = int(round(L / step)); ss = np.linspace(0, L, n + 1)
    return np.stack([np.interp(ss, s, line[:, 0]), np.interp(ss, s, line[:, 1])], 1)

def normals(line):
    t = np.gradient(line, axis=0); t /= np.linalg.norm(t, axis=1, keepdims=True)
    return t, np.stack([-t[:, 1], t[:, 0]], 1)

def road_span(p, n, yref, half=9.0, step=0.1):
    ds = np.arange(-half, half + 1e-9, step)
    ok = np.array([abs(lane_s.top(*(p + n * d), below=yref + 1.5) - yref) < 1.0 for d in ds])
    c = len(ds) // 2
    if not ok[c]:
        k = np.nonzero(ok)[0]
        if not len(k): return None
        c = k[np.argmin(np.abs(k - c))]
    a = c
    while a > 0 and ok[a - 1]: a -= 1
    b = c
    while b < len(ok) - 1 and ok[b + 1]: b += 1
    return ds[a] - step / 2, ds[b] + step / 2

def heights(line, tr):
    """road height along the line, following the road (never jumping onto a road above or below)"""
    y = np.full(len(line), np.nan); prev = None
    for i, (x, z) in enumerate(line):
        hs = tr.all(x, z)
        if hs:
            h = max(hs) if prev is None else min(hs, key=lambda v: abs(v - prev))   # the surface nearest the last one
            y[i] = h; prev = h
    bad = ~np.isfinite(y)
    if bad.any(): y[bad] = np.interp(np.nonzero(bad)[0], np.nonzero(~bad)[0], y[~bad])
    return y, int(bad.sum())
CACHE = os.environ.get('IROHA_CACHE', SRC + '.line.npz')
if os.path.exists(CACHE) and os.path.getmtime(CACHE) > os.path.getmtime(SRC) and os.path.getmtime(CACHE) > os.path.getmtime(__file__):
    _c = np.load(CACHE); line, ly, wid = _c['line'], _c['ly'], list(_c['wid'])
    log(f'centreline from {CACHE}')
else:
    line = resample(centreline())
    ly, nb = heights(line, road_s)
    log(f'  {nb} samples off the road')
    wid = []
    for it in range(2):
        t_, n_ = normals(line)
        off = np.zeros(len(line)); wid = []
        for i in range(len(line)):
            sp = road_span(line[i], n_[i], ly[i])
            if sp and sp[0] <= 0 <= sp[1]: off[i] = np.clip((sp[0] + sp[1]) / 2, -1.0, 1.0); wid.append(sp[1] - sp[0])
        log(f'  centring {it}: offset median {np.median(np.abs(off)):.2f} max {np.abs(off).max():.2f} m, road width {np.median(wid):.2f} m')
        line = resample(line + n_ * gaussian_filter1d(off, 2, mode='nearest')[:, None])
        ly, nb = heights(line, road_s)
    for end in (0, 1):
        p = line[0] if end == 0 else line[-1]; q = line[3] if end == 0 else line[-4]
        u = (p - q) / np.linalg.norm(p - q); k = 0
        while k < 80 and np.isfinite(tar_s.top(*(p + u * (k + 1) * 0.5))): k += 1
        ext = np.array([p + u * j * 0.5 for j in range(1, k + 1)])
        if len(ext): line = np.vstack([ext[::-1], line]) if end == 0 else np.vstack([line, ext])
        log(f'  end {end}: carried {k * 0.5:.1f} m on to the end of the tarmac')
    line = resample(line)
    ly, nb = heights(line, tar_s)
    try: np.savez(CACHE, line=line, ly=ly, wid=np.array(wid))
    except OSError: pass
line_len = float(np.hypot(*np.diff(line, axis=0).T).sum())
ROAD_W = float(np.median(wid))
line_tree = cKDTree(line)
def s_of(x, z):
    j = int(line_tree.query([x, z])[1])
    return j * line_len / (len(line) - 1)
S_START = s_of(AB_FINISH[0], AB_FINISH[2])          # the bottom line
S_FINISH = s_of(AB_START[0], AB_START[2])           # the top line
assert S_FINISH > S_START, 'the line should run from the bottom up'
sl = np.linspace(0, line_len, len(line))
log(f'centreline {line_len:.0f} m, {len(line)} samples, {ly[0]:.1f} m to {ly[-1]:.1f} m; stage {S_START:.0f} to {S_FINISH:.0f} m: '
    f'{S_FINISH - S_START:.0f} m, {np.interp(S_FINISH, sl, ly) - np.interp(S_START, sl, ly):.0f} m climb; road {ROAD_W:.1f} m wide')

