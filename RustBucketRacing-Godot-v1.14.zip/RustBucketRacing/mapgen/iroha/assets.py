"""Textures and materials for the rebuilt Irohazaka: the source model's own textures (by their file names in the
KN5: asphalt, gutters, grass, the stone and rock walls, trees, the forest edge, the road signs) and a few made
here (the guardrail, painted lines)."""
import io
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

import source as S

# the source's textures this map uses
T_ASPHALT = 'image04178800_0931ef50.dds'
T_GUTTER = 'image0418b400_092e9c50.dds'
T_VERGE = 'image041b3000_092fb850.dds'
T_GRASS = 'image092f8e80_092faed0.dds'
T_LAND = 'image092f5b80_092f6bd0.dds'
T_KIKKO = 'image0418e800_09376bd0.dds'         # hexagonal ("kikko") stone retaining wall, dark
T_KIKKO2 = 'image09376d00_09378d50.dds'        # ...the same, a second cut
T_STONES = 'image0418c000_09374a50.dds'        # big fitted stones, light
T_ROCK = 'image041c3c00_093728d0.dds'          # rock cutting with moss
T_ROCK2 = 'image041b7e00_09371750.dds'         # bare rock face
T_CAP = 'image0418e000_0937a850.dds'           # concrete wall tops
T_TREES = ['image041a8800_0936bc50.dds', 'image0419e000_092fe5d0.dds', 'image041c4c00_0935b950.dds', 'image04196000_09363ad0.dds']
T_TREEFAR = 'image041a0800_093597d0.dds'
T_FOREST = 'image0417c800_092e5fd0.dds'        # a band of forest edge (cards)
T_BUSH = 'image09329b80_0932dbd0.dds'
T_DELINEATOR = 'image04190800_0931a550.dds'   # reflector posts
# road signs: their faces are taken from the source as they stand (the shop and filling-station boards are not)
T_SIGNS = ['image0930cf80_0930d3d0.dds', 'image041b9800_093094d0.dds', 'image09317e00_09318250.dds',
           'image092c2c00_092c2e50.dds', 'image041c0e00_09350350.dds', 'image09309980_09309bd0.dds',
           'image092c2280_092c2ad0.dds', 'image092c1f00_092c2150.dds', 'image092fb980_092fc1d0.dds',
           'image0930da80_0930dcd0.dds', 'image0930b700_0930bb50.dds', 'image0937b880_0937bad0.dds',
           'image09310e80_093110d0.dds', 'image041c1000_0930ce50.dds', 'image09309600_09309850.dds',
           'image0930de00_0930e650.dds', 'image0930d500_0930d950.dds', 'image092ed080_092ed1d0.dds',
           'image092fc300_092fc450.dds', 'image041b9600_09309f50.dds', 'image0936ed00_0936f150.dds',
           'image0930bc80_0930c4d0.dds']
WALL_TEX = {T_KIKKO: 'wall_kikko', T_KIKKO2: 'wall_kikko', T_STONES: 'wall_stones', T_ROCK: 'rock', T_ROCK2: 'rock_bare',
            T_CAP: 'wall_kikko'}


def src(name, rgba=False):
    im = Image.open(io.BytesIO(S.ktex_by_name[name]['data'])); im.load()
    return im.convert('RGBA' if rgba else 'RGB')


def has_alpha(name):
    a = np.asarray(src(name, True))[..., 3]
    return bool((a < 128).any())


def tex_guardrail():
    """a Japanese guardrail seen from the road: a white W-beam on white posts, 4 m to the picture (two posts),
    1 m tall (v 0 at the top), clear round it"""
    W, H = 512, 128
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    px = lambda m: int(round(m / 4.0 * W))
    py = lambda m: int(round((1.0 - m) * H))            # m above the ground
    for x0 in (0.15, 2.15):                              # posts: 14 cm, from the ground to 0.9 m
        d.rectangle([px(x0), py(0.9), px(x0 + 0.14), py(0.0)], fill=(226, 228, 226, 255))
        d.rectangle([px(x0 + 0.1), py(0.9), px(x0 + 0.14), py(0.0)], fill=(186, 188, 186, 255))
    # the beam: 0.6-0.92 m, its two ridges lit from above
    for y0, y1, c in ((0.60, 0.65, 200), (0.65, 0.72, 242), (0.72, 0.76, 205), (0.76, 0.80, 225), (0.80, 0.87, 246), (0.87, 0.92, 205)):
        d.rectangle([0, py(y1), W - 1, py(y0)], fill=(c, c, c - 3, 255))
    for x0 in (0.15, 2.15):                              # bolts
        for yb in (0.68, 0.84):
            d.ellipse([px(x0) - 2, py(yb) - 2, px(x0) + 6, py(yb) + 6], fill=(150, 150, 150, 255))
    a = np.asarray(im, np.float32)
    a[..., :3] *= 0.92 + 0.08 * np.random.default_rng(2).random((H, W, 1))
    return Image.fromarray(a.clip(0, 255).astype(np.uint8), 'RGBA')


def tex_tinted(name, gain, tint=(1, 1, 1)):
    a = np.asarray(src(name), np.float32) * gain * np.array(tint, np.float32)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


TEXTURES = {
    'asphalt': lambda: tex_tinted(T_ASPHALT, 0.92),
    'gutter': lambda: tex_tinted(T_GUTTER, 0.82), 'verge': lambda: src(T_VERGE), 'grass': lambda: src(T_GRASS),
    'forest_floor': lambda: tex_tinted(T_GRASS, 0.78, (0.92, 1.0, 0.8)), 'land': lambda: src(T_LAND),
    'wall_kikko': lambda: src(T_KIKKO), 'wall_stones': lambda: src(T_STONES), 'rock': lambda: src(T_ROCK),
    'rock_bare': lambda: src(T_ROCK2), 'guardrail': tex_guardrail,
    'forest': lambda: src(T_FOREST, True), 'bush': lambda: src(T_BUSH, True), 'delineator': lambda: src(T_DELINEATOR, True), 'tree_far': lambda: src(T_TREEFAR, True),
}
for _i, _t in enumerate(T_TREES): TEXTURES[f'tree_{_i}'] = (lambda t: lambda: src(t, True))(_t)
SIGN_ALPHA = {}
for _i, _t in enumerate(T_SIGNS): TEXTURES[f'sign_{_i}'] = (lambda t: lambda: src(t, True))(_t)


def bleed(img):
    a = np.array(img, dtype=np.float32)
    rgb, al = a[:, :, :3], a[:, :, 3]
    known = al > 8
    if known.all() or not known.any(): return img
    out = np.where(known[:, :, None], rgb, 0); filled = known.copy()
    for _ in range(64):
        if filled.all(): break
        s = sum(np.roll(np.roll(out * filled[:, :, None], dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        w = sum(np.roll(np.roll(filled.astype(np.float32), dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        new = (~filled) & (w > 0)
        out[new] = s[new] / w[new][:, None]; filled |= new
    out[~filled] = rgb[known].mean(0)
    return Image.fromarray(np.dstack([out, al]).clip(0, 255).astype(np.uint8), 'RGBA')


def webp(img):
    has_a = img.mode == 'RGBA' and (np.asarray(img)[..., 3] < 250).any()
    img = img.convert('RGBA' if has_a else 'RGB')
    if has_a: img = bleed(img)
    w, h = img.size
    sc = min(1.0, 512 / max(w, h))
    if sc < 1: img = img.resize((max(4, int(w * sc)), max(4, int(h * sc))), Image.LANCZOS)
    bio = io.BytesIO(); img.save(bio, 'WEBP', quality=82, method=6)
    return bio.getvalue()


def M(tex, cat, surf=0, mode=0, fade=0, shadow=False, layer=0, spec=0.1, color=(1, 1, 1, 1), fog=True):
    d = dict(tex=tex, cat=cat, surf=surf, mode=mode, fade=fade, shadow=shadow, layer=layer, spec=spec, color=list(color))
    if not fog: d['fog'] = False
    return d


# material key -> settings (surf: 1 tarmac, 2 kerb, 3 gravel, 4 grass, 0 none)
MATERIALS = {
    'road':        M('asphalt', 'ground', 1, spec=0.25),
    'pave':        M('asphalt', 'ground', 1, spec=0.22),          # the source's other paved ground (lay-bys, forecourt)
    'gutter':      M('gutter', 'ground', 1, spec=0.12),
    'paint':       M(None, 'ground', 1, layer=1, spec=0.2, color=(0.86, 0.86, 0.84, 1)),
    'paint_y':     M(None, 'ground', 1, layer=1, spec=0.2, color=(0.85, 0.62, 0.12, 1)),
    'verge':       M('verge', 'ground', 4, spec=0.03),
    'grass':       M('grass', 'ground', 4, spec=0.03),
    'forest_floor': M('forest_floor', 'ground', 0, spec=0.02),
    'land':        M('land', 'ground', 0, spec=0.02),
    'wall_kikko':  M('wall_kikko', 'wall', fade=0, shadow=True, spec=0.08),
    'wall_stones': M('wall_stones', 'wall', fade=0, shadow=True, spec=0.08),
    'rock':        M('rock', 'wall', fade=0, shadow=True, spec=0.05),
    'rock_bare':   M('rock_bare', 'wall', fade=0, shadow=True, spec=0.05),
    'guardrail':   M('guardrail', 'small', mode=1, fade=900, shadow=True, spec=0.45),
    'pole':        M(None, 'small', fade=450, spec=0.3, color=(0.62, 0.63, 0.64, 1)),
    'sign_back':   M(None, 'small', fade=450, spec=0.2, color=(0.55, 0.56, 0.57, 1)),
    'forest':      M('forest', 'veg', mode=1, fade=0, shadow=True),
    'bush':        M('bush', 'veg', mode=1, fade=450),
    'delineator':  M('delineator', 'small', mode=1, fade=350, spec=0.3),
    'tree_far':    M('tree_far', 'veg', mode=1, fade=0, shadow=True),
}
for _i in range(len(T_TREES)): MATERIALS[f'tree_{_i}'] = M(f'tree_{_i}', 'veg', mode=1, fade=1400, shadow=True)
for _i, _t in enumerate(T_SIGNS): MATERIALS[f'sign_{_i}'] = M(f'sign_{_i}', 'small', mode=1, fade=450, spec=0.2)


def build_tables(used):
    tex_keys, mats, mat_index = [], [], {}
    for k in sorted(used, key=lambda k: list(MATERIALS).index(k)):
        m = dict(MATERIALS[k]); t = m.pop('tex')
        if t is not None:
            if t not in tex_keys: tex_keys.append(t)
            m['tex'] = tex_keys.index(t)
        m['name'] = k
        mat_index[k] = len(mats); mats.append(m)
    images = [webp(TEXTURES[t]()) for t in tex_keys]
    return mats, mat_index, images
