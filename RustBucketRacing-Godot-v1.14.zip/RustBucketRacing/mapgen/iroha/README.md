# The Irohazaka generator

Builds `iroha.bin` (the installable map; its description is `maps/iroha.json` next to the pack in the map zips)
from scratch out of the source model, "Irohazaka Slope", an Assetto Corsa track by sost and its original authors
(free, not for sale: credited in the pack and the description). Only its layout and textures are used; everything
drawn is made here, the way the Motorsport Compound is (`../compound`). Not part of the game build
(`mapgen/.gdignore` keeps Godot out of this folder).

Needs Python 3 with numpy, scipy, scikit-image and Pillow (webp), gcc (the ray tracer in `../bake`), Godot 4.7 (set
`GODOT` to its binary: it makes the LODs headless), and the source model's `sost_irohazaka.kn5`.

    IROHA_KN5=/path/to/sost_irohazaka.kn5 python3 gen.py iroha.bin     # ~1.5 min the first time (the centreline is cached)
    python3 check_phys.py iroha.bin                                     # holes and steps in the drive surface
    python3 ../bake/bake_light.py iroha.bin                             # ~1.5 min: shadows, sky light and bounce baked in

- `source.py`: reads the model, sorts its meshes, finds the road's centreline (routed along the middle of the tarmac),
  its heights and the stage's two lines (as `tools/convert_iroha.py` did for the converted map)
- `gen.py`: the road (a ribbon of the source's width and cross-fall, 1 m steps in the bends, no edge folding back
  round a hairpin), its paint, the ground (one triangulation: dense rows beside the road, the source's retaining
  walls and cuttings in them, coarser out to the valley's edge; each piece textured by its slope and by the source's
  wall nearest it), guardrails where the ground drops away, collisions, trees (the source's trees as cards of their
  size, its far forest, forest-edge cards, bushes and reflector posts, more trees on the slopes it left bare), its road
  signs on poles of our own; then the pack (`../compound/writer.py`: chunks, LODs, one texture array)
- `assets.py`: textures (the source's by file name, the guardrail drawn here) and materials
- `kn5.py`: the KN5 reader
