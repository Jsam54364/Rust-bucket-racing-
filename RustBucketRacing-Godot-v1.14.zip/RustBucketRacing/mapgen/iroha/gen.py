"""Rebuild the Irohazaka map from its source model (source.py: "Irohazaka Slope" by sost and its original authors),
the way the Motorsport Compound is built: only what the map needs, made for the game.

  * the road: a ribbon along the centreline, its width and its cross-fall taken from the source's tarmac (1 m
    steps in the bends, 2 m on the straights), painted edge lines and a dashed lane line, the stage's two lines
  * the ground: one triangulation, the road's edges and rows beside them dense (the walls are in them: the source's
    stone retaining walls and rock cuttings where its ground rises or drops beside the road), coarser with
    distance out to the edge of the valley; each piece gets its texture from its slope and from what the source
    has there (kikko stone, fitted stones, rock, gutters, verges, grass, forest floor, the land beyond)
  * guardrails where the ground drops away (one strip wearing a picture of the rail and its posts), collisions along
    them and along the walls, and across the road's two ends
  * trees: cards on the slopes, dense near the road and thinning with distance, a band of forest edge behind them,
    bushes on the verges
  * the source's road signs, as they stand, on poles of our own
  * chunks, LODs, one texture array (writer.py); then the light baked in (../bake/bake_light.py)

    IROHA_KN5=/path/to/sost_irohazaka.kn5 GODOT=/path/to/godot python3 gen.py iroha.bin
"""
import os, sys, time, json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
from scipy.ndimage import gaussian_filter1d, median_filter
from scipy.spatial import cKDTree, Delaunay

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(1, os.path.join(HERE, '..', 'compound')); sys.path.insert(2, os.path.join(HERE, '..', 'bake'))
import source as S
import assets as AS
from geom import Mesh, strip, grid_tris, quad, cards
import writer as W
import bake_light as BL

OUT = next((a for a in sys.argv[1:] if not a.startswith('--')), 'iroha.bin')
log = S.log
rng = np.random.default_rng(11)

# ---------------------------------------------------------------- the source, for rays
ROAD, CURB, GRASS, WALL, LAND, RAIL, FORE = 1, 4, 8, 16, 32, 64, 256
TERRAIN = ROAD | CURB | GRASS | WALL | LAND | FORE
FORECOURT = 'image092eee80_092ef6d0.dds'
RAIL_TEX = {'image0418a000_092e8bd0.dds', 'image0418a400_092e8850.dds', 'image0418a800_092ea1d0.dds'}


def source_tris():
    T, M, TX = [], [], []
    for mi, c in enumerate(S.cls):
        m = S.meshes[mi]; t = S.tex_name(mi)
        if c == 'road': k = FORE if t == FORECOURT else ROAD
        elif c == 'curb': k = CURB
        elif c == 'grass': k = GRASS
        elif c == 'far': k = LAND
        elif c == 'wall': k = RAIL if t in RAIL_TEX else (WALL if t in AS.WALL_TEX else 0)
        else: k = 0
        if not k or not len(m['I']): continue
        T.append(m['P'][m['I']]); M.append(np.full(len(m['I']), k)); TX.append(np.full(len(m['I']), t, object))
    return np.concatenate(T), np.concatenate(M), np.concatenate(TX)


SRC_T, SRC_M, SRC_TEX = source_tris()
rt = BL.load_rt()
rt.rt_build(len(SRC_T), np.ascontiguousarray(SRC_T.reshape(-1, 9), np.float32), np.ascontiguousarray(SRC_M, np.int32),
            np.full(len(SRC_T), -1, np.int32), np.zeros((len(SRC_T), 6), np.float32))
rt.rt_tground(0.0)
log(f'source surfaces for rays: {len(SRC_T)} triangles')


def probe(xz, ytop, mask):
    """the first surface of `mask` straight down from ytop at each point: height, normal, the source's triangle"""
    xz = np.ascontiguousarray(np.asarray(xz, np.float32).reshape(-1, 2)); n = len(xz)
    ytop = np.ascontiguousarray(np.broadcast_to(np.asarray(ytop, np.float32), (n,)))
    y = np.zeros(n, np.float32); nr = np.zeros((n, 3), np.float32); t = np.zeros(n, np.int32); uv = np.zeros((n, 2), np.float32)
    rt.ground_probe(n, xz, ytop, mask, y, nr, t, uv)
    return y, nr, t


# ---------------------------------------------------------------- the road
def stations():
    """the centreline resampled: 1 m in the bends, 2 m on the straights"""
    P = S.line; s0 = np.r_[0, np.cumsum(np.hypot(*np.diff(P, axis=0).T))]
    t, _ = S.normals(P)
    ang = np.unwrap(np.arctan2(t[:, 1], t[:, 0]))
    kap = np.abs(np.gradient(gaussian_filter1d(ang, 2), s0))
    s, out = 0.0, [0.0]
    while s < s0[-1] - 0.5:
        k = np.interp(s, s0, kap)
        s += 1.0 if k > 1 / 45 else 2.0
        out.append(min(s, s0[-1]))
    s = np.array(out)
    Q = np.c_[np.interp(s, s0, P[:, 0]), np.interp(s, s0, P[:, 1])]
    return s, Q, np.interp(s, s0, S.ly)


ST_S, ST_P, ST_Y = stations()
ST_T, ST_N = S.normals(ST_P)
NS = len(ST_P)
_ang = np.unwrap(np.arctan2(ST_T[:, 1], ST_T[:, 0]))
ST_K = np.gradient(gaussian_filter1d(_ang, 3), ST_S)          # curvature, + turning towards +normal
log(f'road: {NS} stations over {ST_S[-1]:.0f} m')


def road_edges():
    """the tarmac's two edges (offsets along the normal: lo < 0 < hi), from the source's road across each station"""
    ds = np.arange(-12.0, 12.0001, 0.1)
    xz = ST_P[:, None, :] + ST_N[:, None, :] * ds[None, :, None]
    y, _, _ = probe(xz.reshape(-1, 2), np.repeat(ST_Y + 2.0, len(ds)), ROAD)
    y = y.reshape(NS, len(ds))
    ok = np.isfinite(y) & (np.abs(y - ST_Y[:, None]) < 0.8 + 0.1 * np.abs(ds))
    c = len(ds) // 2
    lo = np.full(NS, np.nan); hi = np.full(NS, np.nan)
    for i in range(NS):
        o = ok[i]
        if not o[c]:
            k = np.nonzero(o[c - 15:c + 16])[0]
            if not len(k): continue
            j0 = c - 15 + k[np.argmin(np.abs(k - 15))]
        else: j0 = c
        a = j0
        while a > 0 and o[a - 1] and abs(y[i, a - 1] - y[i, a]) < 0.25: a -= 1
        b = j0
        while b < len(ds) - 1 and o[b + 1] and abs(y[i, b + 1] - y[i, b]) < 0.25: b += 1
        lo[i], hi[i] = ds[a] - 0.05, ds[b] + 0.05
    bad = ~np.isfinite(lo)
    if bad.any():
        idx = np.arange(NS)
        lo[bad] = np.interp(idx[bad], idx[~bad], lo[~bad]); hi[bad] = np.interp(idx[bad], idx[~bad], hi[~bad])
    lo = gaussian_filter1d(median_filter(lo, 9, mode='nearest'), 2.5, mode='nearest')
    hi = gaussian_filter1d(median_filter(hi, 9, mode='nearest'), 2.5, mode='nearest')
    lo = np.clip(lo, -11, -2.6); hi = np.clip(hi, 2.6, 11)
    # never past the bend's own centre on the inside (the edge would fold over)
    R = 1 / np.maximum(np.abs(ST_K), 1e-4)
    inner_hi = ST_K > 0
    lim = 0.92 * R
    for it in range(3):                             # clamp, smooth the kinks the clamp made, clamp again
        hi = np.where(inner_hi, np.minimum(hi, lim), hi); lo = np.where(~inner_hi, np.maximum(lo, -lim), lo)
        if it < 2: hi = gaussian_filter1d(hi, 3, mode='nearest'); lo = gaussian_filter1d(lo, 3, mode='nearest')
    hi = np.maximum(hi, 2.6); lo = np.minimum(lo, -2.6)
    # no edge may run backwards (the inside of a hairpin folding over itself): pull it in where it does
    for side, E in ((1, hi), (-1, lo)):
        for it in range(60):
            e = ST_P + ST_N * E[:, None]
            seg = np.diff(e, axis=0)
            fwd = np.einsum('ij,ij->i', seg, (ST_T[:-1] + ST_T[1:]) / 2)
            bad = np.nonzero(fwd < 0.25 * np.diff(ST_S))[0]
            if not len(bad): break
            for b in bad:
                for j in (b, b + 1):
                    if abs(E[j]) > 2.0: E[j] -= side * 0.15
            E[:] = np.where(side > 0, np.maximum(gaussian_filter1d(E, 1.0, mode='nearest'), 2.0), np.minimum(gaussian_filter1d(E, 1.0, mode='nearest'), -2.0))
        log(f'  edge {side:+d}: {len(bad)} backward steps left after {it} passes')
    log(f'road width: median {np.median(hi - lo):.2f} m, {np.percentile(hi - lo, 5):.1f}-{np.percentile(hi - lo, 95):.1f} m; '
        f'{int(bad.sum())} stations without tarmac found')
    return lo, hi


ED_LO, ED_HI = road_edges()
FRAC = np.array([-1.0, -2 / 3, -1 / 3, 0.0, 1 / 3, 2 / 3, 1.0])


def road_mesh(mesh):
    off = np.where(FRAC[None, :] < 0, -FRAC[None, :] * ED_LO[:, None], FRAC[None, :] * ED_HI[:, None])   # (NS, 7)
    xz = ST_P[:, None, :] + ST_N[:, None, :] * off[..., None]
    y, _, _ = probe(xz.reshape(-1, 2), np.repeat(ST_Y + 2.0, len(FRAC)), ROAD | FORE | CURB)
    y = y.reshape(NS, len(FRAC))
    good = np.isfinite(y) & (np.abs(y - ST_Y[:, None]) < 1.0)
    for j in range(len(FRAC)):                    # fill misses from the centre's height with the cross-fall nearby
        col = np.where(good[:, j], y[:, j] - ST_Y, np.nan)
        idx = np.arange(NS); g = np.isfinite(col)
        col = np.interp(idx, idx[g], col[g]) if g.any() else np.zeros(NS)
        y[:, j] = ST_Y + gaussian_filter1d(col, 1.5, mode='nearest')
    y[:, 3] = ST_Y
    P = np.dstack([xz[..., 0], y, xz[..., 1]])                      # (NS, 7, 3)
    UV = np.dstack([off / 3.0, np.repeat(ST_S[:, None], len(FRAC), 1) / 3.0])
    I = grid_tris(NS, len(FRAC))
    A = P.reshape(-1, 3)
    up = np.cross(A[I[:, 1]] - A[I[:, 0]], A[I[:, 2]] - A[I[:, 0]])[:, 1]
    I = np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)
    mesh.add('road', A, UV.reshape(-1, 2), I, phys=True)
    log(f'road surface: {len(I)} triangles')
    return P


# ---------------------------------------------------------------- paint
def band(mesh, mat, i0, i1, o0, o1, side, lift=0.012):
    """a painted band along the road between stations i0..i1, from o0 to o1 metres in from the edge on `side`
    (-1 lo, +1 hi), or about the middle (side 0: o0, o1 are offsets along the normal)"""
    idx = np.arange(i0, i1 + 1)
    if len(idx) < 2: return
    def at(o):
        if side == 0: d = np.full(len(idx), o)
        elif side < 0: d = ED_LO[idx] + o
        else: d = ED_HI[idx] - o
        xz = ST_P[idx] + ST_N[idx] * d[:, None]
        # height on the road surface: interpolate the cross-section
        off = np.where(FRAC[None, :] < 0, -FRAC[None, :] * ED_LO[idx, None], FRAC[None, :] * ED_HI[idx, None])
        yy = np.array([np.interp(d[k], off[k], ROAD_P[i, :, 1]) for k, i in enumerate(idx)])
        return np.c_[xz[:, 0], yy + lift, xz[:, 1]]
    A, B = at(o0), at(o1)
    P = np.stack([A, B], 1).reshape(-1, 3)
    s = ST_S[idx]
    UV = np.stack([np.c_[np.zeros(len(idx)), s], np.c_[np.ones(len(idx)), s]], 1).reshape(-1, 2)
    I = grid_tris(len(idx), 2)
    up = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])[:, 1]
    I = np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)
    mesh.add(mat, P, UV, I, N=np.tile([0.0, 1.0, 0.0], (len(P), 1)), phys=True)


def paint(mesh):
    """white edge lines 25 cm in from the tarmac's edges, a dashed lane line (3 m on, 5 m off) where the road is
    straight enough, the stage's lines across"""
    band(mesh, 'paint', 0, NS - 1, 0.25, 0.40, -1); band(mesh, 'paint', 0, NS - 1, 0.25, 0.40, +1)
    mid = (ED_LO + ED_HI) / 2
    straight = np.abs(ST_K) < 1 / 30
    on = (ST_S % 8.0) < 3.0
    seg = straight & on
    i = 0
    while i < NS:
        if seg[i]:
            j = i
            while j + 1 < NS and seg[j + 1]: j += 1
            if j > i:
                idx = np.arange(i, j + 1)
                # dashes follow the middle of the tarmac
                o = mid[i:j + 1]
                xzA = ST_P[idx] + ST_N[idx] * (o - 0.06)[:, None]; xzB = ST_P[idx] + ST_N[idx] * (o + 0.06)[:, None]
                yA = ROAD_P[idx, 3, 1] + 0.012
                P = np.stack([np.c_[xzA[:, 0], yA, xzA[:, 1]], np.c_[xzB[:, 0], yA, xzB[:, 1]]], 1).reshape(-1, 3)
                UV = np.zeros((len(P), 2)); I = grid_tris(len(idx), 2)
                up = np.cross(P[I[:, 1]] - P[I[:, 0]], P[I[:, 2]] - P[I[:, 0]])[:, 1]
                I = np.where((up < 0)[:, None], I[:, [0, 2, 1]], I)
                mesh.add('paint', P, UV, I, N=np.tile([0.0, 1.0, 0.0], (len(P), 1)), phys=True)
            i = j + 1
        else: i += 1
    for s_line in (S.S_START, S.S_FINISH):            # the stage's lines: 40 cm across the road
        i = int(np.searchsorted(ST_S, s_line))
        i = min(max(i, 1), NS - 2)
        A = ST_P[i]; t = ST_T[i]; n_ = ST_N[i]
        y = ROAD_P[i, 3, 1] + 0.014
        a0, a1 = ED_LO[i] + 0.1, ED_HI[i] - 0.1
        pts = [A + n_ * a0 - t * 0.2, A + n_ * a1 - t * 0.2, A + n_ * a1 + t * 0.2, A + n_ * a0 + t * 0.2]
        P = np.array([[p[0], y, p[1]] for p in pts])
        I = np.array([[0, 1, 2], [0, 2, 3]])
        if np.cross(P[1] - P[0], P[2] - P[0])[1] < 0: I = I[:, [0, 2, 1]]
        mesh.add('paint', P, np.zeros((4, 2)), I, N=np.tile([0.0, 1.0, 0.0], (4, 1)), phys=True)


# ---------------------------------------------------------------- the ground
OFFS = np.array([0.5, 0.9, 1.4, 2.0, 2.8, 3.8, 5.0, 6.5, 8.5, 11.0, 14.0, 18.0])


def corridor_mask(R=0.25):
    """the road's own area on a raster (the ground leaves it out)"""
    E0 = ST_P + ST_N * ED_LO[:, None]; E1 = ST_P + ST_N * ED_HI[:, None]
    allp = np.vstack([E0, E1])
    x0, z0 = allp.min(0) - 30; x1, z1 = allp.max(0) + 30
    W_, H_ = int((x1 - x0) / R) + 1, int((z1 - z0) / R) + 1
    im = Image.new('L', (W_, H_), 0); d = ImageDraw.Draw(im)
    for i in range(NS - 1):
        poly = [E0[i], E1[i], E1[i + 1], E0[i + 1]]
        d.polygon([((p[0] - x0) / R, (p[1] - z0) / R) for p in poly], fill=255)
    m = np.array(im) > 0
    return dict(m=m, x0=x0, z0=z0, R=R)


def in_corridor(C, xz, shrink=0):
    m = C['m']
    if shrink: m = ndimage.binary_erosion(m, iterations=shrink)
    c = ((xz[:, 0] - C['x0']) / C['R']).astype(int); r = ((xz[:, 1] - C['z0']) / C['R']).astype(int)
    ok = (c >= 0) & (r >= 0) & (c < m.shape[1]) & (r < m.shape[0])
    out = np.zeros(len(xz), bool)
    out[ok] = m[r[ok], c[ok]]
    return out


def ground_points(C):
    """the points the ground is triangulated over: the road's edges, rows beside them, then coarser with distance"""
    pts, kind, stn, offs = [], [], [], []           # kind: 0 road edge, 1 gutter row, 2 rows, 3 far
    Rk = 1 / np.maximum(np.abs(ST_K), 1e-4)
    for side, E in ((-1, ED_LO), (+1, ED_HI)):
        o = ST_N * side                                # outwards
        edge = ST_P + ST_N * E[:, None]
        jy = 0 if side < 0 else -1
        pts.append(np.c_[edge[:, 0], ROAD_P[:, jy, 1], edge[:, 1]]); kind.append(np.zeros(NS, int)); stn.append(np.arange(NS)); offs.append(np.zeros(NS))
        inner = (ST_K * side) > 0                      # this side is the bend's inside
        room = np.where(inner, Rk - np.abs(E), 1e9)    # from the edge to the bend's centre
        for k in OFFS:
            sel = (k < 0.7 * room) & (~inner | (Rk > 15) | (k > 1.0))   # (no gutter round the insides of tight bends)
            if k > 3.0: sel &= (np.arange(NS) % (2 if k < 9 else 4)) == 0
            xz = edge[sel] + o[sel] * k
            pts.append(np.c_[xz[:, 0], np.full(sel.sum(), np.nan), xz[:, 1]]); kind.append(np.full(sel.sum(), 1 if k == OFFS[0] else 2))
            stn.append(np.nonzero(sel)[0]); offs.append(np.full(sel.sum(), k))
    P = np.concatenate(pts); K = np.concatenate(kind); STN = np.concatenate(stn); OF = np.concatenate(offs)
    # far points: jittered grids, coarser with distance from the road
    m = C['m']
    step = 4                                         # 1 m raster for the distance
    small = m[::step, ::step]
    dist = ndimage.distance_transform_edt(~small) * C['R'] * step
    xs = np.array([C['x0'], C['z0']])
    land = SRC_T[SRC_M == LAND].reshape(-1, 3)
    lx0, lz0 = land[:, 0].min(), land[:, 2].min(); lx1, lz1 = land[:, 0].max(), land[:, 2].max()
    far = []
    for d0, d1, sp in ((18, 40, 3.0), (40, 100, 6.0), (100, 250, 12.0), (250, 1e9, 24.0)):
        gx = np.arange(lx0, lx1, sp); gz = np.arange(lz0, lz1, sp)
        GX, GZ = np.meshgrid(gx, gz)
        Q = np.c_[GX.ravel(), GZ.ravel()] + rng.uniform(-0.35, 0.35, (GX.size, 2)) * sp
        c = ((Q[:, 0] - xs[0]) / (C['R'] * step)).astype(int); r = ((Q[:, 1] - xs[1]) / (C['R'] * step)).astype(int)
        inside = (c >= 0) & (r >= 0) & (c < dist.shape[1]) & (r < dist.shape[0])
        dd = np.full(len(Q), 1e9); dd[inside] = dist[r[inside], c[inside]]
        keep = (dd >= d0) & (dd < d1)
        far.append(Q[keep])
    F = np.concatenate(far)
    P = np.vstack([P, np.c_[F[:, 0], np.full(len(F), np.nan), F[:, 1]]])
    K = np.r_[K, np.full(len(F), 3)]; STN = np.r_[STN, np.full(len(F), -1)]; OF = np.r_[OF, np.full(len(F), -1.0)]
    return P, K, STN, OF


def heights_for(P, K, STN):
    """rows and far points on the source's ground (the topmost surface, rails and trees left out)"""
    need = np.isnan(P[:, 1])
    y, nr, tri = probe(P[need][:, [0, 2]], 2000.0, TERRAIN)
    P[need, 1] = y
    src_kind = np.zeros(len(P), np.int32)
    src_kind[need] = np.where(tri >= 0, SRC_M[np.maximum(tri, 0)], 0)
    return src_kind


def build_ground(mesh, C):
    P, K, STN, OF = ground_points(C)
    g = K == 1
    src_kind = heights_for(P, K, STN)
    # which side each row point is on: offsets were built lo side first, then hi; recover from the station's normal
    rel = P[:, [0, 2]] - ST_P[np.maximum(STN, 0)]
    sd = np.sign(np.einsum('ij,ij->i', rel, ST_N[np.maximum(STN, 0)]))
    gy = np.where(sd < 0, ROAD_P[np.maximum(STN, 0), 0, 1], ROAD_P[np.maximum(STN, 0), -1, 1]) - 0.02
    P[g, 1] = gy[g]
    ok = np.isfinite(P[:, 1])
    # points inside the road's area (the other legs' rows reaching over a hairpin) go; the road's edges stay
    inside = in_corridor(C, P[:, [0, 2]], shrink=1) & (K != 0)
    keep = ok & ~inside
    P, K, STN, OF, src_kind, sd = P[keep], K[keep], STN[keep], OF[keep], src_kind[keep], sd[keep]
    # duplicates (rows of neighbouring stations meeting inside a bend)
    tree = cKDTree(P[:, [0, 2]])
    pairs = tree.query_pairs(0.12, output_type='ndarray')
    drop = np.zeros(len(P), bool)
    for a, b in pairs:
        if drop[a] or drop[b]: continue
        drop[b if K[b] >= K[a] else a] = True
    keep = ~drop
    P, K, STN, OF, src_kind, sd = P[keep], K[keep], STN[keep], OF[keep], src_kind[keep], sd[keep]
    log(f'ground: {len(P)} points ({(K == 0).sum()} road edge, {(K == 1).sum() + (K == 2).sum()} in rows, {(K == 3).sum()} beyond)')
    tri = Delaunay(P[:, [0, 2]]).simplices
    T = P[tri]
    cen = T.mean(1)
    longest = np.max([np.hypot(*(T[:, a, [0, 2]] - T[:, b, [0, 2]]).T) for a, b in ((0, 1), (1, 2), (2, 0))], axis=0)
    keep = ~in_corridor(C, cen[:, [0, 2]]) & (longest < 90)
    # (triangles from the road's edge on one side to its edge on the other, through the road)
    tri = tri[keep]
    T = P[tri]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    flip = fn[:, 1] < 0
    tri[flip] = tri[flip][:, [0, 2, 1]]; fn[flip] *= -1
    area = np.linalg.norm(fn, axis=1) / 2
    fu = fn / np.maximum(2 * area, 1e-9)[:, None]
    # vertex normals for the smooth ground
    VN = np.zeros_like(P)
    for k in range(3): np.add.at(VN, tri[:, k], fn)
    VN /= np.maximum(np.linalg.norm(VN, axis=1, keepdims=True), 1e-9)
    # what each triangle is
    cen = P[tri].mean(1)
    dist_tree = cKDTree(np.vstack([ST_P + ST_N * ED_LO[:, None], ST_P + ST_N * ED_HI[:, None]]))
    dR, j = dist_tree.query(cen[:, [0, 2]])
    road_y = np.r_[ROAD_P[:, 0, 1], ROAD_P[:, -1, 1]][j]
    above = cen[:, 1] > road_y + 0.3
    sk = src_kind[tri]
    paved = np.all((sk == ROAD) | (sk == FORE) | (sk == CURB) | (K[tri] == 0), axis=1) & ~np.all(K[tri] == 0, axis=1) & (dR > 0.6)
    st3 = STN[tri]
    gutter = np.all(K[tri] <= 1, axis=1) & (np.ptp(st3, axis=1) <= 3) & (np.ptp(sd[tri], axis=1) == 0)
    steep = fu[:, 1] < 0.5
    slope = (fu[:, 1] >= 0.5) & (fu[:, 1] < 0.8)
    # walls: as the source has them there (its nearest wall's stone), else rock above the road and kikko below
    wt = np.nonzero(SRC_M == WALL)[0]
    wall_tree = cKDTree(SRC_T[wt].mean(1))
    dw, jw = wall_tree.query(cen, distance_upper_bound=6.0)
    near_wall = np.isfinite(dw)
    wmat = np.where(above, 'rock', 'wall_kikko').astype(object)
    wmat[near_wall] = [AS.WALL_TEX.get(SRC_TEX[wt[k]], 'wall_kikko') for k in jw[near_wall]]
    mat = np.full(len(tri), 'grass', object)
    mat[dR < 14] = 'verge'
    mat[(dR > 30)] = 'forest_floor'
    mat[(dR > 200)] = 'land'
    mat[slope & (dR < 30)] = 'grass'
    mat[steep] = wmat[steep]
    mat[steep & (dR > 25)] = 'rock'
    mat[paved] = 'pave'
    mat[gutter] = 'gutter'
    phys = (dR < 7.0) & (fu[:, 1] > 0.6) | gutter | paved
    # texture coordinates: the ground's from above, the walls' from the side they face, the gutters' along the road
    for mname in sorted(set(mat)):
        sel = np.nonzero(mat == mname)[0]
        if not len(sel): continue
        I = tri[sel]
        C3 = P[I].reshape(-1, 3)
        if mname in ('wall_kikko', 'wall_stones', 'rock', 'rock_bare'):
            fx = np.abs(fu[sel, 0]) > np.abs(fu[sel, 2])
            u = np.where(np.repeat(fx, 3), C3[:, 2], C3[:, 0]) / 3.0
            UV = np.c_[u, -C3[:, 1] / 3.0]
            N = np.repeat(fu[sel], 3, 0)
        elif mname == 'gutter':
            st = STN[I].reshape(-1); st = np.maximum(st, 0)
            UV = np.c_[ST_S[st] / 2.0, np.where(K[I].reshape(-1) == 0, 0.0, 1.0)]
            N = VN[I].reshape(-1, 3)
        else:
            sc = {'land': 24.0, 'forest_floor': 6.0, 'grass': 5.0, 'verge': 3.0, 'pave': 3.0}.get(mname, 5.0)
            UV = np.c_[C3[:, 0], C3[:, 2]] / sc
            N = VN[I].reshape(-1, 3)
        mesh.add(mname, C3, UV, np.arange(len(C3)).reshape(-1, 3), N=N, phys=phys[sel])
    log(f'ground: {len(tri)} triangles; ' + ', '.join(f'{k} {int((mat == k).sum())}' for k in sorted(set(mat))))
    return P, tri, mat, VN


# ---------------------------------------------------------------- guardrails and collisions
def runs(flags, min_len=4, gap=4):
    f = flags.copy()
    f = ndimage.binary_closing(f, structure=np.ones(gap * 2 + 1)) | f
    lab, n = ndimage.label(f)
    out = []
    for k in range(1, n + 1):
        idx = np.nonzero(lab == k)[0]
        if len(idx) >= min_len: out.append((idx[0], idx[-1]))
    return out


def barriers(mesh):
    """guardrails where the ground drops away from the road; collisions along them, along the walls where the
    ground rises, a little way out over level verges, and across both ends"""
    total = 0.0
    for side, E in ((-1, ED_LO), (+1, ED_HI)):
        o = ST_N * side
        edge = ST_P + ST_N * E[:, None]
        jy = 0 if side < 0 else -1
        ey = ROAD_P[:, jy, 1]
        samples = np.array([1.2, 2.0, 3.0, 4.5, 6.0])
        xz = edge[:, None, :] + o[:, None, :] * samples[None, :, None]
        y, _, _ = probe(xz.reshape(-1, 2), 2000.0, TERRAIN)
        y = y.reshape(NS, len(samples))
        dy = y - ey[:, None]
        drop = np.nanmin(np.where(np.isfinite(dy[:, :3]), dy[:, :3], 0), axis=1) < -0.7
        rise_at = np.full(NS, np.nan)
        for i in range(NS):
            k = np.nonzero(np.isfinite(dy[i]) & (dy[i] > 0.6))[0]
            if len(k): rise_at[i] = samples[k[0]]
        rail = ndimage.binary_opening(drop, structure=np.ones(3))
        for i0, i1 in runs(rail):
            idx = np.arange(i0, i1 + 1)
            pts = edge[idx] + o[idx] * 0.62
            base = ey[idx] - 0.02
            strip(mesh, 'guardrail', pts, base, base + 1.0, 4.0, face=-o[idx], tilt=0.15)
            mesh.wall_line(pts, base - 0.6, base + 1.2)
            total += float(np.hypot(*np.diff(pts, axis=0).T).sum())
        # elsewhere: the wall where the ground rises within 6 m, else 5 m out
        rest = ~ndimage.binary_dilation(rail, structure=np.ones(3))
        off = np.where(np.isfinite(rise_at), np.minimum(rise_at, 5.0), 5.0)
        off = gaussian_filter1d(median_filter(off, 7, mode='nearest'), 1.5, mode='nearest')
        for i0, i1 in runs(rest, min_len=2, gap=0):
            idx = np.arange(max(i0 - 1, 0), min(i1 + 2, NS))
            pts = edge[idx] + o[idx] * off[idx, None]
            mesh.wall_line(pts, ey[idx] - 1.0, ey[idx] + 3.0)
    for i in (0, NS - 1):                              # the road's two ends
        a = ST_P[i] + ST_N[i] * (ED_LO[i] - 6); b = ST_P[i] + ST_N[i] * (ED_HI[i] + 6)
        mesh.wall(a, b, ST_Y[i] - 2, ST_Y[i] + 4)
    log(f'guardrail {total / 1000:.2f} km; {len(mesh.walls)} wall segments')


# ---------------------------------------------------------------- vegetation
CROWNS = ['image041a8800_0936bc50.dds', 'image041b0800_093028d0.dds', 'image0419e000_092fe5d0.dds', 'image04196000_09363ad0.dds',
          'image041c4c00_0935b950.dds', 'image092fe700_09300750.dds', 'image041a0800_093597d0.dds']
CROWN_MAT = {CROWNS[0]: 'tree_0', CROWNS[1]: 'tree_0', CROWNS[2]: 'tree_1', CROWNS[3]: 'tree_3', CROWNS[4]: 'tree_2',
             CROWNS[5]: 'tree_0', CROWNS[6]: 'tree_far'}


def components(P, I):
    from scipy.sparse.csgraph import connected_components
    from scipy.sparse import coo_matrix
    pid = np.unique(np.round(P * 1000).astype(np.int64), axis=0, return_inverse=True)[1].ravel()
    r = np.r_[pid[I[:, 0]], pid[I[:, 1]]]; c = np.r_[pid[I[:, 1]], pid[I[:, 2]]]
    _, lab = connected_components(coo_matrix((np.ones(len(r)), (r, c)), shape=(pid.max() + 1,) * 2), directed=False)
    return lab[pid[I[:, 0]]]


def pieces_of(classes):
    """every piece (connected cards) of the source's trees: centre, height range, extent across, crown texture"""
    out = []
    for mi in S.of(*classes):
        m = S.meshes[mi]
        if not len(m['I']): continue
        tl = components(m['P'], m['I']); nc = tl.max() + 1; T = m['P'][m['I']]
        c = np.maximum(np.bincount(tl, None, nc), 1)
        cx = np.bincount(tl, T[:, :, 0].mean(1), nc) / c; cz = np.bincount(tl, T[:, :, 2].mean(1), nc) / c
        mn = np.full((nc, 3), np.inf); mx = np.full((nc, 3), -np.inf)
        for k in range(3):
            np.minimum.at(mn[:, k], tl, T[:, :, k].min(1)); np.maximum.at(mx[:, k], tl, T[:, :, k].max(1))
        t = S.tex_name(mi)
        out.append(dict(c=np.c_[cx, cz], lo=mn[:, 1], hi=mx[:, 1], w=np.maximum(mx[:, 0] - mn[:, 0], mx[:, 2] - mn[:, 2]),
                        crown=np.full(nc, CROWNS.index(t) if t in CROWNS else 99)))
    return {k: np.concatenate([o[k] for o in out]) for k in out[0]}


def vegetation(mesh, GP, GT, GM, C):
    """the source's trees where it has them, as crossed cards of their size and kind (its pieces gathered into
    trees, as tools/convert_iroha.py did), its far forest the same way, its forest-edge cards, bushes and the
    reflector posts as they are; more trees filled in over the slopes it left bare"""
    from scipy.sparse.csgraph import connected_components
    from scipy.sparse import coo_matrix
    A = pieces_of(('tree',))
    pairs = cKDTree(A['c']).query_pairs(1.2, output_type='ndarray')
    _, lab = connected_components(coo_matrix((np.ones(len(pairs)), (pairs[:, 0], pairs[:, 1])), shape=(len(A['c']),) * 2), directed=False)
    n = lab.max() + 1
    lo = np.full(n, np.inf); hi = np.full(n, -np.inf); np.minimum.at(lo, lab, A['lo']); np.maximum.at(hi, lab, A['hi'])
    cnt = np.bincount(lab, None, n)
    cx = np.bincount(lab, A['c'][:, 0], n) / cnt; cz = np.bincount(lab, A['c'][:, 1], n) / cnt
    span = np.zeros(n); np.maximum.at(span, lab, A['w'] + 2 * np.hypot(A['c'][:, 0] - cx[lab], A['c'][:, 1] - cz[lab]))
    crown = np.full(n, 99); np.minimum.at(crown, lab, A['crown'])
    h = hi - lo
    ok = (h > 1.5) & ~in_corridor(C, np.c_[cx, cz])
    edges = np.vstack([ST_P + ST_N * ED_LO[:, None], ST_P + ST_N * ED_HI[:, None]])
    etree = cKDTree(edges)
    de, je = etree.query(np.c_[cx, cz])
    ok &= de > 1.2
    mats = np.array([CROWN_MAT.get(CROWNS[k], 'tree_0') if k < len(CROWNS) else 'tree_0' for k in crown], object)
    W_ = np.clip(np.maximum(span, 0.55 * h), 1.5, 1.1 * h)
    # by the road (hedges and trees on the verge): one card along the road, so nothing hangs over it; further
    # out, crossed cards no wider than their room
    hedge = de < 4.0
    head = np.arctan2(ST_T[je % NS, 1], ST_T[je % NS, 0])
    W_ = np.where(hedge, np.clip(np.maximum(span, 0.7 * h), 2.0, 12.0), np.minimum(W_, 2 * (de - 0.6)))
    h = np.minimum(h, W_ / 0.5)                     # (a tree with little room is a smaller tree, not a thinner one)
    for mname in sorted(set(mats[ok])):
        q = np.nonzero(ok & (mats == mname) & ~hedge)[0]
        if len(q): cards(mesh, mname, cx[q], lo[q] - 0.2, cz[q], W_[q], h[q] * 1.02, rng.uniform(0, np.pi, len(q)), crossed=True)
        q = np.nonzero(ok & (mats == mname) & hedge)[0]
        if len(q): cards(mesh, mname, cx[q], lo[q] - 0.2, cz[q], W_[q], h[q] * 1.02, head[q], crossed=False)
    src_xz = np.c_[cx[ok], cz[ok]]
    log(f'trees from the source: {ok.sum()} (of {n}; {int((h > 8)[ok].sum())} taller than 8 m)')
    # its far forest: each canopy piece a big card
    F = pieces_of(('treefar',))
    k = (F['crown'] == CROWNS.index('image041a0800_093597d0.dds'))
    fh = (F['hi'] - F['lo'])[k]
    cards(mesh, 'tree_far', F['c'][k, 0], F['lo'][k], F['c'][k, 1], np.maximum(F['w'][k], 0.5 * fh), fh, rng.uniform(0, np.pi, k.sum()), crossed=True)
    log(f'far forest from the source: {k.sum()} cards')
    # its forest-edge cards, bushes and reflector posts, as they are
    keep_tex = {AS.T_FOREST: 'forest', AS.T_BUSH: 'bush', AS.T_DELINEATOR: 'delineator'}
    nc = 0
    for mi in S.of('wallveg', 'bush'):
        t = S.tex_name(mi)
        if t not in keep_tex or not len(S.meshes[mi]['I']): continue
        m = S.meshes[mi]
        cen = m['P'][m['I']].mean(1)
        sel = ~in_corridor(C, cen[:, [0, 2]])
        if sel.any():
            mesh.add(keep_tex[t], m['P'], m['UV'], m['I'][sel], phys=False); nc += int(sel.sum())
    log(f'forest edge, bushes and reflector posts from the source: {nc} triangles')
    # more trees over the bare slopes
    T = GP[GT]
    fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); area = np.linalg.norm(fn, axis=1) / 2
    ny = fn[:, 1] / np.maximum(2 * area, 1e-9)
    cen = T.mean(1)
    dR, _ = etree.query(cen[:, [0, 2]])
    dens = np.where(dR < 9, 0.0, np.where(dR < 60, 1 / 55, np.where(dR < 200, 1 / 100, np.where(dR < 600, 1 / 260, 0.0))))
    dens = np.where((ny > 0.6) & np.isin(GM, ['verge', 'grass', 'forest_floor', 'land']), dens, 0.0)
    cnt_ = rng.poisson(area * dens)
    kk = np.repeat(np.arange(len(GT)), cnt_)
    r1, r2 = rng.random(len(kk)), rng.random(len(kk))
    fl = r1 + r2 > 1; r1[fl], r2[fl] = 1 - r1[fl], 1 - r2[fl]
    X = T[kk, 0] + (T[kk, 1] - T[kk, 0]) * r1[:, None] + (T[kk, 2] - T[kk, 0]) * r2[:, None]
    dd, _ = etree.query(X[:, [0, 2]])
    ds_, _ = cKDTree(src_xz).query(X[:, [0, 2]]) if len(src_xz) else (np.full(len(X), 1e9), None)
    ok = (dd > 8.0) & (ds_ > 5.0) & ~in_corridor(C, X[:, [0, 2]])
    X = X[ok]; dd = dd[ok]
    near = dd < 200
    names = [f'tree_{i}' for i in range(len(AS.T_TREES))] + ['tree_far']
    pick = rng.integers(0, len(names), len(X))
    for i_, mname in enumerate(names):
        q = np.nonzero(pick == i_)[0]
        if not len(q): continue
        Hh = np.where(near[q], rng.uniform(9, 18, len(q)), rng.uniform(14, 24, len(q)))
        # (crossed by the road; one card each further off, where a tree is a few pixels)
        for cr, sub in ((True, q[dd[q] < 70]), (False, q[dd[q] >= 70])):
            if len(sub):
                hh = Hh[np.searchsorted(q, sub)]
                cards(mesh, mname, X[sub, 0], X[sub, 1] - 0.4, X[sub, 2], hh * rng.uniform(0.7, 0.9, len(sub)), hh, rng.uniform(0, np.pi, len(sub)), crossed=cr)
    log(f'trees filled in: {near.sum()} near, {(~near).sum()} far')


# ---------------------------------------------------------------- signs
def signs(mesh, C):
    """the source's road signs, face and all as they stand, within 14 m of the road; a pole each of our own and a
    grey back"""
    tex_ix = {t: i for i, t in enumerate(AS.T_SIGNS)}
    n = 0
    for mi, c in enumerate(S.cls):
        t = S.tex_name(mi)
        if t not in tex_ix: continue
        m = S.meshes[mi]
        if not len(m['I']): continue
        P, I, UV = m['P'], m['I'], m['UV']
        d, _ = cKDTree(ST_P).query(P[I].mean(1)[:, [0, 2]])
        keep = d < 14
        if not keep.any(): continue
        I = I[keep]
        mesh.add(f'sign_{tex_ix[t]}', P, UV, I, phys=False)
        # a grey back and a pole under each board (boards: pieces of the mesh)
        T = P[I]
        fn = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); fl = np.linalg.norm(fn, axis=1, keepdims=True)
        fu = fn / np.maximum(fl, 1e-9)
        Tb = T - fu[:, None, :] * 0.015
        mesh.add('sign_back', Tb.reshape(-1, 3), np.zeros((len(Tb) * 3, 2)), np.arange(len(Tb) * 3).reshape(-1, 3)[:, [0, 2, 1]], phys=False)
        cen = T.mean(1)
        grid = np.round(cen[:, [0, 2]] / 0.8).astype(int)
        _, first = np.unique(grid, axis=0, return_index=True)
        for k in first:
            lowest = T[k][:, 1].min()
            yb, _, _ = probe(cen[k, [0, 2]][None], lowest - 0.05, TERRAIN)
            if not np.isfinite(yb[0]) or lowest - yb[0] < 0.3 or lowest - yb[0] > 4.0: continue
            x, z = cen[k, 0] - fu[k, 0] * 0.03, cen[k, 2] - fu[k, 2] * 0.03
            r = 0.035
            for a in (0, np.pi / 2):
                c_, s_ = np.cos(a) * r, np.sin(a) * r
                quad(mesh, 'pole', (x - c_, yb[0] - 0.1, z - s_), (x + c_, yb[0] - 0.1, z + s_), (x + c_, lowest, z + s_), (x - c_, lowest, z - s_))
            n += 1
    log(f'signs: {n} poles')


# ---------------------------------------------------------------- pack
def main():
    global ROAD_P
    C = corridor_mask()
    mesh = Mesh()
    ROAD_P = road_mesh(mesh)
    paint(mesh)
    GP, GT, GM, VN = build_ground(mesh, C)
    barriers(mesh)
    vegetation(mesh, GP, GT, GM, C)
    signs(mesh, C)
    st = mesh.stats()
    tv = sum(v for v, _ in st.values()); tt = sum(t for _, t in st.values())
    log(f'mesh: {tv} vertices, {tt} triangles, {len(mesh.walls)} walls')
    for k, (v, t) in sorted(st.items(), key=lambda kv: -kv[1][1])[:20]: print(f'    {k:14s} {t:8d} tris')
    # centred on the road (as the converted map was: positions stay small)
    org = np.round((S.line.min(0) + S.line.max(0)) / 2 / 10) * 10
    ORG = np.array([org[0], 0.0, org[1]])
    for k, L in mesh.parts.items():
        mesh.parts[k] = [(P - ORG, N, UV, I, ph) for P, N, UV, I, ph in L]
    mesh.walls = [(ax - org[0], az - org[1], bx - org[0], bz - org[1], y0, y1) for ax, az, bx, bz, y0, y1 in mesh.walls]
    line = S.line - org
    log(f'origin {org}')
    mats, mat_index, images = AS.build_tables(set(mesh.parts))
    stage = dict(start=round(float(S.S_START), 2), finish=round(float(S.S_FINISH), 2))
    meta = dict(width=round(float(np.median(ED_HI - ED_LO)), 2), loop=False, merge=True, stage=stage,
                credit='"Irohazaka Slope" Assetto Corsa track by sost and the original Irohazaka authors (free, non-commercial); rebuilt for Rust Bucket Racing')
    info = W.write_pack(OUT, mesh, mats, mat_index, images, line.astype(np.float32), S.ly.astype(np.float32), meta, 'Irohazaka', S.line_len)
    log('done', info)


if __name__ == '__main__':
    main()
