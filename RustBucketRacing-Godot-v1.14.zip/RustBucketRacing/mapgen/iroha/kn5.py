# Minimal KN5 (Assetto Corsa model) reader: textures, materials, node tree with meshes (node transforms applied).
import struct
class R:
    def __init__(s, b): s.b = b; s.o = 0
    def u32(s): v = struct.unpack_from('<I', s.b, s.o)[0]; s.o += 4; return v
    def i32(s): v = struct.unpack_from('<i', s.b, s.o)[0]; s.o += 4; return v
    def f32(s): v = struct.unpack_from('<f', s.b, s.o)[0]; s.o += 4; return v
    def u8(s): v = s.b[s.o]; s.o += 1; return v
    def str(s): n = s.u32(); v = s.b[s.o:s.o + n].decode('utf-8', 'replace'); s.o += n; return v
    def raw(s, n): v = s.b[s.o:s.o + n]; s.o += n; return v
def load(path, keep_data=True):
    import numpy as np
    b = open(path, 'rb').read(); r = R(b)
    assert r.raw(6) == b'sc6969', 'not a kn5'
    ver = r.u32()
    if ver > 5: r.u32()
    tex = []
    for _ in range(r.u32()):
        t = r.i32(); name = r.str(); n = r.u32(); data = r.raw(n)
        tex.append(dict(type=t, name=name, size=n, data=data if keep_data else None))
    mats = []
    for _ in range(r.u32()):
        name = r.str(); shader = r.str(); blend = r.u8(); alphatest = r.u8(); depth = r.u32()
        props = {}
        for _ in range(r.u32()):
            pn = r.str(); v = r.f32(); r.raw(36); props[pn] = v
        maps = {}
        for _ in range(r.u32()):
            mn = r.str(); slot = r.u32(); tn = r.str(); maps[mn] = tn
        mats.append(dict(name=name, shader=shader, blend=blend, alphatest=alphatest, depth=depth, props=props, maps=maps))
    meshes = []
    def node(parent_m):
        ntype = r.u32(); name = r.str(); nch = r.u32(); active = r.u8()
        M = parent_m
        if ntype == 1:
            m = np.array(struct.unpack_from('<16f', r.b, r.o)).reshape(4, 4); r.o += 64
            M = m @ parent_m   # row-vector convention: local then parent
        elif ntype == 2:
            castsh, visible, transp = r.u8(), r.u8(), r.u8()
            nv = r.u32()
            vb = np.frombuffer(r.b, dtype=np.float32, count=nv * 11, offset=r.o).reshape(nv, 11); r.o += nv * 44
            ni = r.u32()
            ib = np.frombuffer(r.b, dtype='<u2', count=ni, offset=r.o).astype(np.int64); r.o += ni * 2
            mat = r.u32(); layer = r.u32(); lodin = r.f32(); lodout = r.f32()
            bsc = struct.unpack_from('<3f', r.b, r.o); r.o += 12; brad = r.f32(); renderable = r.u8()
            P = vb[:, 0:3].astype(np.float64); P4 = np.c_[P, np.ones(nv)] @ parent_m
            Nn = vb[:, 3:6].astype(np.float64) @ np.linalg.inv(parent_m[:3, :3]).T   # normals: inverse transpose
            Nn /= np.maximum(np.linalg.norm(Nn, axis=1, keepdims=True), 1e-12)
            I = ib.reshape(-1, 3)
            if np.linalg.det(parent_m[:3, :3]) < 0: I = I[:, [0, 2, 1]]
            meshes.append(dict(name=name, P=P4[:, :3], N=Nn, UV=vb[:, 6:8].astype(np.float64), I=I, mat=mat, cast=castsh, visible=visible, transparent=transp, lodin=lodin, lodout=lodout, active=active))
        elif ntype == 3:
            raise ValueError('skinned mesh in a track')
        for _ in range(nch): node(M)
    node(np.eye(4))
    return ver, tex, mats, meshes
