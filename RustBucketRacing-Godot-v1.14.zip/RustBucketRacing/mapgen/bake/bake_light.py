"""Bake a map pack's light into its vertices (RBMP v2, 16-byte vertices): for every vertex, under the sky the game
draws that map with (data/skies, the sun at the game's bearing),
  byte 6  (pad, low)   how much of the sun it sees, everything in the way (the shadows beyond the shadow maps' reach,
                       and all of them on low graphics)
  byte 7  (pad, high)  its sky light with the world in the way, one bounce included, as a ratio to the open sky's,
                       halved (0-2): dark in corners, under trees and roofs, lighter where sunlit walls and ground
                       throw light back into the shade
  byte 11 (normal w)   how much of the sun it sees with only the ground in the way (hills: the part of the shadows
                       the shadow maps don't draw, as the ground casts none)
and a "bake" entry in the header; and the ground near shadows in texels ("gbake": see ground_bake). The ray tracer
is rt.c, next to this (built here with gcc and OpenMP). Needs numpy and Pillow (webp).

usage: python3 -I bake_light.py maps/spa.bin [out.bin] [--sky NAME] [--rays 96] [--no-ground]
(the sky is the one the game gives the map, by the pack's file name; Main.SkyFor)
"""
import os, sys, json, gzip, struct, time, ctypes, subprocess, io, argparse
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
GAME = os.path.dirname(os.path.dirname(HERE))           # the Godot project (mapgen/bake/..)
SKY_FOR = {'compound': 'sunflowers_puresky', 'spa': 'qwantani_afternoon_puresky', 'mcr': 'qwantani_noon_puresky',
           'iroha': 'kloofendal_43d_clear_puresky'}
DEFAULT_SKY = 'kloofendal_48d_partly_cloudy_puresky'
TO_SUN = np.array([-0.42, 0.74, -0.52]); TO_SUN /= np.linalg.norm(TO_SUN)   # Main.DefaultToSun
# Skies.cs
TARGET, MAX_SUN_TO_SKY = 1.3, 2.6
T0 = time.time()


def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)


def lum(c): return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def basis(d):
    x, y, z = d[..., 0], d[..., 1], d[..., 2]
    return np.stack([0.282095 * np.ones_like(x), 0.488603 * z, 0.488603 * y, 0.488603 * x, 1.092548 * x * z,
                     1.092548 * z * y, 0.315392 * (3 * y * y - 1), 1.092548 * x * y, 0.546274 * (x * x - z * z)], -1)


def sky_light(sky):
    """the game's light for a sky (Skies.Light): sun direction and its light on white (luminance), and the maps'
    sky coefficients as luminance, irradiance / pi"""
    el = np.radians(sky['sunElev']); sin_el = max(np.sin(el), 0.05)
    r = min(MAX_SUN_TO_SKY, sky['sunE'] * np.sin(el) / max(sky['skyE'], 1e-6)) if sky['sunE'] > 0 else 0
    S = TARGET / (1 + r)
    m = S * np.pi / max(sky['skyE'], 1e-6)
    sun_energy = (TARGET - S) / sin_el
    az = np.arctan2(TO_SUN[0], -TO_SUN[2])
    to_sun = np.array([np.sin(az) * np.cos(el), np.sin(el), -np.cos(az) * np.cos(el)]); to_sun /= np.linalg.norm(to_sun)
    rot = np.radians(sky['sunPhi']) - az
    sh = np.array(sky['sh'])                                   # 9 x rgb
    # turn with the panorama: the light at d is the photo's at d turned by -rot about y
    th = (np.arange(96) + 0.5) / 96 * np.pi; ph = (np.arange(192) + 0.5) / 192 * 2 * np.pi
    TH, PH = np.meshgrid(th, ph, indexing='ij')
    d = np.stack([np.sin(TH) * np.sin(PH), np.cos(TH), -np.sin(TH) * np.cos(PH)], -1)
    c, s = np.cos(-rot), np.sin(-rot)                           # Vector3.Rotated(Up, a): x' = x c + z s, z' = -x s + z c
    src = np.stack([d[..., 0] * c + d[..., 2] * s, d[..., 1], -d[..., 0] * s + d[..., 2] * c], -1)
    val = basis(src) @ sh                                       # (.., 3)
    w = np.sin(TH)
    acc = np.einsum('ijk,ijc,ij->kc', basis(d), val, w) * (4 * np.pi / w.sum())
    shI = np.array([lum(acc[k]) for k in range(9)]) * m
    A = np.array([1, 2 / 3, 2 / 3, 2 / 3, 1 / 4, 1 / 4, 1 / 4, 1 / 4, 1 / 4])
    shR = shI / A
    sunE = sun_energy * lum(sky['sunColor'])
    return to_sun, sunE, shI.astype(np.float32), shR.astype(np.float32), dict(S=S, m=m, sun=sun_energy, el=sky['sunElev'])


def load_rt():
    src = os.path.join(HERE, 'rt.c'); so = os.path.join(HERE, 'rt.so')
    if not os.path.exists(so) or os.path.getmtime(so) < os.path.getmtime(src):
        subprocess.check_call(['gcc', '-O3', '-march=native', '-fopenmp', '-shared', '-fPIC', src, '-o', so, '-lm'])
    rt = ctypes.CDLL(so)
    P = np.ctypeslib.ndpointer
    f32, i32, u8, i64 = (P(dtype=np.float32, flags='C_CONTIGUOUS'), P(dtype=np.int32, flags='C_CONTIGUOUS'),
                         P(dtype=np.uint8, flags='C_CONTIGUOUS'), P(dtype=np.int64, flags='C_CONTIGUOUS'))
    I, F = ctypes.c_int, ctypes.c_float
    rt.rt_build.argtypes = [I, f32, i32, i32, f32]; rt.rt_build.restype = I
    rt.rt_textures.argtypes = [I, i32, i32, i64, u8, u8]
    rt.rt_ray.argtypes = [f32, f32, F, I, f32]; rt.rt_ray.restype = I
    rt.rt_tground.argtypes = [F]
    rt.ground_probe.argtypes = [I, f32, f32, I, f32, f32, i32, f32]
    rt.bake_sun.argtypes = [I, f32, I, f32, f32, I, F, F, I, F, f32]
    rt.bake_amb.argtypes = [I, f32, I, f32, i32, I, F, I, F, f32, f32, f32, F, i32, i32, f32, f32,
                            ctypes.c_void_p, F, f32, f32, f32]
    return rt


# --- the ground's baked light, as textures --------------------------------------------------------------------------
# A vertex stands for metres of ground (16 m across a compound's paddock), too coarse for a lorry's or a tree's
# shadow; so the ground near anything that casts a shadow or hides the sky also gets its light in texels of
# TEXEL metres, in pages of PAGE texels (16 m) where there is something to see. An index texture (one texel a
# page over the area) says where each page sits in an atlas (with a texel of border, so filtering doesn't run into
# the next page), or that the page is open ground; the atlas holds the sun seen, the sky light's ratio / 2 and
# (red, green; a page with other ground a metre or more under its top, as a road under a bridge, is left to the
# vertices, which know which surface they are on). Index alpha 0: no page (the vertices' light), blue 255: open
# ground.
TEXEL, PAGE = 0.5, 32
MAX_PAGES = 3000                # (an atlas of 1.9k x 1.9k texels at most, two bytes each in the game)
SPAN = TEXEL * PAGE


def ground_bake(rt, mats, pos, tris, tmat, tmask, ground, layer, mode, keep, triV, triKind, triAlb, vsun, vsun_all, vA,
                shR, shI, L32, sunE, sun_dist, sky_dist, rays):
    caster = ((tmask & 5) != 0) & ~ground[tmat]
    if not caster.any(): return None
    P3 = pos[tris]
    cmin, cmax = P3.min(1), P3.max(1)
    gtri = ground[tmat] & (layer[tmat] == 0) & (mode[tmat] == 0)
    x0 = np.floor((cmin[caster, 0].min() - 64) / SPAN) * SPAN; z0 = np.floor((cmin[caster, 2].min() - 64) / SPAN) * SPAN
    gw = int(np.ceil((cmax[caster, 0].max() + 64 - x0) / SPAN)); gh = int(np.ceil((cmax[caster, 2].max() + 64 - z0) / SPAN))
    occ = np.zeros((gh, gw), bool)
    i0 = np.clip(((cmin[caster][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    i1 = np.clip(((cmax[caster][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    for (a, b), (c, d) in zip(i0, i1):
        occ[b:d + 1, a:c + 1] = True
    # shadows reach some way, the sky is hidden some way round: grow by 48 m
    r = int(np.ceil(48 / SPAN))
    grown = occ.copy()
    for dz in range(-r, r + 1):
        for dx in range(-r, r + 1):
            sh = np.roll(np.roll(occ, dz, 0), dx, 1)
            grown |= sh
    # ...over ground
    gocc = np.zeros((gh, gw), bool)
    g0 = np.clip(((cmin[gtri][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    g1 = np.clip(((cmax[gtri][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    for (a, b), (c, d) in zip(g0, g1):
        gocc[b:d + 1, a:c + 1] = True
    # ...near where cars go (the ground they drive on, and 48 m round it): the rest is seen from afar
    drive = np.zeros((gh, gw), bool)
    surf = np.array([int(m.get('surf', 0)) for m in mats])
    dtri = gtri & np.isin(surf[tmat], (1, 2, 3))
    d0 = np.clip(((cmin[dtri][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    d1 = np.clip(((cmax[dtri][:, [0, 2]] - [x0, z0]) // SPAN).astype(int), 0, [gw - 1, gh - 1])
    for (a, b), (c, d) in zip(d0, d1):
        drive[b:d + 1, a:c + 1] = True
    near = drive.copy()
    for dz in range(-r, r + 1):
        for dx in range(-r, r + 1):
            near |= np.roll(np.roll(drive, dz, 0), dx, 1)
    cand = np.argwhere(grown & gocc & near)                # (row z, col x)
    log(f'ground pages: {gw} x {gh} over the casters, {len(cand)} to look at')
    ytop = float(pos[:, 1].max() + 50)
    E = PAGE + 2

    def texels(pages, n):
        """texel centres of pages (n per side, the border included when n = PAGE + 2)"""
        k = (np.arange(E) - 1 + 0.5) if n == E else (np.arange(n) + 0.5) * (PAGE / n)
        X = x0 + (pages[:, 1, None, None] * PAGE + k[None, None, :]) * TEXEL
        Z = z0 + (pages[:, 0, None, None] * PAGE + k[None, :, None]) * TEXEL
        X, Z = np.broadcast_arrays(X, Z)
        return np.stack([X, Z], -1).reshape(-1, 2).astype(np.float32)

    def probe(xz, interp=False, top=None):
        y = np.zeros(len(xz), np.float32); n = np.zeros((len(xz), 3), np.float32)
        t = np.zeros(len(xz), np.int32); uv = np.zeros((len(xz), 2), np.float32)
        rt.rt_tground(0.0)
        tops = np.full(len(xz), ytop, np.float32) if top is None else np.ascontiguousarray(top, np.float32)
        rt.ground_probe(len(xz), np.ascontiguousarray(xz), tops, 2, y, n, t, uv)
        if not interp: return y, n
        # the vertices' own light there, as the shader would interpolate it
        ok = t >= 0
        tv = triV[np.maximum(t, 0)]
        w = np.c_[1 - uv.sum(1), uv]
        vs = (vsun_all[tv] * w).sum(1); va = (vA[tv] * w).sum(1)
        vs[~ok] = 1; va[~ok] = 1
        return y, n, vs, va

    def bake(xz, y, n, nsun, nsky):
        ok = np.isfinite(y)
        P = np.ascontiguousarray(np.c_[xz[:, 0], np.where(ok, y, 0), xz[:, 1]].astype(np.float32))
        N = np.ascontiguousarray(n)
        sun = np.ones(len(xz), np.float32); A = np.ones(len(xz), np.float32); V = np.ones(len(xz), np.float32); side = np.zeros(len(xz), np.float32)
        rt.rt_tground(1.5)
        rt.bake_sun(len(xz), P, 1, N, L32, nsun, np.radians(1.2), sun_dist, 3, 0.05, sun)
        rt.rt_tground(0.3)
        rt.bake_amb(len(xz), P, 1, N, np.zeros(len(xz), np.int32), nsky, sky_dist, 4, 0.05, shR, shI, L32, float(sunE),
                    triV, triKind, triAlb, vsun, vA.ctypes.data, 0.8, A, V, side)
        sun[~ok] = 1; A[~ok] = 1
        return sun, A

    # a quick look (8 x 8 a page): the pages where the vertices' light (interpolated over their triangles) misses
    # what's there, then those in full
    q = 8
    xz = texels(cand, q); y, n, vs, va = probe(xz, True)
    sun, A = bake(xz, y, n, 4, 16)
    miss = (np.abs(sun - vs) > 0.4) | (np.abs(A - va) > 0.25)
    score = miss.reshape(len(cand), -1).sum(1)
    busy = score >= 2
    ondrive = drive[cand[:, 0], cand[:, 1]]
    log(f'{busy.sum()} pages miss, {(busy & ondrive).sum()} of them on the roads')
    # the roads' own pages first, then the worst missed
    score = np.where(busy, score + np.where(ondrive, 1000, 0), -1)
    if busy.sum() > MAX_PAGES:                             # the worst missed first
        busy[np.argsort(-score)[MAX_PAGES:]] = False
    pages = cand[busy]
    log(f'{busy.sum()} pages where the vertices miss the shadows or the shade')
    if len(pages) == 0: return None
    if len(pages) > 255 * 255: raise SystemExit('too many ground pages')
    out_sun, out_A, out_y = [], [], []
    step = 2048
    for b in range(0, len(pages), step):
        pg = pages[b:b + step]
        xz = texels(pg, E); y, n = probe(xz)
        # more ground a metre or more under the top (a road under a bridge, in a tunnel): the page is left to the
        # vertices, which know which surface they are on
        y2, _ = probe(xz, top=np.where(np.isfinite(y), y - 1.0, ytop))
        under = (np.isfinite(y) & np.isfinite(y2)).reshape(len(pg), -1).any(1)
        s2, a2 = bake(xz, y, n, 8, max(24, rays // 3))
        out_sun.append(s2.reshape(len(pg), E, E)); out_A.append(a2.reshape(len(pg), E, E)); out_y.append(under)
        log(f'  pages {b + len(pg)} / {len(pages)}')
    S = np.concatenate(out_sun); A = np.concatenate(out_A); U = np.concatenate(out_y)
    # pages that came out open after all
    inner = (slice(None), slice(1, E - 1), slice(1, E - 1))
    real = (S[inner].reshape(len(S), -1).min(1) < 0.985) | (A[inner].reshape(len(S), -1).min(1) < 0.95)
    open_pages = pages[~real & ~U]; keep_ = real & ~U
    pages, S, A = pages[keep_], S[keep_], A[keep_]
    log(f'{len(pages)} pages kept ({len(open_pages)} open after all, {U.sum()} over other ground)')
    # the atlas
    cols = int(np.ceil(np.sqrt(len(pages)))); rows = int(np.ceil(len(pages) / cols))
    # (the sky light smoothed over 3 x 3 texels: its rays' noise out, and it packs smaller)
    pad = np.pad(A, ((0, 0), (1, 1), (1, 1)), mode='edge')
    A = sum(pad[:, 1 + dy:1 + dy + E, 1 + dx:1 + dx + E] for dy in (-1, 0, 1) for dx in (-1, 0, 1)) / 9
    atlas = np.zeros((rows * E, cols * E, 4), np.uint8)
    for k in range(len(pages)):
        r_, c_ = divmod(k, cols)
        blk = atlas[r_ * E:(r_ + 1) * E, c_ * E:(c_ + 1) * E]
        blk[..., 0] = np.round(np.clip(S[k], 0, 1) * 255)
        blk[..., 1] = np.round(np.clip(A[k] / 2, 0, 1) * 255)
        blk[..., 3] = 255
    index = np.zeros((gh, gw, 4), np.uint8)
    for k, (pz, px) in enumerate(pages):
        r_, c_ = divmod(k, cols)
        index[pz, px] = (c_, r_, 0, 255)
    for pz, px in open_pages: index[pz, px] = (0, 0, 255, 255)
    def webp(a):        # lossless, every channel kept as it is (exact: even under zero alpha)
        b = io.BytesIO(); Image.fromarray(a, 'RGBA').save(b, 'WEBP', lossless=True, quality=100, method=6, exact=True); return b.getvalue()
    pi, pa = webp(index), webp(atlas)
    chk = np.asarray(Image.open(io.BytesIO(pa)).convert('RGBA'))
    if not np.array_equal(chk, atlas): raise SystemExit('the atlas did not survive WebP')
    log(f'ground textures: index {gw} x {gh} ({len(pi) / 1e3:.0f} kB), atlas {cols * E} x {rows * E} ({len(pa) / 1e6:.2f} MB)')
    info = dict(origin=[float(x0), float(z0)], span=SPAN, texels=PAGE, border=1, grid=[gw, gh], pages=[cols, rows])
    return pi, pa, info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pack'); ap.add_argument('out', nargs='?')
    ap.add_argument('--sky'); ap.add_argument('--rays', type=int, default=96); ap.add_argument('--sun-rays', type=int, default=16)
    ap.add_argument('--no-ground', action='store_true'); ap.add_argument('--sky-dist', type=float, default=400.0); ap.add_argument('--sun-dist', type=float, default=2500.0)
    a = ap.parse_args()
    out = a.out or a.pack
    mapid = os.path.splitext(os.path.basename(a.pack))[0]
    skyname = a.sky or SKY_FOR.get(mapid, DEFAULT_SKY)
    skies = json.load(open(os.path.join(GAME, 'data', 'skies', 'skies.json')))
    to_sun, sunE, shI, shR, info = sky_light(skies[skyname])
    log(f'{mapid}: sky {skyname}, sun {info["el"]:.0f} deg, sun on white {sunE:.2f}, open sky on level ground '
        f'{float(basis(np.array([0., 1., 0.])) @ shI):.3f} (game S {info["S"]:.3f})')

    raw = open(a.pack, 'rb').read()
    assert raw[:4] == b'RBMP'
    jl = struct.unpack('<I', raw[4:8])[0]
    h = json.loads(raw[8:8 + jl]); base = 8 + jl
    assert h.get('vstride', 16) == 16
    g = h['geo']
    geo = bytearray(gzip.decompress(raw[base + g[0]: base + g[0] + g[1]]))
    VL, IL = g[2], g[3]
    nv = VL // 16
    V = np.frombuffer(bytes(geo[:VL]), dtype=[('p', '<i2', 3), ('pad', 'u1', 2), ('n', 'i1', 4), ('uv', '<i2', 2)]).copy()
    I = np.frombuffer(bytes(geo[VL:VL + IL]), '<u2')
    mats = h['materials']
    if 'bake' not in h and (V['pad'].any() or V['n'][:, 3].any()):
        raise SystemExit('the free vertex bytes are in use')

    # vertices in world space, and each one's material (vertices are welded per material, so each has one)
    pos = np.zeros((nv, 3)); vmat = np.full(nv, -1, np.int64); uv = np.zeros((nv, 2))
    tris, tmat = [], []
    for c in h['chunks']:
        qs = c.get('qs', h.get('qs', 64)); o = np.array(c['o']); v0, vn = c['v']; i0 = c['i'][0]
        pos[v0:v0 + vn] = V['p'][v0:v0 + vn] / qs + o
        for d in c['d']:
            m, di0, dn = d[0], d[1], d[2]
            idx = I[i0 + di0: i0 + di0 + dn - dn % 3].astype(np.int64) + v0
            uo = d[3] if len(d) > 3 else [0, 0, 1]
            u = np.unique(idx)
            vmat[u] = m
            uv[u] = V['uv'][u] / uo[2] + np.array(uo[:2])
            tris.append(idx.reshape(-1, 3)); tmat.append(np.full(len(idx) // 3, m))
    tris = np.concatenate(tris); tmat = np.concatenate(tmat)
    nrm = V['n'][:, :3] / 127.0
    nl = np.linalg.norm(nrm, axis=1)
    nrm = np.where(nl[:, None] > 1e-6, nrm / np.maximum(nl, 1e-6)[:, None], [0, 1, 0])
    log(f'{nv} vertices, {len(tris)} triangles, {len(mats)} materials')

    cat = np.array([m.get('cat', 'obj') for m in mats]); mode = np.array([int(m.get('mode', 0)) for m in mats])
    layer = np.array([int(m.get('layer', 0)) for m in mats]); shadow = np.array([bool(m.get('shadow', False)) for m in mats])
    far = cat == 'far'; ground = cat == 'ground'; veg = cat == 'veg'
    # which rays each material stops: 1 the sun (what casts shadows in the game), 2 the sun stopped by the ground,
    # 4 the sky (everything solid but the ground's painted overlays, glass and the backdrop)
    terrain = ground & (layer == 0) & (mode == 0)
    mmask = np.where(shadow & (mode != 2) & ~far, 1, 0) | np.where(terrain, 3, 0) | np.where(~far & (mode != 2) & ~(ground & (layer != 0)), 4, 0)
    tmask = mmask[tmat].astype(np.int32)

    # textures: alpha for the cut-outs, mean colour for the bounce
    alpha_of, alb = {}, np.zeros(len(mats))
    tex_w, tex_h, tex_off, tex_cut, tex_data = [], [], [], [], []
    mean_lin = {}
    for mi, m in enumerate(mats):
        col = np.array((m.get('color') or [1, 1, 1])[:3], float)
        t = m.get('tex')
        if t is None or t >= len(h['images']):
            alb[mi] = lum(col); continue
        if t not in mean_lin:
            o, n, _ = h['images'][t]
            img = np.asarray(Image.open(io.BytesIO(raw[base + o: base + o + n])).convert('RGBA'))
            a8 = img[..., 3]
            lin = (img[..., :3] / 255.0) ** 2.2
            wgt = (a8 >= 128).astype(float) + 1e-6
            mean_lin[t] = ((lin * wgt[..., None]).reshape(-1, 3).sum(0) / wgt.sum(), a8)
        ml, a8 = mean_lin[t]
        alb[mi] = lum(ml * col)
        if mode[mi] == 1:
            if t not in alpha_of:
                alpha_of[t] = len(tex_w)
                tex_w.append(a8.shape[1]); tex_h.append(a8.shape[0]); tex_off.append(sum(x.size for x in tex_data)); tex_cut.append(128)
                tex_data.append(np.ascontiguousarray(a8, np.uint8).ravel())
    ttex = np.array([alpha_of.get(mats[m].get('tex'), -1) if mode[m] == 1 else -1 for m in range(len(mats))], np.int32)[tmat]
    tri_uv = uv[tris].reshape(-1, 6).astype(np.float32)
    kind = np.where(ground, 0, np.where(veg, 1, 2))
    log(f'albedo: ' + ', '.join(f'{mats[i]["name"]} {alb[i]:.2f}' for i in range(min(len(mats), 12))) + ' ...')

    rt = load_rt()
    tri_p = pos[tris].reshape(-1, 9).astype(np.float32)
    sel = tmask != 0
    # (the tracer gets only the triangles that stop something; its indices map back through `keep`)
    keep = np.nonzero(sel)[0]
    nn = rt.rt_build(len(keep), np.ascontiguousarray(tri_p[keep]), np.ascontiguousarray(tmask[keep]),
                     np.ascontiguousarray(ttex[keep]), np.ascontiguousarray(tri_uv[keep]))
    data = np.concatenate(tex_data) if tex_data else np.zeros(1, np.uint8)
    rt.rt_textures(len(tex_w), np.array(tex_w, np.int32), np.array(tex_h, np.int32), np.array(tex_off, np.int64),
                   data, np.array(tex_cut, np.uint8) if tex_cut else np.zeros(1, np.uint8))
    log(f'BVH: {len(keep)} triangles, {nn} nodes, {len(tex_w)} alpha textures')

    if os.environ.get('BAKE_PROBE'):
        px, py, pz, nx, ny, nz = map(float, os.environ['BAKE_PROBE'].split(','))
        o = np.array([px, py, pz], np.float32); res = np.zeros(3, np.float32)
        rng = np.random.default_rng(1)
        for sgn in (1, -1):
            for k in range(12):
                d = rng.normal(size=3); n = np.array([nx, ny, nz]) * sgn
                d = d / np.linalg.norm(d); d = d if d @ n > 0 else -d
                hit = rt.rt_ray((o + n * 0.05).astype(np.float32), d.astype(np.float32), 400.0, 4, res)
                print(sgn, d.round(2), 'miss' if hit < 0 else (round(float(res[0]), 2), mats[tmat[keep[hit]]]['name'][:40], mats[tmat[keep[hit]]]['cat']))
        return
    # the side each vertex is lit on: ground faces up; anything else its normal (towards the sun for the sun)
    vm = np.maximum(vmat, 0)
    vground = ground[vm] & (vmat >= 0); vveg = veg[vm] & (vmat >= 0); vfar = far[vm] | (vmat < 0)
    n_amb = nrm.copy()
    n_amb[vground & (n_amb[:, 1] < 0)] *= -1
    n_sun = n_amb.copy()
    flip = ~vground & (n_sun @ to_sun < 0)
    n_sun[flip] *= -1
    work = np.nonzero(~vfar)[0]
    # where each vertex's rays start: K points a third of the way to the middles of its largest triangles (a vertex
    # stands for the surface round it; on its own it often sits in a corner where faces meet, which would darken a
    # whole wall)
    K = 4
    tv = tris.ravel(); tt = np.repeat(np.arange(len(tris)), 3)
    ar = 0.5 * np.linalg.norm(np.cross(pos[tris[:, 1]] - pos[tris[:, 0]], pos[tris[:, 2]] - pos[tris[:, 0]]), axis=1)
    order = np.lexsort((-ar[tt], tv))
    tv, tt = tv[order], tt[order]
    first = np.searchsorted(tv, np.arange(nv)); count = np.searchsorted(tv, np.arange(nv), 'right') - first
    rank = np.arange(len(tv)) - first[tv]
    pts = np.repeat(pos[:, None, :], K, 1)
    cen = pos[tris].mean(1)
    sel_k = rank < K
    pts[tv[sel_k], rank[sel_k]] = pos[tv[sel_k]] + (cen[tt[sel_k]] - pos[tv[sel_k]]) / 3
    for r in range(1, K):                       # fewer triangles than K: go round them again
        few = np.nonzero((count > 0) & (count <= r))[0]
        pts[few, r] = pts[few, r % count[few]]
    P32 = np.ascontiguousarray(pts[work], np.float32)
    L32 = to_sun.astype(np.float32)

    # (the ground just above ground, as a road over the grass it was laid on, shades nothing)
    rt.rt_tground(1.5)
    sun_all = np.ones(nv, np.float32); sun_ter = np.ones(nv, np.float32)
    o1 = np.zeros(len(work), np.float32)
    rt.bake_sun(len(work), P32, K, np.ascontiguousarray(n_sun[work], np.float32), L32, a.sun_rays, np.radians(1.2), a.sun_dist, 1 | 2, 0.05, o1)
    sun_all[work] = o1
    log(f'sun: {np.mean(o1 < 0.5) * 100:.1f} % of vertices in shadow')
    o2 = np.zeros(len(work), np.float32)
    rt.bake_sun(len(work), P32, K, np.ascontiguousarray(n_sun[work], np.float32), L32, 4, np.radians(1.2), a.sun_dist, 2, 0.05, o2)
    sun_ter[work] = o2
    log(f'sun, the ground only: {np.mean(o2 < 0.5) * 100:.2f} % in shadow')

    # triangles' data for the bounce, by the tracer's index (only `keep` triangles can be hit)
    triV = np.ascontiguousarray(np.searchsorted(work, tris[keep]).clip(0, len(work) - 1).astype(np.int32))
    triKind = np.ascontiguousarray(kind[tmat[keep]].astype(np.int32))
    triAlb = np.ascontiguousarray(alb[tmat[keep]].astype(np.float32))
    vmode = np.ascontiguousarray(np.where(vveg, 1, np.where(vground, 0, 2))[work].astype(np.int32))
    N32 = np.ascontiguousarray(n_amb[work], np.float32)
    vsun = np.ascontiguousarray(o1)
    rt.rt_tground(0.3)
    A = np.zeros(len(work), np.float32); Vs = np.zeros(len(work), np.float32); side = np.zeros(len(work), np.float32)
    for p in range(2):
        prev = A.copy() if p else None
        rt.bake_amb(len(work), P32, K, N32, vmode, a.rays, a.sky_dist, 4, 0.05, shR, shI, L32, float(sunE),
                    triV, triKind, triAlb, vsun, prev.ctypes.data if p else None, 0.8, A, Vs, side)
        log(f'sky, pass {p + 1}: ratio mean {A.mean():.3f}, 5/50/95 % {np.percentile(A, 5):.2f} {np.median(A):.2f} '
            f'{np.percentile(A, 95):.2f}; sky seen {Vs.mean():.2f}; two-sided taken from the back {np.mean(side[vmode == 2] < 0) * 100:.0f} %')
    amb = np.ones(nv, np.float32); amb[work] = A
    gb = None
    if not a.no_ground:
        gb = ground_bake(rt, mats, pos, tris, tmat, tmask, ground, layer, mode, keep, triV, triKind, triAlb, vsun, vsun,
                         np.ascontiguousarray(A), shR, shI, L32, sunE, a.sun_dist, a.sky_dist, a.rays)
    if os.environ.get('BAKE_DEBUG'):
        np.savez(os.environ['BAKE_DEBUG'], pos=pos, vmat=vmat, work=work, A=A, V=Vs, sun=o1, ter=o2, nrm=n_amb, alb=alb)

    # into the vertices
    V['pad'][:, 0] = np.round(np.clip(sun_all, 0, 1) * 255).astype(np.uint8)
    V['pad'][:, 1] = np.round(np.clip(amb / 2, 0, 1) * 255).astype(np.uint8)
    V['n'][:, 3] = (np.round(np.clip(sun_ter, 0, 1) * 255).astype(np.int16) - 0).astype(np.uint8).view(np.int8)
    geo[:VL] = V.tobytes()
    newgeo = gzip.compress(bytes(geo), 9)

    # splice the new geometry in where the old was: everything after it must be regions the header knows (walls,
    # centreline), which move along
    blob = bytearray(raw[base:])
    if 'gbake' in h:                                   # an earlier bake's ground textures (at the end) go
        del blob[min(h['gbake']['index'][0], h['gbake']['atlas'][0]):]
    old_o, old_n = g[0], g[1]
    refs = [('walls', h['walls']), ('line', h['line'])] + ([('lineY', h['lineY'])] if 'lineY' in h else [])
    known = [(o, n) for o, n, *_ in h['images']] + [(r[0], r[1]) for _, r in refs]
    after = sorted((o, n) for o, n in known if o > old_o)
    end = old_o + old_n
    for o, n in after:
        if o - end > 3 or o < end: raise SystemExit(f'unknown data after the geometry at {end}..{o}')
        end = o + n
    if len(blob) - end > 3: raise SystemExit('unknown data at the end of the pack')
    pad = lambda n: (-n) % 4
    shift = (len(newgeo) + pad(len(newgeo))) - (old_n + pad(old_n))
    nb = blob[:old_o] + newgeo + bytes(pad(len(newgeo))) + blob[old_o + old_n + pad(old_n):]
    g[0], g[1] = old_o, len(newgeo)
    h.pop('gbake', None)
    if gb:
        # (a pack baked before has its old ground textures at the end: they go)
        pi, pa, info = gb
        def put(b):
            nb.extend(bytes((-len(nb)) % 4)); o = len(nb); nb.extend(b); return [o, len(b)]
        info['index'] = put(pi); info['atlas'] = put(pa)
        h['gbake'] = info
    for im in h['images']:
        if im[0] > old_o: im[0] += shift
    for _, r in refs:
        if r[0] > old_o: r[0] += shift
    h['bake'] = dict(v=1, sky=skyname, toSun=[round(float(x), 4) for x in to_sun], rays=a.rays,
                     bytes='pad0 sun (all), pad1 sky light ratio / 2, n.w sun (ground only)')
    hj = json.dumps(h, separators=(',', ':')).encode()
    while (8 + len(hj)) % 4: hj += b' '
    data_out = b'RBMP' + struct.pack('<I', len(hj)) + hj + bytes(nb)
    open(out, 'wb').write(data_out)
    log(f'{out}: {len(raw) / 1e6:.2f} -> {len(data_out) / 1e6:.2f} MB')


if __name__ == '__main__':
    main()
