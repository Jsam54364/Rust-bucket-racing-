// Ray tracer for baking a map's light (bake_light.py): a BVH over the map's triangles with alpha-tested
// cut-outs (leaves, fences), and the bakes run over every core with OpenMP:
//  - bake_sun: how much of the sun each vertex sees (a few rays over a small cone, so edges come out soft)
//  - bake_amb: the sky's light each vertex gets with the world in the way, one bounce included: rays that escape
//    see the sky (its spherical harmonics), rays that hit something see that surface lit by the sun and the sky;
//    the result is the ratio to what the open sky would give through the same rays
// Build: gcc -O3 -march=native -fopenmp -shared -fPIC rt.c -o rt.so -lm
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef struct { float mn[3], mx[3]; int a, n; } Node;   // n > 0: leaf of n triangles from a; else children a, a+1

static int NT, NN;
static Node *ND;
static float *TV;          // ordered triangles: v0, e1, e2
static int *TI;            // ordered -> original index
static int *TMASK;         // original index -> bit mask of the rays it stops (1 sun, 2 terrain sun, 4 sky)
static int *TTEX;          // original index -> alpha texture (-1: opaque)
static float *TUV;         // original index -> uv0, uv1, uv2
static int NTEX;
static int *TXW, *TXH;
static long *TXO;
static const uint8_t *TXD;
static uint8_t TXCUT[256];

static float *CEN, *BMN, *BMX;
static int *IDX;

static inline float fminf3(float a, float b, float c) { return fminf(a, fminf(b, c)); }
static inline float fmaxf3(float a, float b, float c) { return fmaxf(a, fmaxf(b, c)); }
static inline float area(const float *mn, const float *mx)
{
    float x = mx[0] - mn[0], y = mx[1] - mn[1], z = mx[2] - mn[2];
    if (x < 0 || y < 0 || z < 0) return 0;
    return x * y + y * z + z * x;
}

static int cmp_axis;
static int cmp_cen(const void *a, const void *b)
{
    float x = CEN[*(const int *)a * 3 + cmp_axis], y = CEN[*(const int *)b * 3 + cmp_axis];
    return x < y ? -1 : x > y;
}

#define NBIN 16
static void build(int ni, int first, int n, int depth)
{
    Node *nd = &ND[ni];
    float cmn[3] = {1e30f, 1e30f, 1e30f}, cmx[3] = {-1e30f, -1e30f, -1e30f};
    for (int k = 0; k < 3; k++) { nd->mn[k] = 1e30f; nd->mx[k] = -1e30f; }
    for (int i = first; i < first + n; i++)
    {
        int t = IDX[i];
        for (int k = 0; k < 3; k++)
        {
            nd->mn[k] = fminf(nd->mn[k], BMN[t * 3 + k]); nd->mx[k] = fmaxf(nd->mx[k], BMX[t * 3 + k]);
            cmn[k] = fminf(cmn[k], CEN[t * 3 + k]); cmx[k] = fmaxf(cmx[k], CEN[t * 3 + k]);
        }
    }
    if (n <= 2 || depth > 80) { nd->a = first; nd->n = n; return; }
    int axis = 0;
    float ext[3] = {cmx[0] - cmn[0], cmx[1] - cmn[1], cmx[2] - cmn[2]};
    if (ext[1] > ext[axis]) axis = 1;
    if (ext[2] > ext[axis]) axis = 2;
    int nl = 0;
    if (ext[axis] < 1e-6f)
    {
        if (n <= 8) { nd->a = first; nd->n = n; return; }
        nl = n / 2;
    }
    else
    {
        int cnt[NBIN] = {0};
        float bmn[NBIN][3], bmx[NBIN][3];
        for (int b = 0; b < NBIN; b++) for (int k = 0; k < 3; k++) { bmn[b][k] = 1e30f; bmx[b][k] = -1e30f; }
        float sc = NBIN / ext[axis];
        for (int i = first; i < first + n; i++)
        {
            int t = IDX[i];
            int b = (int)((CEN[t * 3 + axis] - cmn[axis]) * sc);
            if (b >= NBIN) b = NBIN - 1;
            cnt[b]++;
            for (int k = 0; k < 3; k++) { bmn[b][k] = fminf(bmn[b][k], BMN[t * 3 + k]); bmx[b][k] = fmaxf(bmx[b][k], BMX[t * 3 + k]); }
        }
        float la[NBIN], ra[NBIN]; int lc[NBIN], rc[NBIN];
        float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f}; int c = 0;
        for (int b = 0; b < NBIN - 1; b++)
        {
            for (int k = 0; k < 3; k++) { mn[k] = fminf(mn[k], bmn[b][k]); mx[k] = fmaxf(mx[k], bmx[b][k]); }
            c += cnt[b]; la[b] = area(mn, mx); lc[b] = c;
        }
        for (int k = 0; k < 3; k++) { mn[k] = 1e30f; mx[k] = -1e30f; }
        c = 0;
        for (int b = NBIN - 1; b > 0; b--)
        {
            for (int k = 0; k < 3; k++) { mn[k] = fminf(mn[k], bmn[b][k]); mx[k] = fmaxf(mx[k], bmx[b][k]); }
            c += cnt[b]; ra[b - 1] = area(mn, mx); rc[b - 1] = c;
        }
        float best = 1e30f; int bs = -1;
        for (int b = 0; b < NBIN - 1; b++)
        {
            if (lc[b] == 0 || rc[b] == 0) continue;
            float cost = la[b] * lc[b] + ra[b] * rc[b];
            if (cost < best) { best = cost; bs = b; }
        }
        float leaf = area(nd->mn, nd->mx) * n;
        if (bs < 0 || (best >= leaf && n <= 6)) {
            if (bs < 0 && n > 6) nl = n / 2; else { nd->a = first; nd->n = n; return; }
        }
        if (bs >= 0)
        {
            int i = first, j = first + n - 1;
            while (i <= j)
            {
                int t = IDX[i];
                int b = (int)((CEN[t * 3 + axis] - cmn[axis]) * sc);
                if (b >= NBIN) b = NBIN - 1;
                if (b <= bs) i++;
                else { IDX[i] = IDX[j]; IDX[j] = t; j--; }
            }
            nl = i - first;
        }
        if (nl == 0 || nl == n)
        {
            cmp_axis = axis;
            qsort(IDX + first, n, sizeof(int), cmp_cen);
            nl = n / 2;
        }
    }
    if (nl == n / 2 && ext[axis] < 1e-6f) { /* identical centroids: any split will do */ }
    int c0 = NN; NN += 2;
    nd->a = c0; nd->n = 0;
    build(c0, first, nl, depth + 1);
    build(c0 + 1, first + nl, n - nl, depth + 1);
}

// tri: ntri * 9 floats (world positions); mask: which rays each stops; tex/uv: alpha test (-1 for none)
int rt_build(int ntri, const float *tri, const int *mask, const int *tex, const float *uv)
{
    NT = ntri;
    CEN = malloc(sizeof(float) * 3 * ntri); BMN = malloc(sizeof(float) * 3 * ntri); BMX = malloc(sizeof(float) * 3 * ntri);
    IDX = malloc(sizeof(int) * ntri);
    TMASK = malloc(sizeof(int) * ntri); TTEX = malloc(sizeof(int) * ntri); TUV = malloc(sizeof(float) * 6 * ntri);
    memcpy(TMASK, mask, sizeof(int) * ntri); memcpy(TTEX, tex, sizeof(int) * ntri); memcpy(TUV, uv, sizeof(float) * 6 * ntri);
    for (int t = 0; t < ntri; t++)
    {
        const float *p = tri + t * 9;
        for (int k = 0; k < 3; k++)
        {
            BMN[t * 3 + k] = fminf3(p[k], p[3 + k], p[6 + k]);
            BMX[t * 3 + k] = fmaxf3(p[k], p[3 + k], p[6 + k]);
            CEN[t * 3 + k] = (p[k] + p[3 + k] + p[6 + k]) / 3;
        }
        IDX[t] = t;
    }
    ND = malloc(sizeof(Node) * (2 * (size_t)ntri + 2));
    NN = 1;
    build(0, 0, ntri, 0);
    TV = malloc(sizeof(float) * 9 * ntri); TI = malloc(sizeof(int) * ntri);
    for (int i = 0; i < ntri; i++)
    {
        int t = IDX[i];
        const float *p = tri + t * 9;
        float *o = TV + i * 9;
        for (int k = 0; k < 3; k++) { o[k] = p[k]; o[3 + k] = p[3 + k] - p[k]; o[6 + k] = p[6 + k] - p[k]; }
        TI[i] = t;
    }
    free(CEN); free(BMN); free(BMX); free(IDX);
    return NN;
}

// alpha textures: all images' alpha bytes one after another (offsets), cut = the opacity a texel needs (0-255)
void rt_textures(int ntex, const int *w, const int *h, const long *off, const uint8_t *data, const uint8_t *cut)
{
    NTEX = ntex;
    TXW = malloc(sizeof(int) * ntex); TXH = malloc(sizeof(int) * ntex); TXO = malloc(sizeof(long) * ntex);
    memcpy(TXW, w, sizeof(int) * ntex); memcpy(TXH, h, sizeof(int) * ntex); memcpy(TXO, off, sizeof(long) * ntex);
    TXD = data;
    for (int i = 0; i < ntex && i < 256; i++) TXCUT[i] = cut[i];
}

static inline int opaque(int oi, float u, float v)
{
    int tx = TTEX[oi];
    if (tx < 0) return 1;
    const float *q = TUV + oi * 6;
    float w = 1 - u - v;
    float s = w * q[0] + u * q[2] + v * q[4], t = w * q[1] + u * q[3] + v * q[5];
    s -= floorf(s); t -= floorf(t);
    int x = (int)(s * TXW[tx]), y = (int)(t * TXH[tx]);
    if (x >= TXW[tx]) x = TXW[tx] - 1;
    if (y >= TXH[tx]) y = TXH[tx] - 1;
    return TXD[TXO[tx] + (long)y * TXW[tx] + x] >= TXCUT[tx];
}

// the nearest (any = 0) or any (any = 1) surface along o + t d, t in (tmin, tmax), that stops rays of this mask;
// returns the ordered triangle index or -1, with t and the barycentric u, v. (Not thread-safe to change TGROUND
// while tracing: rt_tground is called between bakes.)
static float TGROUND = 0;   // hits on the ground (mask 2) nearer than this don't count (ground just above ground)
static int trace(const float *o, const float *d, float tmin, float tmax, int mask, int any, float *th, float *hu, float *hv)
{
    float inv[3];
    for (int k = 0; k < 3; k++) inv[k] = fabsf(d[k]) > 1e-12f ? 1.0f / d[k] : (d[k] >= 0 ? 1e30f : -1e30f);
    int stack[128]; float st[128]; int sp = 0;
    int ni = 0, hit = -1;
    float best = tmax, bu = 0, bv = 0;
    for (;;)
    {
        const Node *nd = &ND[ni];
        if (nd->n > 0)
        {
            for (int i = nd->a; i < nd->a + nd->n; i++)
            {
                int oi = TI[i];
                if (!(TMASK[oi] & mask)) continue;
                const float *T = TV + i * 9;
                float px = d[1] * T[8] - d[2] * T[7], py = d[2] * T[6] - d[0] * T[8], pz = d[0] * T[7] - d[1] * T[6];
                float det = T[3] * px + T[4] * py + T[5] * pz;
                if (fabsf(det) < 1e-14f) continue;
                float id = 1.0f / det;
                float sx = o[0] - T[0], sy = o[1] - T[1], sz = o[2] - T[2];
                float u = (sx * px + sy * py + sz * pz) * id;
                if (u < 0 || u > 1) continue;
                float qx = sy * T[5] - sz * T[4], qy = sz * T[3] - sx * T[5], qz = sx * T[4] - sy * T[3];
                float v = (d[0] * qx + d[1] * qy + d[2] * qz) * id;
                if (v < 0 || u + v > 1) continue;
                float t = (T[6] * qx + T[7] * qy + T[8] * qz) * id;
                if (t <= tmin || t >= best) continue;
                if (t < TGROUND && (TMASK[oi] & 2)) continue;
                if (!opaque(oi, u, v)) continue;
                best = t; hit = i; bu = u; bv = v;
                if (any) { *th = t; *hu = u; *hv = v; return i; }
            }
        }
        else
        {
            int c[2] = {nd->a, nd->a + 1};
            float te[2];
            for (int j = 0; j < 2; j++)
            {
                const Node *cn = &ND[c[j]];
                float t0 = 0, t1 = best;
                for (int k = 0; k < 3; k++)
                {
                    float a = (cn->mn[k] - o[k]) * inv[k], b = (cn->mx[k] - o[k]) * inv[k];
                    if (a > b) { float x = a; a = b; b = x; }
                    if (a > t0) t0 = a;
                    if (b < t1) t1 = b;
                }
                te[j] = t0 <= t1 ? t0 : 1e30f;
            }
            if (te[0] > te[1]) { float x = te[0]; te[0] = te[1]; te[1] = x; int y = c[0]; c[0] = c[1]; c[1] = y; }
            if (te[0] < 1e29f)
            {
                if (te[1] < 1e29f && sp < 128) { stack[sp] = c[1]; st[sp] = te[1]; sp++; }
                ni = c[0];
                continue;
            }
        }
        for (;;)
        {
            if (sp == 0) { *th = best; *hu = bu; *hv = bv; return hit; }
            sp--;
            if (st[sp] < best) { ni = stack[sp]; break; }
        }
    }
}

void rt_tground(float t) { TGROUND = t; }

int rt_ray(const float *o, const float *d, float tmax, int mask, float *out)
{
    float t, u, v;
    int h = trace(o, d, 1e-3f, tmax, mask, 0, &t, &u, &v);
    out[0] = t; out[1] = u; out[2] = v;
    return h < 0 ? -1 : TI[h];
}

static inline uint32_t hash(uint32_t x)
{
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
static inline float rnd(uint32_t *s) { *s = hash(*s + 0x9e3779b9U); return (*s >> 8) * (1.0f / 16777216.0f); }
static inline float radinv(uint32_t b)
{
    b = (b << 16) | (b >> 16);
    b = ((b & 0x55555555u) << 1) | ((b & 0xAAAAAAAAu) >> 1);
    b = ((b & 0x33333333u) << 2) | ((b & 0xCCCCCCCCu) >> 2);
    b = ((b & 0x0F0F0F0Fu) << 4) | ((b & 0xF0F0F0F0u) >> 4);
    b = ((b & 0x00FF00FFu) << 8) | ((b & 0xFF00FF00u) >> 8);
    return b * 2.3283064365386963e-10f;
}
static inline void basis(const float *n, float *t, float *b)
{
    float s = n[2] >= 0 ? 1.0f : -1.0f;
    float a = -1.0f / (s + n[2]), c = n[0] * n[1] * a;
    t[0] = 1 + s * n[0] * n[0] * a; t[1] = s * c; t[2] = -s * n[0];
    b[0] = c; b[1] = s + n[1] * n[1] * a; b[2] = -n[1];
}
static inline float sh_eval(const float *c, const float *n)
{
    float x = n[0], y = n[1], z = n[2];
    return c[0] * 0.282095f + c[1] * 0.488603f * z + c[2] * 0.488603f * y + c[3] * 0.488603f * x
         + c[4] * 1.092548f * x * z + c[5] * 1.092548f * z * y + c[6] * 0.315392f * (3 * y * y - 1)
         + c[7] * 1.092548f * x * y + c[8] * 0.546274f * (x * x - z * z);
}

// P: K points per vertex the rays start from (round the vertex, inside its triangles: a vertex stands for the
// surface round it, and on its own it often sits in a corner where faces meet), N: the side to start from (towards
// the sun); L: towards the sun; cone: half-angle
void bake_sun(int nv, const float *P, int K, const float *N, const float *L, int nr, float cone, float tmax, int mask, float off, float *out)
{
    float t[3], b[3];
    basis(L, t, b);
    float r0 = tanf(cone);
#pragma omp parallel for schedule(dynamic, 512)
    for (int v = 0; v < nv; v++)
    {
        uint32_t s = hash((uint32_t)v * 7919u + 17u);
        float rot = rnd(&s) * 6.2831853f;
        int lit = 0;
        for (int i = 0; i < nr; i++)
        {
            float rr = r0 * sqrtf((i + 0.5f) / nr), an = i * 2.3999632f + rot;
            float d[3];
            for (int k = 0; k < 3; k++) d[k] = L[k] + (t[k] * cosf(an) + b[k] * sinf(an)) * rr;
            float l = sqrtf(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
            for (int k = 0; k < 3; k++) d[k] /= l;
            float o[3];
            const float *p0 = P + ((size_t)v * K + i % K) * 3;
            for (int k = 0; k < 3; k++) o[k] = p0[k] + N[v * 3 + k] * off;
            float th, hu, hv;
            if (trace(o, d, 1e-3f, tmax, mask, 1, &th, &hu, &hv) < 0) lit++;
        }
        out[v] = (float)lit / nr;
    }
}

// one side's sky light: nr cosine-weighted rays about n (sphere: alternate rays about n and -n)
typedef struct { float num, den; int vis; } Amb;
static Amb amb_rays(int v, const float *p0, int K, const float *n0, int sphere, int nr, float tmax, int mask, float off,
                    const float *shR, const float *shI, const float *L, float sunE,
                    const int *triV, const int *triKind, const float *triAlb, const float *vSun, const float *vA, float aHit,
                    uint32_t seed)
{
    Amb r = {0, 0, 0};
    uint32_t s = hash((uint32_t)v * 2654435761u + seed);
    float j1 = rnd(&s), j2 = rnd(&s);
    int m = sphere ? (nr + 1) / 2 : nr;
    for (int i = 0; i < nr; i++)
    {
        float n[3] = {n0[0], n0[1], n0[2]};
        int k = i;
        if (sphere) { if (i & 1) { n[0] = -n[0]; n[1] = -n[1]; n[2] = -n[2]; } k = i >> 1; }
        float t[3], b[3];
        basis(n, t, b);
        float u1 = (k + 0.5f) / m + j1; u1 -= floorf(u1);
        float u2 = radinv((uint32_t)k) + j2; u2 -= floorf(u2);
        float rr = sqrtf(u1), ph = 6.2831853f * u2;
        float lx = rr * cosf(ph), ly = rr * sinf(ph), lz = sqrtf(fmaxf(0, 1 - u1));
        float d[3], o[3];
        const float *pk = p0 + (i % K) * 3;
        for (int q = 0; q < 3; q++) { d[q] = t[q] * lx + b[q] * ly + n[q] * lz; o[q] = pk[q] + n[q] * off; }
        float sky = fmaxf(0, sh_eval(shR, d));
        r.den += sky;
        float th, hu, hv;
        int h = trace(o, d, 1e-3f, tmax, mask, 0, &th, &hu, &hv);
        if (h < 0) { r.num += sky; r.vis++; continue; }
        int oi = TI[h];
        const float *T = TV + h * 9;
        float fn[3] = {T[4] * T[8] - T[5] * T[7], T[5] * T[6] - T[3] * T[8], T[3] * T[7] - T[4] * T[6]};
        float fl = sqrtf(fn[0] * fn[0] + fn[1] * fn[1] + fn[2] * fn[2]);
        if (fl < 1e-20f) continue;
        for (int q = 0; q < 3; q++) fn[q] /= fl;
        int kind = triKind[oi];
        if (kind == 0) { if (fn[1] < 0) for (int q = 0; q < 3; q++) fn[q] = -fn[q]; }
        else if (fn[0] * d[0] + fn[1] * d[1] + fn[2] * d[2] > 0) for (int q = 0; q < 3; q++) fn[q] = -fn[q];
        if (kind == 1)
        {
            fn[1] += 1.6f;
            float l = sqrtf(fn[0] * fn[0] + fn[1] * fn[1] + fn[2] * fn[2]);
            for (int q = 0; q < 3; q++) fn[q] /= l;
        }
        float w0 = 1 - hu - hv;
        const int *tv = triV + oi * 3;
        float sv = vSun[tv[0]] * w0 + vSun[tv[1]] * hu + vSun[tv[2]] * hv;
        if (kind == 1) sv = 1 - 0.45f * (1 - sv);
        float ah = vA ? vA[tv[0]] * w0 + vA[tv[1]] * hu + vA[tv[2]] * hv : aHit;
        float ndl = fmaxf(0, fn[0] * L[0] + fn[1] * L[1] + fn[2] * L[2]);
        r.num += triAlb[oi] * (sunE * ndl * sv + fmaxf(0, sh_eval(shI, fn)) * ah);
    }
    return r;
}

// sky light with one bounce
//  P: K points per vertex the rays start from (as bake_sun), N: vertices' normals; mode 0: the hemisphere about N (ground: N faces up), 1: the whole sphere
//  (foliage), 2: two-sided, whichever side sees more of the sky (the outside of a closed shape, whichever way its
//  normals were made)
//  shR: the sky's radiance (luminance, 9 coefficients), shI: its irradiance / pi (what the game's sky_light gives)
//  L, sunE: towards the sun and its light on a white surface facing it (luminance)
//  triV: each triangle's vertices (into the vertex arrays); triKind: 0 ground (faces up), 1 foliage, 2 other;
//  triAlb: luminance albedo; vSun: vertices' sun visibility; vA: vertices' ambient ratio from a previous pass
//  (NULL: aHit for all); outA: ambient ratio to the open sky, outV: the share of rays that see the sky; outS: the
//  side used (1 along N, -1 against it)
void bake_amb(int nv, const float *P, int K, const float *N, const int *mode, int nr, float tmax, int mask, float off,
              const float *shR, const float *shI, const float *L, float sunE,
              const int *triV, const int *triKind, const float *triAlb, const float *vSun, const float *vA, float aHit,
              float *outA, float *outV, float *outS)
{
#pragma omp parallel for schedule(dynamic, 256)
    for (int v = 0; v < nv; v++)
    {
        const float *n0 = N + v * 3;
        Amb r = amb_rays(v, P + (size_t)v * K * 3, K, n0, mode[v] == 1, nr, tmax, mask, off, shR, shI, L, sunE, triV, triKind, triAlb, vSun, vA, aHit, 7u);
        float side = 1;
        if (mode[v] == 2)
        {
            float nb[3] = {-n0[0], -n0[1], -n0[2]};
            Amb b = amb_rays(v, P + (size_t)v * K * 3, K, nb, 0, nr, tmax, mask, off, shR, shI, L, sunE, triV, triKind, triAlb, vSun, vA, aHit, 11u);
            if (b.vis > r.vis || (b.vis == r.vis && b.num > r.num)) { r = b; side = -1; }
        }
        outA[v] = r.den > 1e-9f ? r.num / r.den : 1;
        outV[v] = (float)r.vis / nr;
        outS[v] = side;
    }
}

// the ground under points (x, z): straight down from ytop (one a point), the first surface of this mask; its height
// and normal (facing up), or NaN where there is none
// (and the triangle hit, by the index it was given to rt_build, with the barycentric u, v)
void ground_probe(int n, const float *xz, const float *ytop, int mask, float *outY, float *outN, int *outT, float *outUV)
{
#pragma omp parallel for schedule(dynamic, 1024)
    for (int i = 0; i < n; i++)
    {
        float o[3] = {xz[i * 2], ytop[i], xz[i * 2 + 1]}, d[3] = {0, -1, 0};
        float th, hu, hv;
        int h = trace(o, d, 0, 1e7f, mask, 0, &th, &hu, &hv);
        if (h < 0) { outY[i] = NAN; outN[i * 3] = 0; outN[i * 3 + 1] = 1; outN[i * 3 + 2] = 0; outT[i] = -1; continue; }
        outT[i] = TI[h]; outUV[i * 2] = hu; outUV[i * 2 + 1] = hv;
        const float *T = TV + h * 9;
        float fn[3] = {T[4] * T[8] - T[5] * T[7], T[5] * T[6] - T[3] * T[8], T[3] * T[7] - T[4] * T[6]};
        float fl = sqrtf(fn[0] * fn[0] + fn[1] * fn[1] + fn[2] * fn[2]);
        if (fl < 1e-20f) { fn[0] = 0; fn[1] = 1; fn[2] = 0; fl = 1; }
        if (fn[1] < 0) fl = -fl;
        outY[i] = ytop[i] - th;
        for (int q = 0; q < 3; q++) outN[i * 3 + q] = fn[q] / fl;
    }
}
