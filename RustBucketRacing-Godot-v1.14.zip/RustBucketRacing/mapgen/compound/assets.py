"""Textures and materials for the compound: most textures come from the Spa, Monte Carlo and Irohazaka packs
(tex_src/<pack>_<index>.png), a few are made here (track asphalt with its edge lines, the access-road asphalt with
a centre line, the start line's chequers, grandstand seats, tent canvas)."""
import io
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

import os
SRC = os.environ.get('TEX_SRC', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tex_src')) + '/'


def src(name):
    return Image.open(SRC + name + '.png')


def asphalt(base='iroha_017', gain=0.78, size=512):
    im = src(base).convert('RGB').resize((size, size), Image.LANCZOS)
    a = np.asarray(im, np.float32) * gain
    rng = np.random.default_rng(3)
    n = rng.normal(0, 4, (size, size, 1)).astype(np.float32)
    return np.clip(a + n, 0, 255)


def line(a, u0, u1, col, along=None, period=None, dash=None):
    """paint a vertical band (u0..u1, fractions of the width); dashed if period/dash (fractions of the height)"""
    h, w = a.shape[:2]
    x0, x1 = int(round(u0 * w)), max(int(round(u0 * w)) + 1, int(round(u1 * w)))
    rows = np.arange(h)
    on = np.ones(h, bool) if period is None else ((rows / h) % period) < dash
    wear = 0.85 + 0.15 * np.random.default_rng(5).random((h, x1 - x0, 1))
    a[on, x0:x1] = a[on, x0:x1] * 0.15 + np.array(col, np.float32) * 0.85 * wear[on]


def tex_track():
    a = asphalt(gain=0.72)
    w = 12.0                                   # metres across: the texture spans the road's width
    e0 = 0.15 / w; lw = 0.22 / w
    line(a, e0, e0 + lw, (235, 235, 230)); line(a, 1 - e0 - lw, 1 - e0, (235, 235, 230))
    return Image.fromarray(a.astype(np.uint8))


def tex_road():
    a = asphalt('iroha_017', gain=0.86)
    a = a * np.array([1.02, 1.0, 0.96], np.float32)
    w = 7.2
    e0 = 0.12 / w; lw = 0.15 / w
    line(a, e0, e0 + lw, (225, 225, 215)); line(a, 1 - e0 - lw, 1 - e0, (225, 225, 215))
    line(a, 0.5 - 0.06 / w, 0.5 + 0.06 / w, (230, 190, 60), period=1.0, dash=0.4)     # 3 m of 7.5 m along
    return Image.fromarray(a.astype(np.uint8))


def tex_oval():
    """the oval across its width (u: 0 the apron's inner edge .. 1 the outer wall): a lighter apron, the double
    yellow line at the track's inside edge, a white line by the wall"""
    a = asphalt(gain=0.7)
    w = 30.0
    ap = 12.0 / w
    a[:, :int(ap * 512)] = a[:, :int(ap * 512)] * 1.12 + 6
    line(a, ap - 0.55 / w, ap - 0.4 / w, (230, 190, 50)); line(a, ap - 0.25 / w, ap - 0.1 / w, (230, 190, 50))
    line(a, 1 - 0.75 / w, 1 - 0.5 / w, (235, 235, 230))
    line(a, 0.6 / w, 0.75 / w, (235, 235, 230))
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def tex_pad():
    return Image.fromarray(asphalt(gain=0.8).astype(np.uint8))


def tex_checker():
    im = Image.new('RGB', (512, 64), (240, 240, 240)); d = ImageDraw.Draw(im)
    for i in range(16):
        for j in range(2):
            if (i + j) % 2: d.rectangle([i * 32, j * 32, i * 32 + 31, j * 32 + 31], fill=(20, 20, 20))
    return im


def tex_seats():
    """one row of grandstand seats seen from the front-top: 256 px = 4 m wide, 0.8 m deep (step) + 0.45 m riser"""
    im = Image.new('RGB', (256, 256), (150, 150, 148)); d = ImageDraw.Draw(im)
    d.rectangle([0, 160, 255, 255], fill=(120, 120, 118))                    # the riser
    for i in range(8):
        x = i * 32
        d.rectangle([x + 3, 30, x + 28, 120], fill=(30, 70, 160))             # seat back
        d.rectangle([x + 3, 120, x + 28, 155], fill=(25, 55, 130))            # seat
    return im.filter(ImageFilter.GaussianBlur(0.6))


def tex_canvas():
    im = Image.new('RGB', (256, 256), (238, 236, 230)); d = ImageDraw.Draw(im)
    for i in range(0, 256, 64): d.line([i, 0, i, 255], fill=(200, 198, 192), width=2)
    a = np.asarray(im, np.float32) + np.random.default_rng(9).normal(0, 3, (256, 256, 1))
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def tex_tinted(name, gain):
    a = np.asarray(src(name).convert('RGB'), np.float32) * gain
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))


def tex_track_fill():
    """the track's asphalt without its edge lines (the junction fills)"""
    return Image.fromarray(asphalt(gain=0.72).astype(np.uint8))


def tex_zone_hatch():
    """diagonal white and red stripes on clear (2 m square): drift zones"""
    n = 256
    yy, xx = np.mgrid[0:n, 0:n]
    ph = (xx + yy) % 128                                     # 1 m period across the stripes
    white = ph < 38; red = (ph >= 64) & (ph < 102)
    a = np.zeros((n, n, 4), np.uint8)
    wear = 0.9 + 0.1 * np.random.default_rng(4).random((n, n))
    a[..., 0] = np.where(white, 236, 200) * wear; a[..., 1] = np.where(white, 236, 34) * wear; a[..., 2] = np.where(white, 230, 30) * wear
    a[..., 3] = np.where(white | red, 255, 0)
    return Image.fromarray(a, 'RGBA')


def tex_drift_labels():
    """road lettering for the drift zones, squashed along the road (the quads stretch it back): OZ 1-8, CP 1-8"""
    from PIL import ImageFont
    W, H = 512, 512; cw, ch = 256, 64
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 120)
    for k in range(16):
        txt = ('OZ' if k < 8 else 'CP') + ' ' + str(k % 8 + 1)
        cell = Image.new('RGBA', (cw, ch * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(cell)
        bb = d.textbbox((0, 0), txt, font=font)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        sc = min((cw - 16) / tw, (ch * 2 - 12) / th)
        f2 = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', int(120 * sc))
        bb = d.textbbox((0, 0), txt, font=f2)
        d.text(((cw - (bb[2] - bb[0])) / 2 - bb[0], (ch * 2 - (bb[3] - bb[1])) / 2 - bb[1]), txt, font=f2, fill=(236, 236, 232, 255))
        cell = cell.resize((cw, ch), Image.LANCZOS)
        out.paste(cell, ((k % 2) * cw, (k // 2) * ch))
    return out


# texture key -> image (built lazily)
TEXTURES = {
    'track': tex_track, 'track_fill': tex_track_fill, 'zone_hatch': tex_zone_hatch, 'drift_labels': tex_drift_labels, 'road': tex_road, 'pad': tex_pad, 'oval': tex_oval, 'checker': tex_checker, 'seats': tex_seats, 'canvas': tex_canvas,
    'grass': lambda: src('spa_015'), 'field': lambda: tex_tinted('spa_022', 1.32), 'hill': lambda: tex_tinted('spa_022', 1.15),
    'farhill': lambda: tex_tinted('spa_022', 0.8),
    'gravel': lambda: src('spa_010'), 'kerb': lambda: src('spa_024'), 'sausage': lambda: src('spa_023'),
    'green': lambda: src('spa_013'), 'concrete': lambda: src('spa_059'), 'garage': lambda: src('spa_055'),
    'facade': lambda: src('spa_057'), 'windows': lambda: src('spa_060'), 'block': lambda: src('spa_053'),
    'metal': lambda: src('spa_054'), 'tyres': lambda: tex_tinted('spa_061', 0.33), 'rail': lambda: src('spa_003'),
    'fence': lambda: src('spa_004'), 'tree_a': lambda: src('spa_001'), 'tree_b': lambda: src('spa_002'),
    'pine': lambda: src('spa_006'), 'pinewall': lambda: src('spa_000'), 'treeline': lambda: src('mcr_024'),
    'bush': lambda: src('iroha_000'), 'alps': lambda: src('mcr_030'),
}
import kit
for _k in list(kit.TEX) + list(kit.BAKED): TEXTURES[_k] = (lambda k: lambda: kit.texture(k))(_k)
import hauler
for _k in ('hl_wheel_r', 'hl_wheel_f'): TEXTURES[_k] = (lambda k: lambda: hauler.texture(k))(_k)
TEXTURES['hl_trailer_lo'] = lambda: hauler.texture('trailer_lo')
for _i in range(hauler.N_LIV):
    for _g in ('tractor', 'box'): TEXTURES[f'hl_{_g}_{_i}'] = (lambda k: lambda: hauler.texture(k))(f'{_g}_{_i}')

def webp(img):
    has_a = img.mode in ('RGBA', 'LA')
    img = img.convert('RGBA' if has_a else 'RGB')
    if has_a:
        img = bleed(img)
    w, h = img.size
    sc = min(1.0, 512 / max(w, h))
    if sc < 1: img = img.resize((max(4, int(w * sc)), max(4, int(h * sc))), Image.LANCZOS)
    bio = io.BytesIO(); img.save(bio, 'WEBP', quality=80, method=6)
    return bio.getvalue()


def bleed(img):
    a = np.array(img, dtype=np.float32)
    rgb, al = a[:, :, :3], a[:, :, 3]
    known = al > 8
    if known.all() or not known.any(): return img
    out = np.where(known[:, :, None], rgb, 0); filled = known.copy()
    for _ in range(64):
        if filled.all(): break
        s = sum(np.roll(np.roll(out * filled[:, :, None], dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        w = sum(np.roll(np.roll(filled.astype(np.float32), dy, 0), dx, 1) for dy in (-1, 0, 1) for dx in (-1, 0, 1))
        new = (~filled) & (w > 0)
        out[new] = s[new] / w[new][:, None]; filled |= new
    out[~filled] = rgb[known].mean(0)
    return Image.fromarray(np.dstack([out, al]).clip(0, 255).astype(np.uint8), 'RGBA')


def M(tex, cat, surf=0, mode=0, fade=0, shadow=False, layer=0, spec=0.1, color=(1, 1, 1, 1), fog=True):
    d = dict(tex=tex, cat=cat, surf=surf, mode=mode, fade=fade, shadow=shadow, layer=layer, spec=spec, color=list(color))
    if not fog: d['fog'] = False
    return d

# material key -> settings (surf: 1 tarmac, 2 kerb, 3 gravel, 4 grass, 0 none; cat as in the game's MapMat)
MATERIALS = {
    'grass':    M('grass', 'ground', 4, spec=0.03),
    'field':    M('field', 'ground', 4, spec=0.03),
    'hill':     M('hill', 'ground', 0, spec=0.02),                 # outside the fence: drawn, never driven on
    'track':    M('track', 'ground', 1, spec=0.25),
    'track_fill': M('track_fill', 'ground', 1, layer=1, spec=0.25),
    'road':     M('road', 'ground', 1, spec=0.22),
    'oval':     M('oval', 'ground', 1, spec=0.25),
    'pad':      M('pad', 'ground', 1, spec=0.2),
    'kerb':     M('kerb', 'ground', 2, layer=1, spec=0.2),
    'sausage':  M('sausage', 'ground', 2, layer=1, spec=0.2),
    'green':    M('green', 'ground', 1, layer=1, spec=0.1),      # the painted run-off by the kerbs drives like asphalt
    'gravel':   M('gravel', 'ground', 3, spec=0.03),                 # part of the ground mesh
    'paint':    M(None, 'ground', 1, layer=1, spec=0.2, color=(0.86, 0.86, 0.84, 1)),
    'paint_y':  M(None, 'ground', 1, layer=1, spec=0.2, color=(0.85, 0.66, 0.15, 1)),
    'paint_r':  M(None, 'ground', 1, layer=1, spec=0.2, color=(0.78, 0.12, 0.10, 1)),
    'pole':     M('kerb', 'small', fade=450, spec=0.2),
    'drift_hatch': M('zone_hatch', 'ground', 1, mode=1, layer=1, spec=0.2),
    'drift_text':  M('drift_labels', 'ground', 1, mode=1, layer=1, spec=0.2),
    'checker':  M('checker', 'ground', 1, layer=1, spec=0.2),
    'rail':     M('rail', 'small', fade=900, shadow=True, spec=0.5),
    'post':     M(None, 'small', fade=450, shadow=False, spec=0.3, color=(0.5, 0.5, 0.52, 1)),
    'tyres':    M('tyres', 'wall', fade=900, shadow=True, spec=0.05),
    'concrete': M('concrete', 'wall', fade=1300, shadow=True, spec=0.06),
    'fence':    M('fence', 'small', mode=1, fade=450),
    'garage':   M('garage', 'obj', fade=3000, shadow=True, spec=0.1),
    'facade':   M('facade', 'obj', fade=3000, shadow=True, spec=0.15),
    'windows':  M('windows', 'obj', fade=3000, shadow=True, spec=0.12),
    'block':    M('block', 'obj', fade=3000, shadow=True, spec=0.05),
    'metal':    M('metal', 'obj', fade=3000, shadow=True, spec=0.35),
    'roof':     M(None, 'obj', fade=3000, shadow=True, spec=0.1, color=(0.42, 0.43, 0.45, 1)),
    'seats':    M('seats', 'obj', fade=3000, shadow=True, spec=0.1),
    'canvas':   M('canvas', 'obj', fade=1300, shadow=True, spec=0.05),
    'canvas_r': M('canvas', 'obj', fade=1300, shadow=True, spec=0.05, color=(0.85, 0.22, 0.18, 1)),
    'canvas_b': M('canvas', 'obj', fade=1300, shadow=True, spec=0.05, color=(0.2, 0.35, 0.8, 1)),
    'canvas_y': M('canvas', 'obj', fade=1300, shadow=True, spec=0.05, color=(0.95, 0.75, 0.15, 1)),
    'truck_w':  M(None, 'obj', fade=1300, shadow=True, spec=0.4, color=(0.88, 0.88, 0.9, 1)),
    'truck_r':  M(None, 'obj', fade=1300, shadow=True, spec=0.4, color=(0.7, 0.1, 0.1, 1)),
    'truck_b':  M(None, 'obj', fade=1300, shadow=True, spec=0.4, color=(0.1, 0.18, 0.5, 1)),
    'truck_k':  M(None, 'obj', fade=1300, shadow=True, spec=0.4, color=(0.12, 0.12, 0.13, 1)),
    'glass':    M(None, 'obj', fade=1300, shadow=True, spec=0.8, color=(0.18, 0.24, 0.3, 1)),
    'lamp_r':   M(None, 'obj', fade=450, color=(0.9, 0.1, 0.05, 1)),
    'lamp_y':   M(None, 'obj', fade=450, color=(0.95, 0.75, 0.1, 1)),
    'lamp_g':   M(None, 'obj', fade=450, color=(0.15, 0.85, 0.2, 1)),
    'tree_a':   M('tree_a', 'veg', mode=1, fade=1300, shadow=True),
    'tree_b':   M('tree_b', 'veg', mode=1, fade=1300, shadow=True),
    'pine':     M('pine', 'veg', mode=1, fade=1300, shadow=True),
    'bush':     M('bush', 'veg', mode=1, fade=450),
    'pinewall': M('pinewall', 'veg', mode=1, fade=0),
    'treeline': M('treeline', 'veg', mode=1, fade=0),
    'alps':     M('alps', 'far', mode=1, fog=False),
    # the race track assets pack (Cherk, CC BY 4.0), simplified
    'kit_concrete': M('kit_concrete', 'wall', fade=900, shadow=True, spec=0.08),
    'kit_conc':     M('kit_conc_front', 'wall', mode=1, fade=1300, shadow=True, spec=0.08),
    'kit_conc_top': M('kit_conc_top', 'wall', mode=1, fade=900, shadow=True, spec=0.05),
    'kit_rail':     M('kit_rail_front', 'small', mode=1, fade=900, shadow=True, spec=0.45),
    'kit_rail_b':   M('kit_rail_back', 'small', mode=1, fade=900, shadow=True, spec=0.45),
    'kit_srail':    M('kit_srail', 'small', fade=900, shadow=True, spec=0.45),
    'kit_mast':     M('kit_mast', 'obj', fade=1300, shadow=True, spec=0.3),
    'kit_lights':   M('kit_lights', 'obj', fade=900, shadow=True, spec=0.3),
    'kit_glass':    M(None, 'obj', fade=900, shadow=True, spec=0.8, color=(0.8, 0.8, 0.8, 1)),
    'kit_boards':   M('kit_boards', 'small', fade=450, spec=0.1),
    'kit_signs':    M('kit_signs', 'small', fade=450, spec=0.1),
    'kit_post':     M('kit_post', 'small', fade=450, spec=0.1),
    'kit_tyres':    M('kit_tyres_front', 'wall', mode=1, fade=900, shadow=True, spec=0.12),
    'kit_tyres_top': M('kit_tyres_top', 'wall', mode=1, fade=900, shadow=True, spec=0.05),
    # race transporters ("DAV NASCAR Hauler" by jairobman, CC BY 4.0), simplified, in liveries of our own
    'hl_wheel_r':   M('hl_wheel_r', 'obj', fade=1300, shadow=True, spec=0.15),
    'hl_wheel_f':   M('hl_wheel_f', 'obj', fade=1300, shadow=True, spec=0.15),
    'hl_trailer_lo': M('hl_trailer_lo', 'obj', fade=1300, shadow=True, spec=0.3),
    'far_hill': M('farhill', 'far', 0, spec=0.0),
}
for _i in range(6):
    MATERIALS[f'hl_tractor_{_i}'] = M(f'hl_tractor_{_i}', 'obj', fade=1300, shadow=True, spec=0.5)
    MATERIALS[f'hl_box_{_i}'] = M(f'hl_box_{_i}', 'obj', fade=1300, shadow=True, spec=0.45)


def build_tables(used):
    """materials actually used, in a fixed order, and the textures they need"""
    tex_keys, mats, mat_index = [], [], {}
    for k in sorted(used, key=lambda k: list(MATERIALS).index(k)):
        m = dict(MATERIALS[k]); t = m.pop('tex')
        if t is not None:
            if t not in tex_keys: tex_keys.append(t)
            m['tex'] = tex_keys.index(t)
        m['name'] = k
        mat_index[k] = len(mats); mats.append(m)
    images = [webp(TEXTURES[t]()) for t in tex_keys]
    return mats, mat_index, images


if __name__ == '__main__':
    for k in ('track', 'road', 'seats', 'checker'):
        TEXTURES[k]().save(f'tex_{k}.png')
    print(len(TEXTURES), 'textures,', len(MATERIALS), 'materials')
