// A car's setup: everything the garage's tuning menu changes. Lengths are metres, angles degrees, pressures bar,
// rates N/m, damping N·s/m, torques N·m. Every number has a key (Numbers), which is how setups are saved, loaded and
// compared, so a new setting needs one line there and nothing else in the save code.
using System;

namespace RustBucket.Sim
{
    public enum Drive { RWD, FWD, AWD }
    public enum Gearbox { Auto, Semi, Manual }

    // the four factory suspension packages (springs, bump damping, bars, centre of mass)
    public sealed class Preset
    {
        public readonly double SpringF, SpringR, DampF, DampR, ArbF, ArbR, ComHeight;
        public Preset(double springF, double springR, double dampF, double dampR, double arbF, double arbR, double comHeight)
        { SpringF = springF; SpringR = springR; DampF = dampF; DampR = dampR; ArbF = arbF; ArbR = arbR; ComHeight = comHeight; }
    }

    public sealed class Tune
    {
        public const double FactoryRebound = 1.6; // rebound to bump in the factory packages

        // springs, ride height (m from the factory height: + raises), anti-roll bars
        public double SpringF, SpringR, RideF, RideR, ArbF, ArbR;
        // dampers: slow (below 0.12 m/s of shaft speed) and fast, bump and rebound
        public double DampF, DampR, ReboundF, ReboundR, FastBumpF, FastBumpR, FastReboundF, FastReboundR;
        // alignment: camber (negative: the top of the tyre leans in), toe (positive: toe-in), caster
        public double CamberF, CamberR, ToeF, ToeR, Caster = 4;
        // geometry: roll centres (m above the ground), anti-dive and anti-squat (0..1 of the pitch the links take),
        // camber gain (0..1: how much of the body's roll the linkage takes back out of the camber), centre of mass
        public double RollCenterF = 0.08, RollCenterR = 0.08, AntiDive = 0.15, AntiSquat = 0.15, CamberGainF = 0.5, CamberGainR = 0.5, ComHeight;
        // tyres: pressures (bar, cold) and compound grip
        public double PressureF = 2.2, PressureR = 2.2, Grip = 1.05;
        // brakes: front share, force (x the car's), handbrake (x the car's)
        public double BrakeBias = 0.64, BrakeForce = 1, HandbrakeForce = 1;
        // differential: clutch-type limited slip (preload, lock under power and on the overrun) and a viscous coupling;
        // the front share of the torque with all-wheel drive
        public double LsdPreload, LsdPower, LsdCoast, LsdViscous = 45, AwdFront = 0.4;
        // gearing: final drive and each gear (null: the car's)
        public double FinalDrive = 4;
        public double[] Gears;
        // aero (cars with a splitter and wing): x the car's downforce at each end
        public double AeroF = 1, AeroR = 1;
        // steering: full lock of the front wheels (degrees)
        public double SteerLock = 33.2;

        public Drive Drive = Drive.RWD;
        public bool Abs = true, Tcs = true;
        // the driver's preferences (they follow the driver from car to car and stay out of saved setups)
        public Gearbox Gearbox = Gearbox.Auto;
        public double SteerAssist = 1;  // 0..1: how far full lock is held back to the grip limit at speed
        public double CounterSteer = 0.5; // 0..1: how much the assist catches a sliding rear
        public double SteerSpeed = 1;   // multiplier on how fast the front wheels can turn
        public double Recovery = 0.75;  // 0..1: grip a sliding tyre keeps when you are off the throttle and brake

        public Tune Clone()
        {
            var t = (Tune)MemberwiseClone();
            t.Gears = (double[])Gears?.Clone();
            return t;
        }

        // a factory package: springs, bars and centre of mass, with factory-ratio dampers (linear: fast as slow)
        public void Apply(Preset p)
        {
            SpringF = p.SpringF; SpringR = p.SpringR; DampF = p.DampF; DampR = p.DampR; ArbF = p.ArbF; ArbR = p.ArbR; ComHeight = p.ComHeight;
            ReboundF = p.DampF * FactoryRebound; ReboundR = p.DampR * FactoryRebound;
            FastBumpF = DampF; FastBumpR = DampR; FastReboundF = ReboundF; FastReboundR = ReboundR;
        }

        static bool Eq(double a, double b) => Math.Abs(a - b) < 1e-6 * Math.Max(1, Math.Abs(b));

        public bool Matches(Preset p) =>
            Eq(SpringF, p.SpringF) && Eq(SpringR, p.SpringR) && Eq(DampF, p.DampF) && Eq(DampR, p.DampR) && Eq(ArbF, p.ArbF) && Eq(ArbR, p.ArbR) &&
            Eq(ComHeight, p.ComHeight) && Eq(ReboundF, p.DampF * FactoryRebound) && Eq(ReboundR, p.DampR * FactoryRebound) &&
            Eq(FastBumpF, DampF) && Eq(FastBumpR, DampR) && Eq(FastReboundF, ReboundF) && Eq(FastReboundR, ReboundR);

        // the car's own alignment and linkage
        public void Align(double camberF, double camberR, double toeF, double toeR, double caster, double gainF, double gainR)
        {
            CamberF = camberF; CamberR = camberR; ToeF = toeF; ToeR = toeR; Caster = caster; CamberGainF = gainF; CamberGainR = gainR;
        }

        public double Gear(int i) => Gears != null && i < Gears.Length ? Gears[i] : 1;

        /* ---------------- every number, by key ---------------- */
        public readonly struct Num
        {
            public readonly string Key;
            public readonly Func<Tune, double> Get;
            public readonly Action<Tune, double> Set;
            public readonly bool Length;   // scales with the car's model (setups saved before a rescale convert)
            public Num(string key, Func<Tune, double> get, Action<Tune, double> set, bool length = false) { Key = key; Get = get; Set = set; Length = length; }
        }

        public static readonly Num[] Numbers =
        {
            new Num("springF", t => t.SpringF, (t, v) => t.SpringF = v), new Num("springR", t => t.SpringR, (t, v) => t.SpringR = v),
            new Num("rideF", t => t.RideF, (t, v) => t.RideF = v, true), new Num("rideR", t => t.RideR, (t, v) => t.RideR = v, true),
            new Num("arbF", t => t.ArbF, (t, v) => t.ArbF = v), new Num("arbR", t => t.ArbR, (t, v) => t.ArbR = v),
            new Num("dampF", t => t.DampF, (t, v) => t.DampF = v), new Num("dampR", t => t.DampR, (t, v) => t.DampR = v),
            new Num("reboundF", t => t.ReboundF, (t, v) => t.ReboundF = v), new Num("reboundR", t => t.ReboundR, (t, v) => t.ReboundR = v),
            new Num("fastBumpF", t => t.FastBumpF, (t, v) => t.FastBumpF = v), new Num("fastBumpR", t => t.FastBumpR, (t, v) => t.FastBumpR = v),
            new Num("fastReboundF", t => t.FastReboundF, (t, v) => t.FastReboundF = v), new Num("fastReboundR", t => t.FastReboundR, (t, v) => t.FastReboundR = v),
            new Num("camberF", t => t.CamberF, (t, v) => t.CamberF = v), new Num("camberR", t => t.CamberR, (t, v) => t.CamberR = v),
            new Num("toeF", t => t.ToeF, (t, v) => t.ToeF = v), new Num("toeR", t => t.ToeR, (t, v) => t.ToeR = v),
            new Num("caster", t => t.Caster, (t, v) => t.Caster = v),
            new Num("rollCenterF", t => t.RollCenterF, (t, v) => t.RollCenterF = v, true), new Num("rollCenterR", t => t.RollCenterR, (t, v) => t.RollCenterR = v, true),
            new Num("antiDive", t => t.AntiDive, (t, v) => t.AntiDive = v), new Num("antiSquat", t => t.AntiSquat, (t, v) => t.AntiSquat = v),
            new Num("camberGainF", t => t.CamberGainF, (t, v) => t.CamberGainF = v), new Num("camberGainR", t => t.CamberGainR, (t, v) => t.CamberGainR = v),
            new Num("comHeight", t => t.ComHeight, (t, v) => t.ComHeight = v, true),
            new Num("pressureF", t => t.PressureF, (t, v) => t.PressureF = v), new Num("pressureR", t => t.PressureR, (t, v) => t.PressureR = v),
            new Num("grip", t => t.Grip, (t, v) => t.Grip = v),
            new Num("brakeBias", t => t.BrakeBias, (t, v) => t.BrakeBias = v), new Num("brakeForce", t => t.BrakeForce, (t, v) => t.BrakeForce = v),
            new Num("handbrakeForce", t => t.HandbrakeForce, (t, v) => t.HandbrakeForce = v),
            new Num("lsdPreload", t => t.LsdPreload, (t, v) => t.LsdPreload = v), new Num("lsdPower", t => t.LsdPower, (t, v) => t.LsdPower = v),
            new Num("lsdCoast", t => t.LsdCoast, (t, v) => t.LsdCoast = v), new Num("lsdViscous", t => t.LsdViscous, (t, v) => t.LsdViscous = v),
            new Num("awdFront", t => t.AwdFront, (t, v) => t.AwdFront = v),
            new Num("finalDrive", t => t.FinalDrive, (t, v) => t.FinalDrive = v),
            new Num("aeroF", t => t.AeroF, (t, v) => t.AeroF = v), new Num("aeroR", t => t.AeroR, (t, v) => t.AeroR = v),
            new Num("steerLock", t => t.SteerLock, (t, v) => t.SteerLock = v),
            // the driver's own (kept per car as well, but never in a saved setup)
            new Num("steerAssist", t => t.SteerAssist, (t, v) => t.SteerAssist = v), new Num("counterSteer", t => t.CounterSteer, (t, v) => t.CounterSteer = v),
            new Num("steerSpeed", t => t.SteerSpeed, (t, v) => t.SteerSpeed = v), new Num("recovery", t => t.Recovery, (t, v) => t.Recovery = v),
        };

        public static bool DriverKey(string k) => k == "steerAssist" || k == "counterSteer" || k == "steerSpeed" || k == "recovery";

        public static Num? Find(string key)
        {
            foreach (var n in Numbers) if (n.Key == key) return n;
            return null;
        }
    }
}
