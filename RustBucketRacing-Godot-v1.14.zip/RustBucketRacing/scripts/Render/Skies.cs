// HDRI skies (photographed "pure sky" HDRIs from Poly Haven, CC0; made ready by tools/prep_skies.py): the panorama
// each map is drawn under, and the light the game works out from it, so the sun, the sky's ambient light, the
// cars' reflections and the fog all agree.
//  - the sun is a light with shadows (taken out of the photo, where it would light everything twice); its height
//    and colour come from the photo, its bearing stays the game's own
//  - sunlit level ground shows Target in all (cars' units): the sun gives its share of that and the sky the rest,
//    as in the photo but with the shade never darker than 1 / (1 + MaxSunToSky) of the sunlit
//  - the sky's light is desaturated a little (Saturation): shade is cool, not blue, as the eye sees it
//  - the sky as drawn keeps close to the photo's brightness (a deep blue sky would turn pale); the light it gives
//    is made up below (the cars' ambient mixes in a neutral grey, the maps light with the sky's coefficients)
using System;
using System.Collections.Generic;
using System.Text.Json;
using Godot;

namespace RustBucket.Render
{
    public sealed class SkyInfo
    {
        public string Name = "", File = "";
        public int W, H;
        public double SunElev, SunPhi, SunE, SkyE;
        public double[] SunColor = { 1, 1, 1 }, Horizon = { 0.7, 0.76, 0.83 };
        public double[][] Sh = new double[9][];
    }

    // the light worked out for one sky
    public sealed class SkyLight
    {
        public SkyInfo Info;
        public float PanoramaEnergy, SunEnergy, Rotation, AmbientSky;
        public Color SunColor, AmbientColor, FogColor;
        public Vector3 ToSun;
        public Vector3[] Sh = new Vector3[9];   // the maps' sky light: turned with the sky, scaled, desaturated
    }

    public static class Skies
    {
        public const float Target = 1.3f, MaxSunToSky = 2.6f, Saturation = 0.45f, MaxPanorama = 1.3f;
        public const float MapGain = 1.22f;    // the maps' photographed textures to the screen brightness they had
        public const string Default = "kloofendal_48d_partly_cloudy_puresky", Studio = "studio";

        static Dictionary<string, SkyInfo> all;
        static readonly Dictionary<string, ImageTexture> tex = new Dictionary<string, ImageTexture>();

        static double N(JsonElement e, string k, double d) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetDouble() : d;
        static double[] A(JsonElement e)
        {
            var o = new double[e.GetArrayLength()]; int i = 0;
            foreach (var x in e.EnumerateArray()) o[i++] = x.GetDouble();
            return o;
        }

        static void Load()
        {
            if (all != null) return;
            all = new Dictionary<string, SkyInfo>();
            try
            {
                using var doc = JsonDocument.Parse(FileAccess.GetFileAsString("res://data/skies/skies.json"));
                foreach (var p in doc.RootElement.EnumerateObject())
                {
                    var e = p.Value;
                    var s = new SkyInfo
                    {
                        Name = p.Name, File = e.GetProperty("file").GetString(), W = (int)N(e, "w", 1024), H = (int)N(e, "h", 512),
                        SunElev = N(e, "sunElev", 45), SunPhi = N(e, "sunPhi", 0), SunE = N(e, "sunE", 0), SkyE = N(e, "skyE", 1),
                        SunColor = A(e.GetProperty("sunColor")), Horizon = A(e.GetProperty("horizon")),
                    };
                    int k = 0;
                    foreach (var c in e.GetProperty("sh").EnumerateArray()) if (k < 9) s.Sh[k++] = A(c);
                    all[p.Name] = s;
                }
            }
            catch (Exception ex) { GD.PushWarning("skies: " + ex.Message); }
        }

        public static SkyInfo Get(string name)
        {
            Load();
            if (name != null && all.TryGetValue(name, out var s)) return s;
            return all.TryGetValue(Default, out var d) ? d : null;
        }

        // the panorama: RGB9E5 texels packed in a PNG (stored as .sky so the export ships the bytes as they are)
        public static ImageTexture Texture(SkyInfo s)
        {
            if (s == null) return null;
            if (tex.TryGetValue(s.Name, out var t)) return t;
            var png = new Image();
            var bytes = FileAccess.GetFileAsBytes("res://data/skies/" + System.IO.Path.ChangeExtension(s.File, ".sky"));
            if (bytes == null || bytes.Length == 0 || png.LoadPngFromBuffer(bytes) != Error.Ok) { GD.PushWarning("sky " + s.Name + " did not load"); return null; }
            var img = Image.CreateFromData(s.W, s.H, false, Image.Format.Rgbe9995, png.GetData());
            t = ImageTexture.CreateFromImage(img);
            tex[s.Name] = t;
            return t;
        }

        static readonly float[] Y = new float[9];
        static float[] Basis(Vector3 n)
        {
            Y[0] = 0.282095f; Y[1] = 0.488603f * n.Z; Y[2] = 0.488603f * n.Y; Y[3] = 0.488603f * n.X;
            Y[4] = 1.092548f * n.X * n.Z; Y[5] = 1.092548f * n.Z * n.Y; Y[6] = 0.315392f * (3 * n.Y * n.Y - 1);
            Y[7] = 1.092548f * n.X * n.Y; Y[8] = 0.546274f * (n.X * n.X - n.Z * n.Z);
            return Y;
        }

        // without a sky panorama: the maps' old fixed light (a sky/ground hemisphere with light bounced onto upright
        // faces, the sun 1.32 times stronger than the cars'), as coefficients and a gain
        public const float OldGain = 2.75f * 0.66f / (1.45f * 0.95f);
        public static Vector3[] OldHemisphere()
        {
            var acc = new Vector3[9]; float wsum = 0;
            var gr = new Vector3(0.19f, 0.18f, 0.17f); var sk = new Vector3(0.40f, 0.48f, 0.60f); var b = new Vector3(0.30f, 0.29f, 0.27f);
            for (int i = 0; i < 48; i++)
                for (int j = 0; j < 24; j++)
                {
                    float th = (j + 0.5f) / 24 * Mathf.Pi, ph = (i + 0.5f) / 48 * Mathf.Tau;
                    var d = new Vector3(Mathf.Sin(th) * Mathf.Sin(ph), Mathf.Cos(th), -Mathf.Sin(th) * Mathf.Cos(ph));
                    var c = (gr.Lerp(sk, d.Y * 0.5f + 0.5f) + b * (1 - Mathf.Abs(d.Y))) * (0.66f / 0.95f / OldGain);
                    var yb = Basis(d); float w = Mathf.Sin(th);
                    for (int k = 0; k < 9; k++) acc[k] += c * yb[k] * w;
                    wsum += w;
                }
            for (int k = 0; k < 9; k++) acc[k] *= 4 * Mathf.Pi / wsum;
            return acc;
        }

        // gameAzimuth: the sun's bearing in the game (atan2(x, -z) of the direction towards it)
        public static SkyLight Light(SkyInfo s, float gameAzimuth)
        {
            var L = new SkyLight { Info = s };
            float el = Mathf.DegToRad((float)s.SunElev), sinEl = Mathf.Max(Mathf.Sin(el), 0.05f);
            float r = s.SunE > 0 ? Mathf.Min(MaxSunToSky, (float)(s.SunE * Mathf.Sin(el) / Math.Max(s.SkyE, 1e-6))) : 0f;
            float S = Target / (1 + r);                         // the sky's share on sunlit level ground
            float m = S * Mathf.Pi / (float)Math.Max(s.SkyE, 1e-6);
            L.PanoramaEnergy = Mathf.Min(m, MaxPanorama);
            L.SunEnergy = (Target - S) / sinEl;
            L.SunColor = new Color((float)s.SunColor[0], (float)s.SunColor[1], (float)s.SunColor[2]).LinearToSrgb();
            L.ToSun = new Vector3(Mathf.Sin(gameAzimuth) * Mathf.Cos(el), Mathf.Sin(el), -Mathf.Cos(gameAzimuth) * Mathf.Cos(el)).Normalized();
            L.Rotation = Mathf.DegToRad((float)s.SunPhi) - gameAzimuth;
            L.FogColor = new Color((float)s.Horizon[0] * L.PanoramaEnergy, (float)s.Horizon[1] * L.PanoramaEnergy, (float)s.Horizon[2] * L.PanoramaEnergy).LinearToSrgb();
            // cars: the sky's own ambient (at the drawn brightness), mixed with neutral grey making up the rest
            L.AmbientSky = Saturation;
            float g0 = Mathf.Max(0f, (S - Saturation * L.PanoramaEnergy * (float)s.SkyE / Mathf.Pi) / Mathf.Max(1 - Saturation, 0.05f));
            L.AmbientColor = new Color(g0, g0, g0).LinearToSrgb();
            // maps: the sky's coefficients turned with the panorama (re-projected over a grid of directions), at full m
            var acc = new Vector3[9];
            float wsum = 0;
            for (int i = 0; i < 48; i++)
                for (int j = 0; j < 24; j++)
                {
                    float th = (j + 0.5f) / 24 * Mathf.Pi, ph = (i + 0.5f) / 48 * Mathf.Tau;
                    var d = new Vector3(Mathf.Sin(th) * Mathf.Sin(ph), Mathf.Cos(th), -Mathf.Sin(th) * Mathf.Cos(ph));
                    var src = d.Rotated(Vector3.Up, -L.Rotation);   // what the turned panorama shows at d
                    var yb = Basis(src);
                    var c = Vector3.Zero;
                    for (int k = 0; k < 9; k++) c += new Vector3((float)s.Sh[k][0], (float)s.Sh[k][1], (float)s.Sh[k][2]) * yb[k];
                    float w = Mathf.Sin(th);
                    yb = Basis(d);
                    for (int k = 0; k < 9; k++) acc[k] += c * yb[k] * w;
                    wsum += w;
                }
            for (int k = 0; k < 9; k++)
            {
                var c = acc[k] * (4 * Mathf.Pi / wsum) * m;
                float l = c.Dot(new Vector3(0.2126f, 0.7152f, 0.0722f));
                L.Sh[k] = new Vector3(l, l, l) + (c - new Vector3(l, l, l)) * Saturation;
            }
            return L;
        }
    }
}
