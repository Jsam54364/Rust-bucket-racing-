// The front end's tuning: every setting of the car's setup on its own page (tyres, gearing, alignment, springs,
// damping, anti-roll bars, geometry, aero, brakes, differential), the figures they make (ride frequencies, damping
// ratios, roll stiffness, gear speeds, downforce), and saved setups. Changes apply to the car at once and are kept.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed partial class FrontEnd
    {
        static readonly string[] TuneTabs = { "Tyres", "Gearing", "Alignment", "Springs", "Damping", "Anti-roll", "Geometry", "Aero", "Brakes", "Differential", "Setups" };
        static readonly string[] TuneNotes =
        {
            "Lower pressures make a softer, longer footprint: a lazier response and more rolling drag. Higher pressures answer sharper. Grip is best just under the pressure the tyre is made for and falls away either side of it.",
            "A higher (shorter) ratio pulls harder and reaches the limiter sooner; a lower one reaches a higher speed. The figures show each gear's speed at the limiter.",
            "Negative camber leans the tops of the tyres in, so the outside tyre stands flat as the body rolls: more grip in corners, a little less braking and traction. Toe-in steadies the car, toe-out sharpens the turn-in. Caster adds camber as you steer.",
            "Stiffer springs hold the body flatter and answer quicker but ride bumps worse. Ride height is the body's height at rest: lower brings the centre of mass down and leaves less travel before the bump stops.",
            "Bump damps a wheel going up, rebound a wheel coming back down. Slow damping is the body's roll and pitch; fast damping (shaft speeds over 0.12 m/s) is bumps and kerbs.",
            "A stiffer bar at one end takes grip from that end: a stiffer front pushes the nose wide, a stiffer rear helps the car turn (and can step it out).",
            "Roll centres set how much of the cornering load goes straight through the links instead of the springs; anti-dive and anti-squat do the same under braking and power. Camber gain is how much of the body's roll the linkage takes back out of the camber.",
            "Downforce from the splitter and the wing grows with the square of speed: more at one end grips that end harder, and more wing is more drag.",
            "Bias puts more of the braking on the front or the rear; force scales the whole system. ABS holds each wheel just short of locking.",
            "Preload locks the differential all the time; power and coast lock add locking in proportion to the torque through it, on and off the throttle. More locking puts the power down and steadies the car off the throttle, but pushes the nose wide. The viscous coupling locks with the difference in wheel speed.",
            "Save the car's setup under a name and load it again any time. The driving aids and your steering preferences stay as they are.",
        };

        sealed class TP
        {
            public int Tab, Gear = -1;
            public string Key, Label, Lo = "", Hi = "";
            public double Min, Max, Step;
            public Func<double, string> Fmt;
            public Func<CarSpec, Tune, bool> When;
            public Tune.Num Num;
            public Ui.SliderRow Row;
        }

        readonly List<TP> tps = new List<TP>();
        readonly Control[] tunePanels = new Control[TuneTabs.Length];
        readonly VBoxContainer[] tuneCols = new VBoxContainer[TuneTabs.Length];
        int tuneTab;
        Label tuneCar, tuneNote, figGears;
        GridContainer figGrid;
        readonly List<(Label k, Label v)> figs = new List<(Label, Label)>();
        Fz.Tabs presetOpts, absOpts, tcsOpts, driveOpts;
        Label aeroNone;
        Button bTabReset;
        // setups
        LineEdit setupName;
        Button bSaveSetup;
        VBoxContainer setupList;
        Label setupStatus;
        int setupArmed = -1;

        static string Sgn(double v, int dp) => (v > 0 ? "+" : "") + F(v, dp);

        void T(int tab, string key, string label, double min, double max, double step, Func<double, string> fmt, string lo = "", string hi = "", Func<CarSpec, Tune, bool> when = null)
        {
            var tp = new TP { Tab = tab, Key = key, Label = label, Min = min, Max = max, Step = step, Fmt = fmt, Lo = lo, Hi = hi, When = when };
            if (key.StartsWith("gear")) tp.Gear = int.Parse(key.Substring(4)) - 1;
            else tp.Num = Tune.Find(key).Value;
            var t = tp;
            tp.Row = Fz.Slider(label, min, max, step, fmt, (v) => g.ChangeTune((tn) => SetTp(t, tn, v)), lo, hi);
            tuneCols[tab].AddChild(tp.Row.Root);
            tps.Add(tp);
        }

        static double GetTp(TP p, Tune t) => p.Gear >= 0 ? t.Gear(p.Gear) : p.Num.Get(t);
        static void SetTp(TP p, Tune t, double v)
        {
            if (p.Gear >= 0) { if (t.Gears != null && p.Gear < t.Gears.Length) t.Gears[p.Gear] = v; }
            else p.Num.Set(t, v);
        }

        Fz.Tabs OptionRow(int tab, string label, string[] names, Action<int> pick)
        {
            var o = Fz.Options(names, pick, 40);
            tuneCols[tab].AddChild(Fz.Row(label, o.Root));
            return o;
        }

        void BuildTuning()
        {
            var m = Frame(Page.Tuning);
            var col = Ui.Col(12);
            m.AddChild(col);
            tuneCar = Fz.Caps("", 17, Fz.Body);
            col.AddChild(Head(Page.Tuning, "Tuning", TuneTabs, (i) => { tuneTab = i; ShowTuneTab(); }, tuneCar));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var panel = Fz.Panel(0, 0.88f);
            panel.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            row.AddChild(panel);
            var host = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
            panel.AddChild(host);
            for (int i = 0; i < TuneTabs.Length; i++)
            {
                var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, Visible = false };
                scroll.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                var c = Ui.Col(12);
                c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                scroll.AddChild(Ui.Pad(c, 26, 18, 26, 18));
                host.AddChild(scroll);
                tunePanels[i] = scroll; tuneCols[i] = c;
            }
            Func<double, string> kN = (v) => F(v / 1000, 1) + " kN/m", Ns = (v) => F(v, 0) + " N·s/m", cm = (v) => F(v * 100, 1) + " cm",
                deg = (v) => Sgn(v, 1) + "°", pct = (v) => F(v * 100, 0) + " %", ratio = (v) => F(v, 2);
            // tyres
            T(0, "pressureF", "Front pressure", 1.2, 3.4, 0.05, (v) => F(v, 2) + " bar  ·  " + F(v * 14.5038, 1) + " psi", "Soft", "Hard");
            T(0, "pressureR", "Rear pressure", 1.2, 3.4, 0.05, (v) => F(v, 2) + " bar  ·  " + F(v * 14.5038, 1) + " psi", "Soft", "Hard");
            T(0, "grip", "Compound grip", 0.6, 1.8, 0.01, (v) => F(v, 2) + " μ", "Hard", "Sticky");
            // gearing
            T(1, "finalDrive", "Final drive", 2.2, 6.5, 0.01, ratio, "Speed", "Pull");
            string[] ord = { "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th" };
            for (int i = 0; i < 8; i++)
            {
                int gi = i;
                T(1, "gear" + (i + 1), ord[i] + " gear", 0.45, 5.0, 0.01, ratio, "Speed", "Pull", (s, t) => gi < s.Gears.Length);
            }
            // alignment
            T(2, "camberF", "Front camber", -5, 1, 0.1, deg, "Negative", "Positive");
            T(2, "camberR", "Rear camber", -5, 1, 0.1, deg, "Negative", "Positive");
            T(2, "toeF", "Front toe", -1, 1, 0.05, (v) => Sgn(v, 2) + "°", "Out", "In");
            T(2, "toeR", "Rear toe", -1, 1, 0.05, (v) => Sgn(v, 2) + "°", "Out", "In");
            T(2, "caster", "Caster", 1, 10, 0.1, (v) => F(v, 1) + "°", "Light", "Stable");
            // springs: the factory packages first
            presetOpts = OptionRow(3, "Factory package", new[] { "Comfort", "Street", "Sport", "Race" }, (i) =>
            {
                var name = CarSpec.PresetOrder[i];
                var p = g.Car.Spec.Presets[name];
                g.ChangeTune((t) => t.Apply(p));
                g.Toast(char.ToUpperInvariant(name[0]) + name.Substring(1) + " suspension");
            });
            T(3, "springF", "Front springs", 10000, 180000, 500, kN, "Soft", "Stiff");
            T(3, "springR", "Rear springs", 10000, 180000, 500, kN, "Soft", "Stiff");
            T(3, "rideF", "Front ride height", -0.08, 0.08, 0.002, (v) => Sgn(v * 100, 1) + " cm", "Low", "High");
            T(3, "rideR", "Rear ride height", -0.08, 0.08, 0.002, (v) => Sgn(v * 100, 1) + " cm", "Low", "High");
            // damping
            T(4, "dampF", "Front bump", 300, 12000, 50, Ns, "Soft", "Stiff");
            T(4, "reboundF", "Front rebound", 300, 18000, 50, Ns, "Soft", "Stiff");
            T(4, "dampR", "Rear bump", 300, 12000, 50, Ns, "Soft", "Stiff");
            T(4, "reboundR", "Rear rebound", 300, 18000, 50, Ns, "Soft", "Stiff");
            T(4, "fastBumpF", "Front fast bump", 0, 12000, 50, Ns, "Soft", "Stiff");
            T(4, "fastReboundF", "Front fast rebound", 0, 18000, 50, Ns, "Soft", "Stiff");
            T(4, "fastBumpR", "Rear fast bump", 0, 12000, 50, Ns, "Soft", "Stiff");
            T(4, "fastReboundR", "Rear fast rebound", 0, 18000, 50, Ns, "Soft", "Stiff");
            // anti-roll bars
            T(5, "arbF", "Front bar", 0, 70000, 500, kN, "Soft", "Stiff");
            T(5, "arbR", "Rear bar", 0, 70000, 500, kN, "Soft", "Stiff");
            // geometry
            T(6, "rollCenterF", "Front roll centre", 0, 0.3, 0.005, cm, "Low", "High");
            T(6, "rollCenterR", "Rear roll centre", 0, 0.3, 0.005, cm, "Low", "High");
            T(6, "antiDive", "Anti-dive (front)", 0, 1, 0.01, pct, "Dives", "Flat");
            T(6, "antiSquat", "Anti-squat (rear)", 0, 1, 0.01, pct, "Squats", "Flat");
            T(6, "camberGainF", "Front camber gain", 0, 1, 0.01, pct, "None", "Full");
            T(6, "camberGainR", "Rear camber gain", 0, 1, 0.01, pct, "None", "Full");
            T(6, "comHeight", "Centre of mass height", 0.3, 0.8, 0.005, cm, "Low", "High");
            T(6, "steerLock", "Steering lock", 20, 50, 0.5, (v) => F(v, 1) + "°", "Less", "More");
            // aero
            aeroNone = Fz.Text("This car has no splitter or wing to set: what downforce (or lift) it has comes from its shape.", 17, Fz.Body);
            tuneCols[7].AddChild(aeroNone);
            T(7, "aeroF", "Front splitter", 0, 2, 0.01, pct, "Less", "More", (s, t) => s.HasWing);
            T(7, "aeroR", "Rear wing", 0, 2, 0.01, pct, "Less", "More", (s, t) => s.HasWing);
            // brakes
            T(8, "brakeBias", "Brake bias, front", 0.4, 0.8, 0.01, pct, "Rear", "Front");
            T(8, "brakeForce", "Brake force", 0.5, 1.4, 0.01, pct, "Less", "More");
            T(8, "handbrakeForce", "Handbrake", 0, 2, 0.05, pct, "Less", "More");
            absOpts = OptionRow(8, "ABS", new[] { "Off", "On" }, (i) => g.ChangeTune((t) => t.Abs = i == 1));
            // differential
            driveOpts = OptionRow(9, "Driven wheels", new[] { "Rear", "Front", "All" }, (i) => { g.ChangeTune((t) => t.Drive = (Drive)i); g.Toast((Drive)i + " drivetrain"); });
            T(9, "awdFront", "Torque to the front", 0.1, 0.9, 0.01, pct, "Rear", "Front", (s, t) => t.Drive == Drive.AWD);
            T(9, "lsdPreload", "Preload", 0, 400, 5, (v) => F(v, 0) + " N·m", "Open", "Locked");
            T(9, "lsdPower", "Power lock", 0, 1, 0.01, pct, "Open", "Locked");
            T(9, "lsdCoast", "Coast lock", 0, 1, 0.01, pct, "Open", "Locked");
            T(9, "lsdViscous", "Viscous coupling", 0, 400, 5, (v) => F(v, 0) + " N·m·s", "Open", "Tight");
            tcsOpts = OptionRow(9, "Traction control", new[] { "Off", "On" }, (i) => g.ChangeTune((t) => t.Tcs = i == 1));
            // setups
            BuildSetups(tuneCols[10]);

            // the figures
            var side = Fz.Panel(20, 0.88f);
            side.CustomMinimumSize = new Vector2(330, 0);
            row.AddChild(side);
            var sc = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled };
            side.AddChild(sc);
            var fc = Ui.Col(8);
            fc.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            sc.AddChild(fc);
            tuneNote = Fz.Text("", 15, Fz.Body);
            fc.AddChild(tuneNote);
            fc.AddChild(Gap(2));
            fc.AddChild(Fz.Caps("Figures", 14, Fz.Dim));
            figGrid = new GridContainer { Columns = 2 };
            figGrid.AddThemeConstantOverride("h_separation", 12); figGrid.AddThemeConstantOverride("v_separation", 5);
            fc.AddChild(figGrid);
            figGears = Fz.Text("", 15, Fz.Ink);
            fc.AddChild(figGears);
            fc.AddChild(Gap(4));
            bTabReset = Fz.Btn("Factory values here", ResetTuneTab, Fz.Look.Plain, 44, 15);
            fc.AddChild(bTabReset);
            firstFocus[Page.Tuning] = () =>
            {
                if (tuneTab == 10) return bSaveSetup;   // not the name: on a phone that would open the keyboard
                foreach (var tp in tps) if (tp.Tab == tuneTab && tp.Row.Root.Visible) return tp.Row.Slider;
                return null;
            };
            ShowTuneTab();
        }

        void BuildSetups(VBoxContainer c)
        {
            c.AddChild(Fz.Caps("Save this setup", 14, Fz.Dim));
            var r = Ui.Row(8);
            setupName = new LineEdit { PlaceholderText = "Name", CustomMinimumSize = new Vector2(0, 46), SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, MaxLength = 32 };
            setupName.TextSubmitted += (s) => SaveSetup(-1);
            r.AddChild(setupName);
            bSaveSetup = Fz.Btn("Save as new", () => SaveSetup(-1), Fz.Look.Primary, 46, 17, 180);
            r.AddChild(bSaveSetup);
            c.AddChild(r);
            setupStatus = Fz.Text("", 14, Fz.Dim);
            c.AddChild(setupStatus);
            c.AddChild(Gap(6));
            c.AddChild(Fz.Caps("Saved setups", 14, Fz.Dim));
            setupList = Ui.Col(8);
            setupList.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            c.AddChild(setupList);
            c.AddChild(Gap(10));
            c.AddChild(Fz.Caps("Factory", 14, Fz.Dim));
            var fr = Fz.Btn("Back to the factory setup", () =>
            {
                g.ReplaceTune(g.Car.Spec.DefaultTune);
                setupStatus.Text = "The factory setup is back on.";
            }, Fz.Look.Plain, 46, 16);
            c.AddChild(fr);
        }

        string CarIdForTune => g.CarId;

        void SaveSetup(int slot)
        {
            var store = g.Store;
            string id = CarIdForTune;
            if (slot < 0) slot = store.FreeSetupSlot(id);
            if (slot < 0) { setupStatus.Text = "That's " + Settings.MaxSetups + " setups for this car: delete one first."; return; }
            string name = setupName.Text.Trim();
            var existing = store.Setups(id).Find((x) => x.slot == slot);
            if (name.Length == 0) name = existing.name ?? ("Setup " + (slot + 1));
            store.SaveSetup(id, slot, name, g.Car.Tune);
            setupName.Text = "";
            setupArmed = -1;
            setupStatus.Text = "Saved: " + name;
            RebuildSetups();
        }

        void RebuildSetups()
        {
            if (setupList == null) return;
            foreach (var ch in setupList.GetChildren()) { setupList.RemoveChild(ch); ch.QueueFree(); }
            string id = CarIdForTune;
            var list = g.Store.Setups(id);
            if (list.Count == 0) setupList.AddChild(Fz.Text("None yet for this car.", 16, Fz.Dim));
            foreach (var (slot, name) in list)
            {
                int s = slot; string nm = name;
                var row = Ui.Row(8);
                var l = Fz.Caps(name, 18, Fz.Ink);
                l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                l.VerticalAlignment = VerticalAlignment.Center;
                l.ClipText = true;
                row.AddChild(l);
                row.AddChild(Fz.Btn("Load", () =>
                {
                    g.ReplaceTune(g.Store.LoadSetup(g.Car.Spec, s));
                    setupStatus.Text = "Loaded: " + nm;
                    g.Toast("Setup loaded: " + nm);
                }, Fz.Look.Primary, 42, 16, 110));
                row.AddChild(Fz.Btn("Save over", () => { setupName.Text = nm; SaveSetup(s); }, Fz.Look.Plain, 42, 14, 120));
                row.AddChild(Fz.Btn(setupArmed == s ? "Sure?" : "Delete", () =>
                {
                    if (setupArmed != s) { setupArmed = s; RebuildSetups(); return; }
                    setupArmed = -1;
                    g.Store.DeleteSetup(id, s);
                    setupStatus.Text = "Deleted: " + nm;
                    RebuildSetups();
                }, Fz.Look.Plain, 42, 14, 100));
                setupList.AddChild(row);
            }
            Quiet(setupList);
        }

        void ShowTuneTab()
        {
            for (int i = 0; i < tunePanels.Length; i++) tunePanels[i].Visible = i == tuneTab;
            if (subTabs.TryGetValue(Page.Tuning, out var t)) t.Select(tuneTab);
            tuneNote.Text = TuneNotes[tuneTab];
            bTabReset.Visible = tuneTab != 10;
            if (tuneTab == 10) { setupArmed = -1; RebuildSetups(); }
            if (page == Page.Tuning) { SyncTuning(); FocusFirst(); }
        }

        void ShowTuning()
        {
            tuneTab = Math.Clamp(tuneTab, 0, TuneTabs.Length - 1);
            ShowTuneTab();
        }

        // i < 0: the page last open
        public void OpenTuningTab(int i)
        {
            if (i >= 0) tuneTab = Math.Clamp(i, 0, TuneTabs.Length - 1);
            if (page == Page.Tuning) ShowTuneTab(); else Go(Page.Tuning);
        }

        // this page's settings back to the car's own
        void ResetTuneTab()
        {
            var d = g.Car.Spec.DefaultTune;
            int tab = tuneTab;
            g.ChangeTune((t) =>
            {
                foreach (var tp in tps) if (tp.Tab == tab) SetTp(tp, t, GetTp(tp, d));
                if (tab == 8) t.Abs = d.Abs;
                if (tab == 9) { t.Drive = d.Drive; t.Tcs = d.Tcs; }
            });
        }

        void SyncTuning()
        {
            var car = g.Car;
            if (car == null) return;
            var t = car.Tune; var s = car.Spec;
            tuneCar.Text = Defs.Cars[g.CarId].Title.ToUpperInvariant();
            foreach (var tp in tps)
            {
                bool on = tp.When == null || tp.When(s, t);
                tp.Row.Root.Visible = on;
                if (on) tp.Row.Show(GetTp(tp, t));
            }
            aeroNone.Visible = !s.HasWing;
            int pi = -1;
            for (int i = 0; i < CarSpec.PresetOrder.Length; i++) if (t.Matches(s.Presets[CarSpec.PresetOrder[i]])) pi = i;
            presetOpts.Select(Math.Max(pi, 0));
            if (pi < 0) foreach (var b in presetOpts.Items) b.SetPressedNoSignal(false);
            absOpts.Select(t.Abs ? 1 : 0); tcsOpts.Select(t.Tcs ? 1 : 0); driveOpts.Select((int)t.Drive);
            SyncFigures(car);
        }

        // what the setup adds up to
        void SyncFigures(Car car)
        {
            var s = car.Spec; var t = car.Tune;
            double wb = s.Hubs[2].Z - s.Hubs[0].Z, trF = s.Hubs[1].X - s.Hubs[0].X, trR = s.Hubs[3].X - s.Hubs[2].X;
            double front = (s.Hubs[2].Z - s.ComZ) / wb;
            double mF = s.Mass * front / 2, mR = s.Mass * (1 - front) / 2;
            double Hz(double k, double m) => Math.Sqrt(Math.Max(k, 1) / m) / (2 * Math.PI);
            double Z(double c, double k, double m) => c / (2 * Math.Sqrt(Math.Max(k, 1) * m));
            double kF = trF * trF * (t.SpringF / 2 + t.ArbF), kR = trR * trR * (t.SpringR / 2 + t.ArbR);
            double rr = t.Drive == Drive.FWD && s.WheelRadiusF > 0 ? s.WheelRadiusF : s.WheelRadius;
            int ng = s.Gears.Length;
            double Kmh(double gear) => s.Limiter * 2 * Math.PI / 60 * rr / Math.Max(0.1, gear * t.FinalDrive) * 3.6;
            var rowsF = new List<(string, string)>
            {
                ("Weight, front", F(front * 100, 0) + " %"),
                ("Ride frequency", F(Hz(t.SpringF, mF), 2) + " / " + F(Hz(t.SpringR, mR), 2) + " Hz"),
                ("Damping, bump", F(Z(t.DampF, t.SpringF, mF), 2) + " / " + F(Z(t.DampR, t.SpringR, mR), 2)),
                ("Damping, rebound", F(Z(t.ReboundF, t.SpringF, mF), 2) + " / " + F(Z(t.ReboundR, t.SpringR, mR), 2)),
                ("Roll stiffness, front", F(kF / Math.Max(1, kF + kR) * 100, 0) + " %"),
                ("Ride height", Sgn(t.RideF * 100, 1) + " / " + Sgn(t.RideR * 100, 1) + " cm"),
                ("Camber", Sgn(t.CamberF, 1) + "° / " + Sgn(t.CamberR, 1) + "°"),
                ("Top gear, at the limiter", F(Kmh(t.Gear(ng - 1)), 0) + " km/h"),
                ("Brake bias, front", F(t.BrakeBias * 100, 0) + " %"),
            };
            if (s.HasWing)
            {
                double q = 0.5 * 1.2 * Math.Pow(200 / 3.6, 2) / Cars.G;
                rowsF.Add(("Downforce at 200 km/h", F(q * s.ClA * s.AeroBalance * t.AeroF, 0) + " / " + F(q * s.ClA * (1 - s.AeroBalance) * t.AeroR, 0) + " kg"));
            }
            while (figs.Count < rowsF.Count)
            {
                var k = Fz.Caps("", 13, Fz.Dim); var v = Fz.Caps("", 15, Fz.Ink);
                v.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill; v.HorizontalAlignment = HorizontalAlignment.Right;
                figGrid.AddChild(k); figGrid.AddChild(v);
                figs.Add((k, v));
            }
            for (int i = 0; i < figs.Count; i++)
            {
                bool on = i < rowsF.Count;
                figs[i].k.Visible = figs[i].v.Visible = on;
                if (on) { figs[i].k.Text = rowsF[i].Item1.ToUpperInvariant(); figs[i].v.Text = rowsF[i].Item2; }
            }
            string[] ord = { "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th" };
            var gl = new List<string>();
            for (int i = 0; i < ng; i++) gl.Add(ord[i] + " " + F(Kmh(t.Gear(i)), 0));
            figGears.Text = tuneTab == 1 ? "At the limiter (km/h): " + string.Join("  ·  ", gl) : "";
            figGears.Visible = tuneTab == 1;
        }
    }
}
