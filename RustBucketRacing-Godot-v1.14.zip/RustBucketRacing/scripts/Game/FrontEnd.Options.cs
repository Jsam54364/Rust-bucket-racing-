// The front end's options: settings (audio, display, driving, controls, other), how to play and credits.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Audio;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed partial class FrontEnd
    {
        /* ---------------- settings ---------------- */
        readonly List<Control> tabs = new List<Control>();
        int tab;
        Fz.Tabs sSound, sTele, sAnalog, sGfx, sUnits, sGear, sSteerSeg;
        readonly Ui.SliderRow[] sVol = new Ui.SliderRow[5];
        Ui.SliderRow sSens, sSpeed, sAssist, sCs, sRec;
        Label sRef;
        Button sFirstAudio;

        public void ShowTab(int i)
        {
            tab = Math.Clamp(i, 0, tabs.Count - 1);
            for (int k = 0; k < tabs.Count; k++) tabs[k].Visible = k == tab;
            if (subTabs.TryGetValue(Page.Settings, out var t)) t.Select(tab);
            if (page == Page.Settings) FocusFirst();
        }

        VBoxContainer Tab(Control host)
        {
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, Visible = false };
            scroll.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            var col = Ui.Col(14);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(col, 28, 20, 32, 24));
            host.AddChild(scroll);
            tabs.Add(scroll);
            return col;
        }

        static Label Note(string s) => Fz.Text(s, 14, Fz.Dim);

        static void Head(VBoxContainer c, string s, bool first = false)
        {
            if (!first) c.AddChild(Gap(6));
            c.AddChild(Fz.Title(s, 22, Fz.Red));
        }

        static Fz.Tabs OnOff(Action<bool> set) => Fz.Options(new[] { "Off", "On" }, (i) => set(i == 1), 40);

        void BuildSettings()
        {
            var m = Frame(Page.Settings);
            var col = Ui.Col(12);
            m.AddChild(col);
            col.AddChild(Head(Page.Settings, "Settings", TabNames, (i) => ShowTab(i), Pill("SAVED ON THIS DEVICE", Fz.Dim)));
            var host = Fz.Panel(0, 0.88f);
            host.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(host);
            var inner = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
            host.AddChild(inner);

            // audio
            var a = Tab(inner);
            Head(a, "Sound", true);
            sSound = OnOff((on) => { if (on != g.SoundOn) g.ToggleSound(); Sync(); });
            a.AddChild(Fz.Row("Sound", sSound.Root));
            sFirstAudio = sSound.Items[0];
            Head(a, "Volume");
            a.AddChild(Note("The engine, tyre squeal and crashes are mixed to stand out, with the rest underneath. Set each kind of sound to suit your speaker or headphones; moving a slider plays a sample of it."));
            for (int i = 0; i < 5; i++)
            {
                int k = i;
                sVol[i] = Fz.Slider(EngineAudio.KindNames[i], 0, 100, 1, (v) => v > 0 ? F(v, 0) + " %" : "Off", (v) => g.SetVolume(k, v / 100), "Off", "Full");
                var hint = Note(char.ToUpperInvariant(EngineAudio.KindHints[i][0]) + EngineAudio.KindHints[i].Substring(1));
                sVol[i].Root.AddChild(hint);
                sVol[i].Root.MoveChild(hint, 1);
                a.AddChild(sVol[i].Root);
            }
            var rl = Fz.Btn("Reset levels", () => { for (int i = 0; i < 5; i++) g.SetVolume(i, 1, false); Sync(); }, Fz.Look.Plain, 46, 16, 260);
            rl.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            a.AddChild(rl);

            // display
            var d = Tab(inner);
            Head(d, "Graphics", true);
            sGfx = Fz.Options(new[] { "High", "Medium", "Low" }, (i) => { g.SetQuality(i); Sync(); }, 40);
            d.AddChild(Fz.Row("Quality", sGfx.Root, "High: shadow maps out to 120 m, the sharpest shade near the car. Medium (phones start here): out to 70 m. Low: no shadow maps (the maps' baked shadows stay), a soft shadow under the car, 70 % resolution."));
            Head(d, "Speed");
            sUnits = Fz.Options(new[] { "km/h", "mph" }, (i) => { g.SetUnits(i == 0); Sync(); }, 40);
            d.AddChild(Fz.Row("Units", sUnits.Root));
            Head(d, "Telemetry");
            sTele = OnOff((on) => { if (on != g.TelemetryOn) g.ToggleTelemetry(); Sync(); });
            d.AddChild(Fz.Row("Telemetry", sTele.Root, "Live readouts over the drive: each tyre's load and slip, the suspension, and what the assists are doing."));
            if (!OS.HasFeature("mobile"))
            {
                Head(d, "Window");
                var fs = Fz.Btn("Full screen", () =>
                {
                    var wm = DisplayServer.WindowGetMode();
                    DisplayServer.WindowSetMode(wm == DisplayServer.WindowMode.Fullscreen ? DisplayServer.WindowMode.Windowed : DisplayServer.WindowMode.Fullscreen);
                }, Fz.Look.Plain, 46, 16, 260);
                fs.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
                d.AddChild(fs);
            }

            // driving
            var dr = Tab(inner);
            Head(dr, "Gearbox", true);
            sGear = Fz.Options(new[] { "Auto", "Semi", "Manual" }, (i) => { g.SetGearbox((Gearbox)i); Sync(); }, 40);
            dr.AddChild(Fz.Row("Gearbox", sGear.Root, "Auto shifts for you and reverses when you hold Brake at a stop. Semi lets you shift but protects the engine. Manual takes any gear you ask for. Shifting by hand in Auto switches to Semi."));
            Head(dr, "Steering");
            sSpeed = Fz.Slider("Steering speed", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => g.ChangeTune((t) => t.SteerSpeed = v), "Slow", "Fast");
            dr.AddChild(sSpeed.Root);
            dr.AddChild(Note("How fast the front wheels can turn, lock to lock. Letting go, they come back to centre almost three times as fast."));
            Head(dr, "Assists");
            sAssist = Fz.Slider("Steering assist", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.SteerAssist = v), "Off", "Full");
            dr.AddChild(sAssist.Root);
            dr.AddChild(Note("Holds full lock back to what the front tyres can use at speed, so stabbing the steering doesn't just scrub them. Off gives you the whole rack at any speed. Below about 50 km/h both assists stand back while you are steering."));
            sCs = Fz.Slider("Counter-steer", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.CounterSteer = v), "Off", "Full");
            dr.AddChild(sCs.Root);
            dr.AddChild(Note("When the rear starts to slide, steers into the slide for you to catch it. Higher steps in earlier and harder; lower leaves room for drifts and handbrake turns. The CS light shows when it acts."));
            sRec = Fz.Slider("Slide recovery", 0, 1, 0.05, (v) => v > 0 ? Math.Round(v * 100) + " %" : "Off", (v) => g.ChangeTune((t) => t.Recovery = v), "Off", "Full");
            dr.AddChild(sRec.Root);
            dr.AddChild(Note("How much grip sliding tyres get back when you ease off the throttle and brake, so a slide straightens up. On the pedals (past about half) or the handbrake it stays out of the way. Off is the raw tyre."));
            dr.AddChild(Note("ABS, traction control and the whole setup are in the garage's Tuning (T while you drive, or Tuning in the menu)."));

            // controls
            var c = Tab(inner);
            Head(c, "Steering", true);
            sSens = Fz.Slider("Sensitivity", 0.4, 2.5, 0.05, (v) => F(v, 2) + "×", (v) => { g.Prefs.Sens = v; g.SaveControls(); }, "Low", "High");
            c.AddChild(sSens.Root);
            c.AddChild(Note("Higher turns more for a small movement of the slider or stick (full lock stays at the end). With buttons or keys, how quickly holding one winds the steering on."));
            sSteerSeg = Fz.Options(new[] { "Slider", "Buttons" }, (i) => { g.Prefs.ButtonSteer = i == 1; g.SaveControls(); Sync(); }, 40);
            c.AddChild(Fz.Row("Touch steering", sSteerSeg.Root));
            Head(c, "Pedals");
            sAnalog = OnOff((on) => { g.Prefs.AnalogPedals = on; g.SaveControls(); Sync(); });
            c.AddChild(Fz.Row("Analogue pedals", sAnalog.Root, "On: Gas and Brake press harder the higher you press them, and a tap of the brake gives a light brush. Off: every press is full on."));
            var reset = Fz.Btn("Reset controls to defaults", () =>
            {
                g.Prefs.Sens = 1; g.Prefs.ButtonSteer = false; g.Prefs.AnalogPedals = true; g.SaveControls();
                g.ChangeTune((t) => { t.SteerSpeed = 1; t.SteerAssist = 1; t.CounterSteer = 0.5; t.Recovery = 0.75; });
                Sync();
            }, Fz.Look.Plain, 46, 16, 340);
            reset.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            c.AddChild(reset);
            Head(c, "Reference");
            sRef = Fz.Text("", 15, Fz.Body);
            c.AddChild(sRef);

            // other
            var o = Tab(inner);
            Head(o, "Bug reports", true);
            Button copyBtn = null;
            copyBtn = Fz.Btn("Copy debug log", () => { DebugLog.CopyToClipboard(); copyBtn.Text = "COPIED"; }, Fz.Look.Plain, 46, 16, 300);
            copyBtn.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            o.AddChild(copyBtn);
            o.AddChild(Note("Copies the game's log (device, frame rate, anything that went wrong) so you can paste it into a message."));
            Head(o, "About");
            var cr = Fz.Btn("Credits  ›", () => Go(Page.Credits), Fz.Look.Plain, 46, 16, 300);
            cr.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            o.AddChild(cr);
            o.AddChild(Note("Rust Bucket Racing v" + DebugLog.Version + ", an alpha. Free Roam is the one mode so far; Time Trial, Career and Multiplayer are on the way."));
            firstFocus[Page.Settings] = () => tab switch
            {
                0 => sFirstAudio, 1 => sGfx.Items[0], 2 => sGear.Items[0], 3 => sSens.Slider, _ => copyBtn,
            };
            ShowTab(0);
        }

        void SyncSettings()
        {
            var car = g.Car;
            if (car == null) return;
            var t = car.Tune;
            sSound.Select(g.SoundOn ? 1 : 0);
            for (int i = 0; i < 5; i++) sVol[i].Show(Math.Round(g.Volume(i) * 100));
            sGfx.Select(g.Quality);
            sUnits.Select(g.Kmh ? 0 : 1);
            sTele.Select(g.TelemetryOn ? 1 : 0);
            sGear.Select((int)t.Gearbox);
            sSpeed.Show(t.SteerSpeed); sAssist.Show(t.SteerAssist); sCs.Show(t.CounterSteer); sRec.Show(t.Recovery);
            sSens.Show(g.Prefs.Sens);
            sSteerSeg.Select(g.Prefs.ButtonSteer ? 1 : 0);
            sAnalog.Select(g.Prefs.AnalogPedals ? 1 : 0);
            sRef.Text = ControlsText(g.Touch);
            howControls.Text = ControlsText(g.Touch);
        }

        /* ---------------- how to play, credits ---------------- */
        Label howControls, howMaps, creditMaps;

        void FillGuide()
        {
            var parts = new List<string>();
            foreach (var id in Defs.MapOrder)
            {
                var d = Defs.Maps[id];
                if (d.Guide.Length > 0) parts.Add(d.Name.ToUpperInvariant() + "  " + d.Guide);
            }
            parts.Add("More maps download from Maps; Free Roam lists every map on this phone.");
            howMaps.Text = string.Join("\n\n", parts);
        }

        void FillCredits()
        {
            var parts = new List<string>();
            foreach (var id in Defs.MapOrder) if (Defs.Maps[id].Credit.Length > 0) parts.Add(Defs.Maps[id].Credit);
            creditMaps.Text = parts.Count > 0 ? string.Join("\n", parts) : "The proving ground is the game's own. Maps you install list their credits here.";
        }

        VBoxContainer TextPage(Page p, string title)
        {
            var m = Frame(p);
            var col = Ui.Col(12);
            m.AddChild(col);
            col.AddChild(Head(p, title));
            var card = Fz.Panel(0, 0.88f);
            card.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(card);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, FocusMode = Control.FocusModeEnum.All };
            card.AddChild(scroll);
            var c = Ui.Col(10);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(c, 28, 20, 32, 24));
            firstFocus[p] = () => scroll;
            return c;
        }

        void BuildHowTo()
        {
            var c = TextPage(Page.HowTo, "How to play");
            c.AddChild(Fz.Title("Controls", 22, Fz.Red));
            howControls = Fz.Text("", 17, new Color(0.86f, 0.89f, 0.91f));
            c.AddChild(howControls);
            c.AddChild(Fz.Title("The cars", 22, Fz.Red));
            c.AddChild(Fz.Text("Each corner has its own spring, damper and tyre, so the body rolls, pitches and squats for real, and grip follows the weight: brake into a corner to load the front tyres and sharpen the turn-in, feed in throttle to shift it back to the rears. The garage's Tuning sets everything a race engineer would: tyre pressures, gearing, camber, toe and caster, springs and ride height, bump and rebound damping (slow and fast), anti-roll bars, roll centres, anti-dive and anti-squat, aero, brakes and the differential. Save the setups you like and load them again. The Paint shop paints the car, puts a livery on it and tints its windows.", 16));
            c.AddChild(Fz.Title("The maps", 22, Fz.Red));
            howMaps = Fz.Text("", 16);
            c.AddChild(howMaps);
        }

        void BuildCredits()
        {
            var c = TextPage(Page.Credits, "Credits");
            c.AddChild(Fz.Title("Rust Bucket Racing", 30));
            c.AddChild(Fz.Text("v" + DebugLog.Version + " alpha · made with Godot", 16, Fz.Dim));
            c.AddChild(Fz.Title("Cars", 22, Fz.Red));
            c.AddChild(Fz.Text("\"Lowpoly Abandoned Simple Car Prop\" by Rashad Ibrahimli (CC BY 4.0)\n\"1987 Chevrolet Monte Carlo SS\" by Randomness (CC BY 4.0)\n\"2004 Cadillac CTS-V race car\" by Dave Love, sketchfab.com/Tyler_Dave (CC BY 4.0)\n\"2000 Honda Civic Type-R\" by OUTPISTON, sketchfab.com/outpiston (CC BY-NC-SA 4.0: free, not for sale)\nSkies: Poly Haven's pure-sky HDRIs, polyhaven.com (CC0)", 16, new Color(0.86f, 0.89f, 0.91f)));
            c.AddChild(Fz.Title("Maps on this phone", 22, Fz.Red));
            creditMaps = Fz.Text("", 16, new Color(0.86f, 0.89f, 0.91f));
            c.AddChild(creditMaps);
        }
    }
}
