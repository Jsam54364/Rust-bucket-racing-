// The front end's Play and Maps pages: free roam (pick a map and a start, then drive), the map library
// (install, update, remove) and the modes still in development.
using System;
using System.Collections.Generic;
using System.Globalization;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed partial class FrontEnd
    {
        /* ---------------- free roam ---------------- */
        Fz.Tile[] mapCards = new Fz.Tile[0];
        string[] mapCardIds = new string[0];
        GridContainer mapGrid;
        Label frCar, frCarSub, frStartNote, frStatus;
        Button[] frStart;
        GridContainer frStartRow;
        Button bDrive;
        string selMap;
        readonly Dictionary<string, int> startPick = new Dictionary<string, int>();

        // one tile per installed map, then one for getting more; a second press on the picked map drives
        void RebuildMapCards()
        {
            if (mapGrid == null) return;
            foreach (var c in mapGrid.GetChildren()) { mapGrid.RemoveChild(c); c.QueueFree(); }
            mapCardIds = Defs.MapOrder;
            mapCards = new Fz.Tile[mapCardIds.Length];
            for (int i = 0; i < mapCardIds.Length; i++)
            {
                var d = Defs.Maps[mapCardIds[i]];
                string id = d.Id;
                var t = new Fz.Tile(d.Name, d.Sub, Pic("map_" + id), () => { if (selMap == id) DriveNow(); else { selMap = id; Sync(); } }, 0, 168) { TitleSize = 24 };
                t.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                mapCards[i] = t;
                mapGrid.AddChild(t.B);
            }
            var more = new Fz.Tile("More maps", "Download maps: new ones arrive without a new version of the game", Pic("map_more"), () => Go(Page.Maps), 0, 168) { Icon = "down", TitleSize = 24 };
            more.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            mapGrid.AddChild(more.B);
            Quiet(mapGrid);
        }

        void BuildFreeRoam()
        {
            var m = Frame(Page.FreeRoam);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(Head(Page.FreeRoam, "Free roam", null, null, Pill("NO RULES  ·  NO CLOCK UNLESS YOU WANT ONE", Fz.Dim)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var gscroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            mapGrid = new GridContainer { Columns = 2, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
            mapGrid.AddThemeConstantOverride("h_separation", 12); mapGrid.AddThemeConstantOverride("v_separation", 12);
            gscroll.AddChild(mapGrid);
            row.AddChild(gscroll);
            RebuildMapCards();
            // the car and how to start, then go
            var side = Fz.Panel(20);
            side.CustomMinimumSize = new Vector2(370, 0);
            row.AddChild(side);
            var sc = Ui.Col(8);
            side.AddChild(sc);
            sc.AddChild(Fz.Caps("Car", 14, Fz.Dim));
            frCar = Fz.Title("", 28); sc.AddChild(frCar);
            frCarSub = Fz.Text("", 16, Fz.Dim); sc.AddChild(frCarSub);
            sc.AddChild(Fz.Btn("Change car  ›", () => Go(Page.Garage), Fz.Look.Plain, 46, 17));
            sc.AddChild(Gap(6));
            sc.AddChild(Fz.Caps("Start", 14, Fz.Dim));
            // up to eight ways in, two to a row (a compound has its paddocks, the drag strip, the slalom pad...)
            frStartRow = new GridContainer { Columns = 2 };
            frStartRow.AddThemeConstantOverride("h_separation", 6); frStartRow.AddThemeConstantOverride("v_separation", 6);
            frStart = new Button[8];
            for (int i = 0; i < frStart.Length; i++)
            {
                int k = i;
                var b = Fz.Btn("", () => { if (selMap != null) startPick[selMap] = k; Sync(); }, Fz.Look.Option, 42, 15);
                b.ToggleMode = true;
                b.ClipText = true;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                frStart[i] = b;
                frStartRow.AddChild(b);
            }
            sc.AddChild(frStartRow);
            frStartNote = Fz.Text("", 14, Fz.Dim);
            sc.AddChild(frStartNote);
            sc.AddChild(Fill());
            frStatus = Fz.Text("", 16, Fz.Red);
            sc.AddChild(frStatus);
            bDrive = Fz.Btn("Drive", DriveNow, Fz.Look.Primary, 70, 34);
            sc.AddChild(bDrive);
            firstFocus[Page.FreeRoam] = () =>
            {
                int i = Array.IndexOf(mapCardIds, selMap);
                return i >= 0 && i < mapCards.Length ? mapCards[i].B : bDrive;
            };
        }

        // the starting grid, then the map's own start points
        static string[] StartsOf(MapDef md)
        {
            var o = new List<string> { "Starting grid" };
            foreach (var s in md.Starts) if (o.Count < 8) o.Add(s);
            return o.ToArray();
        }

        int StartFor(string map)
        {
            if (startPick.TryGetValue(map, out int k)) return k;
            return Defs.Maps[map].Stage ? (g.StageDown ? 1 : 0) : 0;
        }

        void DriveNow()
        {
            if (g.Busy || selMap == null) return;
            bDrive.Text = "LOADING…"; bDrive.Disabled = true; frStatus.Text = "";
            g.StartFreeRoam(selMap, StartFor(selMap));
        }

        // the map didn't load (a missing pack, or an error): say so and stay on the page
        public void DriveFailed(string msg)
        {
            bDrive.Text = "DRIVE"; bDrive.Disabled = false;
            frStatus.Text = msg;
        }

        void SyncFreeRoam()
        {
            if (selMap == null || !Defs.Maps.ContainsKey(selMap) || Array.IndexOf(Defs.MapOrder, selMap) < 0)
            {
                // the map last driven, if this build has it
                selMap = g.Store.Str("map", g.MapId);
                if (!Defs.Maps.ContainsKey(selMap) || (selMap != "grid" && !FileAccess.FileExists(Defs.Maps[selMap].Pack))) selMap = g.MapId;
            }
            for (int i = 0; i < mapCards.Length; i++)
            {
                bool on = mapCardIds[i] == selMap;
                if (mapCards[i].Selected != on || mapCards[i].Badge != (on ? "SELECTED" : ""))
                {
                    mapCards[i].Selected = on; mapCards[i].Badge = on ? "SELECTED" : ""; mapCards[i].BadgeColor = Fz.Ink; mapCards[i].Redraw();
                }
            }
            var cd = Defs.Cars[g.CarId];
            frCar.Text = cd.Title.ToUpperInvariant(); frCarSub.Text = cd.Sub;
            var md = Defs.Maps[selMap];
            bool stage = md.Stage;
            string[] opts = selMap == "grid" ? new[] { "Test areas", "Race track" } : stage ? new[] { "Uphill", "Downhill" } : StartsOf(md);
            for (int i = 0; i < frStart.Length; i++)
            {
                frStart[i].Visible = i < opts.Length;
                if (i < opts.Length) frStart[i].Text = opts[i].ToUpperInvariant();
            }
            int sp = Math.Min(StartFor(selMap), opts.Length - 1);
            for (int i = 0; i < frStart.Length; i++) frStart[i].SetPressedNoSignal(i == sp);
            frStartNote.Text = selMap == "grid"
                ? (sp == 0 ? "On the runway, with every test area around you." : "On pole on the race track grid: the lap timer starts at the line.")
                : stage ? (sp == 0 ? "From the bottom: the clock starts at " + md.BottomLine + "." : "From the top: the clock starts at " + md.TopLine + ".")
                : sp > 0 ? "At " + opts[sp].ToLowerInvariant() + (md.Starts.Length > 1 ? ". Every timed course starts its clock at its own line." : ".")
                : "On the grid on the main straight: the lap timer starts at the line.";
            if (!g.Busy && page != Page.None) { bDrive.Text = "DRIVE"; bDrive.Disabled = false; }
        }

        /* ---------------- maps: the library ---------------- */
        VBoxContainer mapRows;
        Label mStatus;
        Button bCheck;
        string removeArmed;   // a first tap on Remove arms it; the second removes
        sealed class MapRow { public MapDef Def; public Label Status; public ColorRect Fill; public Control Track; public Button Main, Remove; }
        readonly List<MapRow> rows = new List<MapRow>();

        void BuildMaps()
        {
            var m = Frame(Page.Maps);
            var col = Ui.Col(12);
            m.AddChild(col);
            bCheck = Fz.Btn("Check again", () => g.Library.Refresh(), Fz.Look.Plain, 44, 16);
            col.AddChild(Head(Page.Maps, "Maps", null, null, bCheck));
            mStatus = Fz.Text("", 16, Fz.Body);
            col.AddChild(mStatus);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            mapRows = Ui.Col(10);
            mapRows.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(mapRows);
            col.AddChild(scroll);
            firstFocus[Page.Maps] = () => rows.Count > 0 ? rows[0].Main : bCheck;
        }

        static string Mb(long bytes) => (bytes / 1048576.0).ToString("F1", CultureInfo.InvariantCulture) + " MB";

        // a row per map on offer, and per installed map that isn't on offer any more
        void RebuildMapRows()
        {
            if (mapRows == null) return;
            foreach (var c in mapRows.GetChildren()) { mapRows.RemoveChild(c); c.QueueFree(); }
            rows.Clear();
            var lib = g.Library;
            var list = new List<MapDef>(lib.Catalogue);
            foreach (var id in Defs.MapOrder)
                if (id != "grid" && !list.Exists((x) => x.Id == id)) list.Add(Defs.Maps[id]);
            if (list.Count == 0)
            {
                mapRows.AddChild(Fz.Text(lib.Fetching ? "Looking for maps…" : "No maps to show yet. Maps appear here once they are published from the repo (RustBucketRacing-Maps-<name>.zip files) and this phone can reach GitHub.", 17, Fz.Dim));
                return;
            }
            foreach (var d in list)
            {
                var r = new MapRow { Def = d };
                var card = Fz.Panel(0, 0.86f);
                var h = Ui.Row(18);
                card.AddChild(h);
                var pic = new TextureRect { Texture = Pic("map_" + d.Id), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCovered, CustomMinimumSize = new Vector2(230, 140), ClipContents = true, MouseFilter = Control.MouseFilterEnum.Ignore };
                h.AddChild(pic);
                var left = Ui.Col(3);
                left.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                left.AddChild(Gap(8));
                left.AddChild(Fz.Title(d.Name, 26));
                if (d.Sub.Length > 0) left.AddChild(Fz.Caps(d.Sub, 15, Fz.Red));
                if (d.Blurb.Length > 0) left.AddChild(Fz.Text(d.Blurb, 14, Fz.Body));
                if (d.Credit.Length > 0) left.AddChild(Fz.Text(d.Credit, 13, Fz.Dim));
                left.AddChild(Gap(6));
                h.AddChild(left);
                var right = Ui.Col(6);
                right.CustomMinimumSize = new Vector2(270, 0);
                right.Alignment = BoxContainer.AlignmentMode.Center;
                r.Status = Fz.Text("", 15, Fz.Dim);
                r.Status.HorizontalAlignment = HorizontalAlignment.Right;
                right.AddChild(r.Status);
                r.Track = new ColorRect { Color = new Color(1, 1, 1, 0.12f), CustomMinimumSize = new Vector2(0, 6), MouseFilter = Control.MouseFilterEnum.Ignore };
                r.Fill = new ColorRect { Color = Fz.Red, MouseFilter = Control.MouseFilterEnum.Ignore, AnchorBottom = 1, AnchorRight = 0 };
                r.Track.AddChild(r.Fill);
                right.AddChild(r.Track);
                var btns = Ui.Row(8);
                var dd = d;
                r.Main = Fz.Btn("Install", () => MapAction(dd), Fz.Look.Primary, 50, 20);
                r.Main.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                r.Remove = Fz.Btn("Remove", () => RemoveMap(dd.Id), Fz.Look.Plain, 50, 15);
                btns.AddChild(r.Main); btns.AddChild(r.Remove);
                right.AddChild(btns);
                var pad = Ui.Pad(right, 0, 0, 18, 0);
                pad.SizeFlagsHorizontal = Control.SizeFlags.ShrinkEnd;
                h.AddChild(pad);
                mapRows.AddChild(card);
                rows.Add(r);
            }
            Quiet(mapRows);
            UpdateMapRows();
        }

        // the main button: install, update, cancel a download, or drive an installed map
        void MapAction(MapDef d)
        {
            var lib = g.Library;
            removeArmed = null;
            if (lib.IsDownloading(d.Id)) { lib.Cancel(d.Id); return; }
            var cat = lib.Catalogue.Find((x) => x.Id == d.Id);
            if (lib.IsInstalled(d.Id) && (cat == null || !lib.UpdateAvailable(cat))) { selMap = d.Id; Go(Page.FreeRoam); return; }
            if (cat != null) lib.Install(cat);
        }

        void RemoveMap(string id)
        {
            if (removeArmed != id) { removeArmed = id; UpdateMapRows(); return; }
            removeArmed = null;
            if (!g.Library.Remove(id)) mStatus.Text = "Couldn't remove it right now: try again in a moment";
        }

        void UpdateMapRows()
        {
            var lib = g.Library;
            mStatus.Text = lib.Status + (lib.AnyDownloading ? "  ·  downloading" : "");
            bCheck.Disabled = lib.Fetching;
            foreach (var r in rows)
            {
                var d = r.Def;
                var cat = lib.Catalogue.Find((x) => x.Id == d.Id);
                bool inst = lib.IsInstalled(d.Id), dl = lib.IsDownloading(d.Id);
                bool upd = cat != null && lib.UpdateAvailable(cat);
                long size = cat != null && cat.Bytes > 0 ? cat.Bytes : inst ? Defs.Maps[d.Id].Bytes : 0;
                string err = lib.Error(d.Id);
                r.Track.Visible = dl;
                r.Fill.AnchorRight = (float)lib.Progress(d.Id);
                r.Remove.Visible = inst && !dl;
                r.Remove.Text = removeArmed == d.Id ? "SURE?" : "REMOVE";
                r.Remove.Disabled = g.Busy;
                r.Status.AddThemeColorOverride("font_color", err != null ? Fz.Red : upd ? Fz.Ink : Fz.Dim);
                if (dl)
                {
                    r.Status.Text = $"Downloading  {Math.Round(lib.Progress(d.Id) * 100)} %  of {Mb(size)}";
                    r.Main.Text = "CANCEL"; r.Main.Disabled = false;
                }
                else if (cat != null && MapLibrary.TooNew(cat) && !inst)
                {
                    r.Status.Text = "Needs a newer version of the game";
                    r.Main.Text = "INSTALL"; r.Main.Disabled = true;
                }
                else if (inst)
                {
                    r.Status.Text = err ?? (upd ? "Update available  ·  " + Mb(size) : "Installed  ·  " + Mb(size));
                    r.Main.Text = upd ? "UPDATE" : "DRIVE  ›"; r.Main.Disabled = upd && g.Busy;
                }
                else
                {
                    r.Status.Text = err ?? Mb(size) + " download";
                    r.Main.Text = err != null ? "TRY AGAIN" : "INSTALL"; r.Main.Disabled = cat == null;
                }
            }
        }

        /* ---------------- modes in development ---------------- */
        Label bestList;

        void BuildLocked(Page p, string title, string line, string text, string[] planned)
        {
            var m = Frame(p);
            var col = Ui.Col(14);
            m.AddChild(col);
            col.AddChild(Head(p, title, null, null, Pill("IN DEVELOPMENT", Fz.Red)));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var card = Fz.Panel(0);
            card.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            row.AddChild(card);
            var cc = Ui.Col(0);
            card.AddChild(cc);
            string picName = p == Page.TimeTrial ? "play_timetrial" : p == Page.Career ? "play_career" : "play_online";
            var banner = new TextureRect { Texture = Pic(picName), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCovered, CustomMinimumSize = new Vector2(0, 170), ClipContents = true, MouseFilter = Control.MouseFilterEnum.Ignore };
            cc.AddChild(banner);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            cc.AddChild(scroll);
            var c = Ui.Col(10);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(c, 24, 16, 24, 18));
            c.AddChild(Fz.Title(line, 28));
            c.AddChild(Fz.Text(text, 17));
            if (p == Page.TimeTrial)
            {
                c.AddChild(Gap(4));
                c.AddChild(Fz.Caps("Your best times so far", 14, Fz.Dim));
                bestList = Fz.Text("", 16, Fz.Ink);
                c.AddChild(bestList);
            }
            c.AddChild(Gap(6));
            var drive = Fz.Btn("Drive in free roam  ›", () => Go(Page.FreeRoam), Fz.Look.Primary, 54, 20, 320);
            drive.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            c.AddChild(drive);
            // what it will have
            var plan = Fz.Panel(22);
            plan.CustomMinimumSize = new Vector2(380, 0);
            row.AddChild(plan);
            var pc = Ui.Col(8);
            plan.AddChild(pc);
            pc.AddChild(Fz.Caps("Planned", 14, Fz.Dim));
            foreach (var s in planned)
            {
                var slot = new PanelContainer();
                var sb = Fz.Box(new Color(1, 1, 1, 0.04f), null, 0, 10, true);
                slot.AddThemeStyleboxOverride("panel", sb);
                slot.AddChild(Fz.Text(s, 16, Fz.Body));
                pc.AddChild(slot);
            }
            firstFocus[p] = () => drive;
        }

        void FillBests()
        {
            if (bestList == null) return;
            var lines = new List<string>();
            foreach (var mid in Defs.MapOrder)
                foreach (var cid in Defs.CarOrder)
                    foreach (var (suffix, what) in new[] { ("", "lap"), ("_up", "uphill"), ("_down", "downhill") })
                    {
                        double t = g.Store.Best(mid + "_" + cid + suffix);
                        if (!double.IsNaN(t)) lines.Add($"{Defs.Maps[mid].Name} {what}  ·  {Defs.Cars[cid].Title}  ·  {LapTimer.Fmt(t, 3)}");
                    }
            bestList.Text = lines.Count > 0 ? string.Join("\n", lines) : "None yet. Laps of the circuits and runs of the stages in Free Roam are timed and the best are kept.";
        }
    }
}
