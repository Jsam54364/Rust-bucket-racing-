// Everything remembered between sessions (user://settings.cfg): car, map, per-car setups and saved setups, each
// car's paint, controls, best laps.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class Settings
    {
        const string PATH = "user://settings.cfg";
        public const int MaxSetups = 24;
        readonly ConfigFile cfg = new ConfigFile();
        bool dirty;
        double saveT;

        public Settings()
        {
            if (FileAccess.FileExists(PATH)) cfg.Load(PATH);
        }

        public string Str(string key, string def) => cfg.GetValue("game", key, def).AsString();
        public bool Bool(string key, bool def) => cfg.GetValue("game", key, def).AsBool();
        public double Num(string key, double def) => cfg.GetValue("game", key, def).AsDouble();
        public void Set(string key, Variant v) { cfg.SetValue("game", key, v); dirty = true; }

        public bool HasBest(string key) => cfg.HasSectionKey("best", key);
        public double Best(string key) => HasBest(key) ? cfg.GetValue("best", key, 0.0).AsDouble() : double.NaN;
        public void SetBest(string key, double t) { cfg.SetValue("best", key, t); Save(); }

        static double ScaleOf(string carId) => Defs.Cars.TryGetValue(carId, out var cd) ? cd.Spec.GeomScale : 1.0;

        /* ---------------- setups ---------------- */
        // a setup from a section; missing keys fall back to the car's defaults (older saves had fewer)
        Tune ReadTune(string s, CarSpec spec, bool driver)
        {
            var d = spec.DefaultTune;
            var t = d.Clone();
            if (!cfg.HasSection(s)) return t;
            foreach (var n in Tune.Numbers)
            {
                if (!driver && Tune.DriverKey(n.Key)) continue;
                if (cfg.HasSectionKey(s, n.Key)) n.Set(t, cfg.GetValue(s, n.Key, n.Get(d)).AsDouble());
            }
            // from before the bump and rebound were set apart, and before each axle had its own roll centre
            if (!cfg.HasSectionKey(s, "reboundF") && cfg.HasSectionKey(s, "dampF"))
            {
                double rr = cfg.GetValue(s, "reboundRatio", Tune.FactoryRebound).AsDouble();
                t.ReboundF = t.DampF * rr; t.ReboundR = t.DampR * rr;
                t.FastBumpF = t.DampF; t.FastBumpR = t.DampR; t.FastReboundF = t.ReboundF; t.FastReboundR = t.ReboundR;
            }
            if (!cfg.HasSectionKey(s, "rollCenterF") && cfg.HasSectionKey(s, "rollCenter"))
                t.RollCenterF = t.RollCenterR = cfg.GetValue(s, "rollCenter", d.RollCenterF).AsDouble();
            // gearing: as many gears as the car has
            int ng = spec.Gears.Length;
            t.Gears = new double[ng];
            for (int i = 0; i < ng; i++) t.Gears[i] = cfg.GetValue(s, "gear" + (i + 1), d.Gear(i)).AsDouble();
            // saved before the car was rescaled: lengths follow the new size
            double was = cfg.GetValue(s, "geomScale", 1.0).AsDouble();
            if (was > 0 && Math.Abs(was - spec.GeomScale) > 1e-6)
            {
                double k = spec.GeomScale / was;
                foreach (var n in Tune.Numbers) if (n.Length && cfg.HasSectionKey(s, n.Key)) n.Set(t, n.Get(t) * k);
                if (!cfg.HasSectionKey(s, "rollCenterF") && cfg.HasSectionKey(s, "rollCenter")) { t.RollCenterF *= k; t.RollCenterR *= k; }
                cfg.SetValue(s, "geomScale", spec.GeomScale); dirty = true;
            }
            t.Abs = cfg.GetValue(s, "abs", d.Abs).AsBool(); t.Tcs = cfg.GetValue(s, "tcs", d.Tcs).AsBool();
            if (Enum.TryParse<Drive>(cfg.GetValue(s, "drive", d.Drive.ToString()).AsString(), out var dr)) t.Drive = dr;
            if (driver && Enum.TryParse<Gearbox>(cfg.GetValue(s, "gearbox", d.Gearbox.ToString()).AsString(), out var gb)) t.Gearbox = gb;
            return t;
        }

        void WriteTune(string s, string carId, Tune t, bool driver)
        {
            foreach (var n in Tune.Numbers)
                if (driver || !Tune.DriverKey(n.Key)) cfg.SetValue(s, n.Key, n.Get(t));
            if (t.Gears != null) for (int i = 0; i < t.Gears.Length; i++) cfg.SetValue(s, "gear" + (i + 1), t.Gears[i]);
            cfg.SetValue(s, "geomScale", ScaleOf(carId));
            cfg.SetValue(s, "abs", t.Abs); cfg.SetValue(s, "tcs", t.Tcs);
            cfg.SetValue(s, "drive", t.Drive.ToString());
            if (driver) cfg.SetValue(s, "gearbox", t.Gearbox.ToString());
            dirty = true;
        }

        // the car's setup now
        public Tune LoadTune(CarSpec spec) => ReadTune("tune_" + spec.Id, spec, true);
        public void SaveTune(string carId, Tune t) => WriteTune("tune_" + carId, carId, t, true);

        // saved setups: named, up to MaxSetups per car, in slots that keep their number
        static string SetupSection(string carId, int slot) => "setup_" + carId + "_" + slot;

        public List<(int slot, string name)> Setups(string carId)
        {
            var o = new List<(int, string)>();
            for (int i = 0; i < MaxSetups; i++)
            {
                string s = SetupSection(carId, i);
                if (cfg.HasSection(s)) o.Add((i, cfg.GetValue(s, "name", "Setup " + (i + 1)).AsString()));
            }
            return o;
        }

        public int FreeSetupSlot(string carId)
        {
            for (int i = 0; i < MaxSetups; i++) if (!cfg.HasSection(SetupSection(carId, i))) return i;
            return -1;
        }

        public void SaveSetup(string carId, int slot, string name, Tune t)
        {
            string s = SetupSection(carId, slot);
            if (cfg.HasSection(s)) cfg.EraseSection(s);
            cfg.SetValue(s, "name", name);
            WriteTune(s, carId, t, false);
            Save();
        }

        public Tune LoadSetup(CarSpec spec, int slot) => ReadTune(SetupSection(spec.Id, slot), spec, false);

        public void RenameSetup(string carId, int slot, string name)
        {
            string s = SetupSection(carId, slot);
            if (cfg.HasSection(s)) { cfg.SetValue(s, "name", name); Save(); }
        }

        public void DeleteSetup(string carId, int slot)
        {
            string s = SetupSection(carId, slot);
            if (cfg.HasSection(s)) { cfg.EraseSection(s); Save(); }
        }

        /* ---------------- paint, windows and livery ---------------- */
        public CarLook LoadLook(string carId)
        {
            string s = "look_" + carId;
            var k = new CarLook();
            if (!cfg.HasSection(s)) return k;
            k.Custom = cfg.GetValue(s, "custom", false).AsBool();
            k.Paint = Color.FromHtml(cfg.GetValue(s, "paint", k.Paint.ToHtml(false)).AsString());
            k.Paint2 = Color.FromHtml(cfg.GetValue(s, "paint2", k.Paint2.ToHtml(false)).AsString());
            k.Finish = Math.Clamp(cfg.GetValue(s, "finish", k.Finish).AsInt32(), 0, CarLook.FinishNames.Length - 1);
            k.Tint = Math.Clamp(cfg.GetValue(s, "tint", k.Tint).AsInt32(), 0, CarLook.TintNames.Length - 1);
            k.Livery = Math.Clamp(cfg.GetValue(s, "livery", k.Livery).AsInt32(), 0, CarLook.LiveryNames.Length - 1);
            return k;
        }

        public void SaveLook(string carId, CarLook k)
        {
            string s = "look_" + carId;
            cfg.SetValue(s, "custom", k.Custom);
            cfg.SetValue(s, "paint", k.Paint.ToHtml(false)); cfg.SetValue(s, "paint2", k.Paint2.ToHtml(false));
            cfg.SetValue(s, "finish", k.Finish); cfg.SetValue(s, "tint", k.Tint); cfg.SetValue(s, "livery", k.Livery);
            dirty = true;
        }

        // slider drags change things every frame: write at most twice a second
        public void Tick(double dt)
        {
            saveT += dt;
            if (dirty && saveT > 0.5) Save();
        }

        public void Save()
        {
            dirty = false; saveT = 0;
            cfg.Save(PATH);
        }
    }
}
