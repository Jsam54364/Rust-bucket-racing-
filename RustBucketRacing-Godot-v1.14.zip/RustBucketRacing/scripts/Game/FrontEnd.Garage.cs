// The front end's garage: your cars (pick one, see its figures) and the paint shop (colour and finish, livery,
// window tint), with the car on the turntable behind.
using System;
using System.Collections.Generic;
using System.Globalization;
using Godot;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed partial class FrontEnd
    {
        /* ---------------- my cars ---------------- */
        string inspect;
        bool autoSpin = true;
        Fz.Tile[] carCards;
        Label gName, gSub, gLoading, gBest;
        readonly List<(Label key, Label val)> gRows = new List<(Label, Label)>();
        readonly ColorRect[] gBar = new ColorRect[3];
        readonly Label[] gBarVal = new Label[3];
        Button bSelect, bSpin;
        static readonly string[] RowKeys = { "Power", "Torque", "Weight", "Drive", "Gearbox", "Redline", "Size", "Wheelbase" };

        void BuildGarage()
        {
            var m = Frame(Page.Garage);
            var col = Ui.Col(12);
            m.AddChild(col);
            col.AddChild(Head(Page.Garage, "My cars"));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            // cars
            var list = Ui.Col(10);
            list.CustomMinimumSize = new Vector2(300, 0);
            row.AddChild(list);
            carCards = new Fz.Tile[Defs.CarOrder.Length];
            for (int i = 0; i < Defs.CarOrder.Length; i++)
            {
                var d = Defs.Cars[Defs.CarOrder[i]];
                string id = d.Id;
                var t = new Fz.Tile(d.Title, d.Sub, Pic("car_" + id), () => { if (inspect == id && id != g.CarId) Choose(); else Inspect(id, false); }, 0, 92) { TitleSize = 22 };
                t.B.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
                carCards[i] = t;
                list.AddChild(t.B);
            }
            gLoading = Fz.Text("", 15, Fz.Red, false);
            list.AddChild(gLoading);
            var ctl = Ui.Row(8);
            bSpin = Fz.Btn("Auto spin", () => { autoSpin = !autoSpin; Room.AutoSpin = autoSpin; Sync(); }, Fz.Look.Option, 44, 15);
            bSpin.ToggleMode = true;
            bSpin.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            var rv = Fz.Btn("Reset view", () => Room.ResetView(), Fz.Look.Plain, 44, 15);
            rv.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            ctl.AddChild(bSpin); ctl.AddChild(rv);
            list.AddChild(ctl);
            row.AddChild(Fill(false));
            // figures
            var side = Fz.Panel(20, 0.84f);
            side.CustomMinimumSize = new Vector2(350, 0);
            row.AddChild(side);
            var sc = Ui.Col(6);
            side.AddChild(sc);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            var body = Ui.Col(6);
            body.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(body);
            sc.AddChild(scroll);
            gName = Fz.Title("", 28); body.AddChild(gName);
            gSub = Fz.Text("", 15, Fz.Dim); body.AddChild(gSub);
            body.AddChild(Gap(4));
            string[] bars = { "Power", "Torque", "Power to weight" };
            for (int i = 0; i < 3; i++) body.AddChild(Bar(bars[i], out gBar[i], out gBarVal[i]));
            body.AddChild(Gap(4));
            var grid = new GridContainer { Columns = 2 };
            grid.AddThemeConstantOverride("h_separation", 14); grid.AddThemeConstantOverride("v_separation", 3);
            foreach (var k in RowKeys)
            {
                var kl = Fz.Caps(k, 14, Fz.Dim);
                var vl = Fz.Text("", 15, Fz.Ink, false);
                vl.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                grid.AddChild(kl); grid.AddChild(vl);
                gRows.Add((kl, vl));
            }
            body.AddChild(grid);
            body.AddChild(Gap(4));
            body.AddChild(Fz.Caps("Best times", 14, Fz.Dim));
            gBest = Fz.Text("", 14, Fz.Body);
            body.AddChild(gBest);
            bSelect = Fz.Btn("Select", Choose, Fz.Look.Primary, 60, 26);
            sc.AddChild(bSelect);
            var more = Ui.Row(8);
            var bp = Fz.Btn("Paint shop", () => { Choose(); Go(Page.Paint); }, Fz.Look.Plain, 44, 15);
            var bt = Fz.Btn("Tuning", () => { Choose(); OpenTuningTab(tuneTab); }, Fz.Look.Plain, 44, 15);
            bp.SizeFlagsHorizontal = bt.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            more.AddChild(bp); more.AddChild(bt);
            sc.AddChild(more);
            firstFocus[Page.Garage] = () => { int i = Array.IndexOf(Defs.CarOrder, inspect ?? g.CarId); return i >= 0 ? carCards[i].B : null; };
        }

        void Choose()
        {
            if (inspect != null && inspect != g.CarId) { g.SwitchCar(inspect); Sync(); }
        }

        static Control Bar(string label, out ColorRect fill, out Label val)
        {
            var c = Ui.Col(3);
            var h = Ui.Row();
            var l = Fz.Caps(label, 14, Fz.Dim);
            l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            val = Fz.Caps("", 14, Fz.Ink);
            h.AddChild(l); h.AddChild(val);
            c.AddChild(h);
            var track = new ColorRect { Color = new Color(1, 1, 1, 0.1f), CustomMinimumSize = new Vector2(0, 6), MouseFilter = Control.MouseFilterEnum.Ignore };
            fill = new ColorRect { Color = Fz.Red, MouseFilter = Control.MouseFilterEnum.Ignore };
            fill.AnchorLeft = 0; fill.AnchorTop = 0; fill.AnchorBottom = 1; fill.AnchorRight = 0.5f;
            fill.OffsetLeft = 0; fill.OffsetTop = 0; fill.OffsetRight = 0; fill.OffsetBottom = 0;
            track.AddChild(fill);
            c.AddChild(track);
            return c;
        }

        // peak power (hp, rpm) and torque (Nm, rpm) along the full-throttle curve, up to the limiter
        public static (double hp, double hpRpm, double nm, double nmRpm) Peaks(CarSpec s)
        {
            double hp = 0, hpR = 0, nm = 0, nmR = 0;
            var c = s.Curve;
            for (double r = c[0][0]; r <= Math.Min(s.Limiter, c[c.Length - 1][0]); r += 25)
            {
                double t = c[c.Length - 1][1];
                for (int i = 0; i + 1 < c.Length; i++)
                    if (r <= c[i + 1][0]) { t = c[i][1] + (c[i + 1][1] - c[i][1]) * (r - c[i][0]) / (c[i + 1][0] - c[i][0]); break; }
                double p = t * r * Math.PI / 30 / 745.7;
                if (p > hp) { hp = p; hpR = r; }
                if (t > nm) { nm = t; nmR = r; }
            }
            return (hp, hpR, nm, nmR);
        }

        static string Rpm(double r) => (Math.Round(r / 100) * 100).ToString("F0", CultureInfo.InvariantCulture);

        async void Inspect(string id, bool quietly)
        {
            inspect = id;
            Sync();
            if (page != Page.Garage) return;
            if (!g.HasCarView(id))
            {
                gLoading.Text = "Loading the car…";
                await Root.ToSignal(Root.GetTree(), SceneTree.SignalName.ProcessFrame);
                await Root.ToSignal(Root.GetTree(), SceneTree.SignalName.ProcessFrame);
                if (inspect != id || page != Page.Garage) return;
            }
            try { Room.Show(id); }
            catch (Exception e) { GD.PushError("garage: " + e.Message); }
            gLoading.Text = "";
        }

        void SyncGarage()
        {
            string id = inspect ?? g.CarId;
            if (id == null || !Defs.Cars.ContainsKey(id)) return;
            var d = Defs.Cars[id];
            var s = d.Spec;
            for (int i = 0; i < carCards.Length; i++)
            {
                string cid = Defs.CarOrder[i];
                bool look = cid == id, driving = cid == g.CarId;
                string badge = driving ? "DRIVING" : "";
                if (carCards[i].Selected != look || carCards[i].Badge != badge) { carCards[i].Selected = look; carCards[i].Badge = badge; carCards[i].BadgeColor = Fz.Ink; carCards[i].Redraw(); }
            }
            gName.Text = d.Title.ToUpperInvariant();
            gSub.Text = d.Sub + (id == g.CarId ? "  ·  driving" : "");
            var pk = Peaks(s);
            double maxHp = 0, maxNm = 0, maxPw = 0;
            foreach (var cid in Defs.CarOrder)
            {
                var o = Defs.Cars[cid].Spec; var q = Peaks(o);
                maxHp = Math.Max(maxHp, q.hp); maxNm = Math.Max(maxNm, q.nm); maxPw = Math.Max(maxPw, q.hp / o.Mass * 1000);
            }
            double pw = pk.hp / s.Mass * 1000;
            double[] frac = { pk.hp / maxHp, pk.nm / maxNm, pw / maxPw };
            string[] vals = { F(pk.hp, 0) + " hp", F(pk.nm, 0) + " Nm", F(pw, 0) + " hp/t" };
            for (int i = 0; i < 3; i++) { gBar[i].AnchorRight = (float)Math.Clamp(frac[i], 0.04, 1); gBarVal[i].Text = vals[i]; }
            var drive = s.DefaultTune.Drive;
            string[] rws =
            {
                $"{F(pk.hp, 0)} hp ({F(pk.hp * 0.7457, 0)} kW) at {Rpm(pk.hpRpm)} rpm",
                $"{F(pk.nm, 0)} Nm at {Rpm(pk.nmRpm)} rpm",
                $"{F(s.Mass, 0)} kg",
                drive == Drive.RWD ? "Rear-wheel drive" : drive == Drive.FWD ? "Front-wheel drive" : "All-wheel drive",
                $"{s.Gears.Length}-speed",
                $"{F(s.Redline, 0)} rpm",
                $"{F(s.HullMaxZ - s.HullMinZ, 2)} × {F(s.HullMaxX - s.HullMinX, 2)} × {F(s.HullMaxY, 2)} m",
                $"{F(Math.Abs(s.Hubs[2].Z - s.Hubs[0].Z), 2)} m",
            };
            for (int i = 0; i < gRows.Count; i++) gRows[i].val.Text = rws[i];
            // best times with this car, from free roam
            var lines = new List<string>();
            foreach (var mid in Defs.MapOrder)
            {
                var md = Defs.Maps[mid];
                foreach (var (suffix, what) in new[] { ("", "lap"), ("_up", "uphill"), ("_down", "downhill") })
                {
                    double t = g.Store.Best(mid + "_" + id + suffix);
                    if (!double.IsNaN(t)) lines.Add($"{md.Short} {what}: {LapTimer.Fmt(t, 3)}");
                }
            }
            gBest.Text = lines.Count > 0 ? string.Join("\n", lines) : "None yet: set some in Free Roam.";
            bool current = id == g.CarId;
            bSelect.Text = current ? "DRIVING THIS ONE" : "SELECT";
            bSelect.Disabled = current || g.Busy;
            bSpin.SetPressedNoSignal(autoSpin);
            bSpin.Text = "AUTO SPIN";
        }

        // turning the car: one finger or the mouse turns the platform and tilts the view; two fingers zoom
        readonly Dictionary<int, Vector2> touches = new Dictionary<int, Vector2>();
        float pinch;
        bool mouseDown;

        void OnDrag(InputEvent e)
        {
            if (e is InputEventMouseButton mb && mb.Device != -1)
            {
                if (mb.ButtonIndex == MouseButton.Left) mouseDown = mb.Pressed;
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelUp) Room.Zoom(Math.Exp(-0.1));
                else if (mb.Pressed && mb.ButtonIndex == MouseButton.WheelDown) Room.Zoom(Math.Exp(0.1));
            }
            else if (e is InputEventMouseMotion mm && mm.Device != -1)
            {
                if (mouseDown) Room.Turn(mm.Relative.X * 0.0065, mm.Relative.Y * 0.004);
            }
            else if (e is InputEventScreenTouch st)
            {
                if (st.Pressed) touches[st.Index] = st.Position; else touches.Remove(st.Index);
                pinch = touches.Count == 2 ? Spread() : 0;
            }
            else if (e is InputEventScreenDrag sd)
            {
                touches[sd.Index] = sd.Position;
                if (touches.Count >= 2)
                {
                    float d = Spread();
                    if (pinch > 0 && d > 0) Room.Zoom(pinch / d);
                    pinch = d;
                }
                else Room.Turn(sd.Relative.X * 0.0065, sd.Relative.Y * 0.004);
            }
        }

        float Spread()
        {
            var it = touches.Values.GetEnumerator();
            it.MoveNext(); var a = it.Current; it.MoveNext(); var b = it.Current;
            return a.DistanceTo(b);
        }

        // for the self-test: turn the platform as a drag would
        public void TestTurn(double dx, double dy) => Room.Turn(dx, dy);
        public void TestInspect(string id) => Inspect(id, false);

        /* ---------------- the paint shop ---------------- */
        static readonly string[] PaintTabs = { "Paint", "Livery", "Windows" };
        // sRGB: whites and greys, reds, oranges and yellows, greens, blues, purples and pinks
        static readonly Color[] Palette =
        {
            Ui.Hex(0xf2f2ee), Ui.Hex(0xc9cbcd), Ui.Hex(0x8b8f94), Ui.Hex(0x4a4e54), Ui.Hex(0x1d1f22), Ui.Hex(0x080808),
            Ui.Hex(0xd1191c), Ui.Hex(0x9e0e16), Ui.Hex(0x5c0b10), Ui.Hex(0xf0561d), Ui.Hex(0xff9a1f), Ui.Hex(0xf4d01c),
            Ui.Hex(0xc8e02a), Ui.Hex(0x3fae49), Ui.Hex(0x0f6b3b), Ui.Hex(0x1c3d2a), Ui.Hex(0x2bc4c9), Ui.Hex(0x1f7fd8),
            Ui.Hex(0x1f3fa8), Ui.Hex(0x0e1a4a), Ui.Hex(0x6a3bc4), Ui.Hex(0x4a1a5c), Ui.Hex(0xe0408a), Ui.Hex(0xb08d57),
        };
        static readonly Color[] Palette2 =
        {
            Ui.Hex(0xf2f2ee), Ui.Hex(0x080808), Ui.Hex(0x8b8f94), Ui.Hex(0xd1191c), Ui.Hex(0xff9a1f), Ui.Hex(0xf4d01c),
            Ui.Hex(0x3fae49), Ui.Hex(0x2bc4c9), Ui.Hex(0x1f7fd8), Ui.Hex(0x1f3fa8), Ui.Hex(0x6a3bc4), Ui.Hex(0xe0408a),
        };
        readonly Control[] paintPanels = new Control[3];
        readonly List<(Fz.Tile t, Color c)> swatches = new List<(Fz.Tile, Color)>(), swatches2 = new List<(Fz.Tile, Color)>();
        Fz.Tabs finishOpts, tintOpts;
        Button bFactoryPaint;
        Button[] liveryBtns;
        Ui.SliderRow hueS, satS, valS;
        Label paintCar, tintNote, liveryNote;
        int paintTab;
        bool paintSyncing;

        void BuildPaint()
        {
            var m = Frame(Page.Paint);
            var col = Ui.Col(12);
            m.AddChild(col);
            paintCar = Fz.Caps("", 17, Fz.Body);
            col.AddChild(Head(Page.Paint, "Paint shop", PaintTabs, (i) => { paintTab = i; ShowPaintTab(); }, paintCar));
            var row = Ui.Row(16);
            row.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            col.AddChild(row);
            var panel = Fz.Panel(0, 0.86f);
            panel.CustomMinimumSize = new Vector2(500, 0);
            row.AddChild(panel);
            row.AddChild(Fill(false));
            var host = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
            panel.AddChild(host);

            // paint: the palette, a colour of your own, the finish
            var p = PaintPanel(host, 0);
            p.AddChild(Fz.Caps("Colour", 14, Fz.Dim));
            bFactoryPaint = Fz.Btn("Factory colour", () => EditLook((k) => k.Custom = false), Fz.Look.Option, 40, 15);
            bFactoryPaint.ToggleMode = true;
            p.AddChild(bFactoryPaint);
            p.AddChild(SwatchGrid(Palette, swatches, (c) => EditLook((k) => { k.Custom = true; k.Paint = c; })));
            p.AddChild(Gap(4));
            p.AddChild(Fz.Caps("Mix your own", 14, Fz.Dim));
            hueS = Fz.Slider("Hue", 0, 360, 1, (v) => F(v, 0) + "°", (v) => MixPaint(), "", "");
            satS = Fz.Slider("Saturation", 0, 100, 1, (v) => F(v, 0) + " %", (v) => MixPaint(), "Grey", "Vivid");
            valS = Fz.Slider("Brightness", 0, 100, 1, (v) => F(v, 0) + " %", (v) => MixPaint(), "Dark", "Bright");
            p.AddChild(hueS.Root); p.AddChild(satS.Root); p.AddChild(valS.Root);
            p.AddChild(Gap(4));
            p.AddChild(Fz.Caps("Finish", 14, Fz.Dim));
            finishOpts = Fz.Options(CarLook.FinishNames, (i) => EditLook((k) => k.Finish = i), 40);
            p.AddChild(finishOpts.Root);

            // livery
            var l = PaintPanel(host, 1);
            l.AddChild(Fz.Caps("Livery", 14, Fz.Dim));
            var lg = new GridContainer { Columns = 2 };
            lg.AddThemeConstantOverride("h_separation", 6); lg.AddThemeConstantOverride("v_separation", 6);
            liveryBtns = new Button[CarLook.LiveryNames.Length];
            for (int i = 0; i < liveryBtns.Length; i++)
            {
                int k = i;
                var b = Fz.Btn(CarLook.LiveryNames[i], () => EditLook((lk) => lk.Livery = k), Fz.Look.Option, 46, 16);
                b.ToggleMode = true;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                liveryBtns[i] = b;
                lg.AddChild(b);
            }
            l.AddChild(lg);
            liveryNote = Fz.Text("", 14, Fz.Dim);
            l.AddChild(liveryNote);
            l.AddChild(Gap(4));
            l.AddChild(Fz.Caps("Stripe colour", 14, Fz.Dim));
            l.AddChild(SwatchGrid(Palette2, swatches2, (c) => EditLook((k) => k.Paint2 = c)));

            // windows
            var w = PaintPanel(host, 2);
            w.AddChild(Fz.Caps("Window tint", 14, Fz.Dim));
            tintOpts = Fz.Options(CarLook.TintNames, (i) => EditLook((k) => k.Tint = i), 46);
            w.AddChild(tintOpts.Root);
            tintNote = Fz.Text("", 14, Fz.Dim);
            w.AddChild(tintNote);

            var reset = Fz.Btn("Back to factory", () => { g.SetLook(g.CarId, new CarLook()); SyncPaint(); }, Fz.Look.Plain, 44, 15);
            var foot = Ui.Pad(reset, 22, 0, 22, 18);
            foot.SetAnchorsPreset(Control.LayoutPreset.BottomWide);
            foot.OffsetTop = -64;
            host.AddChild(foot);
            firstFocus[Page.Paint] = () => paintTab == 0 ? bFactoryPaint : paintTab == 1 ? liveryBtns[0] : tintOpts.Items[0];
            ShowPaintTab();
        }

        VBoxContainer PaintPanel(Control host, int i)
        {
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, Visible = false };
            scroll.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            scroll.OffsetBottom = -70;
            var c = Ui.Col(8);
            c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(c, 22, 18, 22, 10));
            host.AddChild(scroll);
            paintPanels[i] = scroll;
            return c;
        }

        GridContainer SwatchGrid(Color[] cols, List<(Fz.Tile, Color)> into, Action<Color> pick)
        {
            var grid = new GridContainer { Columns = 6 };
            grid.AddThemeConstantOverride("h_separation", 6); grid.AddThemeConstantOverride("v_separation", 6);
            foreach (var c in cols)
            {
                var cc = c;
                var t = new Fz.Tile("", "", null, () => pick(cc), 0, 44) { Swatch = cc, Grey = false };
                t.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                into.Add((t, cc));
                grid.AddChild(t.B);
            }
            return grid;
        }

        void ShowPaintTab()
        {
            for (int i = 0; i < paintPanels.Length; i++) paintPanels[i].Visible = i == paintTab;
            if (subTabs.TryGetValue(Page.Paint, out var t)) t.Select(paintTab);
            if (page == Page.Paint) { SyncPaint(); FocusFirst(); }
        }

        void ShowPaint() { paintTab = Math.Clamp(paintTab, 0, 2); ShowPaintTab(); }

        void EditLook(Action<CarLook> f)
        {
            if (paintSyncing) return;
            var k = g.Look(g.CarId).Clone();
            f(k);
            g.SetLook(g.CarId, k);
            SyncPaint();
        }

        void MixPaint()
        {
            if (paintSyncing) return;
            var c = Color.FromHsv((float)(hueS.Slider.Value / 360), (float)(satS.Slider.Value / 100), (float)(valS.Slider.Value / 100));
            EditLook((k) => { k.Custom = true; k.Paint = c; });
        }

        static bool Near(Color a, Color b) => Math.Abs(a.R - b.R) + Math.Abs(a.G - b.G) + Math.Abs(a.B - b.B) < 0.02f;

        void SyncPaint()
        {
            if (!Defs.Cars.TryGetValue(g.CarId, out var d)) return;
            var k = g.Look(g.CarId);
            var pd = d.Paint;
            paintSyncing = true;
            paintCar.Text = d.Title.ToUpperInvariant();
            bFactoryPaint.SetPressedNoSignal(!k.Custom);
            var col = k.Custom ? k.Paint : pd.Factory;
            foreach (var (t, c) in swatches) { bool on = k.Custom && Near(c, k.Paint); if (t.Selected != on) { t.Selected = on; t.Redraw(); } }
            foreach (var (t, c) in swatches2) { bool on = Near(c, k.Paint2); if (t.Selected != on) { t.Selected = on; t.Redraw(); } }
            hueS.Show(Math.Round(col.H * 360)); satS.Show(Math.Round(col.S * 100)); valS.Show(Math.Round(col.V * 100));
            finishOpts.Select(k.Finish);
            for (int i = 0; i < liveryBtns.Length; i++) liveryBtns[i].SetPressedNoSignal(i == k.Livery);
            liveryBtns[1].Visible = pd.FactoryLivery;
            liveryNote.Text = pd.FactoryLivery
                ? "Factory is the car's own race livery (your colour takes the place of its orange). Plain takes it off; the stripes go over plain paint."
                : "The stripes and the two-tone go over the body colour, in the stripe colour below.";
            bool win = pd.Windows.Length > 0;
            foreach (var b in tintOpts.Items) b.Disabled = !win;
            tintOpts.Select(win ? k.Tint : 0);
            tintNote.Text = win ? "Darker glass all round (the lamps stay as they are). From inside the car the windows stay clear." : "This car's windows are part of its paint: there is no glass to tint.";
            paintSyncing = false;
        }
    }
}
