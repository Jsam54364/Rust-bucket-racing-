// The menus' look, after the big open-world racing games' front ends: a slanted dark tab bar along the top (the
// picked tab white), big picture tiles with bold slanted capitals that stay grey until picked and then come into
// colour with a red outline, slanted buttons, and button hints along the bottom for the keys, a pad or touch.
// Everything is built from stock controls (skewed style boxes, and drawing through the controls' draw signal).
using System;
using System.Collections.Generic;
using Godot;

namespace RustBucket.Game
{
    public enum InputKind { Touch, Keys, Pad }

    public static class Fz
    {
        public static readonly Color Red = new Color(1f, 0.17f, 0.25f);
        public static readonly Color Ink = new Color(0.96f, 0.97f, 0.98f);
        public static readonly Color Body = new Color(0.82f, 0.85f, 0.88f);
        public static readonly Color Dim = new Color(0.6f, 0.64f, 0.68f);
        public static readonly Color Dark = new Color(0.03f, 0.035f, 0.045f);
        public static readonly Color Line = new Color(1, 1, 1, 0.09f);
        public const float SkewX = 0.24f;

        /* ---------------- what the player is using: the hints show its buttons ---------------- */
        public static InputKind Device { get; private set; } = OS.HasFeature("mobile") ? InputKind.Touch : InputKind.Keys;
        public static event Action DeviceChanged;

        public static void Note(InputEvent e)
        {
            InputKind k;
            if (e is InputEventScreenTouch || e is InputEventScreenDrag) k = InputKind.Touch;
            else if (e is InputEventKey ek && ek.Pressed) k = InputKind.Keys;
            else if (e is InputEventMouseButton mb && mb.Pressed && mb.Device != -1) k = InputKind.Keys;
            else if (e is InputEventJoypadButton jb && jb.Pressed) k = InputKind.Pad;
            else if (e is InputEventJoypadMotion jm && Math.Abs(jm.AxisValue) > 0.6f) k = InputKind.Pad;
            else return;
            if (k == Device) return;
            Device = k;
            DeviceChanged?.Invoke();
        }

        /* ---------------- type ---------------- */
        static Font slant;
        // the condensed bold, leaning forward: titles and tiles
        public static Font Slant => slant ??= new FontVariation
        {
            BaseFont = Ui.Display,
            VariationTransform = new Transform2D(new Vector2(1, 0), new Vector2(0.21f, 1), Vector2.Zero),
        };

        public static Label Title(string s, int size, Color? c = null)
        {
            var l = Ui.Text(s.ToUpperInvariant(), size, c ?? Ink);
            l.AddThemeFontOverride("font", Slant);
            return l;
        }

        public static Label Caps(string s, int size, Color? c = null)
        {
            var l = Ui.Text(s.ToUpperInvariant(), size, c ?? Ink);
            l.AddThemeFontOverride("font", Ui.Display);
            return l;
        }

        public static Label Text(string s, int size = 17, Color? c = null, bool wrap = true) => Ui.Text(s, size, c ?? Body, wrap);

        /* ---------------- boxes ---------------- */
        public static StyleBoxFlat Box(Color bg, Color? edge = null, int ew = 0, float pad = 0, bool skew = false, int radius = 2)
        {
            var sb = Ui.Box(bg, radius, edge, ew, pad);
            if (skew)
            {
                sb.Skew = new Vector2(SkewX, 0);
                sb.ContentMarginLeft = pad + 10; sb.ContentMarginRight = pad + 10;
            }
            return sb;
        }

        public static PanelContainer Panel(float pad = 18, float alpha = 0.82f)
        {
            var p = new PanelContainer();
            p.AddThemeStyleboxOverride("panel", Box(new Color(Dark, alpha), Line, 1, pad));
            return p;
        }

        static readonly Dictionary<(Color, bool), StyleBoxFlat> boxCache = new Dictionary<(Color, bool), StyleBoxFlat>();
        // for draw calls: one box per look
        public static StyleBoxFlat Cached(Color bg, bool skew)
        {
            if (!boxCache.TryGetValue((bg, skew), out var sb)) { sb = Box(bg, null, 0, 0, skew); boxCache[(bg, skew)] = sb; }
            return sb;
        }

        /* ---------------- buttons ---------------- */
        public enum Look { Primary, Plain, Option, Flat }

        static void Style(Button b, Look look, float pad)
        {
            StyleBoxFlat n, h, p, d;
            Color fn = Ink, fh = Ink, fp = Ink;
            switch (look)
            {
                case Look.Primary:
                    n = Box(Red, null, 0, pad, true); h = Box(Red.Lightened(0.12f), null, 0, pad, true);
                    p = Box(Red.Darkened(0.15f), null, 0, pad, true); d = Box(new Color(Red, 0.4f), null, 0, pad, true);
                    break;
                case Look.Option:
                    n = Box(new Color(1, 1, 1, 0.06f), null, 0, pad, true); h = Box(new Color(1, 1, 1, 0.16f), null, 0, pad, true);
                    p = Box(Ink, null, 0, pad, true); d = Box(new Color(1, 1, 1, 0.03f), null, 0, pad, true);
                    fn = Body; fp = Dark;
                    break;
                case Look.Flat:
                    n = Box(new Color(0, 0, 0, 0), null, 0, pad); h = Box(new Color(1, 1, 1, 0.08f), null, 0, pad);
                    p = h; d = n; fn = Body;
                    break;
                default:
                    n = Box(new Color(Dark, 0.78f), Line, 1, pad, true); h = Box(new Color(0.13f, 0.14f, 0.16f, 0.92f), new Color(1, 1, 1, 0.3f), 1, pad, true);
                    p = Box(Ink, null, 0, pad, true); d = Box(new Color(Dark, 0.5f), Line, 1, pad, true);
                    fp = Dark;
                    break;
            }
            b.AddThemeStyleboxOverride("normal", n); b.AddThemeStyleboxOverride("hover", h);
            b.AddThemeStyleboxOverride("pressed", p); b.AddThemeStyleboxOverride("hover_pressed", p);
            b.AddThemeStyleboxOverride("disabled", d);
            var f = Box(new Color(0, 0, 0, 0), look == Look.Primary ? Ink : Red, 3, pad, look != Look.Flat);
            f.DrawCenter = false;
            b.AddThemeStyleboxOverride("focus", f);
            b.AddThemeColorOverride("font_color", fn); b.AddThemeColorOverride("font_hover_color", fh);
            b.AddThemeColorOverride("font_focus_color", fn);
            b.AddThemeColorOverride("font_pressed_color", fp); b.AddThemeColorOverride("font_hover_pressed_color", fp);
            b.AddThemeColorOverride("font_disabled_color", new Color(Dim, 0.6f));
        }

        public static Button Btn(string s, Action a, Look look = Look.Plain, float h = 52, int font = 19, float w = 0)
        {
            var b = new Button { Text = s.ToUpperInvariant(), FocusMode = Control.FocusModeEnum.All, CustomMinimumSize = new Vector2(w, h) };
            b.Pressed += () => a?.Invoke();
            Style(b, look, 8);
            b.AddThemeFontSizeOverride("font_size", font);
            b.AddThemeFontOverride("font", look == Look.Primary ? Slant : Ui.Display);
            return b;
        }

        /* ---------------- tabs: a dark bar of slanted tabs, the picked one white ---------------- */
        public sealed class Tabs
        {
            public PanelContainer Root;
            public Button[] Items;
            public int Selected = -1;
            public Action<int> Picked;
            public Control Prev, Next;
            public HBoxContainer Row;
            public ScrollContainer Scroll;   // a long bar scrolls to keep the picked tab in sight

            public void Select(int i, bool notify = false)
            {
                Selected = Math.Clamp(i, 0, Items.Length - 1);
                for (int k = 0; k < Items.Length; k++) Items[k].SetPressedNoSignal(k == Selected);
                if (Scroll != null) Scroll.CallDeferred(ScrollContainer.MethodName.EnsureControlVisible, Items[Selected]);
                if (notify) Picked?.Invoke(Selected);
            }

            // the shoulder keys: on to the next visible tab, round the ends
            public void Step(int d)
            {
                int n = Items.Length, i = Selected;
                for (int t = 0; t < n; t++)
                {
                    i = ((i + d) % n + n) % n;
                    if (Items[i].Visible) { Select(i, true); return; }
                }
            }
        }

        public static Tabs MakeTabs(string[] names, Action<int> picked, bool big = true, bool shoulders = true)
        {
            var t = new Tabs { Picked = picked, Items = new Button[names.Length] };
            t.Root = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Pass };
            var bar = Box(new Color(0.015f, 0.02f, 0.025f, 0.78f), null, 0, 0, true);
            bar.ContentMarginLeft = 12; bar.ContentMarginRight = 12; bar.ContentMarginTop = 4; bar.ContentMarginBottom = 4;
            t.Root.AddThemeStyleboxOverride("panel", bar);
            t.Row = Ui.Row(2);
            t.Root.AddChild(t.Row);
            float h = big ? 40 : 34;
            int fs = big ? 19 : 16;
            if (shoulders) { t.Prev = Glyph("tabprev", () => t.Step(-1)); t.Row.AddChild(t.Prev); }
            for (int i = 0; i < names.Length; i++)
            {
                int k = i;
                var b = new Button { Text = names[i].ToUpperInvariant(), ToggleMode = true, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, h) };
                b.Pressed += () => t.Select(k, true);
                var n = Box(new Color(0, 0, 0, 0), null, 0, 6, true); n.ContentMarginLeft = n.ContentMarginRight = big ? 22 : 16;
                var hv = Box(new Color(1, 1, 1, 0.12f), null, 0, 6, true); hv.ContentMarginLeft = hv.ContentMarginRight = n.ContentMarginLeft;
                var p = Box(Ink, null, 0, 6, true); p.ContentMarginLeft = p.ContentMarginRight = n.ContentMarginLeft;
                b.AddThemeStyleboxOverride("normal", n); b.AddThemeStyleboxOverride("hover", hv);
                b.AddThemeStyleboxOverride("pressed", p); b.AddThemeStyleboxOverride("hover_pressed", p);
                b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
                b.AddThemeColorOverride("font_color", Dim); b.AddThemeColorOverride("font_hover_color", Ink);
                b.AddThemeColorOverride("font_pressed_color", Dark); b.AddThemeColorOverride("font_hover_pressed_color", Dark);
                b.AddThemeFontSizeOverride("font_size", fs);
                b.AddThemeFontOverride("font", Slant);
                t.Items[i] = b;
                t.Row.AddChild(b);
            }
            if (shoulders) { t.Next = Glyph("tabnext", () => t.Step(1)); t.Row.AddChild(t.Next); }
            return t;
        }

        // a row of choices for a setting (slanted, the chosen one white)
        public static Tabs Options(string[] names, Action<int> picked, float h = 42)
        {
            var t = new Tabs { Picked = picked, Items = new Button[names.Length] };
            t.Root = new PanelContainer();
            t.Root.AddThemeStyleboxOverride("panel", new StyleBoxEmpty());
            t.Row = Ui.Row(6);
            t.Root.AddChild(t.Row);
            for (int i = 0; i < names.Length; i++)
            {
                int k = i;
                var b = Btn(names[i], () => t.Select(k, true), Look.Option, h, names.Length >= 5 ? 13 : 15);
                b.ClipText = true;   // equal shares of the row, whatever the words
                foreach (var st in new[] { "normal", "hover", "pressed", "hover_pressed", "disabled" })
                    if (b.GetThemeStylebox(st) is StyleBoxFlat sb) { sb.ContentMarginLeft = 10; sb.ContentMarginRight = 10; }
                b.ToggleMode = true;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                t.Items[i] = b;
                t.Row.AddChild(b);
            }
            return t;
        }

        /* ---------------- hints: what the keys, the pad or a tap do here ---------------- */
        // the glyph for an action on the current device: keys ("Q"), pad buttons ("LB"), nothing on touch
        static string GlyphText(string id) => Device == InputKind.Pad
            ? id switch { "select" => "A", "back" => "B", "tabprev" => "LB", "tabnext" => "RB", "alt" => "X", "alt2" => "Y", _ => "" }
            : id switch { "select" => "Enter", "back" => "Esc", "tabprev" => "Q", "tabnext" => "E", "alt" => "R", "alt2" => "F", _ => "" };

        static Color PadColour(string g) => g switch
        {
            "A" => new Color(0.36f, 0.72f, 0.3f), "B" => new Color(0.86f, 0.24f, 0.22f), "X" => new Color(0.25f, 0.5f, 0.9f),
            "Y" => new Color(0.92f, 0.72f, 0.15f), _ => new Color(0.32f, 0.34f, 0.37f),
        };

        static readonly List<Control> glyphs = new List<Control>();

        // draws a key or pad glyph at x (vertically centred in the control); returns its width
        static float DrawGlyph(Control c, string g, float x)
        {
            if (g.Length == 0) return 0;
            var f = Ui.Display;
            float cy = c.Size.Y / 2;
            bool round = Device == InputKind.Pad && g.Length == 1;
            int fs = 14;
            float tw = f.GetStringSize(g, HorizontalAlignment.Left, -1, fs).X;
            float w = round ? 24 : Math.Max(24, tw + 12), h = 24;
            var r = new Rect2(x, cy - h / 2, w, h);
            if (Device == InputKind.Pad)
            {
                if (round) c.DrawCircle(r.GetCenter(), 12, PadColour(g));
                else c.DrawStyleBox(Cached(PadColour(g), false), r);
                c.DrawString(f, new Vector2(x + (w - tw) / 2, cy + 5), g, HorizontalAlignment.Left, -1, fs, Ink);
            }
            else
            {
                c.DrawStyleBox(Cached(new Color(1, 1, 1, 0.14f), false), r);
                c.DrawRect(r, new Color(1, 1, 1, 0.35f), false, 1);
                c.DrawString(f, new Vector2(x + (w - tw) / 2, cy + 5), g, HorizontalAlignment.Left, -1, fs, Ink);
            }
            return w;
        }

        // a shoulder glyph beside a tab bar (hidden on touch, where the tabs are tapped)
        static Control Glyph(string id, Action a)
        {
            var c = new Control { CustomMinimumSize = new Vector2(40, 30), MouseFilter = Control.MouseFilterEnum.Stop, SizeFlagsVertical = Control.SizeFlags.ShrinkCenter };
            c.Draw += () => { float gw = c.Size.X; DrawGlyph(c, GlyphText(id), (gw - (Device == InputKind.Pad ? 30 : 24)) / 2); };
            c.GuiInput += (e) => { if (e is InputEventMouseButton mb && mb.Pressed && mb.ButtonIndex == MouseButton.Left) a(); };
            c.Visible = Device != InputKind.Touch;
            glyphs.Add(c);
            return c;
        }

        // one hint: its glyph and what it does; a button, so a click or tap does it too
        static readonly Dictionary<Button, string> hintLabels = new Dictionary<Button, string>();

        // what a hint says it does (it can change from page to page)
        public static void SetHintLabel(Button b, string label)
        {
            hintLabels[b] = label;
            RefreshHints();
        }

        public static Button Hint(string id, string label, Action a)
        {
            var b = new Button { Text = label.ToUpperInvariant(), FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(0, 40) };
            b.Pressed += () => a?.Invoke();
            var n = Box(new Color(0, 0, 0, 0), null, 0, 8); var h = Box(new Color(1, 1, 1, 0.08f), null, 0, 8);
            b.AddThemeStyleboxOverride("normal", n); b.AddThemeStyleboxOverride("hover", h); b.AddThemeStyleboxOverride("pressed", h);
            b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            b.AddThemeColorOverride("font_color", Body); b.AddThemeColorOverride("font_hover_color", Ink); b.AddThemeColorOverride("font_pressed_color", Ink);
            b.AddThemeFontSizeOverride("font_size", 16);
            b.AddThemeFontOverride("font", Ui.Display);
            void Fit()
            {
                string g = GlyphText(id);
                bool touch = Device == InputKind.Touch;
                float gw = touch || g.Length == 0 ? 0 : Math.Max(24, Ui.Display.GetStringSize(g, HorizontalAlignment.Left, -1, 14).X + 12) + 8;
                if (id == "tabs" && !touch) gw = 24 + 8 + 24 + 8;
                n.ContentMarginLeft = h.ContentMarginLeft = 8 + gw;
                b.Text = (touch && id == "back" ? "‹  " : "") + (hintLabels.TryGetValue(b, out var hl) ? hl : label).ToUpperInvariant();
                b.Visible = !touch || id == "back" || id == "alt" || id == "alt2";
                b.QueueRedraw();
            }
            b.Draw += () =>
            {
                if (Device == InputKind.Touch) return;
                if (id == "tabs") { float w0 = DrawGlyph(b, GlyphText("tabprev"), 8); DrawGlyph(b, GlyphText("tabnext"), 8 + w0 + 6); }
                else DrawGlyph(b, GlyphText(id), 8);
            };
            Fit();
            fits.Add(Fit);
            return b;
        }

        static readonly List<Action> fits = new List<Action>();

        // the player picked up another device: every glyph changes
        public static void RefreshHints()
        {
            foreach (var f in fits) f();
            foreach (var c in glyphs) { c.Visible = Device != InputKind.Touch; c.QueueRedraw(); }
        }

        /* ---------------- picture tiles ---------------- */
        public static readonly List<Tile> AllTiles = new List<Tile>();
        static Shader tileShader;

        public sealed class Tile
        {
            public readonly Button B;
            readonly TextureRect pic;
            readonly Control over;
            readonly ShaderMaterial mat;
            public string Title, Sub = "", Badge = "", Icon = "";
            public Color BadgeColor = Red;
            public Color? Swatch;
            public bool Selected, Grey = true;
            public int TitleSize;
            float k = -1;

            public Tile(string title, string sub, Texture2D picture, Action press, float minW = 0, float minH = 120)
            {
                Title = title; Sub = sub ?? "";
                B = new Button { FocusMode = Control.FocusModeEnum.All, CustomMinimumSize = new Vector2(minW, minH), ClipContents = true };
                B.Pressed += () => press?.Invoke();
                var bg = Box(new Color(0.09f, 0.1f, 0.115f), null, 0, 0);
                foreach (var st in new[] { "normal", "hover", "pressed", "hover_pressed", "disabled" }) B.AddThemeStyleboxOverride(st, bg);
                B.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
                tileShader ??= GD.Load<Shader>("res://shaders/ui_tile.gdshader");
                mat = new ShaderMaterial { Shader = tileShader };
                pic = new TextureRect
                {
                    ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.KeepAspectCovered,
                    MouseFilter = Control.MouseFilterEnum.Ignore, Material = mat, Texture = picture,
                };
                pic.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                B.AddChild(pic);
                over = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
                over.SetAnchorsPreset(Control.LayoutPreset.FullRect);
                over.Draw += DrawOver;
                B.AddChild(over);
                AllTiles.Add(this);
            }

            public Texture2D Picture { get => pic.Texture; set => pic.Texture = value; }
            public void Redraw() => over.QueueRedraw();

            bool Lit => B.HasFocus() || B.IsHovered() || B.ButtonPressed;

            public void Tick(double dt)
            {
                float want = Lit ? 1 : Selected ? 0.75f : 0;
                float nk = k < 0 ? want : k + (want - k) * (float)Math.Min(1, dt * 12);
                if (Math.Abs(nk - k) < 0.002f && k >= 0) return;
                k = nk;
                float c = Grey ? k : 1;
                mat.SetShaderParameter("sat", Mathf.Lerp(0.08f, 1f, c));
                mat.SetShaderParameter("lum", Mathf.Lerp(0.52f, 1f, c));
                over.QueueRedraw();
            }

            void DrawOver()
            {
                var sz = over.Size;
                var r = new Rect2(Vector2.Zero, sz);
                float lit = Math.Max(0, k);
                if (Swatch.HasValue) over.DrawRect(r, Swatch.Value);
                if (Title.Length > 0)
                {
                    // shade under the words
                    var clear = new Color(0, 0, 0, 0); var shade = new Color(0, 0, 0, 0.86f);
                    float top = sz.Y * (Sub.Length > 0 ? 0.36f : 0.5f);
                    over.DrawPolygon(new[] { new Vector2(0, top), new Vector2(sz.X, top), new Vector2(sz.X, sz.Y), new Vector2(0, sz.Y) },
                        new[] { clear, clear, shade, shade });
                }
                if (Icon.Length > 0) DrawIcon(over, Icon, new Vector2(sz.X / 2, sz.Y * (Title.Length > 0 ? 0.4f : 0.5f)), Math.Min(sz.X, sz.Y) * 0.2f, new Color(Ink, 0.55f + 0.45f * lit));
                if (Title.Length > 0)
                {
                    int fs = TitleSize > 0 ? TitleSize : (int)Math.Clamp(sz.Y * 0.15f, 18, 34);
                    // a long name on a narrow tile: smaller type rather than cut off
                    while (fs > 14 && Slant.GetStringSize(Title.ToUpperInvariant(), HorizontalAlignment.Left, -1, fs).X > sz.X - 30) fs--;
                    float y = sz.Y - (Sub.Length > 0 ? 34 : 14);
                    over.DrawString(Slant, new Vector2(16, y), Title.ToUpperInvariant(), HorizontalAlignment.Left, sz.X - 30, fs, Ink);
                    if (Sub.Length > 0) over.DrawString(Ui.Body, new Vector2(17, sz.Y - 12), Sub, HorizontalAlignment.Left, sz.X - 30, 14, new Color(Body, 0.8f + 0.2f * lit));
                }
                if (Badge.Length > 0)
                {
                    float tw = Ui.Display.GetStringSize(Badge, HorizontalAlignment.Left, -1, 13).X;
                    var br = new Rect2(sz.X - tw - 30, 10, tw + 20, 22);
                    over.DrawStyleBox(Cached(BadgeColor, true), br);
                    bool darkInk = BadgeColor.Luminance > 0.6f;
                    over.DrawString(Ui.Display, new Vector2(br.Position.X + 10, br.Position.Y + 16), Badge, HorizontalAlignment.Left, -1, 13, darkInk ? Dark : Ink);
                }
                // picked: a red outline; the one in use: a white one
                if (Lit && k > 0.02f) over.DrawRect(r.Grow(-1.5f), new Color(Red, Math.Min(1, k * 1.3f)), false, 3);
                else if (Selected) over.DrawRect(r.Grow(-1f), new Color(Ink, 0.75f), false, 2);
            }
        }

        // simple line icons for the tiles that have no picture
        public static void DrawIcon(Control c, string icon, Vector2 at, float r, Color col)
        {
            switch (icon)
            {
                case "gear":
                    {
                        var pts = new List<Vector2>();
                        for (int i = 0; i < 48; i++)
                        {
                            float a = Mathf.Tau * i / 48;
                            float rr = (i / 3) % 2 == 0 ? r : r * 0.78f;
                            pts.Add(at + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * rr);
                        }
                        pts.Add(pts[0]);
                        c.DrawPolyline(pts.ToArray(), col, 3, true);
                        c.DrawArc(at, r * 0.36f, 0, Mathf.Tau, 32, col, 3, true);
                        break;
                    }
                case "help":
                    c.DrawArc(at, r, 0, Mathf.Tau, 48, col, 3, true);
                    c.DrawString(Ui.Display, at + new Vector2(-r * 0.3f, r * 0.45f), "?", HorizontalAlignment.Left, -1, (int)(r * 1.3f), col);
                    break;
                case "star":
                    {
                        var pts = new Vector2[11];
                        for (int i = 0; i < 11; i++)
                        {
                            float a = -Mathf.Pi / 2 + Mathf.Tau * i / 10, rr = i % 2 == 0 ? r : r * 0.42f;
                            pts[i] = at + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * rr;
                        }
                        c.DrawPolyline(pts, col, 3, true);
                        break;
                    }
                case "plus":
                    c.DrawLine(at - new Vector2(r, 0), at + new Vector2(r, 0), col, 4, true);
                    c.DrawLine(at - new Vector2(0, r), at + new Vector2(0, r), col, 4, true);
                    break;
                case "down":
                    c.DrawLine(at - new Vector2(0, r), at + new Vector2(0, r * 0.6f), col, 4, true);
                    c.DrawPolyline(new[] { at + new Vector2(-r * 0.55f, 0), at + new Vector2(0, r * 0.6f), at + new Vector2(r * 0.55f, 0) }, col, 4, true);
                    c.DrawLine(at + new Vector2(-r, r), at + new Vector2(r, r), col, 4, true);
                    break;
                case "save":
                    c.DrawRect(new Rect2(at - new Vector2(r, r), new Vector2(r * 2, r * 2)), col, false, 3);
                    c.DrawRect(new Rect2(at + new Vector2(-r * 0.55f, -r), new Vector2(r * 1.1f, r * 0.7f)), col, false, 3);
                    c.DrawRect(new Rect2(at + new Vector2(-r * 0.6f, r * 0.15f), new Vector2(r * 1.2f, r * 0.85f)), col, false, 3);
                    break;
            }
        }

        // a solid colour picture for tiles that have none of their own
        public static Texture2D Plate(Color a, Color b)
        {
            var g = new Gradient { Colors = new[] { a, b }, Offsets = new[] { 0f, 1f } };
            return new GradientTexture2D { Gradient = g, Width = 64, Height = 64, FillFrom = new Vector2(0, 0), FillTo = new Vector2(1, 1) };
        }

        /* ---------------- settings rows ---------------- */
        // a setting with its choices beside it
        public static Control Row(string label, Control right, string note = null)
        {
            var col = Ui.Col(4);
            var row = Ui.Row(16);
            var l = Caps(label, 18, Body);
            l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            l.SizeFlagsStretchRatio = 0.8f;
            l.VerticalAlignment = VerticalAlignment.Center;
            row.AddChild(l);
            right.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            row.AddChild(right);
            col.AddChild(row);
            if (!string.IsNullOrEmpty(note)) col.AddChild(Text(note, 14, Dim));
            return col;
        }

        // a slider for a number: its name and value above, what the ends mean either side
        public static Ui.SliderRow Slider(string label, double min, double max, double step, Func<double, string> fmt, Action<double> onChange, string lo = "", string hi = "")
        {
            var r = new Ui.SliderRow { Root = Ui.Col(0), Fmt = fmt };
            var head = Ui.Row();
            var l = Caps(label, 17, Body);
            l.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            r.Value = Caps("", 18, Ink);
            head.AddChild(l); head.AddChild(r.Value);
            var line = Ui.Row(10);
            r.Slider = new HSlider { MinValue = min, MaxValue = max, Step = step, CustomMinimumSize = new Vector2(0, 38), FocusMode = Control.FocusModeEnum.All, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
            r.Slider.ValueChanged += (double v) => { r.Value.Text = fmt(v); onChange(v); };
            if (lo.Length > 0) { var a = Text(lo.ToUpperInvariant(), 12, Dim, false); a.CustomMinimumSize = new Vector2(58, 0); a.VerticalAlignment = VerticalAlignment.Center; line.AddChild(a); }
            line.AddChild(r.Slider);
            if (hi.Length > 0) { var b = Text(hi.ToUpperInvariant(), 12, Dim, false); b.CustomMinimumSize = new Vector2(58, 0); b.HorizontalAlignment = HorizontalAlignment.Right; b.VerticalAlignment = VerticalAlignment.Center; line.AddChild(b); }
            r.Root.AddChild(head); r.Root.AddChild(line);
            return r;
        }

        /* ---------------- the menus' theme: thin red-filled sliders, white grabbers ---------------- */
        static Theme theme;
        public static Theme Theme
        {
            get
            {
                if (theme != null) return theme;
                var t = (Theme)Ui.Theme.Duplicate();
                t.SetStylebox("slider", "HSlider", Ui.Box(new Color(1, 1, 1, 0.16f), 1, null, 0, 3));
                t.SetStylebox("grabber_area", "HSlider", Ui.Box(Red, 1, null, 0, 3));
                t.SetStylebox("grabber_area_highlight", "HSlider", Ui.Box(Red.Lightened(0.15f), 1, null, 0, 3));
                var knob = Knob();
                t.SetIcon("grabber", "HSlider", knob); t.SetIcon("grabber_highlight", "HSlider", knob); t.SetIcon("grabber_disabled", "HSlider", knob);
                var fs = Box(new Color(0, 0, 0, 0), Red, 2, 0); fs.DrawCenter = false;
                t.SetStylebox("focus", "HSlider", fs);
                t.SetStylebox("grabber_pressed", "VScrollBar", Ui.Box(new Color(Red, 0.7f), 4, null, 0, 2));
                t.SetStylebox("grabber", "VScrollBar", Ui.Box(new Color(1, 1, 1, 0.26f), 4, null, 0, 2));
                t.SetColor("caret_color", "LineEdit", Red);
                t.SetStylebox("normal", "LineEdit", Box(new Color(1, 1, 1, 0.06f), Line, 1, 10));
                t.SetStylebox("focus", "LineEdit", Box(new Color(1, 1, 1, 0.08f), Red, 2, 10));
                t.SetFontSizeOverride("font_size", "LineEdit", 18);
                theme = t;
                return t;
            }
        }

        // a slim upright grabber
        static ImageTexture Knob()
        {
            int w = 14, h = 30;
            var img = Image.CreateEmpty(w, h, false, Image.Format.Rgba8);
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    float dx = Math.Max(0, Math.Abs(x + 0.5f - w / 2f) - (w / 2f - 3)), dy = Math.Max(0, Math.Abs(y + 0.5f - h / 2f) - (h / 2f - 3));
                    float a = Mathf.Clamp(3.2f - Mathf.Sqrt(dx * dx + dy * dy) * 1.1f, 0, 1);
                    img.SetPixel(x, y, new Color(Ink, a));
                }
            return ImageTexture.CreateFromImage(img);
        }
    }

    // Theme.SetFontSizeOverride doesn't exist: a tiny helper keeps the call above readable
    static class ThemeExt
    {
        public static void SetFontSizeOverride(this Theme t, string name, string type, int size) => t.SetFontSize(name, type, size);
    }
}
