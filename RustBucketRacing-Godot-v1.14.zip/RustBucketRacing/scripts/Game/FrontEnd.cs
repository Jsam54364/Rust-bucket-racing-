// The front end: the hub (Play, Garage, Maps, Options), free roam, the garage (cars, the paint shop, tuning and
// saved setups), the map library, settings, the modes still to come, how to play and credits. Styled after the big
// racing games' menus (Fz): a slanted tab bar along the top on every page, picture tiles, hints along the bottom.
// It sits over the garage studio (the car on its turntable), or over the paused drive for settings, tuning and how
// to play opened from it. Parts: FrontEnd.Play.cs, FrontEnd.Garage.cs, FrontEnd.Tuning.cs, FrontEnd.Options.cs.
using System;
using System.Collections.Generic;
using System.Globalization;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed partial class FrontEnd
    {
        public enum Page { None, Main, FreeRoam, Garage, Paint, Tuning, Maps, Settings, TimeTrial, Career, Online, HowTo, Credits }
        public static readonly string[] TabNames = { "Audio", "Display", "Driving", "Controls", "Other" };
        static readonly string[] HubNames = { "Play", "Garage", "Maps", "Options" };

        readonly Main g;
        public readonly Control Root;
        public readonly Showroom Room;
        readonly TextureRect shade;
        readonly ColorRect dim;
        readonly Control dragArea;
        readonly Texture2D shadeLeft, shadeSides, shadeRight;
        readonly Dictionary<Page, Control> pages = new Dictionary<Page, Control>();
        readonly Dictionary<Page, Fz.Tabs> subTabs = new Dictionary<Page, Fz.Tabs>();
        readonly Dictionary<Page, Func<Control>> firstFocus = new Dictionary<Page, Func<Control>>();
        readonly List<MarginContainer> frames = new List<MarginContainer>();
        Page page = Page.None;
        readonly Stack<Page> history = new Stack<Page>();   // where Back goes
        bool overGame, fromGame;

        public bool IsOpen => page != Page.None;
        public Page Current => page;
        // opened over the drive (settings, tuning or how to play): the paused game shows behind, dimmed
        public bool OverGame => IsOpen && overGame;

        public FrontEnd(Main game)
        {
            g = game;
            Root = new Control { Name = "FrontEnd", Theme = Fz.Theme, Visible = false, MouseFilter = Control.MouseFilterEnum.Ignore };
            Root.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Room = new Showroom(game, game.BorrowCarView, game.ReturnCarView);
            Root.AddChild(Room.View);
            shadeLeft = Grad(new[] { 0f, 0.4f, 0.66f, 1f }, new[] { 0.92f, 0.78f, 0.05f, 0f });
            shadeSides = Grad(new[] { 0f, 0.27f, 0.73f, 1f }, new[] { 0.82f, 0f, 0f, 0.82f });
            shadeRight = Grad(new[] { 0f, 0.4f, 0.62f, 1f }, new[] { 0f, 0f, 0.7f, 0.9f });
            shade = new TextureRect { ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize, StretchMode = TextureRect.StretchModeEnum.Scale, MouseFilter = Control.MouseFilterEnum.Ignore };
            shade.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Root.AddChild(shade);
            dim = new ColorRect { Color = new Color(0.03f, 0.035f, 0.045f, 0.6f), MouseFilter = Control.MouseFilterEnum.Stop };
            dim.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            Root.AddChild(dim);
            // the garage pages: drag anywhere off the panels to turn the car
            dragArea = new Control { Name = "TurnArea", MouseFilter = Control.MouseFilterEnum.Stop, Visible = false };
            dragArea.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            dragArea.GuiInput += OnDrag;
            Root.AddChild(dragArea);
            BuildMain();
            BuildFreeRoam();
            BuildGarage();
            BuildPaint();
            BuildTuning();
            BuildMaps();
            BuildSettings();
            BuildLocked(Page.TimeTrial, "Time trial", "Race the clock on every map, against your own ghost.",
                "Your best laps and stage times from Free Roam are already being kept, and they are listed below. The Time Trial mode will set proper runs with a countdown, a ghost of your best run to chase, sector splits and medal times for each car on each map.",
                new[] { "Countdown starts and clean-run rules", "Ghost car of your best run", "Sector splits and a delta bar", "Bronze, silver and gold medal times", "Leaderboards" });
            BuildLocked(Page.Career, "Career", "Start with a rust bucket. Work your way up.",
                "Buy cheap cars, fix them up and tune them, enter events on the maps you know, and earn your way to faster machinery.",
                new[] { "Money, a car lot and a parts shop", "Repairs and upgrades: engine, suspension, tyres, brakes", "Events: time attacks, hill climbs and races", "Championships across the maps", "A garage that fills up with your cars" });
            BuildLocked(Page.Online, "Multiplayer", "Drive together.",
                "Share the road with friends: free roam together, race head to head on the circuits, and run the mountain stages against each other's times.",
                new[] { "Free roam lobbies", "Head-to-head races", "Shared stage leaderboards", "Your garage cars online" });
            BuildHowTo();
            BuildCredits();
            BuildBars();
            foreach (var kv in pages) Quiet(kv.Value);
            Fz.DeviceChanged += () => { Fz.RefreshHints(); if (IsOpen) SetHints(page); };
        }

        static Texture2D Grad(float[] at, float[] alpha)
        {
            var cols = new Color[alpha.Length];
            for (int i = 0; i < alpha.Length; i++) cols[i] = new Color(0.03f, 0.035f, 0.045f, alpha[i]);
            var gr = new Gradient { Colors = cols, Offsets = at };
            return new GradientTexture2D { Gradient = gr, Width = 256, Height = 4, FillFrom = new Vector2(0, 0), FillTo = new Vector2(1, 0) };
        }

        // containers let touches through to what is behind them (the garage turn area); panels and buttons keep them
        static void Quiet(Control c)
        {
            if (c is Container && !(c is PanelContainer) && !(c is ScrollContainer)) c.MouseFilter = Control.MouseFilterEnum.Ignore;
            foreach (var ch in c.GetChildren()) if (ch is Control cc) Quiet(cc);
        }

        static string F(double v, int dp) => v.ToString("F" + dp, CultureInfo.InvariantCulture);

        // a tile's picture: shipped with the game (ui/tiles), or a dark plate
        static readonly Dictionary<string, Texture2D> pics = new Dictionary<string, Texture2D>();
        static Texture2D Pic(string name)
        {
            if (pics.TryGetValue(name, out var t)) return t;
            string p = "res://ui/tiles/" + name + ".webp";
            t = ResourceLoader.Exists(p) ? GD.Load<Texture2D>(p) : null;
            t ??= Fz.Plate(new Color(0.55f, 0.07f, 0.12f), new Color(0.12f, 0.02f, 0.04f));
            pics[name] = t;
            return t;
        }

        /* ---------------- navigation ---------------- */
        // fromGame: opened over a drive in progress (Back from the first page goes back to it)
        public void Open(Page p, bool fromGame)
        {
            this.fromGame = fromGame;
            overGame = fromGame && OverGameOk(p);
            history.Clear();
            page = Page.None;
            Go(p);
        }

        static bool OverGameOk(Page p) => p == Page.Settings || p == Page.HowTo || p == Page.Tuning;

        public void Go(Page p)
        {
            if (p == Page.None) { Close(); return; }
            if (p == Page.Main) history.Clear();
            else if (page != Page.None && page != p) history.Push(page);
            Show(p);
        }

        void Show(Page p)
        {
            page = p;
            if (overGame && !OverGameOk(p)) overGame = false;
            Root.Visible = true;
            foreach (var kv in pages) kv.Value.Visible = kv.Key == p;
            bool garage = p == Page.Garage || p == Page.Paint;
            dragArea.Visible = garage;
            bool studio = !overGame;
            Room.SetActive(studio);
            if (studio)
            {
                if (p != Page.Garage) Room.Show(g.CarId);
                Room.Shift = p == Page.Main ? 0.4f : p == Page.Garage ? -0.02f : p == Page.Paint ? 0.36f : 0.42f;
                Room.AutoSpin = p != Page.Garage && p != Page.Paint || autoSpin;
                Room.SpinSpeed = garage ? 0.22 : 0.16;
                Room.Back = garage ? 1.2 : 1;
            }
            shade.Visible = studio && (p == Page.Main || garage);
            shade.Texture = p == Page.Garage ? shadeSides : shadeLeft;
            dim.Visible = overGame || !(p == Page.Main || garage);
            dim.Color = new Color(0.03f, 0.035f, 0.045f, overGame ? 0.66f : p == Page.FreeRoam ? 0.6f : 0.76f);
            if (p == Page.Garage) Inspect(inspect ?? g.CarId, true);
            if (p == Page.TimeTrial) FillBests();
            if (p == Page.HowTo) FillGuide();
            if (p == Page.Credits) FillCredits();
            if (p == Page.Paint) ShowPaint();
            if (p == Page.Tuning) ShowTuning();
            if (p == Page.Maps)
            {
                removeArmed = null;
                RebuildMapRows();
                if (!g.Library.Fetching && Time.GetTicksMsec() / 1000.0 - g.Library.LastFetch > 60) g.Library.Refresh();
            }
            nav.Select(p == Page.Main ? hubTab : Section(p));
            SetHints(p);
            Sync();
            FocusFirst();
        }

        // which part of the hub a page belongs to
        static int Section(Page p) => p switch
        {
            Page.Garage or Page.Paint or Page.Tuning => 1,
            Page.Maps => 2,
            Page.Settings or Page.HowTo or Page.Credits => 3,
            Page.Main => -1,
            _ => 0,
        };

        // keys and pads need something picked to move from; touch screens get the same look (one tile lit)
        void FocusFirst()
        {
            if (!firstFocus.TryGetValue(page, out var f)) return;
            var c = f();
            if (c == null || !c.IsVisibleInTree()) return;
            // next frame, if it is still there (a list may be rebuilt meanwhile)
            Callable.From(() => { if (GodotObject.IsInstanceValid(c) && c.IsInsideTree() && c.IsVisibleInTree()) c.GrabFocus(); }).CallDeferred();
        }

        public void Back()
        {
            if (!IsOpen) return;
            if (history.Count > 0) { Show(history.Pop()); return; }
            if (fromGame || (page == Page.Main && g.HasSession)) { if (!g.Busy) Close(); return; }
            if (page != Page.Main) Show(Page.Main);
        }

        public void Close()
        {
            page = Page.None;
            Root.Visible = false;
            dragArea.Visible = false;
            Room.SetActive(false);
            inspect = null;
            overGame = false;
            history.Clear();
        }

        // the shoulder keys: the page's own tabs, or the hub's
        public void TabStep(int d)
        {
            if (!IsOpen) return;
            if (subTabs.TryGetValue(page, out var t)) t.Step(d);
            else if (page == Page.Main) nav.Step(d);
        }

        float lastL = -1, lastR = -1;
        public void Layout(Vector2 size, float safeL, float safeR)
        {
            if (safeL == lastL && safeR == lastR) return;
            lastL = safeL; lastR = safeR;
            foreach (var m in frames)
            {
                m.AddThemeConstantOverride("margin_left", (int)(40 + safeL));
                m.AddThemeConstantOverride("margin_right", (int)(40 + safeR));
            }
        }

        public void Update(double dt, Vector2 size)
        {
            Room.Update(dt, size);
            if (page == Page.Maps) UpdateMapRows();
            if (!IsOpen) return;
            for (int i = Fz.AllTiles.Count - 1; i >= 0; i--)
            {
                var t = Fz.AllTiles[i];
                // tiles of a list that was rebuilt (the maps) go
                if (!GodotObject.IsInstanceValid(t.B) || t.B.IsQueuedForDeletion()) { Fz.AllTiles.RemoveAt(i); continue; }
                if (t.B.IsVisibleInTree()) t.Tick(dt);
            }
        }

        // maps were installed, removed or listed: rebuild what shows them
        public void MapsChanged()
        {
            RebuildHubMaps();
            RebuildMapCards();
            RebuildMapRows();
            Sync();
        }

        /* ---------------- building blocks ---------------- */
        MarginContainer Frame(Page p, MarginContainer m = null)
        {
            m ??= new MarginContainer { Visible = false, Name = p.ToString() };
            m.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            m.AddThemeConstantOverride("margin_left", 40); m.AddThemeConstantOverride("margin_right", 40);
            m.AddThemeConstantOverride("margin_top", 84); m.AddThemeConstantOverride("margin_bottom", 58);
            Root.AddChild(m);
            pages[p] = m; frames.Add(m);
            return m;
        }

        static Control Gap(float h) => new Control { CustomMinimumSize = new Vector2(0, h), MouseFilter = Control.MouseFilterEnum.Ignore };
        static Control Fill(bool vertical = true)
        {
            var c = new Control { MouseFilter = Control.MouseFilterEnum.Ignore };
            if (vertical) c.SizeFlagsVertical = Control.SizeFlags.ExpandFill; else c.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            return c;
        }

        static Control Pill(string s, Color c)
        {
            var p = new PanelContainer { MouseFilter = Control.MouseFilterEnum.Ignore, SizeFlagsVertical = Control.SizeFlags.ShrinkCenter };
            var sb = Fz.Box(new Color(c, 0.14f), new Color(c, 0.7f), 1, 0, true);
            sb.ContentMarginTop = 4; sb.ContentMarginBottom = 4;
            p.AddThemeStyleboxOverride("panel", sb);
            p.AddChild(Fz.Caps(s, 14, c));
            return p;
        }

        // a page's own heading: its title, its tabs (if it has them), something on the right
        // (more than six tabs get a row of their own under the title, which scrolls sideways on a narrow screen)
        Control Head(Page p, string title, string[] tabs = null, Action<int> picked = null, Control right = null)
        {
            var row = Ui.Row(22);
            var t = Fz.Title(title, 34);
            t.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
            row.AddChild(t);
            Fz.Tabs st = null;
            bool wide = tabs != null && tabs.Length > 6;
            if (tabs != null)
            {
                st = Fz.MakeTabs(tabs, picked, false, true);
                st.Root.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
                subTabs[p] = st;
                if (!wide) row.AddChild(st.Root);
            }
            row.AddChild(Fill(false));
            if (right != null) row.AddChild(right);
            if (!wide) return row;
            var col = Ui.Col(6);
            col.AddChild(row);
            var sc = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.ShowNever, VerticalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(0, 46) };
            st.Root.SizeFlagsHorizontal = Control.SizeFlags.ShrinkBegin;
            sc.AddChild(st.Root);
            st.Scroll = sc;
            col.AddChild(sc);
            return col;
        }

        /* ---------------- the bars on every page: the hub's tabs along the top, hints along the bottom ---------------- */
        Fz.Tabs nav;
        Label navCar;
        HBoxContainer hintRow;
        Label hintLeft;
        Button hBack, hSelect, hTabs;

        void BuildBars()
        {
            var top = new MarginContainer { Name = "TopBar", MouseFilter = Control.MouseFilterEnum.Ignore };
            top.SetAnchorsPreset(Control.LayoutPreset.TopWide);
            top.OffsetBottom = 70;
            top.AddThemeConstantOverride("margin_left", 40); top.AddThemeConstantOverride("margin_right", 40);
            top.AddThemeConstantOverride("margin_top", 16); top.AddThemeConstantOverride("margin_bottom", 6);
            frames.Add(top);
            var row = Ui.Row(18);
            row.MouseFilter = Control.MouseFilterEnum.Ignore;
            top.AddChild(row);
            var logo = Ui.Col(-6);
            logo.MouseFilter = Control.MouseFilterEnum.Ignore;
            logo.AddChild(Fz.Title("Rust Bucket", 21));
            logo.AddChild(Fz.Title("Racing", 21, Fz.Red));
            row.AddChild(logo);
            nav = Fz.MakeTabs(HubNames, (i) => { hubTab = i; if (page != Page.Main) Go(Page.Main); else ShowHubTab(); }, true, true);
            nav.Root.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
            row.AddChild(nav.Root);
            row.AddChild(Fill(false));
            navCar = Fz.Caps("", 17, Fz.Body);
            navCar.SizeFlagsVertical = Control.SizeFlags.ShrinkCenter;
            row.AddChild(navCar);
            row.AddChild(Pill("ALPHA  ·  v" + DebugLog.Version, Fz.Dim));
            Root.AddChild(top);

            var bottom = new MarginContainer { Name = "Hints", MouseFilter = Control.MouseFilterEnum.Ignore };
            bottom.SetAnchorsPreset(Control.LayoutPreset.BottomWide);
            bottom.OffsetTop = -54;
            bottom.AddThemeConstantOverride("margin_left", 40); bottom.AddThemeConstantOverride("margin_right", 40);
            bottom.AddThemeConstantOverride("margin_top", 4); bottom.AddThemeConstantOverride("margin_bottom", 10);
            frames.Add(bottom);
            hintRow = Ui.Row(6);
            hintRow.MouseFilter = Control.MouseFilterEnum.Ignore;
            bottom.AddChild(hintRow);
            hintLeft = Fz.Text("", 14, Fz.Dim, false);
            hintLeft.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            hintLeft.VerticalAlignment = VerticalAlignment.Center;
            hintRow.AddChild(hintLeft);
            hTabs = Fz.Hint("tabs", "Section", null);
            hSelect = Fz.Hint("select", "Select", () => { var f = Root.GetViewport().GuiGetFocusOwner(); if (f is BaseButton bb) bb.EmitSignal(BaseButton.SignalName.Pressed); });
            hBack = Fz.Hint("back", "Back", Back);
            hintRow.AddChild(hTabs); hintRow.AddChild(hSelect); hintRow.AddChild(hBack);
            Root.AddChild(bottom);
        }

        void SetHints(Page p)
        {
            bool tabs = p == Page.Main || subTabs.ContainsKey(p);
            Fz.SetHintLabel(hTabs, p == Page.Main ? "Section" : "Page");
            Fz.SetHintLabel(hBack, p == Page.Main && (g.HasSession || fromGame) ? "Resume" : "Back");
            if (Fz.Device != InputKind.Touch) hTabs.Visible = tabs;
            hBack.Visible = p != Page.Main || g.HasSession || fromGame;
            hintLeft.Text = p switch
            {
                Page.Garage or Page.Paint => Fz.Device == InputKind.Touch ? "Drag to turn the car, pinch to zoom" : "Drag to turn the car, scroll to zoom",
                Page.Tuning => "Changes are saved as you make them",
                Page.Settings => "Saved on this device",
                _ => "",
            };
        }

        /* ---------------- the hub ---------------- */
        int hubTab;
        readonly Control[] hubPanels = new Control[4];
        Fz.Tile tFree, tResume, tCars, tSettings;
        GridContainer hubMaps;
        Label carName, carSub;

        void BuildMain()
        {
            var m = Frame(Page.Main);
            var row = Ui.Row(0);
            m.AddChild(row);
            var host = new Control { CustomMinimumSize = new Vector2(760, 0), MouseFilter = Control.MouseFilterEnum.Ignore };
            row.AddChild(host);

            // play: free roam big, the rest beside it
            var play = HubRow(host, 0);
            tFree = new Fz.Tile("Free roam", "Any map, no rules: drive anywhere", Pic("play_freeroam"), () => Go(Page.FreeRoam), 440, 0) { Badge = "PLAY" };
            play.AddChild(Big(tFree));
            var pc = Ui.Col(12);
            pc.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            tResume = new Fz.Tile("Resume drive", "Back where you left it", Pic("play_resume"), Close, 0, 0) { Badge = "PAUSED", BadgeColor = Fz.Ink };
            pc.AddChild(Small(tResume));
            pc.AddChild(Small(new Fz.Tile("Time trial", "Race the clock and your own ghost", Pic("play_timetrial"), () => Go(Page.TimeTrial)) { Badge = "SOON", BadgeColor = Fz.Dim }));
            pc.AddChild(Small(new Fz.Tile("Career", "Buy, fix up and race your way up", Pic("play_career"), () => Go(Page.Career)) { Badge = "SOON", BadgeColor = Fz.Dim }));
            pc.AddChild(Small(new Fz.Tile("Multiplayer", "Drive with your friends online", Pic("play_online"), () => Go(Page.Online)) { Badge = "SOON", BadgeColor = Fz.Dim }));
            play.AddChild(pc);

            // garage: your cars big; paint, tuning and setups beside them
            var gar = HubRow(host, 1);
            tCars = new Fz.Tile("My cars", "Choose what you drive", Pic("garage_cars"), () => Go(Page.Garage), 440, 0);
            gar.AddChild(Big(tCars));
            var gc = Ui.Col(12);
            gc.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            gc.AddChild(Small(new Fz.Tile("Paint shop", "Paint, livery and window tint", Pic("garage_paint"), () => Go(Page.Paint))));
            gc.AddChild(Small(new Fz.Tile("Tuning", "Suspension, alignment, tyres, gearing, diff", Pic("garage_tuning"), () => OpenTuningTab(0))));
            gc.AddChild(Small(new Fz.Tile("Setups", "Save your setups and load them again", Pic("garage_setups"), () => OpenTuningTab(TuneTabs.Length - 1))));
            gar.AddChild(gc);

            // maps: one tile each, then a way to get more
            var mp = HubRow(host, 2);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill, SizeFlagsVertical = Control.SizeFlags.ExpandFill };
            hubMaps = new GridContainer { Columns = 3, SizeFlagsHorizontal = Control.SizeFlags.ExpandFill };
            hubMaps.AddThemeConstantOverride("h_separation", 12); hubMaps.AddThemeConstantOverride("v_separation", 12);
            scroll.AddChild(hubMaps);
            mp.AddChild(scroll);
            RebuildHubMaps();

            // options
            var op = HubRow(host, 3);
            tSettings = new Fz.Tile("Settings", "Sound, graphics, driving aids, controls", Pic("options_settings"), () => Go(Page.Settings), 440, 0) { Icon = "gear" };
            op.AddChild(Big(tSettings));
            var oc = Ui.Col(12);
            oc.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            oc.AddChild(Small(new Fz.Tile("How to play", "The controls, the cars and the maps", Pic("options_howto"), () => Go(Page.HowTo)) { Icon = "help" }));
            oc.AddChild(Small(new Fz.Tile("Controls", "Steering, pedals, touch layout", Pic("options_controls"), () => { ShowTab(3); Go(Page.Settings); }) { Icon = "gear" }));
            oc.AddChild(Small(new Fz.Tile("Credits", "The people whose work is in the game", Pic("options_credits"), () => Go(Page.Credits)) { Icon = "star" }));
            op.AddChild(oc);

            // the car on the turntable, named on the right
            var right = Ui.Col(2);
            right.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            right.AddChild(Fill());
            carName = Fz.Title("", 34);
            carName.HorizontalAlignment = HorizontalAlignment.Right;
            carSub = Fz.Text("", 17, Fz.Body, false);
            carSub.HorizontalAlignment = HorizontalAlignment.Right;
            right.AddChild(carName); right.AddChild(carSub);
            row.AddChild(right);
            firstFocus[Page.Main] = () => hubTab switch { 0 => (g.HasSession ? tResume.B : tFree.B), 1 => tCars.B, 2 => hubMaps.GetChildCount() > 0 ? hubMaps.GetChild(0) as Control : null, _ => tSettings.B };
            ShowHubTab();
        }

        // for the self-test
        public void TestHubTab(int i) { hubTab = i; if (page != Page.Main) Go(Page.Main); else ShowHubTab(); }
        public void TestPaintTab(int i) { paintTab = i; ShowPaintTab(); }

        HBoxContainer HubRow(Control host, int i)
        {
            var r = Ui.Row(12);
            r.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            r.Visible = false;
            host.AddChild(r);
            hubPanels[i] = r;
            return r;
        }

        static Control Big(Fz.Tile t)
        {
            t.B.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            t.TitleSize = 40;
            return t.B;
        }

        static Control Small(Fz.Tile t)
        {
            t.B.SizeFlagsVertical = Control.SizeFlags.ExpandFill;
            t.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            return t.B;
        }

        void ShowHubTab()
        {
            for (int i = 0; i < hubPanels.Length; i++) hubPanels[i].Visible = i == hubTab;
            nav?.Select(hubTab);
            if (page == Page.Main) { SetHints(page); FocusFirst(); }
        }

        void RebuildHubMaps()
        {
            if (hubMaps == null) return;
            foreach (var c in hubMaps.GetChildren()) { hubMaps.RemoveChild(c); c.QueueFree(); }
            foreach (var id in Defs.MapOrder)
            {
                var d = Defs.Maps[id];
                string mid = id;
                var t = new Fz.Tile(d.Name, d.Sub, Pic("map_" + id), () => { selMap = mid; Go(Page.FreeRoam); }, 236, 156);
                t.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                t.TitleSize = 22;
                hubMaps.AddChild(t.B);
            }
            var more = new Fz.Tile("More maps", "Download maps to this phone", Pic("map_more"), () => Go(Page.Maps), 236, 156) { Icon = "down", TitleSize = 22 };
            more.B.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            hubMaps.AddChild(more.B);
            Quiet(hubMaps);
        }

        void SyncMain()
        {
            tResume.B.Visible = g.HasSession;
            string rid = Room.CarId ?? g.CarId;
            if (rid != null && Defs.Cars.ContainsKey(rid)) { carName.Text = Defs.Cars[rid].Title.ToUpperInvariant(); carSub.Text = Defs.Cars[rid].Sub; }
            navCar.Text = Defs.Cars.TryGetValue(g.CarId, out var cd) ? cd.Title.ToUpperInvariant() : "";
            tFree.Badge = g.HasSession ? "" : "PLAY";
            tFree.Redraw();
        }

        /* ---------------- sync every control to the game ---------------- */
        public void Sync()
        {
            if (!IsOpen) return;
            SyncMain();
            SyncFreeRoam();
            SyncGarage();
            if (page == Page.Paint) SyncPaint();
            if (page == Page.Tuning) SyncTuning();
            SyncSettings();
        }

        public static string ControlsText(bool touch) => touch
            ? "Left thumb: slide along the steering pad, and flick the gear slider up or down (or tap its ends) to shift. Right thumb: Gas, Brake and Hand. Gas and Brake are pressure-sensitive: press higher for more, lower (or slide down) to feather. Camera and menu are top right; drag in the orbit camera to fly round the car, pinch to zoom. The menu's Free camera flies on Gas, Brake and the steering (drag to look); the camera button brings the chase cam back. The phone's back button pauses to the main menu."
            : "W S throttle, brake (tap S to feather)  ·  A D steer  ·  Space handbrake  ·  Q E shift down, up  ·  C camera  ·  M gearbox  ·  T tuning  ·  K controls  ·  G telemetry  ·  V car  ·  N map  ·  L starting grid  ·  R reset (Shift+R start)  ·  H how to play  ·  Esc main menu  ·  drag to look, wheel or + - to zoom. A gamepad works too. In the menus: arrow keys or the stick to move, Enter or A to pick, Esc or B to go back, Q E or the bumpers for the tabs.";
    }
}
