// The in-game menus: camera and menu buttons (top right) and the drop-down menu (car, map, tuning, resets, starts,
// and the way to settings and the main menu), in the menus' style (Fz). Tuning opens the garage's tuning pages over
// the paused drive; general settings live in the front end's settings page.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public interface IGame
    {
        Car Car { get; }
        string CarId { get; }
        string MapId { get; }
        void SwitchCar(string id);
        void SwitchMap(string id);
        void ResetCar(bool toStart);
        void ToGrid();
        void CycleCamera();
        void FreeCamera();
        void ChangeTune(Action<Tune> change);
        void OpenTuning();
        void Toast(string s);
        bool IsStage { get; }
        bool StageDown { get; }
        void StageStart(bool down);
        string[] Spots { get; }      // the map's start points (a compound's paddocks, drag strip...), or none
        void ToSpot(int i);
        void PanelsChanged();
        void OpenSettings(int tab);
        void OpenHowTo();
        void OpenMainMenu();
        void OpenMaps();
    }

    public sealed class Panels
    {
        readonly IGame g;
        public readonly Control Root;
        IconButton bCam, bMenu;
        PanelContainer menu;
        VBoxContainer menuCol;
        Fz.Tabs carSeg;
        readonly List<Button> mapBtns = new List<Button>();
        string[] mapIds = new string[0];
        VBoxContainer mapBox;
        Button mTrack, mTrackDown;
        Label spotHead;
        VBoxContainer spotBox;
        string spotSig = "";

        public bool MenuOpen => menu.Visible;
        public bool AnyOpen => menu.Visible;

        public Panels(IGame game)
        {
            g = game;
            Root = new Control { Name = "Panels", MouseFilter = Control.MouseFilterEnum.Ignore, Theme = Fz.Theme };
            Root.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            BuildTopRight();
            BuildMenu();
            Sync();
        }

        /* ---------------- top right ---------------- */
        void BuildTopRight()
        {
            bCam = new IconButton { Icon = 0, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            bMenu = new IconButton { Icon = 1, FocusMode = Control.FocusModeEnum.None, CustomMinimumSize = new Vector2(76, 76) };
            var sb = Fz.Box(new Color(Fz.Dark, 0.62f), Ui.Line, 1, 0, true);
            var sbh = Fz.Box(new Color(Fz.Dark, 0.75f), Fz.Red, 2, 0, true);
            foreach (var b in new Button[] { bCam, bMenu })
            {
                b.AddThemeStyleboxOverride("normal", sb); b.AddThemeStyleboxOverride("hover", sbh); b.AddThemeStyleboxOverride("pressed", sbh);
                b.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
            }
            bCam.Pressed += () => g.CycleCamera();
            bMenu.Pressed += () => ShowMenu(!menu.Visible);
            var row = Ui.Row(12);
            row.AddChild(bCam); row.AddChild(bMenu);
            row.SetAnchorsPreset(Control.LayoutPreset.TopRight);
            row.Position = new Vector2(-24 - 76 * 2 - 12, 18);
            row.GrowHorizontal = Control.GrowDirection.Begin;
            row.Name = "TopRight";
            Root.AddChild(row);
            topRow = row;
        }
        HBoxContainer topRow;

        // keep the top-right buttons clear of a notch
        public void Layout(Vector2 size, float safeR)
        {
            float right = 24 + safeR;
            topRow.Position = new Vector2(size.X - right - 76 * 2 - 12, 18);
            menu.Position = new Vector2(size.X - right - MenuW, 104);
            menu.Size = new Vector2(MenuW, Math.Min(menuCol.GetCombinedMinimumSize().Y + 28, size.Y - 120));
        }

        const float MenuW = 410;

        /* ---------------- menu ---------------- */
        void BuildMenu()
        {
            menu = new PanelContainer { Visible = false, Name = "Menu" };
            var ps = Fz.Box(new Color(Fz.Dark, 0.97f), Ui.Line, 1, 12);
            ps.BorderWidthTop = 3; ps.BorderColor = Fz.Red;
            menu.AddThemeStyleboxOverride("panel", ps);
            var scroll = new ScrollContainer { HorizontalScrollMode = ScrollContainer.ScrollMode.Disabled, CustomMinimumSize = new Vector2(MenuW - 24, 0) };
            var col = Ui.Col(6);
            col.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
            scroll.AddChild(Ui.Pad(col, 2, 2, 8, 2));
            menu.AddChild(scroll);
            menuCol = col;

            var top = Ui.Row(6);
            foreach (var (label, act) in new (string, Action)[] { ("Settings", () => g.OpenSettings(0)), ("Main menu", () => g.OpenMainMenu()) })
            {
                var a = act;
                var b = Fz.Btn(label, () => { ShowMenu(false); a(); }, Fz.Look.Plain, 46, 16);
                b.FocusMode = Control.FocusModeEnum.None;
                b.SizeFlagsHorizontal = Control.SizeFlags.ExpandFill;
                top.AddChild(b);
            }
            col.AddChild(top);
            col.AddChild(Heading("Car"));
            carSeg = Fz.Options(new[] { "Rust", "Monte", "CTS-V", "Civic" }, (i) => { g.SwitchCar(Defs.CarOrder[i]); Sync(); }, 44);
            foreach (var b in carSeg.Items) b.FocusMode = Control.FocusModeEnum.None;
            col.AddChild(carSeg.Root);
            col.AddChild(Heading("Map"));
            mapBox = Ui.Col(6);
            col.AddChild(mapBox);
            BuildMapButtons();
            col.AddChild(Gap(4));
            MenuItem(col, "Tuning", () => g.OpenTuning());
            MenuItem(col, "Free camera", () => g.FreeCamera());
            MenuItem(col, "Reset car", () => g.ResetCar(false));
            MenuItem(col, "Back to start", () => g.ResetCar(true));
            mTrack = MenuItem(col, "Race track grid", () => { if (g.IsStage) g.StageStart(false); else g.ToGrid(); });
            mTrackDown = MenuItem(col, "Stage start: downhill", () => g.StageStart(true));
            // the map's start points, two to a row (only maps that have them)
            spotHead = Heading("Go to");
            col.AddChild(spotHead);
            spotBox = Ui.Col(6);
            col.AddChild(spotBox);
            MenuItem(col, "How to play", () => g.OpenHowTo());
            Root.AddChild(menu);
        }

        static Label Heading(string s)
        {
            var l = Fz.Title(s, 16, Fz.Red);
            return l;
        }

        static Control Gap(float h) => new Control { CustomMinimumSize = new Vector2(0, h), MouseFilter = Control.MouseFilterEnum.Ignore };

        // the installed maps two to a row, and a way to get more at the end
        void BuildMapButtons()
        {
            foreach (var c in mapBox.GetChildren()) { mapBox.RemoveChild(c); c.QueueFree(); }
            mapBtns.Clear();
            mapIds = Defs.MapOrder;
            var labels = new List<string>();
            foreach (var id in mapIds) labels.Add(Defs.Maps[id].Short);
            labels.Add("More maps…");
            var ids = mapIds;
            for (int r = 0; r * 2 < labels.Count; r++)
            {
                int first = r * 2;
                var row = Fz.Options(labels.GetRange(first, Math.Min(2, labels.Count - first)).ToArray(), (k) =>
                {
                    int i = first + k;
                    if (i < ids.Length) { g.SwitchMap(ids[i]); Sync(); }
                    else { ShowMenu(false); g.OpenMaps(); }
                }, 42);
                foreach (var b in row.Items) { b.FocusMode = Control.FocusModeEnum.None; mapBtns.Add(b); }
                mapBox.AddChild(row.Root);
            }
        }

        public void MapsChanged() { BuildMapButtons(); Sync(); }

        void SyncSpots()
        {
            var spots = g.Spots;
            string sig = g.MapId + ":" + string.Join("|", spots);
            if (sig == spotSig) return;
            spotSig = sig;
            foreach (var c in spotBox.GetChildren()) { spotBox.RemoveChild(c); c.QueueFree(); }
            for (int r = 0; r * 2 < spots.Length; r++)
            {
                int first = r * 2;
                var labels = new List<string>();
                for (int i = first; i < Math.Min(first + 2, spots.Length); i++) labels.Add(spots[i]);
                Fz.Tabs row = null;
                row = Fz.Options(labels.ToArray(), (k) => { foreach (var b in row.Items) b.SetPressedNoSignal(false); ShowMenu(false); g.ToSpot(first + k); }, 42);
                foreach (var b in row.Items) b.FocusMode = Control.FocusModeEnum.None;
                spotBox.AddChild(row.Root);
            }
            spotHead.Visible = spotBox.Visible = spots.Length > 0;
        }

        Button MenuItem(VBoxContainer col, string text, Action a)
        {
            var b = Fz.Btn(text, () => { ShowMenu(false); a(); }, Fz.Look.Flat, 50, 18);
            b.FocusMode = Control.FocusModeEnum.None;
            b.Alignment = HorizontalAlignment.Left;
            col.AddChild(b);
            return b;
        }

        public void ShowMenu(bool on) { menu.Visible = on; g.PanelsChanged(); }

        public void CloseAll() { menu.Visible = false; g.PanelsChanged(); }

        // a touch at p lands on an open panel (so the driving controls ignore it)
        public bool Covers(Vector2 p)
        {
            foreach (Control c in new Control[] { menu, topRow })
                if (c.Visible && c.GetGlobalRect().HasPoint(p)) return true;
            return false;
        }

        public void TapOutside(Vector2 p)
        {
            if (menu.Visible && !menu.GetGlobalRect().HasPoint(p) && !topRow.GetGlobalRect().HasPoint(p)) ShowMenu(false);
        }

        /* ---------------- sync every control to the current state ---------------- */
        public void Sync()
        {
            var car = g.Car;
            if (car == null) return;
            carSeg.Select(Math.Max(0, Array.IndexOf(Defs.CarOrder, g.CarId)));
            int mi = Array.IndexOf(mapIds, g.MapId);
            for (int i = 0; i < mapBtns.Count; i++) mapBtns[i].SetPressedNoSignal(i == mi);
            mTrack.Text = (g.IsStage ? "Stage start: uphill" : g.MapId == "grid" ? "Race track grid" : "Starting grid").ToUpperInvariant();
            mTrackDown.Visible = g.IsStage;
            SyncSpots();
        }
    }
}
