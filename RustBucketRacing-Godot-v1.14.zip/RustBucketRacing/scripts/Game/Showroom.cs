// The garage studio: a turntable under soft lights in a world of its own, drawn into a texture that the menus sit
// on. The car on it is the game's own model, borrowed from the main scene while the studio is showing and given
// back after, posed by a display copy of the car settled on its springs on a flat floor.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Render;
using RustBucket.Sim;

namespace RustBucket.Game
{
    // a level floor at y = 0 for the display cars
    sealed class FlatTerrain : TerrainBase
    {
        public override double Height(double x, double z) => 0;
        public override double HeightVis(double x, double z) => 0;
        public override V3 Normal(double x, double z) => V3.UnitY;
        public override Surf Surface(double x, double z) => Surf.Tarmac;
        public override double Raycast(V3 o, V3 d, double maxT)
        {
            if (o.Y <= 0) return 0;
            if (d.Y >= 0) return -1;
            double t = -o.Y / d.Y;
            return t <= maxT ? t : -1;
        }
    }

    public sealed class Showroom
    {
        public const float TableR = 3.05f;
        public readonly SubViewport Vp;
        public readonly TextureRect View;
        readonly Node3D spinner;
        readonly Camera3D cam;
        readonly MeshInstance3D contact;
        readonly FlatTerrain flat = new FlatTerrain();
        readonly Dictionary<string, Car> poses = new Dictionary<string, Car>();
        readonly Func<string, CarView> borrow;      // the main scene's model of a car (made if need be)
        readonly Action<string, CarView> giveBack;  // ... and back it goes
        string id;
        CarView view;
        double yaw = Math.PI - 0.7, pitch = 0.16, dist = 8, distMin = 5, distMax = 14, distDef = 8, idle = 99;
        double camY = 0.6;
        public bool AutoSpin = true;     // turn slowly by itself when nobody is turning it
        public double SpinSpeed = 0.16;  // rad/s
        public float Shift;              // where the car sits across the picture: -1 left .. 1 right
        public double Back = 1;          // camera further back than the framing (the garage has panels both sides)
        public bool Active { get; private set; }
        public string CarId => id;

        public Showroom(Node parent, Func<string, CarView> borrow, Action<string, CarView> giveBack)
        {
            this.borrow = borrow; this.giveBack = giveBack;
            bool mobile = OS.HasFeature("mobile");
            Vp = new SubViewport
            {
                Name = "Studio", OwnWorld3D = true, TransparentBg = false,
                Msaa3D = mobile ? Viewport.Msaa.Msaa2X : Viewport.Msaa.Msaa4X,
                RenderTargetUpdateMode = SubViewport.UpdateMode.Disabled,
                Size = new Vector2I(1280, 720),
            };
            parent.AddChild(Vp);
            View = new TextureRect
            {
                Name = "StudioView", Texture = Vp.GetTexture(), ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize,
                StretchMode = TextureRect.StretchModeEnum.Scale, MouseFilter = Control.MouseFilterEnum.Ignore, Visible = false,
            };
            View.SetAnchorsPreset(Control.LayoutPreset.FullRect);

            // light: a big soft box overhead (the sky, for reflections and ambient), a key light with shadows, a
            // cool fill from behind on the other side, and a warm pool on the turntable
            // the sky is the backdrop too: a soft grey cove, the floor fading into its horizon colour in the fog
            var horizon = new Color(0.15f, 0.165f, 0.19f);
            var sky = new ProceduralSkyMaterial
            {
                SkyTopColor = new Color(0.58f, 0.62f, 0.68f), SkyHorizonColor = horizon, SkyCurve = 0.3f,
                GroundHorizonColor = horizon, GroundBottomColor = horizon,
                SunAngleMax = 1, SkyEnergyMultiplier = 1,
            };
            var bg = horizon;
            var env = new Godot.Environment
            {
                BackgroundMode = Godot.Environment.BGMode.Sky,
                Sky = new Sky { SkyMaterial = sky },
                AmbientLightSource = Godot.Environment.AmbientSource.Sky, AmbientLightSkyContribution = 1, AmbientLightEnergy = 0.55f,
                ReflectedLightSource = Godot.Environment.ReflectionSource.Sky,
                TonemapMode = Godot.Environment.ToneMapper.Aces, TonemapExposure = 1.05f,
                FogEnabled = true, FogLightColor = bg, FogDensity = 0.04f, FogSkyAffect = 0,
            };
            Vp.AddChild(new WorldEnvironment { Environment = env });
            var key = new DirectionalLight3D
            {
                LightEnergy = 1.5f, LightColor = new Color(1f, 0.96f, 0.9f), ShadowEnabled = true,
                DirectionalShadowMode = DirectionalLight3D.ShadowMode.Orthogonal, DirectionalShadowMaxDistance = 22,
                ShadowBias = 0.03f, ShadowNormalBias = 1.0f, ShadowBlur = 1.6f,
            };
            Vp.AddChild(key);
            key.LookAtFromPosition(Vector3.Zero, new Vector3(-0.45f, -0.8f, -0.4f), Vector3.Up);
            var fill = new DirectionalLight3D { LightEnergy = 0.45f, LightColor = new Color(0.62f, 0.74f, 1f) };
            Vp.AddChild(fill);
            fill.LookAtFromPosition(Vector3.Zero, new Vector3(0.6f, -0.35f, 0.7f), Vector3.Up);
            var pool = new OmniLight3D { Position = new Vector3(0, 5.5f, 0), OmniRange = 11, LightEnergy = 1.1f, LightColor = new Color(1f, 0.86f, 0.66f), OmniAttenuation = 1.4f };
            Vp.AddChild(pool);

            // floor (fades into the dark with the fog), the turntable, its lit rim and the marks that show it turn
            var floorMat = new StandardMaterial3D { AlbedoColor = new Color(0.075f, 0.08f, 0.09f), Roughness = 0.6f, Metallic = 0.15f };
            Vp.AddChild(new MeshInstance3D { Mesh = new PlaneMesh { Size = new Vector2(800, 800) }, MaterialOverride = floorMat, Position = new Vector3(0, -0.16f, 0) });
            spinner = new Node3D { Name = "Turntable" };
            Vp.AddChild(spinner);
            var discMat = new StandardMaterial3D { AlbedoColor = new Color(0.16f, 0.17f, 0.18f), Roughness = 0.34f, Metallic = 0.65f };
            spinner.AddChild(new MeshInstance3D
            {
                Mesh = new CylinderMesh { TopRadius = TableR, BottomRadius = TableR + 0.06f, Height = 0.16f, RadialSegments = 96, Rings = 1 },
                MaterialOverride = discMat, Position = new Vector3(0, -0.08f, 0), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
            });
            var rimMat = new StandardMaterial3D { AlbedoColor = Fz.Red, EmissionEnabled = true, Emission = Fz.Red, EmissionEnergyMultiplier = 1.6f, ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded };
            spinner.AddChild(new MeshInstance3D
            {
                Mesh = new TorusMesh { InnerRadius = TableR - 0.03f, OuterRadius = TableR + 0.025f, Rings = 96, RingSegments = 6 },
                MaterialOverride = rimMat, Position = new Vector3(0, 0.005f, 0), Scale = new Vector3(1, 0.4f, 1), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
            });
            var markMat = new StandardMaterial3D { AlbedoColor = new Color(0.32f, 0.34f, 0.36f), Roughness = 0.5f, Metallic = 0.3f };
            var markMesh = new BoxMesh { Size = new Vector3(0.035f, 0.004f, 0.42f) };
            for (int i = 0; i < 24; i++)
            {
                float a = i * Mathf.Tau / 24;
                var m = new MeshInstance3D { Mesh = markMesh, MaterialOverride = markMat, CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
                m.Transform = new Transform3D(new Basis(Vector3.Up, a), new Basis(Vector3.Up, a) * new Vector3(0, 0.002f, TableR - 0.32f));
                spinner.AddChild(m);
            }
            // soft contact shadow under the car (the stand-in's shadow is blocky close up)
            var grad = new Gradient { Colors = new[] { new Color(0, 0, 0, 0.78f), new Color(0, 0, 0, 0.45f), new Color(0, 0, 0, 0) }, Offsets = new[] { 0f, 0.55f, 1f } };
            var tex = new GradientTexture2D { Gradient = grad, Fill = GradientTexture2D.FillEnum.Radial, FillFrom = new Vector2(0.5f, 0.5f), FillTo = new Vector2(1f, 0.5f), Width = 128, Height = 128 };
            var shMat = new StandardMaterial3D
            {
                AlbedoTexture = tex, Transparency = BaseMaterial3D.TransparencyEnum.Alpha, ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded,
                CullMode = BaseMaterial3D.CullModeEnum.Disabled,
            };
            contact = new MeshInstance3D { Mesh = new PlaneMesh { Size = new Vector2(1, 1) }, MaterialOverride = shMat, Position = new Vector3(0, 0.006f, 0), CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
            spinner.AddChild(contact);

            cam = new Camera3D { Fov = 34, Near = 0.1f, Far = 120, Current = true };
            Vp.AddChild(cam);
        }

        // studio on (drawing) or off (the car goes back to the game)
        public void SetActive(bool on)
        {
            if (on == Active) return;
            Active = on;
            View.Visible = on;
            Vp.RenderTargetUpdateMode = on ? SubViewport.UpdateMode.Always : SubViewport.UpdateMode.Disabled;
            if (!on) Release();
        }

        void Release()
        {
            if (view == null) return;
            var v = view; string vid = id;
            view = null; id = null;
            giveBack(vid, v);
        }

        // put a car on the turntable (its model loads first if the game hasn't shown it yet)
        public void Show(string carId)
        {
            if (carId == id && view != null) return;
            Release();
            var d = Defs.Cars[carId];
            var v = borrow(carId);
            if (v == null) return;
            v.Root.Reparent(spinner, false);
            v.Root.Transform = Transform3D.Identity;
            v.SetVisible(true);
            v.SetInside(false, d.GlassInside);
            var pose = Pose(carId);
            v.Update(pose, d.SteerRatio);
            view = v; id = carId;
            // frame the car: the contact shadow under its body, the camera back far enough to see all of it
            var s = d.Spec;
            double len = s.HullMaxZ - s.HullMinZ, wid = s.HullMaxX - s.HullMinX;
            contact.Scale = new Vector3((float)(wid * 1.32), 1, (float)(len * 1.18));
            contact.Position = new Vector3(0, 0.006f, (float)((s.HullMaxZ + s.HullMinZ) / 2));
            camY = s.HullMaxY * 0.4;
            distDef = len * 1.45 + 1.4;
            distMin = len * 0.85 + 1.2; distMax = len * 2.6 + 2;
            if (dist < distMin || dist > distMax || Math.Abs(dist - distDef) > 0.01 && idle > 30) dist = distDef;
        }

        // a display copy of the car on the flat floor, brakes on and the front wheels turned a little, settled on
        // its springs for three quarters of a second
        Car Pose(string carId)
        {
            if (poses.TryGetValue(carId, out var c)) return c;
            var spec = Defs.Cars[carId].Spec;
            c = new Car(flat, spec.DefaultTune.Clone(), spec);
            c.Reset(V3.Zero, 0);
            var inp = new DriveInput { Brake = 1, Handbrake = 1, Steer = 0.38 };
            for (int i = 0; i < 360; i++) c.Step(1.0 / 480, inp);
            c.Vel = V3.Zero; c.AngVel = V3.Zero;
            poses[carId] = c;
            return c;
        }

        // turn the platform (dx) and look from higher or lower (dy), in radians
        public void Turn(double dx, double dy)
        {
            yaw += dx;
            pitch = Math.Clamp(pitch + dy, 0.02, 1.1);
            idle = 0;
        }

        public void Zoom(double k)
        {
            dist = Math.Clamp(dist * k, distMin, distMax);
            idle = 0;
        }

        // a set view (the pictures for the menus' tiles): the platform's turn, the camera's height, how far back
        public void Pose(double yaw, double pitch, double distK)
        {
            this.yaw = yaw; this.pitch = pitch;
            dist = Math.Clamp(distDef * distK, distMin * 0.4, distMax);
            idle = 0; AutoSpin = false;
        }

        public void ResetView()
        {
            yaw = Math.PI - 0.7; pitch = 0.16; dist = distDef; idle = 99;
        }

        public void Update(double dt, Vector2 screen)
        {
            if (!Active) return;
            // draw at the size of the screen in real pixels (the menus' canvas is stretched to it)
            var win = DisplayServer.WindowGetSize();
            var want = win.X > 0 && win.Y > 0 ? win : new Vector2I((int)screen.X, (int)screen.Y);
            if (OS.HasFeature("mobile")) want = new Vector2I((int)(want.X * 0.85f), (int)(want.Y * 0.85f));
            if (Vp.Size != want && want.X > 16 && want.Y > 16) Vp.Size = want;
            idle += dt;
            if (AutoSpin && idle > 3) yaw += SpinSpeed * dt * Math.Min(1, (idle - 3) / 1.5);
            if (yaw > Math.PI * 4) yaw -= Math.PI * 2;
            if (yaw < -Math.PI * 4) yaw += Math.PI * 2;
            spinner.Rotation = new Vector3(0, (float)yaw, 0);
            // the camera orbits in a fixed direction; the platform does the turning
            var target = new Vector3(0, (float)camY, 0);
            double cy = Math.Cos(pitch), sy = Math.Sin(pitch);
            double dd = dist * Back;
            var pos = target + new Vector3(0, (float)(sy * dd), (float)(cy * dd));
            cam.LookAtFromPosition(pos, target, Vector3.Up);
            // shift the picture sideways so the car sits beside the menus rather than under them
            float aspect = Vp.Size.Y > 0 ? (float)Vp.Size.X / Vp.Size.Y : 1.78f;
            float halfW = (float)(dd * Math.Tan(cam.Fov * Math.PI / 360)) * aspect;
            cam.HOffset = -Shift * halfW;
        }
    }
}
