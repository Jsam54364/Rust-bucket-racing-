// HUD: analogue instrument cluster with gear, assist lamps and the lap timer (bottom centre), optional chassis
// telemetry with the grip map (top left), toasts (top centre) and the loading pill.
using System;
using System.Collections.Generic;
using Godot;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public partial class Hud : Control
    {
        public Car Car;
        public bool Kmh = true;
        public bool Telemetry;
        public bool LapShow, LapValid;
        public string LapLabel = "LAP"; // UP / DOWN on a stage
        public double LapTime, LapBest = double.NaN;
        public string Loading = "";
        public float BottomLift; // keep the cluster above the touch controls when they crowd the middle
        public Action OnUnits = () => { };
        string toast = ""; double toastT;
        Button unitBtn;
        Rect2 clusterRect, speedRect;

        public override void _Ready()
        {
            MouseFilter = MouseFilterEnum.Ignore;
            SetAnchorsAndOffsetsPreset(LayoutPreset.FullRect);
            // tap the speed readout to switch km/h and mph
            unitBtn = new Button { Flat = true, FocusMode = FocusModeEnum.None, MouseFilter = MouseFilterEnum.Stop };
            var empty = new StyleBoxEmpty();
            foreach (var st in new[] { "normal", "hover", "pressed", "hover_pressed", "focus" }) unitBtn.AddThemeStyleboxOverride(st, empty);
            unitBtn.Pressed += () => OnUnits();
            AddChild(unitBtn);
        }

        public void Toast(string msg) { toast = msg; toastT = 1.6; }

        public override void _Process(double delta)
        {
            if (toastT > 0) toastT -= delta;
            QueueRedraw();
        }

        static string Sgn(double v) => (v >= 0 ? "+" : "-") + Math.Abs(v).ToString("0.0") + "°";

        void Text(Font f, string s, Vector2 pos, int size, Color c) => DrawString(f, pos, s, HorizontalAlignment.Left, -1, size, c);
        static float W(Font f, string s, int size) => f.GetStringSize(s, HorizontalAlignment.Left, -1, size).X;

        public override void _Draw()
        {
            var size = Size;
            if (Car != null) DrawCluster(size);
            if (Car != null && Telemetry) DrawTelemetry();
            if (toastT > 0 && toast.Length > 0)
            {
                float a = Mathf.Round((float)Math.Min(1, toastT / 0.25) * 10) / 10f;
                var f = Ui.Body; int fs = 22;
                float w = W(f, toast, fs) + 36;
                float y = Telemetry ? 268 : 20;
                var r = new Rect2(size.X / 2 - w / 2, y, w, 46);
                DrawStyleBox(Ui.Cached(new Color(Ui.Panel, 0.95f * a), 23, new Color(Ui.Line, Ui.Line.A * a), 1), r);
                Text(f, toast, new Vector2(r.Position.X + 18, r.Position.Y + 31), fs, new Color(Ui.Ink, a));
            }
            if (Loading.Length > 0)
            {
                var f = Ui.Body; int fs = 19;
                string s = Loading.ToUpperInvariant();
                float w = W(f, s, fs) + 40;
                var r = new Rect2(size.X / 2 - w / 2, size.Y * 0.5f - 24, w, 48);
                DrawStyleBox(Ui.Cached(Ui.Panel, 24, Ui.Line, 1), r);
                Text(f, s, new Vector2(r.Position.X + 20, r.Position.Y + 31), fs, Ui.Muted);
            }
        }

        /* ---------------- instrument cluster ----------------
           Three round dials in a row at the bottom, between the thumbs when the touch controls are up:
           revs on the left, speed in the middle (on top), gear / mode / lap / assist lamps on the right with the
           throttle and brake on its outer edge. Semi-transparent faces with a blue rim. Tap the speedometer to
           switch km/h and mph. */
        public double SpeedoKmh = 200, SpeedoMph = 120;
        public double Thr, Brk;          // pedal positions for the right dial
        public float BandL, BandR = -1;  // free strip between the touch controls (BandR < 0: the whole width)

        static readonly Color GFace = new Color(0.015f, 0.025f, 0.055f, 0.58f);
        static readonly Color GRim = new Color(0.27f, 0.5f, 1f, 0.95f), GGlow = new Color(0.27f, 0.5f, 1f, 0.22f);
        static readonly Color GTick = new Color(1, 1, 1, 0.92f), GMinor = new Color(1, 1, 1, 0.55f);
        static readonly Color GRed = new Color(1f, 0.18f, 0.12f), GNeedle = new Color(1f, 0.22f, 0.12f);
        static readonly Color GHub = new Color(0.08f, 0.09f, 0.11f, 0.95f), GHubRim = new Color(1, 1, 1, 0.35f);
        static readonly Color GThr = new Color(0.28f, 0.83f, 0.54f, 0.95f), GBrk = new Color(1f, 0.36f, 0.24f, 0.95f), GTrack = new Color(1, 1, 1, 0.12f);
        static readonly string[] Num = MakeNums();
        static string[] MakeNums() { var a = new string[401]; for (int i = 0; i < a.Length; i++) a[i] = i.ToString(); return a; }
        static string N(double v) { int i = (int)Math.Round(v); return i >= 0 && i < Num.Length ? Num[i] : i.ToString(); }

        // face outlines are cached per layout; nothing is allocated per frame
        Vector2 faceKeyC; float faceKeyS = -1;
        Vector2[] faceL, faceR, faceC, rimL, rimR, glowL, glowR;
        readonly Vector2[] needleBuf = new Vector2[4];
        double rpmSm, spdSm;

        static Vector2 Pt(Vector2 c, double angDeg, float rad)
        {
            double a = angDeg * Math.PI / 180;
            return c + new Vector2((float)Math.Cos(a), (float)-Math.Sin(a)) * rad;
        }

        void Txt(Font f, string s, Vector2 at, int fs, Color col)
        {
            float w = f.GetStringSize(s, HorizontalAlignment.Left, -1, fs).X;
            DrawString(f, at + new Vector2(-w / 2, fs * 0.36f), s, HorizontalAlignment.Left, -1, fs, col);
        }

        // a side dial's outline with the part behind the centre dial cut away, its rim and glow
        static void SideFace(Vector2 c, float r, Vector2 cutC, float cutR, out Vector2[] poly, out Vector2[] rim, out Vector2[] glow)
        {
            float d = c.DistanceTo(cutC);
            double toward = Math.Atan2(-(cutC.Y - c.Y), cutC.X - c.X) * 180 / Math.PI;
            double phi = Math.Acos(Math.Clamp((d * d + r * r - cutR * cutR) / (2.0 * d * r), -1, 1)) * 180 / Math.PI;
            const int n = 48, m = 12;
            poly = new Vector2[n + 1 + m - 1]; rim = new Vector2[n + 1]; glow = new Vector2[n + 1];
            for (int i = 0; i <= n; i++)
            {
                double a = toward + phi + (360 - 2 * phi) * i / n;
                poly[i] = Pt(c, a, r); rim[i] = poly[i]; glow[i] = Pt(c, a, r + 2.5f);
            }
            double a0 = Math.Atan2(-(poly[n].Y - cutC.Y), poly[n].X - cutC.X) * 180 / Math.PI;
            double a1 = Math.Atan2(-(poly[0].Y - cutC.Y), poly[0].X - cutC.X) * 180 / Math.PI;
            double span = a1 - a0; while (span > 180) span -= 360; while (span < -180) span += 360;
            for (int i = 1; i < m; i++) poly[n + i] = Pt(cutC, a0 + span * i / m, cutR);
        }

        void Needle(Vector2 c, double ang, float len, float w)
        {
            var tip = Pt(c, ang, len); var back = Pt(c, ang + 180, len * 0.14f);
            var side = (tip - c).Normalized().Orthogonal() * w;
            needleBuf[0] = back + side * 0.9f; needleBuf[1] = tip + side * 0.15f; needleBuf[2] = tip - side * 0.15f; needleBuf[3] = back - side * 0.9f;
            DrawColoredPolygon(needleBuf, GNeedle);
            DrawCircle(c, w * 1.6f, GHub);
            DrawArc(c, w * 1.6f, 0, Mathf.Tau, 20, GHubRim, 1.2f, true);
        }

        void DrawCluster(Vector2 size)
        {
            var car = Car; var tel = car.Tel; var e = car.Engine; var S = car.Spec;
            var fd = Ui.Display;
            float dt = (float)Math.Min(0.1, GetProcessDeltaTime());
            // layout: fit between the touch controls; shrink a little if the gap is narrow, lift it above them if very narrow
            const float R0 = 86, r0 = 63, dx0 = 134, W0 = 2 * (dx0 + r0);
            float bl = BandR < 0 ? 0 : BandL, br = BandR < 0 ? size.X : BandR;
            float s = Math.Clamp((br - bl - 16) / W0, 0.68f, 1f);
            float cx = (bl + br) / 2, bottom = size.Y - 12;
            if (br - bl - 16 < 0.68f * W0) { s = 0.8f; cx = size.X / 2; bottom = size.Y - 12 - BottomLift; }
            float R = R0 * s, r = r0 * s, dx = dx0 * s;
            var c = new Vector2(cx, bottom - R);
            var cl = c + new Vector2(-dx, 14 * s); var cr = c + new Vector2(dx, 14 * s);
            if (faceKeyS != s || faceKeyC != c)
            {
                faceKeyS = s; faceKeyC = c;
                SideFace(cl, r, c, R + 4 * s, out faceL, out rimL, out glowL);
                SideFace(cr, r, c, R + 4 * s, out faceR, out rimR, out glowR);
                faceC = new Vector2[64];
                for (int i = 0; i < 64; i++) faceC[i] = Pt(c, i * 360.0 / 64, R);
            }
            clusterRect = new Rect2(cl.X - r, c.Y - R, 2 * (dx + r), 2 * R);

            // ---- revs (left): zero just right of the bottom, up the left side and over the top
            DrawColoredPolygon(faceL, GFace);
            DrawPolyline(glowL, GGlow, 6 * s, true); DrawPolyline(rimL, GRim, 2.2f * s, true);
            rpmSm = M.Lerp(rpmSm, e.Rpm, 1 - Math.Exp(-dt * 30));
            double tmax = Math.Ceiling((S.Limiter + 400) / 1000);
            const double TA0 = -75, TSW = 215;
            int tq = (int)(tmax * 4);
            for (int k = 0; k <= tq; k++)
            {
                double v = k * 250, a = TA0 - TSW * v / (tmax * 1000);
                bool red = v >= S.Redline, major = k % 4 == 0;
                DrawLine(Pt(cl, a, r - (major ? 11 : 6) * s), Pt(cl, a, r - 3 * s), red ? GRed : major ? GTick : GMinor, (major ? 2.2f : 1.2f) * s, true);
                if (major) Txt(fd, N(v / 1000), Pt(cl, a, r - 21 * s), (int)(14 * s), red ? GRed : GTick);
            }
            Txt(fd, "x1000 rpm", cl + new Vector2(14 * s, 21 * s), (int)(9 * s), GMinor);
            // shift light: on near the redline, flashing on the limiter
            bool flash = e.LimiterCut && (Time.GetTicksMsec() / 90) % 2 == 0;
            if (e.Rpm > S.Redline - 250 && !flash) DrawCircle(cl + new Vector2(0, -r * 0.42f), 4.5f * s, e.OverRev ? Ui.Hot : GRed);
            Needle(cl, TA0 - TSW * M.Clamp(rpmSm / (tmax * 1000), 0, 1.02), r - 8 * s, 3.2f * s);

            // ---- right dial: gear and mode, lap, assist lamps; throttle and brake on the outer edge
            DrawColoredPolygon(faceR, GFace);
            DrawPolyline(glowR, GGlow, 6 * s, true); DrawPolyline(rimR, GRim, 2.2f * s, true);
            float aTop = Mathf.DegToRad(-40), aBot = Mathf.DegToRad(40); // Godot angles run clockwise: -40 is up-right
            DrawArc(cr, r - 6 * s, aBot, aTop, 24, GTrack, 4 * s, true);
            if (Thr > 0.01) DrawArc(cr, r - 6 * s, aBot, aBot - (aBot - aTop) * (float)M.Clamp(Thr, 0, 1), 24, GThr, 4 * s, true);
            if (Brk > 0.01) DrawArc(cr, r - 12 * s, aBot, aBot - (aBot - aTop) * (float)M.Clamp(Brk, 0, 1), 24, GBrk, 4 * s, true);
            int gn = e.Shift != null ? e.Shift.To : e.Gear;
            string gear = gn < 0 ? "R" : gn == 0 ? "N" : N(gn);
            string mode = car.Tune.Gearbox == Gearbox.Auto ? "AUTO" : car.Tune.Gearbox == Gearbox.Semi ? "SEMI" : "MAN";
            Txt(fd, gear, cr + new Vector2(6 * s, -12 * s), (int)(42 * s), Ui.Amber);
            Txt(fd, mode, cr + new Vector2(6 * s, 15 * s), (int)(11 * s), GMinor);
            if (LapShow)
            {
                Txt(fd, LapLabel + " " + LapTimer.Fmt(LapTime), cr + new Vector2(4 * s, 31 * s), (int)(12 * s), LapValid ? GTick : GMinor);
                Txt(fd, "BEST " + LapTimer.Fmt(LapBest, 2), cr + new Vector2(4 * s, 44 * s), (int)(10 * s), GMinor);
            }
            int nl = (tel.AbsActive ? 1 : 0) + (tel.TcsActive ? 1 : 0) + (tel.CsActive ? 1 : 0);
            float lx = cr.X - 26 * s * (nl - 1) / 2f + 6 * s, ly = cr.Y - 42 * s;
            if (tel.AbsActive) { Txt(fd, "ABS", new Vector2(lx, ly), (int)(11 * s), Ui.Amber); lx += 26 * s; }
            if (tel.TcsActive) { Txt(fd, "TCS", new Vector2(lx, ly), (int)(11 * s), Ui.Amber); lx += 26 * s; }
            if (tel.CsActive) { Txt(fd, "CS", new Vector2(lx, ly), (int)(11 * s), Ui.Amber); }

            // ---- speed (centre, drawn last so it sits on top)
            DrawColoredPolygon(faceC, GFace);
            DrawArc(c, R + 2.5f * s, 0, Mathf.Tau, 72, GGlow, 6 * s, true);
            DrawArc(c, R, 0, Mathf.Tau, 72, GRim, 2.2f * s, true);
            double smax = Kmh ? SpeedoKmh : SpeedoMph, step = smax <= 240 ? 20 : 40, minor = step / 4;
            const double SA0 = 225, SSW = 270;
            int ns = (int)Math.Round(smax / minor);
            for (int k = 0; k <= ns; k++)
            {
                double v = k * minor, a = SA0 - SSW * v / smax;
                bool major = k % 4 == 0, mid = k % 2 == 0;
                DrawLine(Pt(c, a, R - (major ? 13 : mid ? 9 : 6) * s), Pt(c, a, R - 3 * s), major ? GTick : GMinor, (major ? 2.4f : 1.2f) * s, true);
                if (major) Txt(fd, N(v), Pt(c, a, R - 25 * s), (int)(14 * s), GTick);
            }
            double sp = Math.Abs(tel.Speed) * (Kmh ? 3.6 : 2.23694);
            spdSm = M.Lerp(spdSm, sp, 1 - Math.Exp(-dt * 20));
            Txt(fd, sp < 0.5 ? "0" : N(sp), c + new Vector2(0, 33 * s), (int)(27 * s), new Color(1, 1, 1, 0.95f));
            Txt(fd, Kmh ? "km/h" : "mph", c + new Vector2(0, 53 * s), (int)(11 * s), GMinor);
            Needle(c, SA0 - SSW * M.Clamp(spdSm / smax, 0, 1.02), R - 10 * s, 3.6f * s);
            speedRect = new Rect2(c - new Vector2(R, R), new Vector2(2 * R, 2 * R));
            unitBtn.Position = speedRect.Position; unitBtn.Size = speedRect.Size;
        }

        void DrawTelemetry()
        {
            var car = Car; var tel = car.Tel; var S = car.Spec;
            var fb = Ui.Body; var fd = Ui.Display;
            var panel = new Rect2(22, 18, 560, 236);
            DrawStyleBox(Ui.Cached(Ui.Glass, 16, Ui.Line, 1), panel);
            // grip map
            DrawGrip(new Rect2(panel.Position.X + 14, panel.Position.Y + 10, 150, 216));
            // suspension travel bars
            float bx0 = panel.Position.X + 180, top = panel.Position.Y + 30;
            string[] names = { "FL", "FR", "RL", "RR" };
            for (int i = 0; i < 4; i++)
            {
                var w = car.Wheels[i];
                float x = bx0 + i * 46;
                Text(fb, names[i], new Vector2(x + 2, top), 15, Ui.Muted);
                var tr = new Rect2(x + 6, top + 10, 20, 72);
                DrawStyleBox(Ui.Cached(new Color(1, 1, 1, 0.08f), 5, Ui.Line, 1), tr);
                double f = M.Clamp(w.X / w.L0, 0, 1);
                double st = M.Clamp((w.L0 - S.MountAbove) / w.L0, 0, 1);
                double over = (f - st) / Math.Max(1e-3, 1 - st);
                Color c = !w.Contact ? new Color(0.29f, 0.33f, 0.38f) : w.Grip > 1.15 ? Ui.Hot : over > 0.4 ? Ui.Amber : Ui.Cool;
                float fh = (float)(tr.Size.Y * f);
                if (fh > 0.5f) DrawRect(new Rect2(tr.Position.X + 1, tr.End.Y - fh, tr.Size.X - 2, fh), c);
                float my = tr.End.Y - (float)(tr.Size.Y * st);
                DrawLine(new Vector2(tr.Position.X - 3, my), new Vector2(tr.End.X + 3, my), new Color(1, 1, 1, 0.85f), 2);
                string load = w.Contact ? (w.Load / 1000).ToString("0.0") : "air";
                Text(fd, load, new Vector2(x + 16 - W(fd, load, 17) / 2, tr.End.Y + 22), 17, Ui.Ink);
            }
            // body attitude silhouette, rolled with the body
            var sc = new Vector2(bx0 + 22, panel.Position.Y + 160);
            DrawSilhouette(sc, tel.Roll * 180 / Math.PI);
            // values
            double rd = tel.Roll * 180 / Math.PI, pd = tel.Pitch * 180 / Math.PI;
            var cnt = new int[5];
            foreach (var w in car.Wheels) if (w.Contact) cnt[(int)w.Surface]++;
            int topS = -1; for (int i = 0; i < 5; i++) if (cnt[i] > 0 && (topS < 0 || cnt[i] > cnt[topS])) topS = i;
            var rows = new (string k, string v)[]
            {
                ("ROLL", Sgn(rd)), ("PITCH", Sgn(pd)), ("G", M.Hypot(tel.GLat, tel.GLong).ToString("0.00") + " g"),
                ("FRONT", tel.HasLoad ? Math.Round(tel.FrontLoad * 100) + "%" : "-"), ("SURFACE", topS >= 0 ? Surfaces.Table[topS].Name : "Air"),
            };
            float vx = panel.Position.X + 380, vy = panel.Position.Y + 50;
            foreach (var (k, v) in rows)
            {
                Text(fb, k, new Vector2(vx, vy), 15, Ui.Muted);
                Text(fd, v, new Vector2(panel.End.X - 16 - W(fd, v, 21), vy), 21, Ui.Ink);
                vy += 40;
            }
        }

        void DrawSilhouette(Vector2 c, double rollDeg)
        {
            float s = 1.25f;
            // ground line and tyres don't roll
            DrawLine(c + new Vector2(-56 * s, 12.5f * s), c + new Vector2(56 * s, 12.5f * s), new Color(1, 1, 1, 0.25f), 1);
            DrawStyleBox(Ui.Cached(new Color(0.165f, 0.192f, 0.22f), 4, new Color(1, 1, 1, 0.18f), 1), new Rect2(c + new Vector2(-43 * s, -5 * s), new Vector2(17 * s, 17 * s)));
            DrawStyleBox(Ui.Cached(new Color(0.165f, 0.192f, 0.22f), 4, new Color(1, 1, 1, 0.18f), 1), new Rect2(c + new Vector2(26 * s, -5 * s), new Vector2(17 * s, 17 * s)));
            float ang = (float)(Math.Clamp(rollDeg * 3, -24, 24) * Math.PI / 180);
            // body outline in the web SVG's coordinates (viewBox 120 x 56, pivot at 60, 40)
            Vector2[] body = { P(14, 26), P(19, 20), P(32, 19), P(40, 6), P(44, 4), P(76, 4), P(80, 6), P(88, 19), P(101, 20), P(106, 26), P(106, 39), P(103, 42), P(17, 42), P(14, 39) };
            Vector2[] glass = { P(44, 8), P(76, 8), P(83, 18), P(37, 18) };
            Vector2 P(float x, float y) => new Vector2(x - 60, y - 40);
            Vector2 Xf(Vector2 p) => c + p.Rotated(ang) * s;
            var b2 = new Vector2[body.Length]; for (int i = 0; i < body.Length; i++) b2[i] = Xf(body[i]);
            var g2 = new Vector2[glass.Length]; for (int i = 0; i < glass.Length; i++) g2[i] = Xf(glass[i]);
            DrawColoredPolygon(b2, new Color(0.722f, 0.278f, 0.18f));
            DrawColoredPolygon(g2, new Color(0.114f, 0.165f, 0.208f));
        }

        // Top-down grip map. Each tyre's circle is its friction circle: it grows and shrinks with the weight on
        // that tyre. The dot is the force the tyre is making now; at the rim the tyre is at its limit, red means
        // it is sliding. The diamond is where the weight sits, the small cross where it sits at rest.
        void DrawGrip(Rect2 area)
        {
            var car = Car; var S = car.Spec;
            float W0 = area.Size.X, H0 = area.Size.Y;
            double halfT = S.Hubs[1].X, zF = S.Hubs[0].Z, zR = S.Hubs[2].Z;
            float sc = (float)Math.Min((W0 - 4) / (2 * halfT + 0.9), (H0 - 4) / (zR - zF + 1.5));
            Vector2 Pt(double x, double z) => new Vector2(area.Position.X + W0 / 2 + (float)x * sc, area.Position.Y + H0 / 2 + (float)(z - (zF + zR) / 2) * sc);
            // body
            var bp = Pt(-halfT - 0.1, zF - 0.72);
            var br = new Rect2(bp, new Vector2((float)(2 * halfT + 0.2) * sc, (float)(zR - zF + 1.44) * sc));
            DrawStyleBox(Ui.Cached(new Color(0, 0, 0, 0), (int)(0.3f * sc), new Color(1, 1, 1, 0.2f), 1), br);
            float R0 = Math.Min(0.4f * sc, 20);
            foreach (var w in car.Wheels)
            {
                var p = Pt(w.HubModel.X, w.HubModel.Z);
                float d = (float)w.Steer;
                // tyre
                DrawSetTransform(p, -d, Vector2.One);
                DrawRect(new Rect2(-0.11f * sc, -0.3f * sc, 0.22f * sc, 0.6f * sc), new Color(0, 0, 0, 0.55f));
                DrawSetTransform(Vector2.Zero, 0, Vector2.One);
                if (!w.Contact || w.Cap <= 0) { DrawArc(p, R0 * 0.5f, 0, Mathf.Tau, 24, new Color(1, 1, 1, 0.18f), 1); continue; }
                // friction circle sized by the load on this tyre
                float r = R0 * (float)M.Clamp(w.Load / w.StaticLoad, 0.15, 1.85);
                DrawCircle(p, r, new Color(90 / 255f, 169 / 255f, 1, 0.22f));
                DrawArc(p, r, 0, Mathf.Tau, 40, new Color(120 / 255f, 186 / 255f, 1, 0.9f), 1.5f, true);
                // force in use
                double u = M.Hypot(w.Fx, w.Fy) / w.Cap, k = r / w.Cap;
                double fx = -Math.Sin(d), fy = -Math.Cos(d), rx = Math.Cos(d), ry = -Math.Sin(d);
                var q = p + new Vector2((float)((w.Fx * fx + w.Fy * rx) * k), (float)((w.Fx * fy + w.Fy * ry) * k));
                Color col = w.Grip > 1.12 ? Ui.Hot : u > 0.85 ? Ui.Amber : Ui.Hex(0xe9eef2);
                DrawLine(p, q, col, 2.5f);
                DrawCircle(q, 4, col);
            }
            // where the weight sits
            var s0 = Pt(0, S.ComZ);
            DrawLine(s0 - new Vector2(4, 0), s0 + new Vector2(4, 0), new Color(1, 1, 1, 0.45f), 1.5f);
            DrawLine(s0 - new Vector2(0, 4), s0 + new Vector2(0, 4), new Color(1, 1, 1, 0.45f), 1.5f);
            if (car.Tel.HasLoad)
            {
                var c = Pt(car.Tel.LoadCx, car.Tel.LoadCz);
                DrawLine(s0, c, new Color(Ui.Amber, 0.6f), 1.5f);
                DrawColoredPolygon(new[] { c + new Vector2(0, -7), c + new Vector2(7, 0), c + new Vector2(0, 7), c + new Vector2(-7, 0) }, Ui.Amber);
            }
        }
    }
}
