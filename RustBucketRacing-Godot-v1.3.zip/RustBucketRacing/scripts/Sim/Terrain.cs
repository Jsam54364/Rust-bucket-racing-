// Proving-ground terrain: a flat grid plane plus analytic height features (ramps, bumps, moguls, a banked
// bowl, loose-surface strips, kerbs, gravel traps) and the race circuit around it all.
// Every feature is a height function over a bounded region; the ground height is the max of all of them.
// The renderer samples the same functions, so what you see is exactly what the wheels touch.
using System;
using System.Collections.Generic;

namespace RustBucket.Sim
{
    public enum Surf { Tarmac = 0, Rumble = 1, Dirt = 2, Gravel = 3, Grass = 4 }

    public sealed class SurfInfo
    {
        public readonly string Name;
        public readonly double Mu, Slide, Kp, Ap, Roll;
        public SurfInfo(string name, double mu, double slide, double kp, double ap, double roll)
        { Name = name; Mu = mu; Slide = slide; Kp = kp; Ap = ap; Roll = roll; }
    }

    // Driving surfaces. Mu: grip vs the grid; Slide: grip left past the peak (loose surfaces keep more);
    // Kp/Ap: peak slip ratio / slip angle multipliers (loose surfaces peak later); Roll: rolling resistance.
    public static class Surfaces
    {
        public static readonly SurfInfo[] Table =
        {
            new SurfInfo("Grid", 1.0, 0.78, 1.0, 1.0, 0.013),
            new SurfInfo("Rumble strip", 0.95, 0.78, 1.0, 1.0, 0.02),
            new SurfInfo("Dirt", 0.68, 0.9, 1.6, 1.35, 0.03),
            new SurfInfo("Gravel", 0.6, 0.95, 2.0, 1.6, 0.042),
            new SurfInfo("Grass", 0.5, 0.86, 1.5, 1.3, 0.05),
        };
        public static SurfInfo Of(Surf s) => Table[(int)s];
        public static bool Loose(Surf s) => s == Surf.Dirt || s == Surf.Gravel || s == Surf.Grass;
    }

    // Undulation of the loose surfaces: sums of plane waves. `Fine` terms (gravel chatter) only exist in the
    // physics; the meshes use the smooth `Long` part.
    public struct WaveTerm
    {
        public double A, K, Dx, Dz, Ph;
        public WaveTerm(double a, double wl, double dx, double dz)
        {
            A = a; Dx = dx; Dz = dz;
            K = (2 * Math.PI) / (wl * Math.Sqrt(dx * dx + dz * dz));
            Ph = wl * 7.3;
        }
    }

    public static class Shapes
    {
        public static readonly WaveTerm[] DirtLong = { new WaveTerm(0.012, 3.1, 0.95, 0.3), new WaveTerm(0.008, 5.3, 0.2, 1), new WaveTerm(0.005, 1.7, 0.7, -0.7) };
        public static readonly WaveTerm[] DirtFine = { new WaveTerm(0.003, 0.47, 1, 0.25) };
        public static readonly WaveTerm[] GravelLong = { new WaveTerm(0.006, 4.0, 1, 0.4), new WaveTerm(0.004, 2.3, -0.3, 1) };
        public static readonly WaveTerm[] GravelFine = { new WaveTerm(0.005, 0.31, 1, 0.2), new WaveTerm(0.004, 0.43, 0.3, 1), new WaveTerm(0.003, 0.57, -0.6, 0.8) };
        public static readonly WaveTerm[] GrassLong = { new WaveTerm(0.012, 4.5, 0.9, 0.4), new WaveTerm(0.009, 7.1, -0.2, 1), new WaveTerm(0.004, 2.2, 0.6, 0.8) };
        public static readonly WaveTerm[] GrassFine = new WaveTerm[0];

        public static double Waves(WaveTerm[] terms, double x, double z)
        {
            double h = 0;
            for (int i = 0; i < terms.Length; i++)
            {
                var t = terms[i];
                h += t.A * Math.Sin(t.K * (t.Dx * x + t.Dz * z) + t.Ph);
            }
            return h;
        }

        public static void For(Surf s, out WaveTerm[] lng, out WaveTerm[] fine)
        {
            switch (s)
            {
                case Surf.Dirt: lng = DirtLong; fine = DirtFine; break;
                case Surf.Gravel: lng = GravelLong; fine = GravelFine; break;
                default: lng = GrassLong; fine = GrassFine; break;
            }
        }
    }

    // Oriented rectangle: origin at the toe, `dir` is a yaw angle
    public sealed class RectFrame
    {
        public readonly double Fx, Fz, Rx, Rz, L, W, Ox, Oz;
        public readonly double MinX, MaxX, MinZ, MaxZ;

        public RectFrame(double x, double z, double dir, double length, double width)
        {
            V3 f = M.FwdFromYaw(dir), r = M.RightFromYaw(dir);
            Fx = f.X; Fz = f.Z; Rx = r.X; Rz = r.Z; L = length; W = width; Ox = x; Oz = z;
            const double m = 1.5;
            double minX = double.PositiveInfinity, maxX = double.NegativeInfinity, minZ = double.PositiveInfinity, maxZ = double.NegativeInfinity;
            foreach (double u in new[] { -m, L + m })
                foreach (double v in new[] { -W / 2 - m, W / 2 + m })
                {
                    double px = x + Fx * u + Rx * v, pz = z + Fz * u + Rz * v;
                    minX = Math.Min(minX, px); maxX = Math.Max(maxX, px); minZ = Math.Min(minZ, pz); maxZ = Math.Max(maxZ, pz);
                }
            MinX = minX; MaxX = maxX; MinZ = minZ; MaxZ = maxZ;
        }

        public void UV(double x, double z, out double u, out double v)
        {
            double dx = x - Ox, dz = z - Oz;
            u = dx * Fx + dz * Fz;
            v = dx * Rx + dz * Rz;
        }
    }

    // How the renderer tessellates a feature: a rectangle grid in its frame, or a polar grid (ring or sector)
    public sealed class MeshSpec
    {
        public bool Polar;
        // rect
        public RectFrame Frame;
        public double[] UBreaks = new double[0];
        public double VEdge = double.NaN; // NaN: default 0.3
        public double Du = double.NaN, Dv = double.NaN; // NaN: default 0.5
        // polar
        public double Cx, Cz, R0, R;
        public double[] RBreaks = new double[0];
        public bool HasHalf;
        public double Amid, Half;
        public double Dr = double.NaN, Ds = double.NaN; // NaN: default 0.5
    }

    public sealed class ArcInfo { public double Cx, Cz, R; }

    public abstract class Feature
    {
        public string Kind = "";
        public int Tint;
        public bool HasSurface;
        public Surf Surface = Surf.Tarmac;
        public double MinX, MaxX, MinZ, MaxZ;
        public ArcInfo Arc;
        public MeshSpec Mesh;

        public abstract double H(double x, double z);
        public virtual double HVis(double x, double z) => H(x, z);
        public virtual bool Inside(double x, double z) => false;

        protected void SetBox(RectFrame fr) { MinX = fr.MinX; MaxX = fr.MaxX; MinZ = fr.MinZ; MaxZ = fr.MaxZ; }

        // tight bounding box of an annular sector (samples the arc ends and any axis crossings)
        protected void SetSectorBox(double cx, double cz, double r0, double r1, double amid, double half, double pad)
        {
            var angs = new List<double> { amid - half, amid + half };
            for (int k = -4; k <= 4; k++) { double a = (k * Math.PI) / 2; if (Math.Abs(M.WrapA(a - amid)) <= half) angs.Add(a); }
            double minX = double.PositiveInfinity, maxX = double.NegativeInfinity, minZ = double.PositiveInfinity, maxZ = double.NegativeInfinity;
            foreach (double a in angs)
                foreach (double r in new[] { r0, r1 })
                {
                    double x = cx + Math.Cos(a) * r, z = cz + Math.Sin(a) * r;
                    minX = Math.Min(minX, x); maxX = Math.Max(maxX, x); minZ = Math.Min(minZ, z); maxZ = Math.Max(maxZ, z);
                }
            MinX = minX - pad; MaxX = maxX + pad; MinZ = minZ - pad; MaxZ = maxZ + pad;
        }
    }

    // Wedge / kicker / jump: rises over `up`, flat for `top`, falls over `down`
    public sealed class Ramp : Feature
    {
        readonly RectFrame fr;
        readonly double up, top, down, height, width, curve, side, len;

        public Ramp(double x, double z, double dir, double width, double up, double top, double down, double height,
                    double curve = 1, double sideSlope = 2.5, int tint = 0)
        {
            this.up = up; this.top = top; this.down = down; this.height = height; this.width = width;
            this.curve = curve; side = sideSlope; len = up + top + down;
            fr = new RectFrame(x, z, dir, len, width);
            Kind = "ramp"; Tint = tint; SetBox(fr);
            Mesh = new MeshSpec { Frame = fr, UBreaks = new[] { 0, up, up + top, len }, VEdge = height / side, Du = curve > 1 ? 0.3 : 0.5 };
        }

        double Prof(double u)
        {
            if (u <= 0 || u >= len) return 0;
            if (u < up) return height * Math.Pow(u / up, curve);
            if (u < up + top) return height;
            return height * (1 - (u - up - top) / down);
        }

        public override double H(double x, double z)
        {
            fr.UV(x, z, out double u, out double v);
            double e = width / 2 - Math.Abs(v);
            if (e <= 0) return 0;
            return Math.Min(Prof(u), e * side);
        }
    }

    // Row of rounded speed bumps across a lane
    public sealed class Bumps : Feature
    {
        readonly RectFrame fr;
        readonly double width, length, spacing, bumpLen, height;

        public Bumps(double x, double z, double dir, double width, double length, double spacing, double bumpLen, double height)
        {
            this.width = width; this.length = length; this.spacing = spacing; this.bumpLen = bumpLen; this.height = height;
            fr = new RectFrame(x, z, dir, length, width);
            Kind = "bumps"; Tint = 1; SetBox(fr);
            Mesh = new MeshSpec { Frame = fr, Du = 0.08, Dv = 0.25, UBreaks = new[] { 0, length } };
        }

        public override double H(double x, double z)
        {
            fr.UV(x, z, out double u, out double v);
            if (u < 0 || u > length) return 0;
            double e = width / 2 - Math.Abs(v);
            if (e <= 0) return 0;
            double ph = u - Math.Floor(u / spacing) * spacing;
            if (ph > bumpLen) return 0;
            return height * 0.5 * (1 - Math.Cos((2 * Math.PI * ph) / bumpLen)) * M.Smooth01(e / 0.35);
        }
    }

    // Egg-crate moguls: diagonal humps that twist the chassis
    public sealed class Moguls : Feature
    {
        readonly RectFrame fr;
        readonly double width, length, k, height;

        public Moguls(double x, double z, double dir, double width, double length, double wavelength, double height)
        {
            this.width = width; this.length = length; this.height = height;
            k = (2 * Math.PI) / wavelength;
            fr = new RectFrame(x, z, dir, length, width);
            Kind = "moguls"; Tint = 2; SetBox(fr);
            Mesh = new MeshSpec { Frame = fr, Du = 0.35, Dv = 0.35, UBreaks = new[] { 0, length } };
        }

        public override double H(double x, double z)
        {
            fr.UV(x, z, out double u, out double v);
            if (u < 0 || u > length || Math.Abs(v) > width / 2) return 0;
            double s = Math.Sin(k * u) * Math.Sin(k * v);
            if (s <= 0) return 0;
            double fade = M.Smooth01(u / 4) * M.Smooth01((length - u) / 4) * M.Smooth01((width / 2 - Math.Abs(v)) / 3);
            return height * s * s * fade;
        }
    }

    // Banked ring (velodrome bowl) with an entry gap
    public sealed class Bowl : Feature
    {
        readonly double cx, cz, r0, w, H0, top, back, R, gapAng, gapHalf;

        public Bowl(double x, double z, double inner, double bank, double height, double top, double back, double gapAngle, double gapHalf)
        {
            cx = x; cz = z; r0 = inner; w = bank; H0 = height; this.top = top; this.back = back;
            R = r0 + w + top + back; gapAng = gapAngle; this.gapHalf = gapHalf;
            Kind = "bowl"; Tint = 3;
            MinX = cx - R; MaxX = cx + R; MinZ = cz - R; MaxZ = cz + R;
            Mesh = new MeshSpec { Polar = true, Cx = cx, Cz = cz, RBreaks = new[] { r0, r0 + w, r0 + w + top, R }, R0 = r0, R = R };
        }

        double Prof(double r)
        {
            if (r <= r0 || r >= R) return 0;
            if (r < r0 + w) return H0 * Math.Pow((r - r0) / w, 1.6);
            if (r < r0 + w + top) return H0;
            return H0 * (1 - (r - r0 - w - top) / back);
        }

        public override double H(double x, double z)
        {
            double dx = x - cx, dz = z - cz;
            double r = Math.Sqrt(dx * dx + dz * dz);
            if (r <= r0 || r >= R) return 0;
            double da = M.WrapA(Math.Atan2(dz, dx) - gapAng);
            double arc = Math.Abs(da) * r; // metres along the ring from the gap centre
            double gate = M.Smooth01((arc - gapHalf) / 10);
            return Prof(r) * gate;
        }
    }

    // Loose-surface test strip: sits 3 cm proud of the grid with surface-specific undulation
    public sealed class SurfaceStrip : Feature
    {
        readonly RectFrame fr;
        readonly double W, L;
        const double edge = 0.5;
        readonly WaveTerm[] lng, fine;

        public SurfaceStrip(double x, double z, double dir, double width, double length, Surf surface)
        {
            W = width; L = length;
            fr = new RectFrame(x, z, dir, length, width);
            Shapes.For(surface, out lng, out fine);
            Kind = "strip"; HasSurface = true; Surface = surface; SetBox(fr);
            Mesh = new MeshSpec { Frame = fr, Du = 0.4, Dv = 0.4, UBreaks = new[] { 0, L }, VEdge = edge };
        }

        double Shape(double x, double z)
        {
            fr.UV(x, z, out double u, out double v);
            if (u < 0 || u > L || Math.Abs(v) > W / 2) return 0;
            return M.Smooth01(u / edge) * M.Smooth01((L - u) / edge) * M.Smooth01((W / 2 - Math.Abs(v)) / edge);
        }

        public override double HVis(double x, double z) { double s = Shape(x, z); return s > 0 ? s * (0.03 + Shapes.Waves(lng, x, z)) : 0; }
        public override double H(double x, double z) { double s = Shape(x, z); return s > 0 ? s * (0.03 + Shapes.Waves(lng, x, z) + Shapes.Waves(fine, x, z)) : 0; }
        public override bool Inside(double x, double z) { fr.UV(x, z, out double u, out double v); return u >= 0 && u <= L && Math.Abs(v) <= W / 2; }
    }

    // Rumble strip: rounded ridges every 0.40 m, 22 mm tall, chamfered at the edges
    public sealed class Rumble : Feature
    {
        readonly RectFrame fr;
        readonly double W, L, lam, Hh;

        public Rumble(double x, double z, double dir, double width, double length, double spacing = 0.4, double height = 0.022)
        {
            W = width; L = length; lam = spacing; Hh = height;
            fr = new RectFrame(x, z, dir, length, width);
            Kind = "rumble"; HasSurface = true; Surface = Surf.Rumble; SetBox(fr);
            Mesh = new MeshSpec { Frame = fr, Du = lam / 8, Dv = Math.Min(0.25, W / 6), UBreaks = new[] { 0, L }, VEdge = 0.06 };
        }

        public override double H(double x, double z)
        {
            fr.UV(x, z, out double u, out double v);
            double e = M.Min3(u, L - u, W / 2 - Math.Abs(v));
            if (e <= 0) return 0;
            return Math.Min(1, e / 0.06) * (0.004 + Hh * (0.5 - 0.5 * Math.Cos((2 * Math.PI * u) / lam)));
        }

        public override bool Inside(double x, double z) { fr.UV(x, z, out double u, out double v); return u >= 0 && u <= L && Math.Abs(v) <= W / 2; }
    }

    // Curved kerb: the same ridged rumble profile, laid along an arc around (cx, cz) at radius R, covering
    // polar angles amid +- half. Ridges run across the kerb, so they follow the corner.
    public sealed class ArcRumble : Feature
    {
        readonly double cx, cz, R, w, amid, half, L;
        const double lam = 0.4, Hh = 0.022;

        public ArcRumble(double cx, double cz, double R, double w, double amid, double half)
        {
            this.cx = cx; this.cz = cz; this.R = R; this.w = w; this.amid = amid; this.half = half;
            L = 2 * half * R;
            Kind = "rumble"; HasSurface = true; Surface = Surf.Rumble;
            Arc = new ArcInfo { Cx = cx, Cz = cz, R = R };
            SetSectorBox(cx, cz, R - w / 2, R + w / 2, amid, half, 0.3);
            Mesh = new MeshSpec
            {
                Polar = true, Cx = cx, Cz = cz, R0 = R - w / 2, R = R + w / 2,
                RBreaks = new[] { R - w / 2, R - w / 2 + 0.06, R + w / 2 - 0.06, R + w / 2 },
                HasHalf = true, Amid = amid, Half = half, Dr = w / 6, Ds = lam / 8,
            };
        }

        void Local(double x, double z, out double u, out double v)
        {
            double dx = x - cx, dz = z - cz, r = Math.Sqrt(dx * dx + dz * dz);
            double rel = M.WrapA(Math.Atan2(dz, dx) - amid);
            u = (rel + half) * R; v = r - R;
        }

        public override double H(double x, double z)
        {
            Local(x, z, out double u, out double v);
            double e = M.Min3(u, L - u, w / 2 - Math.Abs(v));
            if (e <= 0) return 0;
            return Math.Min(1, e / 0.06) * (0.004 + Hh * (0.5 - 0.5 * Math.Cos((2 * Math.PI * u) / lam)));
        }

        public override bool Inside(double x, double z) { Local(x, z, out double u, out double v); return u >= 0 && u <= L && Math.Abs(v) <= w / 2; }
    }

    // Gravel trap: an annular sector of loose gravel (same surface as the gravel test strip)
    public sealed class ArcGravel : Feature
    {
        readonly double cx, cz, r0, r1, amid, half;
        const double edge = 0.8;

        public ArcGravel(double cx, double cz, double r0, double r1, double amid, double half)
        {
            this.cx = cx; this.cz = cz; this.r0 = r0; this.r1 = r1; this.amid = amid; this.half = half;
            Kind = "strip"; HasSurface = true; Surface = Surf.Gravel;
            SetSectorBox(cx, cz, r0, r1, amid, half, 0.3);
            Mesh = new MeshSpec
            {
                Polar = true, Cx = cx, Cz = cz, R0 = r0, R = r1, RBreaks = new[] { r0, r0 + edge, r1 - edge, r1 },
                HasHalf = true, Amid = amid, Half = half, Dr = 0.45, Ds = 0.45,
            };
        }

        double Shape(double x, double z)
        {
            double dx = x - cx, dz = z - cz, r = Math.Sqrt(dx * dx + dz * dz);
            if (r < r0 || r > r1) return 0;
            double rel = Math.Abs(M.WrapA(Math.Atan2(dz, dx) - amid));
            if (rel > half) return 0;
            double ea = (half - rel) * r;
            return M.Smooth01((r - r0) / edge) * M.Smooth01((r1 - r) / edge) * M.Smooth01(ea / edge);
        }

        public override double HVis(double x, double z) { double k = Shape(x, z); return k > 0 ? k * (0.03 + Shapes.Waves(Shapes.GravelLong, x, z)) : 0; }
        public override double H(double x, double z) { double k = Shape(x, z); return k > 0 ? k * (0.03 + Shapes.Waves(Shapes.GravelLong, x, z) + Shapes.Waves(Shapes.GravelFine, x, z)) : 0; }
        public override bool Inside(double x, double z) => Shape(x, z) > 0;
    }

    /* ---------------- centrelines ---------------- */

    public struct PathPt { public double X, Z, H, K; public int Part; }
    public struct NearRes { public int I; public double S, D, Dist; }

    public interface IPath
    {
        double Len { get; }
        PathPt At(double s);
        NearRes Nearest(double x, double z, int hint = -1);
    }

    public sealed class PathPart
    {
        public char Type;
        public double X, Z, H, S0, Len, R, A, K, Cx, Cz;
        public string Name;
    }

    public struct Seg
    {
        public char T; public double A, B; public string Name;
        public Seg(char t, double a, double b, string name) { T = t; A = a; B = b; Name = name; }
        public static Seg S(double len) => new Seg('S', len, 0, null);
        public static Seg Arc(double radius, double degrees, string name = null) => new Seg('A', radius, degrees, name);
    }

    // The centreline is straights and constant-radius arcs, joined tangent to tangent.
    // Heading h: direction (cos h, sin h) in (x, z). Arc degrees: negative = left.
    public sealed class ArcPath : IPath
    {
        public readonly List<PathPart> Parts = new List<PathPart>();
        public double Len { get; private set; }
        public double EndX, EndZ, EndH;
        readonly double[] sx, sz, sh;

        public ArcPath(double x, double z, double h, IList<Seg> segs)
        {
            double s = 0;
            foreach (var sg in segs)
            {
                if (sg.T == 'S')
                {
                    Parts.Add(new PathPart { Type = 'S', X = x, Z = z, H = h, S0 = s, Len = sg.A });
                    x += Math.Cos(h) * sg.A; z += Math.Sin(h) * sg.A; s += sg.A;
                }
                else
                {
                    double R = sg.A, a = (sg.B * Math.PI) / 180, k = M.Sgn(a);
                    double cx = x - R * k * Math.Sin(h), cz = z + R * k * Math.Cos(h);
                    Parts.Add(new PathPart { Type = 'A', X = x, Z = z, H = h, S0 = s, Len = R * Math.Abs(a), R = R, A = a, K = k, Cx = cx, Cz = cz, Name = sg.Name });
                    h += a; x = cx + R * k * Math.Sin(h); z = cz - R * k * Math.Cos(h); s += R * Math.Abs(a);
                }
            }
            Len = s; EndX = x; EndZ = z; EndH = h;
            // 1 m samples for nearest-point queries
            int n = (int)Math.Ceiling(s);
            sx = new double[n]; sz = new double[n]; sh = new double[n];
            for (int i = 0; i < n; i++) { var p = At(i); sx[i] = p.X; sz[i] = p.Z; sh[i] = p.H; }
        }

        // position, heading and curvature (1/R, + = right) at distance s
        public PathPt At(double s)
        {
            s = ((s % Len) + Len) % Len;
            int lo = 0, hi = Parts.Count - 1;
            while (lo < hi) { int m = (lo + hi + 1) >> 1; if (Parts[m].S0 <= s) lo = m; else hi = m - 1; }
            var p = Parts[lo];
            double u = s - p.S0;
            if (p.Type == 'S') return new PathPt { X = p.X + Math.Cos(p.H) * u, Z = p.Z + Math.Sin(p.H) * u, H = p.H, K = 0, Part = lo };
            double hh = p.H + (u / p.R) * p.K;
            return new PathPt { X = p.Cx + p.R * p.K * Math.Sin(hh), Z = p.Cz - p.R * p.K * Math.Cos(hh), H = hh, K = p.K / p.R, Part = lo };
        }

        // nearest centreline point: s along the path, d sideways (+ = right of the driving direction)
        public NearRes Nearest(double x, double z, int hint = -1)
        {
            int best = -1; double bd = double.PositiveInfinity;
            NearestScan.Find(sx, sz, x, z, hint, ref best, ref bd);
            double h = sh[best], dx = x - sx[best], dz = z - sz[best];
            double along = dx * Math.Cos(h) + dz * Math.Sin(h);
            return new NearRes { I = best, S = (best + along + Len) % Len, D = -dx * Math.Sin(h) + dz * Math.Cos(h), Dist = Math.Sqrt(bd) };
        }
    }

    static class NearestScan
    {
        static void Scan(double[] sx, double[] sz, double x, double z, int a, int b, ref int best, ref double bd)
        {
            int n = sx.Length;
            for (int j = a; j <= b; j++)
            {
                int i = ((j % n) + n) % n;
                double dx = x - sx[i], dz = z - sz[i], d = dx * dx + dz * dz;
                if (d < bd) { bd = d; best = i; }
            }
        }

        // a window around the hint first; the whole line when there is no hint or the hint was far off
        public static void Find(double[] sx, double[] sz, double x, double z, int hint, ref int best, ref double bd)
        {
            int n = sx.Length;
            if (hint >= 0) Scan(sx, sz, x, z, hint - 40, hint + 40, ref best, ref bd);
            if (hint < 0 || bd > 30 * 30) { bd = double.PositiveInfinity; Scan(sx, sz, x, z, 0, n - 1, ref best, ref bd); }
        }
    }

    // Static solid boxes (pit wall, garages, gantry legs): the body collides with their sides.
    // yaw: rotation of the box's x axis from world +x towards +z.
    public sealed class SolidBox
    {
        public readonly double Cx, Cz, Hx, Hz, Yaw, H, AxX, AxZ, AzX, AzZ, MinX, MaxX, MinZ, MaxZ;
        public readonly string Col;

        public SolidBox(double cx, double cz, double hx, double hz, double yaw, double h, string col)
        {
            double c = Math.Cos(yaw), s = Math.Sin(yaw);
            double ex = Math.Abs(c) * hx + Math.Abs(s) * hz, ez = Math.Abs(s) * hx + Math.Abs(c) * hz;
            Cx = cx; Cz = cz; Hx = hx; Hz = hz; Yaw = yaw; H = h; Col = col;
            AxX = c; AxZ = s; AzX = -s; AzZ = c;
            MinX = cx - ex; MaxX = cx + ex; MinZ = cz - ez; MaxZ = cz + ez;
        }
    }

    public sealed class GridSlot { public double S, D, X, Z, H; }

    public sealed class PitInfo
    {
        public ArcPath Path;
        public double Width, Z, WallZ;
        public List<double> Boxes = new List<double>();
    }

    public sealed class Circuit
    {
        public IPath Path;
        public double Width, SLine;
        public List<Feature> Features = new List<Feature>();
        public List<SolidBox> Solids = new List<SolidBox>();
        public List<double> Markers = new List<double>();
        public List<GridSlot> Grid = new List<GridSlot>();
        public PitInfo Pit;
        public bool HasGantry;
        public double GantryX, GantryZ, GantryH;
        public bool Mesh;
        public string Name = "";
        public StageInfo Stage;   // point-to-point stage (an open centreline) instead of a lap
    }

    // A stage between two lines on an open centreline, driven either way.
    public sealed class StageInfo
    {
        public double Start, Finish; // s of the START gantry (bottom) and the FINISH gantry (top)
    }

    /* ---------------- terrain interface ---------------- */

    public abstract class TerrainBase
    {
        public Circuit Circuit;
        public bool HasSpawn;
        public V3 SpawnPos;
        public double SpawnYaw;
        public double Floor = double.NegativeInfinity; // map packs: what Height() reports off the edge of the map
        public double KerbLift = 0.024;               // skid marks ride this far over a kerb
        public double BoundsMinY = double.NegativeInfinity;
        public readonly List<Feature> Features = new List<Feature>();
        public readonly List<SolidBox> Solids = new List<SolidBox>();
        public float[] WallSeg;                        // 6 per wall segment (ax, az, bx, bz, yBottom, yTop), or null
        public int[] WNear = new int[1024];

        public abstract double Height(double x, double z);
        public abstract double HeightVis(double x, double z);
        public abstract V3 Normal(double x, double z);
        public abstract Surf Surface(double x, double z);
        public abstract double Raycast(V3 o, V3 d, double maxT);
        public virtual int WallsNear(double x, double z, double r) => 0;

        // The same for a point at height y: the ground at or just above it, never a rock overhang or a bridge
        // higher up. Mesh maps have those; the grid map has one layer, so these are the plain queries.
        public const double Reach = 1.2;
        public virtual double HeightAt(double x, double z, double y, double reach = Reach) => Height(x, z);
        public virtual double HeightVisAt(double x, double z, double y, double reach = Reach) => HeightVis(x, z);
        public virtual V3 NormalAt(double x, double z, double y, double reach = Reach) => Normal(x, z);
        public virtual Surf SurfaceAt(double x, double z, double y, double reach = Reach) => Surface(x, z);
    }

    // Features are bucketed into 32 m cells so a height query only looks at what is nearby
    // (the wheels make several hundred queries per physics step).
    public sealed class GridTerrain : TerrainBase
    {
        const int CELL = 32;
        static readonly Feature[] NONE = new Feature[0];
        readonly Dictionary<long, Feature[]> fCells, zCells;

        static long Key(int ix, int iz) => (long)(ix + 32768) * 65536 + (iz + 32768);

        static Dictionary<long, Feature[]> CellIndex(List<Feature> list)
        {
            var m = new Dictionary<long, List<Feature>>();
            foreach (var f in list)
                for (int ix = (int)Math.Floor(f.MinX / CELL); ix <= (int)Math.Floor(f.MaxX / CELL); ix++)
                    for (int iz = (int)Math.Floor(f.MinZ / CELL); iz <= (int)Math.Floor(f.MaxZ / CELL); iz++)
                    {
                        long k = Key(ix, iz);
                        if (!m.TryGetValue(k, out var l)) { l = new List<Feature>(); m[k] = l; }
                        l.Add(f);
                    }
            var o = new Dictionary<long, Feature[]>();
            foreach (var kv in m) o[kv.Key] = kv.Value.ToArray();
            return o;
        }

        public GridTerrain(List<Feature> features, List<SolidBox> solids)
        {
            Features.AddRange(features);
            Solids.AddRange(solids);
            var zones = features.FindAll((f) => f.HasSurface);
            fCells = CellIndex(features); zCells = CellIndex(zones);
        }

        Feature[] Near(Dictionary<long, Feature[]> cells, double x, double z)
        {
            return cells.TryGetValue(Key((int)Math.Floor(x / CELL), (int)Math.Floor(z / CELL)), out var l) ? l : NONE;
        }

        // Surface under a point: the zone that contains it, else the grid itself
        public override Surf Surface(double x, double z)
        {
            var zs = Near(zCells, x, z);
            for (int i = 0; i < zs.Length; i++)
            {
                var f = zs[i];
                if (x >= f.MinX && x <= f.MaxX && z >= f.MinZ && z <= f.MaxZ && f.Inside(x, z)) return f.Surface;
            }
            return Surf.Tarmac;
        }

        public override double Height(double x, double z)
        {
            double h = 0;
            var fs = Near(fCells, x, z);
            for (int i = 0; i < fs.Length; i++)
            {
                var f = fs[i];
                if (x < f.MinX || x > f.MaxX || z < f.MinZ || z > f.MaxZ) continue;
                double v = f.H(x, z);
                if (v > h) h = v;
            }
            return h;
        }

        // height of the surface as drawn (loose surfaces carry fine chatter only in the physics)
        public override double HeightVis(double x, double z)
        {
            double h = 0;
            var fs = Near(fCells, x, z);
            for (int i = 0; i < fs.Length; i++)
            {
                var f = fs[i];
                if (x < f.MinX || x > f.MaxX || z < f.MinZ || z > f.MaxZ) continue;
                double v = f.HVis(x, z);
                if (v > h) h = v;
            }
            return h;
        }

        public override V3 Normal(double x, double z)
        {
            const double e = 0.04;
            double hx = Height(x + e, z) - Height(x - e, z);
            double hz = Height(x, z + e) - Height(x, z - e);
            return new V3(-hx, 2 * e, -hz).Normalized();
        }

        // First t in [0, maxT] where o + d*t is at or below the ground; -1 if none.
        public override double Raycast(V3 o, V3 d, double maxT)
        {
            double f0 = o.Y - Height(o.X, o.Z);
            if (f0 <= 0) return 0;
            const double step = 0.07;
            double tPrev = 0;
            for (double t = step; ; t += step)
            {
                double tt = Math.Min(t, maxT);
                double f = o.Y + d.Y * tt - Height(o.X + d.X * tt, o.Z + d.Z * tt);
                if (f <= 0)
                {
                    double a = tPrev, b = tt;
                    for (int i = 0; i < 9; i++)
                    {
                        double m = (a + b) / 2;
                        double fm = o.Y + d.Y * m - Height(o.X + d.X * m, o.Z + d.Z * m);
                        if (fm <= 0) b = m; else a = m;
                    }
                    return b;
                }
                tPrev = tt;
                if (tt >= maxT) return -1;
            }
        }
    }

    public static class ProvingGround
    {
        // The circuit wraps around the proving ground: ~3.2 km, anticlockwise from above (mostly left turns).
        public static Circuit BuildCircuit()
        {
            const double W = 13;
            double sx0 = -150, sz0 = 110, sh0 = 0;
            double back = 302, west1 = 468;
            List<Seg> Segs() => new List<Seg>
            {
                Seg.S(420),
                Seg.Arc(38, -90, "T1"), Seg.S(130),
                Seg.Arc(55, 35, "T2"), Seg.Arc(55, -70, "T3"), Seg.Arc(55, 35, "T4"), Seg.S(140),
                Seg.Arc(16, 180, "T5"), Seg.S(120), Seg.Arc(16, -180, "T6"), Seg.S(380),
                Seg.Arc(70, -90, "T7"), Seg.S(back),
                Seg.Arc(140, 22, "T8"), Seg.Arc(140, -22, "T9"), Seg.S(120),
                Seg.Arc(45, -90, "T10"), Seg.S(west1),
                Seg.Arc(50, 45, "T11"), Seg.Arc(50, -90, "T12"), Seg.Arc(50, 45, "T13"), Seg.S(80),
                Seg.Arc(15, -180, "T14"), Seg.S(70), Seg.Arc(15, 180, "T15"), Seg.S(60),
                Seg.Arc(60, -90, "T16"),
            };
            // close the loop exactly: the back straight runs west and the west straight south
            for (int it = 0; it < 8; it++)
            {
                var e = new ArcPath(sx0, sz0, sh0, Segs());
                back += e.EndX - sx0; west1 -= e.EndZ - sz0;
            }
            var path = new ArcPath(sx0, sz0, sh0, Segs());
            const double sLine = 210; // start / finish line, alongside the pits (x = 60)
            var c = new Circuit { Path = path, Width = W, SLine = sLine };
            var parts = path.Parts;
            for (int pi = 0; pi < parts.Count; pi++)
            {
                var p = parts[pi];
                if (p.Type != 'A') continue;
                double deg = Math.Abs(p.A) * 180 / Math.PI;
                bool sharp = deg >= 89;
                double a0 = Math.Atan2(p.Z - p.Cz, p.X - p.Cx);  // polar angle where the arc starts
                double sweep = (p.Len / p.R) * p.K;               // polar angle travelled (sign = direction)
                double amid = a0 + sweep / 2;
                // apex kerb on the inside, around the middle of the corner, half on the asphalt edge
                const double kw = 1.3;
                double kHalf = Math.Min(0.62 * p.Len, 46) / 2 / (p.R - W / 2 + 0.3);
                c.Features.Add(new ArcRumble(p.Cx, p.Cz, p.R - W / 2 + 0.3, kw, amid, kHalf));
                if (sharp)
                {
                    // exit kerb on the outside, over the last third of the corner
                    double Ro = p.R + W / 2 - 0.3, aEnd = a0 + sweep, len = Math.Min(p.Len * 0.38, 26);
                    double halfO = len / 2 / Ro;
                    c.Features.Add(new ArcRumble(p.Cx, p.Cz, Ro, kw, aEnd - M.Sgn(sweep) * halfO, halfO));
                    // gravel trap beyond the outside, from mid-corner to a little past the exit
                    double r0 = p.R + W / 2 + 4, r1 = r0 + Math.Min(18, 8 + p.R * 0.25);
                    double over = 0.8 * Math.Acos(Math.Min(1, (p.R + W / 2 + 1.5) / r0));
                    double g0 = a0 + sweep * 0.35, g1 = aEnd + M.Sgn(sweep) * over;
                    c.Features.Add(new ArcGravel(p.Cx, p.Cz, r0, r1, (g0 + g1) / 2, Math.Abs(g1 - g0) / 2));
                    // braking boards painted on the approach straight: 150, 100 and 50 m to go
                    var prev = parts[(pi - 1 + parts.Count) % parts.Count];
                    foreach (double m in new double[] { 150, 100, 50 })
                        if (prev.Type == 'S' && m <= prev.Len - 15) c.Markers.Add((p.S0 - m + path.Len) % path.Len);
                }
            }
            // --- pits: lane south of the main straight, wall between, garages behind ---
            const double pitZ = 134, pitW = 10;
            var pit = new ArcPath(-140, 113, 0, new List<Seg> { Seg.Arc(78, 30), Seg.Arc(78, -30), Seg.S(232), Seg.Arc(78, -30), Seg.Arc(78, 30) });
            const double wallZ = 122.6;
            c.Solids.Add(new SolidBox(55, wallZ, 112, 0.4, 0, 1.05, "wall"));                // pit wall x -57 .. 167
            c.Solids.Add(new SolidBox(55, pitZ + pitW / 2 + 6.5, 116, 6, 0, 5.2, "garage")); // garage block x -61 .. 171
            // start gantry legs over the line
            var gl = path.At(sLine);
            foreach (double sgn in new double[] { -1, 1 }) c.Solids.Add(new SolidBox(gl.X, gl.Z + sgn * (W / 2 + 2.2), 0.35, 0.35, 0, 7.2, "gantry"));
            // starting grid: 10 staggered slots, 8 m apart, pole on the left (inside of T1)
            for (int i = 0; i < 10; i++)
            {
                double sg = sLine - 7 - i * 8; var p = path.At(sg); double side = i % 2 == 0 ? -1 : 1;
                c.Grid.Add(new GridSlot { S = sg, D = side * 3.1, X = p.X - Math.Sin(p.H) * side * 3.1, Z = p.Z + Math.Cos(p.H) * side * 3.1, H = p.H });
            }
            // pit boxes on the garage side of the lane, 12 m each
            var pitInfo = new PitInfo { Path = pit, Width = pitW, Z = pitZ, WallZ = wallZ };
            for (double x = -50; x + 10 <= 165; x += 12) pitInfo.Boxes.Add(x);
            c.Pit = pitInfo;
            c.HasGantry = true; c.GantryX = gl.X; c.GantryZ = gl.Z; c.GantryH = gl.H;
            return c;
        }

        // The proving-ground layout. Spawn is (0, 0, 5) facing -Z.
        public static GridTerrain BuildGridMap()
        {
            var F = new List<Feature>();
            // Left of the runway: suspension test lanes
            F.Add(new Bumps(-24, -40, 0, 7, 80, 13, 0.9, 0.1));
            F.Add(new Ramp(-36.6, -40, 0, 1.3, 4, 12, 4, 0.38, 1, 1.4, 1));
            F.Add(new Moguls(-58, -36, 0, 22, 96, 6.5, 0.32));
            // Big gap jump
            F.Add(new Ramp(-120, -70, 0, 9, 16, 2, 3, 2.6, 1.6));
            F.Add(new Ramp(-120, -113, 0, 11, 4.5, 2, 28, 2.6));
            // Right of the runway: kickers of rising size
            F.Add(new Ramp(48, -45, 0, 5, 4, 0.6, 1.6, 0.5, 1.4));
            F.Add(new Ramp(48, -95, 0, 6, 7, 1, 2.2, 1.0, 1.5));
            F.Add(new Ramp(48, -150, 0, 7, 11, 1.5, 2.8, 1.7, 1.6));
            // Banked bowl, entry facing the start line
            F.Add(new Bowl(150, -330, 55, 22, 9, 3, 9, Math.PI / 2, 9));
            // Tabletop far up the runway
            F.Add(new Ramp(0, -420, 0, 12, 14, 10, 14, 1.4));
            // Surface test strips, right of the skid pad: dirt, gravel, grass (230 m each)
            F.Add(new SurfaceStrip(165, 40, 0, 16, 230, Surf.Dirt));
            F.Add(new SurfaceStrip(187, 40, 0, 16, 230, Surf.Gravel));
            F.Add(new SurfaceStrip(209, 40, 0, 16, 230, Surf.Grass));
            // Rumble strips: both runway edges, and three warning bands before the tabletop
            F.Add(new Rumble(-10.75, -20, 0, 0.9, 220));
            F.Add(new Rumble(10.75, -20, 0, 0.9, 220));
            foreach (double z in new double[] { -360, -368, -376 }) F.Add(new Rumble(0, z, 0, 20, 2.4));
            // Race circuit around it all, with kerbs, gravel traps, pit wall and garages
            var circuit = BuildCircuit();
            F.AddRange(circuit.Features);
            var T = new GridTerrain(F, circuit.Solids) { Circuit = circuit };
            return T;
        }

        // Cones: slalom, skid-pad ring, gate markers on the runway
        public static List<(double x, double z)> BuildCones()
        {
            var c = new List<(double, double)>();
            for (int i = 0; i < 11; i++) c.Add((24, -40 - i * 18));
            const double R = 28, cx = 95, cz = -55;
            for (int i = 0; i < 22; i++) { double a = (i / 22.0) * Math.PI * 2; c.Add((cx + Math.Cos(a) * R, cz + Math.Sin(a) * R)); }
            for (int i = 0; i < 6; i++) c.Add((-3 + (i % 2) * 6, -260 - i * 40));
            return c;
        }
    }
}
