// The cars: physics spec, where the model and engine recordings live, camera framing, and the maps.
using System.Collections.Generic;
using RustBucket.Audio;
using RustBucket.Sim;

namespace RustBucket.Game
{
    public sealed class CarDef
    {
        public string Id, Title, Sub, Toast;
        public CarSpec Spec;
        public string Model;        // res:// path
        public bool Pack;           // car pack (true) or imported scene (false)
        public string Engine;       // engine recordings (json)
        public double Chase = 6.5;
        public V3 Bumper;
        public bool HasCockpit;
        public V3 Cockpit;
        public double SteerRatio = 8;
        public float GlassInside = 0.04f;
        public double SpeedoKmh = 200, SpeedoMph = 120; // full scale of the speedometer
        public float ModelScale = 1;  // the model drawn at this size (matches CarSpec.GeomScale)
        // the CTS-V borrows the Monte Carlo's V8, heard through a race exhaust
        public System.Action<Profile> EngineProfile;
    }

    public sealed class MapDef
    {
        public string Id, Name, Short, Sub, Toast, Pack;
        public float Far = 6000;     // camera far plane (m)
        public float Fog = 0;        // fog density, 0 = the usual for map packs
        public bool Occlude;         // build occluders from the ground (mountains hide most of the map)
        public bool Extra;           // its pack comes in its own zip (RustBucketRacing-Maps-*.zip) and may be missing
        // what the stage lines are called (the toasts at a stage start)
        public string TopLine = "the line at the top", BottomLine = "the line at the bottom";
    }

    public static class Defs
    {
        public static readonly string[] CarOrder = { "rust", "monte", "cts" };
        public static readonly string[] MapOrder = { "grid", "spa", "mcr", "iroha" };

        public static readonly Dictionary<string, CarDef> Cars = new Dictionary<string, CarDef>
        {
            ["rust"] = new CarDef
            {
                Id = "rust", Title = "Rust Bucket", Sub = "92 hp four · 1.25 t", Toast = "Rust Bucket · 92 hp four",
                Spec = Sim.Cars.Rust, Model = "res://models/rust.glb", Pack = false, Engine = "res://data/engine_audio.json",
                Chase = 6.0, Bumper = new V3(0, 0.74 * Sim.Cars.RustScale, -2.3 * Sim.Cars.RustScale), ModelScale = (float)Sim.Cars.RustScale,
            },
            ["monte"] = new CarDef
            {
                Id = "monte", Title = "Monte Carlo SS", Sub = "320 hp V8 · 1.55 t", Toast = "Monte Carlo SS · 320 hp V8",
                Spec = Sim.Cars.Monte, Model = "res://data/monte.bin", Pack = true, Engine = "res://data/engine_v8.json",
                Chase = 6.9, Bumper = new V3(0, 0.8, -2.52), HasCockpit = true, Cockpit = new V3(-0.405, 1.185, 0.27), SteerRatio = 12,
                SpeedoKmh = 240, SpeedoMph = 160,
            },
            ["cts"] = new CarDef
            {
                Id = "cts", Title = "CTS-V Race", Sub = "500 hp V8 · slicks", Toast = "Cadillac CTS-V race car · 500 hp V8 · slicks",
                Spec = Sim.Cars.Cts, Model = "res://data/cts.bin", Pack = true, Engine = "res://data/engine_v8.json",
                Chase = 7.0, Bumper = new V3(0, 0.62, -2.47), HasCockpit = true, Cockpit = new V3(-0.373, 0.97, 0.32), SteerRatio = 8.5,
                SpeedoKmh = 300, SpeedoMph = 180,
                // muffled top end, a little more weight low down, spread over its 1100-7800 rpm range
                EngineProfile = (p) =>
                {
                    p.Rpm0 = 1100; p.Rpm1 = 7800; p.IdleFade0 = 1350; p.IdleFade1 = 2100; p.Level = 1.85;
                    p.PopRpm = 4200; p.PopPitch = 0.9; p.Lowpass = 2100; p.LowpassQ = 0.55; p.ShelfF = 170; p.ShelfG = 3;
                },
            },
        };

        public static readonly Dictionary<string, MapDef> Maps = new Dictionary<string, MapDef>
        {
            ["grid"] = new MapDef { Id = "grid", Name = "Proving ground", Short = "Proving ground", Sub = "Test areas · 3.2 km circuit", Toast = "Proving ground" },
            ["spa"] = new MapDef { Id = "spa", Name = "Spa-Francorchamps", Short = "Spa 1992", Sub = "1992 · 6.97 km · 102 m climb", Toast = "Spa-Francorchamps · 1992 layout · 6.97 km", Pack = "res://data/spa.bin" },
            ["mcr"] = new MapDef
            {
                Id = "mcr", Name = "Monte Carlo Rally", Short = "Monte Carlo", Sub = "Stage · 4.9 km · 263 m climb",
                Toast = "Monte Carlo Rally · 4.9 km stage, either way", Pack = "res://data/mcr.bin", Far = 14000, Fog = 0.0002f, Occlude = true,
                TopLine = "the FINISH gantry", BottomLine = "the START gantry",
            },
            ["iroha"] = new MapDef
            {
                Id = "iroha", Name = "Irohazaka", Short = "Irohazaka", Sub = "Stage · 4.6 km · 339 m drop",
                Toast = "Irohazaka · 4.6 km of hairpins, either way", Pack = "res://data/iroha.bin", Far = 6000, Fog = 0.00035f, Occlude = true,
                Extra = true,
            },
        };
    }
}
