# Rust Bucket Racing (Godot 4.7, C#, mobile)

This is a Godot port of the browser game. It includes all three cars (Rust Bucket, Monte Carlo SS and CTS-V race car) and four maps (the proving ground with its race track, Spa-Francorchamps 1992, the Monte Carlo Rally mountain stage and the Irohazaka hairpins). It also includes:

- the 480 Hz suspension, tyre and drivetrain simulation;
- the granular engine sound;
- every camera, including the interior cameras;
- touch controls, the HUD, telemetry, the car setup and controls panels, the lap timer, and a stage timer that runs either way on Monte Carlo and Irohazaka.

The game is built for phones in landscape. It also runs on desktop with a keyboard or gamepad, which is the quickest way to try it.

> **If the game closes on start-up**, open it again: it shows the log of the run that closed, with a **Copy report** button. The menu also has **Copy debug log** for problems that don't close the game. Send either one over and it can be fixed.

## What you need

| | |
|---|---|
| Godot | **4.7.2, .NET edition** (godotengine.org → Download → "Godot Engine - .NET") |
| .NET SDK | **9.0 or newer** (Android export needs 9; desktop needs 8 or later) |
| Android export | JDK 17, the Android SDK (easiest to get through Android Studio), and Godot's export templates (.NET) |
| iOS export | A Mac with Xcode, and an Apple developer account for signing |

If you use a different 4.7.x editor, change the version on the first line of `RustBucket.csproj` (`Godot.NET.Sdk/4.7.2`) to match it.

## First run (desktop)

1. Unzip the project and open `project.godot` in Godot 4.7 .NET. The first import takes a minute: it imports `models/rust.glb` and compiles the shaders.
2. Press the hammer icon (**Build**) at the top right. If there are errors, the MSBuild panel at the bottom lists them.
3. Press **Run** (F5). The start sheet lets you pick a car and a map; **Drive** starts.

## Build the APK on GitHub (no Godot or .NET needed)

`.github/workflows/main.yml` runs `ci/build.sh` on GitHub's servers on every push to `main`. The workflow also works if the repository holds just this project zipped as `RustBucketRacing-Godot.zip`. The build:

1. downloads Godot 4.7.2 .NET and its export templates;
2. compiles the C# and imports the assets;
3. runs a **self-test**: the game on a virtual screen with software OpenGL, driving every car on both maps, switching cameras, opening the menus and taking screenshots;
4. exports a debug APK and checks the C# code is inside it.

**Map packs in their own zip.** GitHub's upload page takes files up to 25 MB, so the Irohazaka map comes as its own `RustBucketRacing-Maps-Irohazaka.zip`. Upload it next to the project zip once; it stays in the repository and every build after that unpacks it into `data/` (`ci/build.sh`). Without it the game still builds, and Irohazaka shows as not in this build.

**Getting the APK.** The APK is published as the release **latest-apk**. On your phone, open `https://github.com/<you>/<repo>/releases/latest/download/RustBucketRacing.apk`, or the repository's **Releases** page. Android asks you to allow installs from your browser the first time.

**Logs.** The logs (`csharp-build.log`, `import.log`, `smoke.log`, `export.log`) and the self-test screenshots go to the branch **ci-logs**. The run's summary page shows each step's result.

Godot's exporter needs the solution file `RustBucket.sln`. Without it, Godot treats the project as having no C# code, and the APK closes right after the splash screen.

## Export to Android

1. In **Editor → Manage Export Templates**, download the templates for your Godot version.
2. In **Editor → Editor Settings → Export → Android**, set:
   - **Java SDK Path**, to your JDK 17 folder;
   - **Android SDK Path**, to the folder Android Studio installed the SDK into;
   - a debug keystore. Godot can make one for you; see "Exporting for Android" in the Godot docs.
3. **Project → Export…** already has an **Android** preset, set to arm64 with the package name `com.rustbucket.racing`. Press **Export Project** to get an APK, or plug in a phone with USB debugging enabled and use the one-click deploy icon at the top right of the editor.

The game data under `data/` (maps, car packs and engine recordings) is included through the preset's **Resources → Filters to export non-resource files** = `data/*`. Keep that filter if you make a new preset.

## Export to iOS

On a Mac, add your Apple **Team ID** to the iOS preset (**Project → Export → iOS → App Store Team ID**) and export. This creates an Xcode project; build and sign it in Xcode. Godot's C# support on iOS is still marked experimental.

## Controls

**Touch** (shown automatically on touch screens):

- **Left thumb.** Slide along the steering pad. Flick the gear slider up or down to shift, or tap either end of it.
- **Right thumb.** Use **Gas**, **Brake** and **Hand**. Gas and Brake are pressure-sensitive: press higher on the pedal for more, lower to feather it.
- **Top right.** The camera button cycles chase, orbit, bumper, interior and trackside. The menu button opens the car, map, gearbox, car setup, controls, resets and sound.
- **Orbit camera.** Drag to fly round the car; pinch to zoom.
- **Controls panel.** Switches the steering pad to two buttons, and turns analogue pedals on or off.

**Keyboard:**

| Key | Action |
|---|---|
| W / S | throttle, brake |
| A / D | steer |
| Space | handbrake |
| Q / E | shift down / up |
| C | camera |
| G | telemetry |
| T | car setup |
| K | controls |
| M | gearbox mode |
| V | next car |
| N | next map |
| L | starting grid |
| R | reset (Shift+R: back to the start) |
| H | help |
| + / − or mouse wheel | zoom |
| drag | look around |

**Gamepad:**

| Input | Action |
|---|---|
| left stick | steer |
| RT / LT | throttle / brake |
| A or B | handbrake |
| RB / LB | shift up / down |
| Y | camera |
| X | gearbox mode |
| Start | reset |
| Back | car setup |

## Project layout

```
project.godot, RustBucket.csproj, export_presets.cfg, Main.tscn (one node, scripts/Game/Main.cs)
data/       spa.bin, mcr.bin, iroha.bin (map packs; iroha.bin comes from its own zip), monte.bin / cts.bin (car packs), engine_*.json, sfx.json
models/     rust.glb (imported by Godot)
shaders/    surface (proving ground), track, world_* (Spa), world_arr_* and world_far (Monte Carlo), skid, smoke, shared includes
scripts/Sim/     the simulation, a line-by-line port of physics.js (pure C#, no Godot types)
scripts/Render/  map chunks, proving-ground meshes, car models, skid marks, smoke
scripts/Audio/   granular engine, tyres, kerbs, wind, shifts, pops; AudioStreamGenerator output
scripts/Game/    main loop, cameras, input, touch controls, HUD, menus, settings
```

The whole scene is built in code at start-up, so there is nothing to wire up in the editor.

## Tuning the look

The browser version had its own lighting. This port uses Godot's sun, sky, shadows, fog and ACES tonemapping instead, so colours won't match exactly. You can adjust them with the constants at the top of `scripts/Game/Main.cs`:

- `SunEnergy`
- `AmbientSky`
- `Exposure`
- `FogGrid`
- `FogMap`

The renderer is **Compatibility** (OpenGL ES 3), which runs on the widest range of phones.

Monte Carlo is drawn with a level-of-detail system: every chunk of ground, rock, wall and building carries simplified versions (made with Godot's own mesh simplifier when the map pack is built), and the renderer swaps to a coarser one as it gets further away (how coarse is set by the graphics quality); trees, bushes, fences and guardrails fade out with distance; all the textures sit in one texture array so each chunk draws in a handful of calls; and the hills act as occluders, so what's behind a ridge isn't drawn at all. Irohazaka is drawn the same way.

**Body collisions** are solved as impulses: a hull point that touches a wall, a box or the ground stops going into it at once (so the body never sinks into a guardrail and catches the posts behind it), with a small bounce (a quarter of the speed it hit at, down to a twentieth for a big hit) and low friction along walls, so a glancing hit keeps most of the speed and turns the car along the wall. The self-test checks straight hits, glancing hits on the garage block and a guardrail on Monte Carlo.

## Credits

All models are CC BY 4.0:

- "Lowpoly Abandoned Simple Car Prop" by Rashad Ibrahimli
- "1987 Chevrolet Monte Carlo SS" by Randomness
- "Circuit de Spa-Francorchamps 1992 layout" by Dave Love (sketchfab.com/Tyler_Dave)
- "Monte Carlo Rally" by Dave Love (sketchfab.com/Tyler_Dave)
- "2004 Cadillac CTS-V race car" by Dave Love (sketchfab.com/Tyler_Dave)

"Irohazaka Slope", an Assetto Corsa track by sost and its original authors, is a free community mod: it is used here free and not for sale, with credit, and anything made from it stays free.
