"""The racing compound, laid out on an 8 km square (x east, z south, metres; the fence at +-3990).

Tracks are fillet paths (corner points with radii). Access roads never cross a track; every facility hangs off
the road network that starts at the main gate on the south edge."""
import numpy as np
from paths import fillet, smooth, frame, length

HALF = 3990.0                     # the perimeter fence

# ---------------------------------------------------------------- tracks
GP_V = [  # clockwise on a map with z down: (x, z, fillet radius)
    (-1000, 200, 45),     # T1: hard braking at the end of the main straight, right
    (-1090, -310, 190),   # left kink in the dip
    (-880, -750, 140),    # right: up the hill (the esses)
    (-1250, -1630, 420),  # fast left over the crest
    (-1180, -2250, 24),   # hairpin right at the top of the hill
    (-560, -2130, 90),    # left
    (-150, -2580, 200),   # right: fast downhill
    (650, -2480, 300),    # fast right sweeper
    (1450, -1930, 80),    # medium right onto the back straight
    (1520, -930, 25),     # hairpin right at the bottom
    (900, -1380, 60),     # left
    (450, -1130, 45),     # left
    (520, -590, 18),      # chicane right
    (390, -460, 18),      # chicane left
    (470, -160, 80),      # left
    (1200, -140, 110),    # right
    (1300, 200, 120),     # right onto the main straight
]
def _scaled(V, k, c=None):
    c = np.mean([(x, z) for x, z, r in V], 0) if c is None else np.array(c)
    return [(c[0] + (x - c[0]) * k, c[1] + (z - c[1]) * k, max(14, r * min(1, k * 1.2))) for x, z, r in V]
CLUB_V = _scaled([  # club circuit, east
    (1950, 1250, 30), (1980, 650, 60), (2500, 520, 140), (3050, 700, 40), (2850, 1000, 35),
    (3300, 1250, 70), (3250, 1750, 50), (2700, 1600, 90), (2400, 1850, 30),
], 0.7, (2600, 1200))
HANDLING_V = _scaled([  # handling course, south-east: narrow and twisty
    (2150, 2850, 16), (2300, 2600, 25), (2700, 2650, 20), (2650, 2900, 18), (3000, 3000, 30),
    (3350, 2800, 25), (3500, 3150, 40), (3200, 3550, 20), (2800, 3400, 22), (2500, 3600, 30), (2200, 3350, 25),
], 0.52, (2850, 3150))
OVAL_C, OVAL_STRAIGHT, OVAL_R = (-2650, 1500), 640, 240     # banked oval, west: straights run east-west
DRAG_Z, DRAG_X0, DRAG_X1 = 3300, -3650, -2200               # drag strip, south-west, run toward +x
DRAG_START = DRAG_X0 + 120                                   # start line; finish 402.3 m on
SLALOM = dict(x0=-1250, x1=-700, z0=2450, z1=2800)           # slalom and skid pad (asphalt)
PADDOCK = dict(x0=-700, x1=1000, z0=230, z1=620)             # paddock behind the pit garages (from the pit lane edge)
CLUB_PAD = dict(x0=1860, x1=2080, z0=1240, z1=1440)          # club circuit paddock
HAND_PAD = dict(x0=2270, x1=2430, z0=2740, z1=2860)          # handling course paddock
OVAL_PAD = dict(x0=-2480, x1=-2120, z0=1800, z1=1950)        # oval paddock (south of the oval)
DRAG_PAD = dict(x0=-3700, x1=-3480, z0=3180, z1=3292)        # drag strip staging area (north of the lanes, touching them)
GATE_PAD = dict(x0=-180, x1=220, z0=3560, z1=3760)           # visitor parking by the main building
GATE = (0, HALF)

def oval_path(step=1.0):
    cx, cz = OVAL_C; L, R = OVAL_STRAIGHT, OVAL_R
    pts = []
    # bottom straight heading +x at z = cz + R, then the east turn, top straight heading -x, west turn
    for x in np.arange(cx - L / 2, cx + L / 2, step): pts.append((x, cz + R))
    for a in np.arange(np.pi / 2, -np.pi / 2, -step / R): pts.append((cx + L / 2 + R * np.cos(a), cz + R * np.sin(a)))
    for x in np.arange(cx + L / 2, cx - L / 2, -step): pts.append((x, cz - R))
    for a in np.arange(-np.pi / 2, -3 * np.pi / 2, -step / R): pts.append((cx - L / 2 + R * np.cos(a), cz + R * np.sin(a)))
    return np.array(pts)

# ---------------------------------------------------------------- roads (open paths, 7 m wide)
ROADS_V = {
    'gate':     [(0, HALF + 60, 0), (40, 3500, 300), (-60, 2600, 400), (0, 2050, 0)],
    'paddock':  [(0, 2050, 0), (60, 1500, 500), (-40, 1000, 400), (100, 600, 0)],
    'east':     [(0, 2050, 0), (700, 1900, 600), (1400, 1950, 300), (1900, 1500, 0)],
    'to_handling': [(1400, 1950, 0), (1800, 2400, 250), (2340, 2800, 0)],
    'west':     [(0, 2050, 0), (-500, 2150, 500), (-950, 2380, 0)],
    'to_drag':  [(-950, 2380, 0), (-1330, 2410, 120), (-1500, 2600, 250), (-2000, 2950, 300), (-2350, 3195, 0)],   # ends where the drag strip's turn and return road meet
    'to_oval':  [(-1500, 2600, 0), (-1800, 2150, 300), (-2300, 1940, 0)],
    # the drag strip's shutdown loops back north into the return road, which runs back to the staging area
    'drag_turn':   [(-2190, 3300, 0), (-2040, 3300, 45), (-2040, 3195, 45), (-2350, 3195, 0)],
    'drag_return': [(-2350, 3195, 0), (-3000, 3215, 0), (-3485, 3225, 0)],
}
DRAG_V = [(DRAG_X0 - 60, DRAG_Z, 0), (DRAG_X1 + 10, DRAG_Z, 0)]   # the strip itself (16 m: two lanes)

GP_START_X = 260.0                # start / finish line on the main straight (it runs west, -x)
PIT_Z = 224.0                     # pit lane centre (the main straight is at z = 200)

def roll_to(P, x, z):
    """a closed path started at the point nearest (x, z)"""
    i = int(np.argmin(np.hypot(P[:, 0] - x, P[:, 1] - z)))
    return np.roll(P, -i, axis=0)

def pit_lane():
    # in after the last corner (it leaves the straight on its left, the south side), out before T1
    V = [(1060, 203, 0), (930, PIT_Z, 300), (-640, PIT_Z, 300), (-800, 204, 0)]
    return smooth(fillet(V, False), 6, False)

def build():
    gp = roll_to(smooth(fillet(GP_V, True), 6, True), GP_START_X, 200)
    club = smooth(fillet(CLUB_V, True), 5, True)
    hand = smooth(fillet(HANDLING_V, True), 4, True)
    oval = smooth(oval_path(), 30, True)
    roads = {k: smooth(fillet(v, False), 8, False) for k, v in ROADS_V.items()}
    # short connectors from each paddock onto its track (they end on the track's centreline)
    def link(name, a, P):
        j = int(np.argmin(np.hypot(P[:, 0] - a[0], P[:, 1] - a[1])))
        roads[name] = fillet([(a[0], a[1], 0), (P[j, 0], P[j, 1], 0)], False)
        return np.roll(P, -((j + 45) % len(P)), axis=0)       # the lap line just after the paddock exit joins
    club = link('club_link', (CLUB_PAD['x1'] - 5, (CLUB_PAD['z0'] + CLUB_PAD['z1']) / 2), club)
    hand = link('hand_link', (HAND_PAD['x1'] - 5, (HAND_PAD['z0'] + HAND_PAD['z1']) / 2), hand)
    oval = link('oval_link', (OVAL_PAD['x0'] + 12, OVAL_PAD['z0'] + 5), oval)     # onto the straight, clear of the banking
    roads['to_slalom'] = fillet([(-950, 2380, 0), (-950, SLALOM['z0'] + 6, 0)], False)
    drag = fillet(DRAG_V, False)
    return dict(gp=gp, club=club, handling=hand, oval=oval, roads=roads, pit=pit_lane(), drag=drag)

if __name__ == '__main__':
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    L = build()
    for k in ('gp', 'club', 'handling', 'oval'): print(k, round(length(L[k], True)), 'm')
    fig, ax = plt.subplots(figsize=(12, 12))
    for k in ('gp', 'club', 'handling', 'oval'):
        P = L[k]; ax.plot(np.r_[P[:, 0], P[0, 0]], np.r_[P[:, 1], P[0, 1]], lw=2, label=k)
    for k, P in L['roads'].items(): ax.plot(P[:, 0], P[:, 1], 'k-', lw=1)
    ax.plot(L['pit'][:, 0], L['pit'][:, 1], 'r-', lw=1); ax.plot(*L['gp'][0], 'ro')
    ax.plot([DRAG_X0, DRAG_X1], [DRAG_Z, DRAG_Z], 'm-', lw=3)
    for r, c in ((SLALOM, 'orange'), (PADDOCK, 'gray')):
        ax.add_patch(plt.Rectangle((r['x0'], r['z0']), r['x1'] - r['x0'], r['z1'] - r['z0'], color=c, alpha=0.5))
    ax.add_patch(plt.Rectangle((-HALF, -HALF), 2 * HALF, 2 * HALF, fill=False, ls='--'))
    ax.set_aspect('equal'); ax.invert_yaxis(); ax.grid(True); ax.legend()
    ax.set_xlim(-4100, 4100); ax.set_ylim(4100, -4100)
    fig.savefig('layout.png', dpi=60)
