"""Build the compound map pack: layout -> heights -> ground -> roads, kerbs, run-off, barriers -> buildings,
stands, paddocks -> trees and scenery -> pack (maps/compound.bin)."""
import os, sys, time, json
import numpy as np
import layout as LY
import terrain as TR
import tin
import trackgen as TG
import objects as OB
import assets as AS
import writer as W
from geom import Mesh, quad

OUT = next((a for a in sys.argv[1:] if not a.startswith('--')), 'compound.bin')
SCR = os.environ.get('SCRATCH', '.') + '/'
T0 = time.time()
def log(*a): print(f'[{time.time() - T0:6.1f}s]', *a, flush=True)

ACCESS = ['gate', 'paddock', 'east', 'to_handling', 'west', 'to_drag', 'to_oval', 'to_slalom',
          'club_link', 'hand_link', 'oval_link', 'drag_turn', 'drag_return']


def ring_paint(mesh, cx, cz, y, r, w=0.15, n=96, mat='paint'):
    a = np.linspace(0, 2 * np.pi, n + 1)
    for i in range(n):
        p = [(cx + rr * np.cos(a[j]), y, cz + rr * np.sin(a[j])) for rr, j in ((r - w, i), (r - w, i + 1), (r + w, i + 1), (r + w, i))]
        quad(mesh, mat, p[0], p[1], p[2], p[3], phys=True)


def slalom(mesh, y):
    """cone lines and a skid circle on the slalom pad; cones are the game's own props (positions in the pack)"""
    r = LY.SLALOM
    cones = []
    # a long slalom (18 m), a tight one (12 m), both run west to east
    for z, step in ((r['z0'] + 70, 18.0), (r['z0'] + 130, 12.0)):
        for x in np.arange(r['x0'] + 90, r['x1'] - 60, step): cones.append((x, z))
        OB.flat_quad(mesh, 'paint', r['x0'] + 60, z - 4, r['x0'] + 60.3, z + 4, y, lift=0.012)       # start
        OB.flat_quad(mesh, 'checker', r['x1'] - 40.6, z - 4, r['x1'] - 40, z + 4, y, lift=0.013)     # finish
    # a skid circle of 40 m radius: painted, cones round the outside
    cx, cz = (r['x0'] + r['x1']) / 2, r['z1'] - 90
    ring_paint(mesh, cx, cz, y + 0.012, 40.0)
    ring_paint(mesh, cx, cz, y + 0.012, 30.0, mat='paint_y')
    for a in np.linspace(0, 2 * np.pi, 28, endpoint=False): cones.append((cx + 43 * np.cos(a), cz + 43 * np.sin(a)))
    # a lane-change box near the west end
    for dz in (-6, 6):
        for x in np.arange(r['x0'] + 30, r['x0'] + 60, 5.0): cones.append((x, cz + dz))
    return np.array(cones)


def check_crossings(G):
    """warn where an access road runs over a track or a pad away from its own ends"""
    for k in ACCESS:
        rd = G.roads[k]
        pn, _ = G.pad_at(rd.P[:, 0], rd.P[:, 1], margin=rd.half)
        inner = np.arange(len(rd.P)); inner = (inner > 90) & (inner < len(rd.P) - 90)
        if ((pn != None) & inner).any():
            j = np.nonzero((pn != None) & inner)[0]
            log(f'WARNING: {k} runs over pad {set(pn[j])} at {rd.P[j[0]].round()}')
        nm, _ = G.road_at(rd.P[:, 0], rd.P[:, 1])
        bad = np.array([n_ is not None and n_ != k and G.roads[n_].prio < 1 for n_ in nm])
        inner = np.arange(len(rd.P)); inner = (inner > 20) & (inner < len(rd.P) - 20)
        if (bad & inner).any():
            j = np.nonzero(bad & inner)[0]
            log(f'WARNING: {k} crosses {set(nm[j])} at {rd.P[j[0]].round()}')


def main():
    L = LY.build()
    H0, roads, pads = TR.build(L)
    for i, k in enumerate(ACCESS): roads[k].prio = 3 + 0.01 * i
    H, T = TR.shape(H0, roads, pads)
    log('terrain shaped')
    G = tin.Ground(H, T, roads, pads)
    log('ground triangulated')
    check_crossings(G)
    mesh = Mesh()
    G.mesh(mesh)
    # ---- surfaces
    for rd in roads.values(): TG.road_surface(mesh, G, rd)
    for name, (r, h) in pads.items(): OB.pad_mesh(mesh, G, name, r, h)
    log('roads and pads', len(roads), len(pads))
    # ---- kerbs (Spa's placement), run-off, barriers
    nk = 0
    for k in ('gp', 'club', 'handling'):
        plan = TG.kerb_plan(roads[k])
        for sd, i0, i1, kind in plan: TG.kerb_mesh(mesh, G, roads[k], sd, i0, i1, kind)
        nk += len(plan)
    TG.gravel_and_walls(mesh, G, roads['gp'], wall_off=14.0)
    TG.gravel_and_walls(mesh, G, roads['club'], wall_off=10.0)
    TG.gravel_and_walls(mesh, G, roads['handling'], wall_off=7.0)
    log(f'kerbs {nk} pieces, run-off and barriers')
    # ---- lines
    TG.start_line(mesh, roads['gp'], 0.0, checker=True)
    grid = TG.grid_boxes(mesh, roads['gp'])
    for k in ('club', 'handling', 'oval'): TG.start_line(mesh, roads[k], 0.0, checker=True)
    # ---- buildings and facilities
    flat = pads['paddock'][1]
    OB.pit_complex(mesh, G, flat)
    OB.paddock(mesh, G, flat)
    for k in ('club', 'handling'): OB.small_paddock(mesh, pads[k][0], pads[k][1], None)
    OB.small_paddock(mesh, pads['oval'][0], pads['oval'][1], None)
    OB.drag_strip(mesh, G, roads['drag'])
    OB.oval_walls(mesh, G, roads['oval'])
    OB.gate(mesh, G, float(roads['gate'].y[0]))
    OB.perimeter_fence(mesh, G)
    OB.marshal_posts(mesh, G, roads['gp'])
    OB.marshal_posts(mesh, G, roads['club'], every=600)
    cones = slalom(mesh, pads['slalom'][1])
    log('buildings')
    OB.trees(mesh, G)
    OB.far_scenery(mesh, G)
    log('scenery')
    st = mesh.stats()
    tv = sum(v for v, _ in st.values()); tt = sum(t for _, t in st.values())
    log(f'mesh: {tv} vertices, {tt} triangles, {len(mesh.walls)} walls')
    for k, (v, t) in sorted(st.items(), key=lambda kv: -kv[1][1])[:14]: print(f'    {k:10s} {t:8d} tris')
    # ---- the pack
    if '--nowrite' in sys.argv:
        import pickle; pickle.dump(dict(mesh=mesh, grid=grid, cones=cones), open(SCR + 'mesh.pkl', 'wb')); return
    mats, mat_index, images = AS.build_tables(set(mesh.parts))
    gp = roads['gp']
    meta = dict(width=12.0, loop=True, merge=True, grid=grid,
                credit='Textures: Spa-Francorchamps 1992 and Monte Carlo Rally by Dave Love (CC BY 4.0), Irohazaka Slope by sost',
                tracks=track_meta(roads), roads=road_meta(roads), cones=cones.astype(np.float32).ravel(), spots=spots(roads, pads),
                pads=np.array([[r['x0'], r['z0'], r['x1'], r['z1']] for r, h in pads.values()], np.float32).ravel())
    starts = [s['name'] for s in meta['spots']]
    info = W.write_pack(OUT, mesh, mats, mat_index, images, gp.P.astype(np.float32), gp.y.astype(np.float32), meta, 'Motorsport Compound', gp.L)
    write_json(OUT.replace('.bin', '.json'), roads, starts)
    log('done', info)


def write_json(path, roads, starts):
    gp = roads['gp']
    climb = float(gp.y.max() - gp.y.min())
    km = lambda k: f"{roads[k].L / 1000:.1f} km"
    d = {
        "id": "compound",
        "name": "Motorsport Compound",
        "short": "Compound",
        "sub": f"5 miles square · {gp.L / 1000:.1f} km GP circuit · 6 timed courses",
        "toast": f"Motorsport Compound · GP circuit {gp.L / 1000:.2f} km",
        "blurb": "Five miles square of private proving ground: a Grand Prix circuit over the hills, a club circuit, a handling course, a banked oval, a quarter-mile drag strip and a slalom pad, joined by service roads.",
        "guide": (f"A {gp.L / 1000:.1f} km Grand Prix circuit with {climb:.0f} m of climb, fast sweepers and tight hairpins, with pits, paddock and grandstands on the main straight. "
                  f"Service roads lead to the club circuit ({km('club')}), the handling course ({km('handling')}), the banked oval ({km('oval')}), the quarter-mile drag strip and the slalom pad. "
                  "Each course times itself: drive over its line and the clock starts (laps on the circuits and the oval; a run from the start lights to the finish on the drag strip and the slaloms, 2 s for every cone knocked over). "
                  "Go to (in the menu) puts you at any of them; Reset car puts you back on the nearest road if you are off one."),
        "credit": "Built for Rust Bucket Racing. Textures from \"Circuit de Spa-Francorchamps 1992 layout\" and \"Monte Carlo Rally\" by Dave Love, sketchfab.com/Tyler_Dave (CC BY 4.0), and \"Irohazaka Slope\" by sost and its original authors",
        "far": 16000,
        "fog": 0.00012,
        "occlude": False,
        "stage": False,
        "starts": starts,
        "minGame": "1.9",
    }
    json.dump(d, open(path, 'w'), indent=1, ensure_ascii=False)


def track_meta(roads):
    """the extra timed courses: laps of the club circuit, handling course and oval; the drag strip's quarter mile"""
    out = []
    for k, name, w in (('club', 'Club circuit', 10.0), ('handling', 'Handling course', 8.0), ('oval', 'Oval', 15.0)):
        rd = roads[k]
        idx = np.arange(0, len(rd.P), 2)
        out.append(dict(id=k, name=name, loop=True, width=w, len=round(float(rd.L), 1),
                        line=rd.P[idx].astype(np.float32).ravel(), lineY=rd.y[idx].astype(np.float32)))
    x0 = LY.DRAG_START; z = LY.DRAG_Z
    out.append(dict(id='drag', name='Drag strip', sprint=True, start=[x0, z], finish=[x0 + 402.34, z], width=16.0, dir=[1, 0]))
    sl = LY.SLALOM
    out.append(dict(id='slalom', name='Slalom', sprint=True, start=[sl['x0'] + 60.15, sl['z0'] + 70], finish=[sl['x1'] - 40.3, sl['z0'] + 70], width=8.0, dir=[1, 0]))
    out.append(dict(id='slalom2', name='Tight slalom', sprint=True, start=[sl['x0'] + 60.15, sl['z0'] + 130], finish=[sl['x1'] - 40.3, sl['z0'] + 130], width=8.0, dir=[1, 0]))
    return out


def road_meta(roads):
    """every driveable centreline, every 5 m (x, y, z): the reset puts the car back on the nearest one"""
    out = []
    for k, rd in roads.items():
        idx = np.arange(0, len(rd.P), 5)
        if idx[-1] != len(rd.P) - 1: idx = np.r_[idx, len(rd.P) - 1]
        out.append(dict(id=k, half=float(rd.half), loop=bool(rd.closed),
                        pts=np.c_[rd.P[idx, 0], rd.y[idx], rd.P[idx, 1]].astype(np.float32).ravel()))
    return out


def spots(roads, pads):
    """starting points for free roam: (name, x, z, heading as a direction)"""
    def on(k, s, back=0.0):
        rd = roads[k]; j = int(s) % len(rd.P)
        p = rd.P[j] - rd.t[j] * back
        return [round(float(p[0]), 2), round(float(p[1]), 2), round(float(rd.t[j, 0]), 4), round(float(rd.t[j, 1]), 4)]
    out = [dict(name='Pit lane', at=on('pit', 120)),
           dict(name='Club circuit', at=on('club_link', 10)),
           dict(name='Handling course', at=on('hand_link', 10)),
           dict(name='Oval', at=on('oval_link', 10)),
           dict(name='Drag strip', at=[LY.DRAG_START - 9.0, LY.DRAG_Z - 4.0, 1.0, 0.0]),
           dict(name='Slalom pad', at=[LY.SLALOM['x0'] + 40.0, LY.SLALOM['z0'] + 70, 1.0, 0.0]),
           dict(name='Main gate', at=on('gate', 110))]
    return out


if __name__ == '__main__':
    main()
