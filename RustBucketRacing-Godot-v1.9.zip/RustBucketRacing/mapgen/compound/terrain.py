"""Terrain for the compound: a heightfield (4 m grid over +-5.2 km), road profiles, and the ground cut and filled
to meet the roads and pads.

  * rolling hills from a few octaves of smooth noise, stronger in the north (the GP circuit), gentle in the south
    (the facilities), and rising hills outside the fence that frame the view
  * designed features for the GP circuit: a valley after T1 (the esses), a hill for the top hairpin, the back
    straight running down to the bottom hairpin
  * each road follows the ground smoothed (more smoothing and a lower grade limit for access roads), the oval,
    the drag strip and the pads are flat; the GP main straight and the paddock share one height
  * the ground: under a road it sits 0.3 m down (the road mesh covers it), then a verge falling 2 % (grass
    run-off), then an embankment blending into the natural ground over 2.2 m per metre of height difference"""
import numpy as np
from scipy.ndimage import zoom, gaussian_filter1d, map_coordinates
from scipy.spatial import cKDTree
import layout as LY
from paths import frame

EXT, RES = 5200.0, 4.0
N = int(round(2 * EXT / RES)) + 1
AX = -EXT + RES * np.arange(N)


def smoothstep(t):
    t = np.clip(t, 0, 1); return t * t * (3 - 2 * t)


def noise(seed):
    """sum of smooth random fields (bicubic upsampled), unit-ish amplitude per octave"""
    rng = np.random.default_rng(seed)
    total = np.zeros((N, N), np.float32)
    for lam, amp in ((2600, 1.0), (1300, 0.55), (650, 0.28), (300, 0.12), (120, 0.04)):
        k = int(np.ceil(2 * EXT / lam)) + 4
        g = rng.standard_normal((k, k)).astype(np.float32)
        z = zoom(g, (N + 2 * lam / RES) / k, order=3)
        o = int(lam / RES)
        total += amp * z[o:o + N, o:o + N]
    return total


def bump(X, Z, x, z, sig, h):
    return h * np.exp(-((X - x) ** 2 + (Z - z) ** 2) / (2 * sig * sig))


def base_height():
    X, Z = np.meshgrid(AX, AX)                                   # rows: z, cols: x
    n = noise(7)
    region = np.where(Z < 0, 1.25, np.where(Z > 900, 0.45, 1.25 - 0.8 * Z / 900))
    H = 14.0 * n * region
    # the GP circuit's hills and dips
    H += bump(X, Z, -1250, -2200, 520, 34)       # the top hairpin's hill
    H += bump(X, Z, -1060, -330, 280, -15)       # the valley after T1
    H += bump(X, Z, -900, -900, 300, 8)          # up the esses
    H += bump(X, Z, 700, -2450, 650, 20)         # the fast sweepers along the top
    H += bump(X, Z, 1500, -950, 320, -12)        # down to the bottom hairpin
    H += bump(X, Z, 1450, -1900, 400, 14)        # ...from the top of the back straight
    # outside the fence the ground rises into hills, with more relief
    box = (np.abs(X) ** 6 + np.abs(Z) ** 6) ** (1 / 6)          # a rounded square: no creases at the corners
    rim = smoothstep((box - 3750) / 1450)
    H += rim * (120 + 60 * noise(11))
    return H.astype(np.float32)


def sample(H, x, z):
    c = (np.asarray(x) + EXT) / RES; r = (np.asarray(z) + EXT) / RES
    return map_coordinates(H, [r, c], order=1, mode='nearest')


def limit_grade(y, ds, gmax, closed, sigma):
    mode = 'wrap' if closed else 'nearest'
    for _ in range(12):
        g = np.abs(np.gradient(y) / ds)
        if g.max() <= gmax: break
        w = gaussian_filter1d(np.clip((g - 0.8 * gmax) / (0.4 * gmax), 0, 1), 20 / ds, mode=mode)
        y2 = gaussian_filter1d(y, 3 * sigma / ds, mode=mode)
        y = y + np.clip(w * 2, 0, 1) * (y2 - y)
    return y


class Road:
    """a road surface along a path: centreline heights, half width, banking (height change per metre to the left)"""
    def __init__(self, name, P, closed, half, verge, y, bank=None, prio=5):
        self.name, self.P, self.closed, self.half, self.verge, self.y, self.prio = name, P, closed, half, verge, y, prio
        self.t, self.n, self.k = frame(P, closed)
        self.bank = np.zeros(len(P)) if bank is None else bank
        d = np.hypot(*np.diff(P, axis=0).T)
        self.s = np.concatenate([[0], np.cumsum(d)])
        self.L = self.s[-1] + (np.hypot(*(P[0] - P[-1])) if closed else 0)

    def surface(self, j, o):
        """road height at sample j, lateral offset o (+ = left), clamped to the road"""
        return self.y[j] + self.bank[j] * np.clip(o, -self.half, self.half)


def profile(H, P, closed, sigma, gmax, ds=1.0):
    y = sample(H, P[:, 0], P[:, 1]).astype(np.float64)
    mode = 'wrap' if closed else 'nearest'
    y = gaussian_filter1d(y, sigma / ds, mode=mode)
    return limit_grade(y, ds, gmax, closed, sigma)


def pin_ends(y, a=None, b=None, blend=0.35, flat=12.0, fade=30.0):
    """move the ends of an open profile onto given heights, the correction fading along the road; the last `flat`
    metres at a pinned end are level with it (across the road it joins), easing back over `fade` metres"""
    n = len(y); u = np.linspace(0, 1, n)
    if a is not None: y = y + (a - y[0]) * (1 - smoothstep(u / blend))
    if b is not None: y = y + (b - y[-1]) * smoothstep((u - (1 - blend)) / blend)
    if flat:
        s = np.arange(n, dtype=float)
        if a is not None: y = y + (a - y) * (1 - smoothstep((s - flat) / fade))
        if b is not None: y = y + (b - y) * (1 - smoothstep(((n - 1 - s) - flat) / fade))
    return y


def pad_height(H, r):
    xs = np.linspace(r['x0'], r['x1'], 12); zs = np.linspace(r['z0'], r['z1'], 12)
    X, Z = np.meshgrid(xs, zs)
    return float(np.median(sample(H, X.ravel(), Z.ravel())))


def build(L):
    H0 = base_height()
    roads = {}
    # ---- GP: the main straight (and pits, paddock) on one level
    gp = L['gp']
    y = profile(H0, gp, True, 35, 0.085)
    straight = (gp[:, 1] > 150) & (gp[:, 0] > -900) & (gp[:, 0] < 1150)
    flat = float(np.mean(y[straight]))
    w = gaussian_filter1d(straight.astype(float), 40, mode='wrap')
    w = np.clip(w * 1.6, 0, 1)
    y = w * flat + (1 - w) * y
    y = limit_grade(y, 1.0, 0.085, True, 35)
    roads['gp'] = Road('gp', gp, True, 6.0, 10.0, y, prio=0)
    roads['pit'] = Road('pit', L['pit'], False, 6.0, 0.0, np.full(len(L['pit']), flat), prio=1)
    pads = {'paddock': (LY.PADDOCK, flat)}
    # ---- the other tracks
    roads['club'] = Road('club', L['club'], True, 5.0, 8.0, profile(H0, L['club'], True, 40, 0.07), prio=0)
    roads['handling'] = Road('handling', L['handling'], True, 4.0, 6.0, profile(H0, L['handling'], True, 25, 0.09), prio=0)
    ov = L['oval']
    yo = float(np.median(sample(H0, ov[:, 0], ov[:, 1])))
    _, _, k = frame(ov, True)
    bank = -np.sign(k) * np.tan(np.radians(14)) * np.clip(np.abs(k) * LY.OVAL_R, 0, 1)   # the outside edge higher
    roads['oval'] = Road('oval', ov, True, 7.5, 4.0, np.full(len(ov), yo), bank=bank, prio=0)
    dg = L['drag']
    yd = float(np.median(sample(H0, dg[:, 0], dg[:, 1])))
    roads['drag'] = Road('drag', dg, False, 8.0, 3.0, np.full(len(dg), yd), prio=0)
    for name, r in (('club', LY.CLUB_PAD), ('handling', LY.HAND_PAD), ('slalom', LY.SLALOM), ('gate', LY.GATE_PAD)):
        pads[name] = (r, pad_height(H0, r))
    pads['oval'] = (LY.OVAL_PAD, yo)
    pads['drag'] = (LY.DRAG_PAD, yd)
    # ---- access roads, in order, each starting or ending on a height that is already fixed
    R = L['roads']
    def at(name, x, z):
        rd = roads[name]; j = int(np.argmin(np.hypot(rd.P[:, 0] - x, rd.P[:, 1] - z))); return float(rd.y[j])
    def acc(name, a=None, b=None):
        P = R[name]; y = profile(H0, P, False, 70, 0.07)
        roads[name] = Road(name, P, False, 3.6, 3.0, pin_ends(y, a, b), prio=3)
    j0 = float(sample(H0, [0], [2050])[0])
    acc('gate', None, j0)
    acc('paddock', j0, flat)
    acc('east', j0, pads['club'][1])
    acc('to_handling', at('east', 1400, 1950), pads['handling'][1])
    acc('west', j0, None)
    acc('to_drag', at('west', -950, 2380), yd)
    acc('to_oval', at('to_drag', -1500, 2600), yo)
    def link(name, track, pad):
        P = R[name]; y = profile(H0, P, False, 15, 0.08)
        roads[name] = Road(name, P, False, 3.6, 2.0, pin_ends(y, pads[pad][1], at(track, P[-1, 0], P[-1, 1]), blend=0.5), prio=3)
    link('club_link', 'club', 'club'); link('hand_link', 'handling', 'handling'); link('oval_link', 'oval', 'oval')
    acc('to_slalom', at('west', -950, 2380), pads['slalom'][1])
    for name in ('drag_turn', 'drag_return'):          # on the drag strip's level
        roads[name] = Road(name, R[name], False, 3.6, 3.0, np.full(len(R[name]), yd), prio=3)
    level_on_pads(roads, pads)
    return H0, roads, pads


def level_on_pads(roads, pads, blend=40.0):
    """where an access road crosses a pad (with a margin), it runs at the pad's level; the change fades over `blend` m"""
    from scipy.ndimage import distance_transform_edt
    for rd in roads.values():
        if rd.prio < 2: continue
        y = rd.y.copy(); d = np.zeros(len(y)); hit = np.zeros(len(y), bool)
        for (r, h) in pads.values():
            m = rd.half + 2.0
            ins = (rd.P[:, 0] > r['x0'] - m) & (rd.P[:, 0] < r['x1'] + m) & (rd.P[:, 1] > r['z0'] - m) & (rd.P[:, 1] < r['z1'] + m)
            d[ins] = h - y[ins]; hit |= ins
        if not hit.any(): continue
        dist, (near,) = distance_transform_edt(~hit, return_indices=True)
        w = 1 - smoothstep(dist / blend)
        rd.y = y + d[near] * w


def shape(H0, roads, pads):
    """the ground cut and filled to the roads and pads; also returns the influence (0 at a road, 1 untouched)"""
    H = H0.copy(); T = np.ones_like(H0)
    X, Z = np.meshgrid(AX, AX)
    def apply(mask_rc, tgt, tinf):
        r, c = mask_rc
        sub = tinf < T[r, c]
        H[r[sub], c[sub]] = tgt[sub]; T[r[sub], c[sub]] = tinf[sub]
    reach = 140.0
    for rd in sorted(roads.values(), key=lambda r: -r.prio):          # most important last: it wins ties
        lo = rd.P.min(0) - reach; hi = rd.P.max(0) + reach
        c0, c1 = np.searchsorted(AX, [lo[0], hi[0]]); r0, r1 = np.searchsorted(AX, [lo[1], hi[1]])
        rr, cc = np.mgrid[r0:r1, c0:c1]; rr = rr.ravel(); cc = cc.ravel()
        px, pz = AX[cc], AX[rr]
        tree = cKDTree(rd.P)
        d, j = tree.query(np.c_[px, pz], distance_upper_bound=reach + rd.half + rd.verge)
        ok = np.isfinite(d); rr, cc, px, pz, j = rr[ok], cc[ok], px[ok], pz[ok], j[ok]
        dx, dz = px - rd.P[j, 0], pz - rd.P[j, 1]
        o = dx * rd.n[j, 0] + dz * rd.n[j, 1]
        a = dx * rd.t[j, 0] + dz * rd.t[j, 1]
        dout = np.abs(o) - rd.half
        if not rd.closed:                                   # beyond the ends: round caps
            end = ((j == 0) & (a < -0.5)) | ((j == len(rd.P) - 1) & (a > 0.5))
            dout = np.where(end, np.hypot(np.maximum(dout, 0), np.abs(a)) + np.where(dout < 0, 0, 0), dout)
        ye = rd.surface(j, o)
        h0 = H0[rr, cc]
        vh = ye - 0.05 - 0.02 * rd.verge
        dh = h0 - vh
        B = np.maximum(10.0, 2.2 * np.abs(dh))
        tb = smoothstep((dout - rd.verge) / B)
        tgt = np.where(dout <= 0.3, ye - 0.3, np.where(dout <= rd.verge, ye - 0.05 - 0.02 * np.maximum(dout, 0), vh + tb * dh))
        tinf = np.where(dout <= rd.verge, 0.0, tb)
        apply((rr, cc), tgt.astype(np.float32), tinf.astype(np.float32))
    for name, (r, h) in pads.items():
        lo = np.array([r['x0'], r['z0']]) - reach; hi = np.array([r['x1'], r['z1']]) + reach
        c0, c1 = np.searchsorted(AX, [lo[0], hi[0]]); r0, r1 = np.searchsorted(AX, [lo[1], hi[1]])
        rr, cc = np.mgrid[r0:r1, c0:c1]; rr = rr.ravel(); cc = cc.ravel()
        px, pz = AX[cc], AX[rr]
        ddx = np.maximum(np.maximum(r['x0'] - px, px - r['x1']), 0); ddz = np.maximum(np.maximum(r['z0'] - pz, pz - r['z1']), 0)
        dout = np.hypot(ddx, ddz)
        inside = (px >= r['x0']) & (px <= r['x1']) & (pz >= r['z0']) & (pz <= r['z1'])
        h0 = H0[rr, cc]; vh = h - 0.1; dh = h0 - vh
        B = np.maximum(10.0, 2.2 * np.abs(dh))
        tb = smoothstep((dout - 2) / B)
        tgt = np.where(inside, h - 0.3, np.where(dout <= 2, h - 0.05, vh + tb * dh))
        tinf = np.where(dout <= 2, 0.0, tb)
        apply((rr, cc), tgt.astype(np.float32), tinf.astype(np.float32))
    return H, T


if __name__ == '__main__':
    import time
    t0 = time.time()
    L = LY.build()
    H0, roads, pads = build(L)
    print(f'base and profiles {time.time() - t0:.1f}s, H0 {H0.min():.0f}..{H0.max():.0f} m')
    for k, r in roads.items():
        g = np.abs(np.gradient(r.y) / np.maximum(np.gradient(r.s), 1e-6))
        print(f'  {k:12s} {r.L:7.0f} m  y {r.y.min():6.1f}..{r.y.max():6.1f}  max grade {g.max() * 100:4.1f} %')
    H, T = shape(H0, roads, pads)
    print(f'shaped {time.time() - t0:.1f}s')
    np.savez_compressed('terrain.npz', H=H, H0=H0, T=T)
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    from matplotlib.colors import LightSource
    fig, ax = plt.subplots(figsize=(12, 12))
    ls = LightSource(azdeg=315, altdeg=35)
    sub = H[::3, ::3]
    rgb = ls.shade(sub, cmap=plt.cm.gist_earth, vert_exag=3, blend_mode='soft', vmin=H.min(), vmax=H.max())
    ax.imshow(rgb, extent=[-EXT, EXT, EXT, -EXT])
    for k, r in roads.items():
        P = r.P if not r.closed else np.vstack([r.P, r.P[:1]])
        ax.plot(P[:, 0], P[:, 1], 'k-', lw=0.6)
    ax.add_patch(plt.Rectangle((-LY.HALF, -LY.HALF), 2 * LY.HALF, 2 * LY.HALF, fill=False, ls='--', color='w'))
    fig.savefig('terrain.png', dpi=70)
    print('done')
