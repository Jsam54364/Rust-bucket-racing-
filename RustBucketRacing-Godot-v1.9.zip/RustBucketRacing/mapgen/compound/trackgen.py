"""Road surfaces, kerbs, run-off and barriers.

Kerbs follow the way Spa-Francorchamps has them (measured from its map pack): on every corner tighter than about
250 m, a red and white kerb on the inside from 40-70 m before the apex to 10-80 m after it; one on the outside at
the exit running 50-120 m on (longer for faster corners); one on the outside at turn-in for medium and fast
corners; sausage kerbs behind the apex kerb of hairpins and chicanes; green paint beyond the exit kerb of the
faster corners. They sit across the track edge (0.9 m on the asphalt, 0.7 m over the verge), nearly flush.
Gravel traps lie on the outside of the slower corners, with tyre walls behind the slowest; Armco runs along both
sides of the circuits beyond the run-off."""
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import cKDTree
from geom import grid_tris, quad, strip, box
import layout as LY

TRACKS = ('gp', 'club', 'handling', 'oval', 'pit')


def wrap_range(i0, i1, n, closed):
    """indices from i0 to i1 inclusive (wrapping on a loop)"""
    if not closed: return np.arange(max(0, i0), min(n - 1, i1) + 1)
    return np.arange(i0, i1 + 1) % n


def road_surface(mesh, G, rd):
    """the road ribbon: left skirt, left edge, centre, right edge, right skirt; sunk 3 cm wherever a more
    important road or a pad already covers it"""
    idx = G.stations(rd, 2.0, 5.0)
    if rd.closed and idx[-1] == len(rd.P) - 1: idx = idx[:-1]
    h = rd.half
    offs = np.array([h + 0.45, h, 0, -h, -h - 0.45])
    na, nc = len(idx), len(offs)
    X = rd.P[idx][:, None, :] + rd.n[idx][:, None, :] * offs[None, :, None]
    Y = np.stack([rd.surface(idx, o) for o in offs], 1)
    Y[:, 0] -= 0.3; Y[:, -1] -= 0.3
    # sink under more important surfaces
    flat = X.reshape(-1, 2)
    yf = Y.reshape(-1)
    for k, other in G.roads.items():
        if other.prio >= rd.prio or k == rd.name: continue
        nm, yo = G.road_at(flat[:, 0], flat[:, 1], margin=-0.02)
        sink = np.array([n_ is not None and G.roads[n_].prio < rd.prio for n_ in nm])
        yf = np.where(sink, np.minimum(yf, yo - 0.03), yf)
        break
    if rd.prio > 2:
        pn, yp = G.pad_at(flat[:, 0], flat[:, 1], margin=-0.02)
        yf = np.where(pn != None, np.minimum(yf, yp - 0.03), yf)
    Y = yf.reshape(na, nc)
    P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
    s = rd.s[idx]
    if rd.name == 'drag':
        U = np.stack([np.broadcast_to(-offs / 8, (na, nc)), np.broadcast_to(s[:, None] / 8, (na, nc))], -1)
        mat = 'pad'
    elif rd.name in TRACKS:
        u = np.clip(0.5 - offs / (2 * h), -0.03, 1.03)
        U = np.stack([np.broadcast_to(u, (na, nc)), np.broadcast_to(s[:, None] / (2 * h), (na, nc))], -1)
        mat = 'track'
    else:
        u = np.clip(0.5 - offs / (2 * h), -0.03, 1.03)
        U = np.stack([np.broadcast_to(u, (na, nc)), np.broadcast_to(s[:, None] / 7.5, (na, nc))], -1)
        mat = 'road'
    if rd.closed:      # the texture's v must not jump where the loop closes: the last row repeats the first
        P = np.vstack([P, P[:nc]]); U = U.reshape(-1, 2); U = np.vstack([U, np.c_[U[:nc, 0], np.full(nc, rd.L / (2 * h))]])
        na += 1
    I = grid_tris(na, nc)
    # triangles touching the skirt columns are drawn only
    col = I % nc
    phys = ~((col == 0).any(1) | (col == nc - 1).any(1))
    mesh.add(mat, P, U.reshape(-1, 2), I, phys=phys)
    return idx


# ---------------------------------------------------------------- corners and kerbs
def corners(rd, r_max=250.0):
    """corner runs: start, apex, end indices, min radius R, turn side (+1 left, -1 right), length L (m)"""
    closed = rd.closed
    k = gaussian_filter1d(rd.k, 10, mode='wrap' if closed else 'nearest')
    n = len(k)
    on = np.abs(k) > 1 / r_max
    if not on.any() or on.all(): return []
    sh = int(np.argmin(on)) if closed else 0                  # start on a straight
    kk = np.roll(k, -sh); oo = np.roll(on, -sh)
    edges = np.diff(np.r_[0, oo.astype(int), 0])
    starts, ends = np.nonzero(edges == 1)[0], np.nonzero(edges == -1)[0] - 1
    out = []
    for a, b in zip(starts, ends):
        ids = np.arange(a, b + 1)
        sg = np.sign(kk[ids])
        for part in np.split(ids, np.nonzero(np.diff(sg) != 0)[0] + 1):     # esses: one corner per direction
            if len(part) < 6: continue
            ap = part[np.argmax(np.abs(kk[part]))]
            m = lambda i: int((i + sh) % n) if closed else int(i)
            out.append(dict(start=m(part[0]), apex=m(ap), end=m(part[-1]), R=1 / abs(kk[ap]), side=int(np.sign(kk[ap])), L=float(len(part))))
    return out


def kerb_plan(rd):
    """pieces: (side, i0, i1, kind) by the Spa rules"""
    pieces = []
    for c in corners(rd):
        ap, L, R, sd = c['apex'], c['L'], c['R'], c['side']
        a0 = ap - int(min(70, 0.55 * L + 12)); a1 = ap + int(min(80, 0.35 * L + 8))
        if a1 - a0 < 25: a0, a1 = ap - 15, ap + 12
        pieces.append((sd, a0, a1, 'kerb'))
        e0 = ap + int(0.15 * L); e1 = c['end'] + int(25 + min(90, 0.35 * R))
        pieces.append((-sd, e0, max(e1, e0 + 30), 'kerb'))
        if R >= 40:
            pieces.append((-sd, c['start'] - int(30 + min(40, 0.25 * R)), c['start'] + int(0.15 * L), 'kerb'))
        if R < 35:
            pieces.append((sd, ap - 12, ap + 12, 'sausage'))
        if R > 60:
            pieces.append((-sd, e0 + 5, max(e1, e0 + 30) - 5, 'green'))
    # merge overlapping pieces of one side and kind
    merged = []
    for sd, kind in {(p[0], p[3]) for p in pieces}:
        ps = sorted((p[1], p[2]) for p in pieces if p[0] == sd and p[3] == kind)
        cur = list(ps[0])
        for a, b in ps[1:]:
            if a <= cur[1] + 8: cur[1] = max(cur[1], b)
            else: merged.append((sd, cur[0], cur[1], kind)); cur = [a, b]
        merged.append((sd, cur[0], cur[1], kind))
    return merged


def kerb_mesh(mesh, G, rd, side, i0, i1, kind):
    n = len(rd.P)
    ids = wrap_range(i0, i1, n, rd.closed)[::2]
    if len(ids) < 3: return
    h = rd.half
    if kind == 'kerb': offs, lift, mat, uvl = [h - 0.9, h - 0.1, h + 0.7], [0.005, 0.045, 0.015], 'kerb', 2.8
    elif kind == 'sausage': offs, lift, mat, uvl = [h + 1.0, h + 1.25, h + 1.6], [0.03, 0.14, 0.03], 'sausage', 3.0
    else: offs, lift, mat, uvl = [h + 0.7, h + 1.9, h + 3.2], [0.03, 0.03, 0.03], 'green', 4.0
    offs = np.array(offs) * side
    na, nc = len(ids), 3
    taper = np.clip(np.minimum(np.arange(na), np.arange(na)[::-1]) / 1.5, 0, 1)
    X = rd.P[ids][:, None, :] + rd.n[ids][:, None, :] * offs[None, :, None]
    Y = np.zeros((na, nc))
    for c in range(nc):
        if abs(offs[c]) <= h: base = rd.surface(ids, offs[c])
        else:            # over the verge: on the ground, and never under the road's edge plane
            gy = G.height(X[:, c, 0], X[:, c, 1])
            base = gy if kind != 'kerb' else np.maximum(gy, rd.surface(ids, np.sign(offs[c]) * h))
        Y[:, c] = base + lift[c] * (taper if kind == 'kerb' or c == 1 else 1)
    P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
    s = np.arange(na) * 2.0
    U = np.stack([np.repeat(s[:, None] / uvl, nc, 1), np.broadcast_to([0.0, 0.55, 1.0], (na, nc))], -1)
    I = grid_tris(na, nc)
    if side < 0: I = I[:, [0, 2, 1]]
    mesh.add(mat, P, U.reshape(-1, 2), I, phys=True)


# ---------------------------------------------------------------- run-off and barriers
def gravel_and_walls(mesh, G, rd, plan_traps=True, wall_off=14.0, rails=True):
    """gravel traps on the outside of slow corners (tyre walls behind the slowest), Armco along both sides"""
    n = len(rd.P); h = rd.half
    outer = {1: np.full(n, h + wall_off), -1: np.full(n, h + wall_off)}
    traps = []
    if plan_traps:
        for c in corners(rd):
            if c['R'] > 115: continue
            sd = -c['side']
            a = c['apex'] - int(0.2 * c['L']); b = c['end'] + int(50 + 0.4 * c['R'])
            W = float(np.clip(12 + 0.12 * c['R'], 12, 26))
            traps.append((sd, a, b, W, c['R']))
    for sd, a, b, W, R in traps:
        ids = wrap_range(a, b, n, rd.closed)[::3]
        if len(ids) < 4: continue
        u = np.linspace(0, 1, len(ids))
        wid = W * np.clip(np.minimum(u, 1 - u) / 0.18, 0, 1) ** 0.7
        o0 = h + 3.4
        cols = 6
        frac = np.linspace(0, 1, cols)
        O = o0 + wid[:, None] * frac[None, :]
        X = rd.P[ids][:, None, :] + rd.n[ids][:, None, :] * (O * sd)[:, :, None]
        Y = G.height(X[:, :, 0].ravel(), X[:, :, 1].ravel()).reshape(X.shape[:2]) + 0.035
        P = np.dstack([X[:, :, 0], Y, X[:, :, 1]]).reshape(-1, 3)
        U = np.dstack([X[:, :, 0] / 6, X[:, :, 1] / 6]).reshape(-1, 2)
        I = grid_tris(len(ids), cols)
        if sd < 0: I = I[:, [0, 2, 1]]
        mesh.add('gravel', P, U, I)
        wall_o = o0 + W + 1.5
        outer[sd][ids] = np.maximum(outer[sd][ids], wall_o + 2.0)
        if R < 60:      # tyre wall along the back of the trap
            k = (wid > W * 0.6)
            seg = ids[k]
            if len(seg) > 2:
                pts = rd.P[seg] + rd.n[seg] * (sd * wall_o)
                yg = G.height(pts[:, 0], pts[:, 1])
                tyre_wall(mesh, pts, yg, sd, rd.n[seg])
    if not rails: return
    # Armco: smooth the offsets, keep inside the corner's own radius, stop where it would cross another road
    for sd in (1, -1):
        o = gaussian_filter1d(outer[sd], 25, mode='wrap' if rd.closed else 'nearest')
        kin = rd.k * sd                                       # > 0: this side is the inside of a turn
        lim = np.where(kin > 1e-4, 0.75 / np.maximum(kin, 1e-9), 1e9)
        o = np.minimum(o, lim)
        pts = rd.P + rd.n * (sd * o[:, None])
        ok = o > h + 4
        nm, _ = G.road_at(pts[:, 0], pts[:, 1], margin=3.0)
        ok &= (nm == None)
        pn, _ = G.pad_at(pts[:, 0], pts[:, 1], margin=3.0)
        ok &= (pn == None)
        # not too close to the track itself elsewhere (where another part of the circuit runs by)
        dd, jj = cKDTree(rd.P).query(pts)
        ok &= dd > h + 3.5
        runs = np.split(np.arange(n), np.nonzero(np.diff(ok.astype(int)))[0] + 1)
        for r in runs:
            if not ok[r[0]] or len(r) < 12: continue
            seg = r[::2]
            P2 = pts[seg]
            yg = G.height(P2[:, 0], P2[:, 1])
            armco(mesh, P2, yg)


def armco(mesh, pts, yg):
    strip(mesh, 'rail', pts, yg + 0.45, yg + 0.8, 4.0, 0.0, 1.0)
    s = np.concatenate([[0], np.cumsum(np.hypot(*np.diff(pts, axis=0).T))])
    for d in np.arange(2.0, s[-1], 4.0):
        i = np.searchsorted(s, d); i = min(max(i, 1), len(pts) - 1)
        p = pts[i - 1] + (pts[i] - pts[i - 1]) * ((d - s[i - 1]) / max(s[i] - s[i - 1], 1e-6))
        y = yg[i - 1]
        t = pts[i] - pts[i - 1]; t /= max(np.linalg.norm(t), 1e-6)
        a, b = p - t * 0.06, p + t * 0.06
        quad(mesh, 'post', (a[0], y - 0.1, a[1]), (b[0], y - 0.1, b[1]), (b[0], y + 0.75, b[1]), (a[0], y + 0.75, a[1]))
    mesh.wall_line(pts, yg - 0.3, yg + 0.95)


def tyre_wall(mesh, pts, yg, sd, nrm):
    """two tyres deep, a metre high: a face toward the track, the top, and the back"""
    front = pts - nrm * (sd * 0.6); back = pts + nrm * (sd * 0.6)
    strip(mesh, 'tyres', front, yg - 0.05, yg + 1.0, 1.2, 0.0, 1.0)
    strip(mesh, 'tyres', back, yg - 0.05, yg + 1.0, 1.2, 0.0, 1.0)
    n = len(pts)
    P = np.concatenate([np.c_[front[:, 0], yg + 1.0, front[:, 1]], np.c_[back[:, 0], yg + 1.0, back[:, 1]]])
    I = np.concatenate([[[i, i + 1, n + i], [i + 1, n + i + 1, n + i]] for i in range(n - 1)])
    s = np.concatenate([[0], np.cumsum(np.hypot(*np.diff(pts, axis=0).T))])
    U = np.concatenate([np.c_[s / 1.2, np.zeros(n)], np.c_[s / 1.2, np.full(n, 0.5)]])
    mesh.add('tyres', P, U, I, phys=False)
    mesh.wall_line(front, yg - 0.3, yg + 1.0)


# ---------------------------------------------------------------- paint
def paint_band(mesh, mat, rd, s0, s1, o0, o1, lift=0.012, uv=None):
    """a painted rectangle on a road between s0..s1 (metres) and lateral o0..o1"""
    n = len(rd.P)
    def at(s, o):
        j = int(round(s)) % n if rd.closed else int(np.clip(round(s), 0, n - 1))
        p = rd.P[j] + rd.n[j] * o
        return (p[0], rd.surface(j, o) + lift, p[1])
    A, B, C, D = at(s0, o1), at(s0, o0), at(s1, o0), at(s1, o1)
    quad(mesh, mat, A, B, C, D, uv=uv or ((0, 0), (1, 0), (1, 1), (0, 1)), phys=True)


def start_line(mesh, rd, s=0.0, checker=False):
    h = rd.half
    if checker: paint_band(mesh, 'checker', rd, s - 0.6, s + 0.6, -h, h, uv=((0, 0), (0, 1), (1, 1), (1, 0)))
    else: paint_band(mesh, 'paint', rd, s - 0.3, s + 0.3, -h, h)


def grid_boxes(mesh, rd, count=20):
    """painted grid boxes behind the line (the circuit's start is s = 0, cars face along +s): returns their
    centres for the pack (the game puts each car 1.5 m ahead of its box centre)"""
    L = rd.L; out = []
    for i in range(count):
        sc = L - 9 - 8 * i
        d = -2.9 if i % 2 == 0 else 2.9               # pole on the right: the inside of T1
        front = sc + 1.5
        paint_band(mesh, 'paint', rd, front - 0.15, front + 0.15, d - 1.1, d + 1.1)
        for e in (d - 1.1, d + 1.1):
            paint_band(mesh, 'paint', rd, front - 1.2, front, e - 0.08, e + 0.08)
        j = int(round(sc)) % len(rd.P)
        p = rd.P[j] + rd.n[j] * d
        out.append([round(float(p[0]), 2), round(float(p[1]), 2)])
    return out
