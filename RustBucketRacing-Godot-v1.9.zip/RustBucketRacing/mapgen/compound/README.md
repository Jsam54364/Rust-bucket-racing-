# The Motorsport Compound generator

Builds `compound.bin` and `compound.json` (the installable map) from scratch: layout, heights, ground, roads,
kerbs, run-off, barriers, buildings, trees and the scenery beyond the fence. Not part of the game build
(`mapgen/.gdignore` keeps Godot out of this folder).

Needs Python 3 with numpy, scipy, Pillow (webp) and matplotlib, and Godot 4.7 (headless, for the LODs: set `GODOT`
to its binary).

    python3 extract_textures.py <folder with spa.bin, mcr.bin, iroha.bin>   # the borrowed textures -> tex_src/
    GODOT=/path/to/godot python3 gen.py compound.bin                         # ~1 min: compound.bin + compound.json
    python3 check_phys.py compound.bin                                       # holes and steps in the drive surface

- `layout.py`: where everything goes (the circuits as fillet polygons, the oval, drag strip, pads, access roads)
- `terrain.py`: the heightfield, each road's height profile (grade-limited, levelled at junctions and pads), cut and fill
- `tin.py`: the ground as one triangulation, dense near the roads, edged by a rounded square
- `trackgen.py`: road surfaces, kerbs placed the way Spa-Francorchamps has them, gravel traps, tyre walls, Armco, lines, grid
- `objects.py`: pits, paddocks, stands, transporters, tents, gate, fences, trees, and the far hills and mountains
- `writer.py`: the RBMP v2 pack (chunks, LODs, walls, the extra map data the game reads from 1.9)
