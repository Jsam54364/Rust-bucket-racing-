"""Everything that stands on the compound: pads (paddocks, parking, the slalom pad), the pit garages, race control,
grandstands, transporters and tents, workshops, the main building and gate, the drag strip's tower and lights,
walls and fences, marshal posts, trees and forests, and the scenery beyond the fence (wooded hills, tree lines,
mountains on the horizon)."""
import numpy as np
from scipy.spatial import cKDTree
from geom import box, quad, strip, card, cards, grid_tris
import layout as LY
import terrain as TR

RNG = np.random.default_rng(42)


def pad_mesh(mesh, G, name, r, h, mat='pad', step=16.0):
    xs = np.arange(r['x0'] - 0.45, r['x1'] + 0.45 + 1e-6, step); xs[-1] = r['x1'] + 0.45
    zs = np.arange(r['z0'] - 0.45, r['z1'] + 0.45 + 1e-6, step); zs[-1] = r['z1'] + 0.45
    xs = np.unique(np.r_[xs, r['x0'], r['x1']]); zs = np.unique(np.r_[zs, r['z0'], r['z1']])
    X, Z = np.meshgrid(xs, zs)
    Y = np.full(X.shape, h)
    edge = (X < r['x0']) | (X > r['x1']) | (Z < r['z0']) | (Z > r['z1'])
    Y[edge] -= 0.3                                            # skirt down under the ground
    # under the pit lane and other more important roads (pads rank below the tracks and the pit lane)
    nm, yo = G.road_at(X.ravel(), Z.ravel(), margin=-0.02)
    sink = np.array([n_ is not None and G.roads[n_].prio < 2 for n_ in nm]).reshape(X.shape)
    Y = np.where(sink, np.minimum(Y, yo.reshape(X.shape) - 0.03), Y)
    P = np.dstack([X, Y, Z]).reshape(-1, 3)
    U = np.dstack([X / 8, Z / 8]).reshape(-1, 2)
    I = grid_tris(len(zs), len(xs))
    I = I[:, [0, 2, 1]]
    col = I % len(xs); row = I // len(xs)
    phys = ~((col == 0).any(1) | (col == len(xs) - 1).any(1) | (row == 0).any(1) | (row == len(zs) - 1).any(1))
    mesh.add(mat, P, U, I, phys=phys)


def flat_quad(mesh, mat, x0, z0, x1, z1, y, uvk=None, lift=0.0, phys=True):
    k = uvk
    uv = ((x0 / k, z1 / k), (x1 / k, z1 / k), (x1 / k, z0 / k), (x0 / k, z0 / k)) if k else ((0, 1), (1, 1), (1, 0), (0, 0))
    quad(mesh, mat, (x0, y + lift, z1), (x1, y + lift, z1), (x1, y + lift, z0), (x0, y + lift, z0), uv=uv, phys=phys)


# ---------------------------------------------------------------- buildings
def building(mesh, cx, cz, y0, w, d, h, yaw=0.0, front='facade', side='concrete', roof='roof', uvm=(8.0, 8.0), full=False):
    mats = dict(front=front, back=side, left=side, right=side, top=roof)
    return box(mesh, cx, cz, y0, w, d, h, yaw, mats, uvm=uvm, tex_full=('front',) if full else ())


def grandstand(mesh, x0, x1, zf, y0, rows=14, depth=0.85, rise=0.5, facing=1, roof=True):
    """stepped seating facing +z (facing=1) or -z (-1): front edge at zf, seats as one sloped surface"""
    D = rows * depth; Hh = rows * rise + 1.2
    zb = zf - facing * D
    # seating slope (two-sided lit, seen from the track)
    yb, yf_ = y0 + Hh, y0 + 1.2
    if facing > 0: quad(mesh, 'seats', (x0, yf_, zf), (x1, yf_, zf), (x1, yb, zb), (x0, yb, zb), uv=((0, rows), (abs(x1 - x0) / 4, rows), (abs(x1 - x0) / 4, 0), (0, 0)))
    else: quad(mesh, 'seats', (x1, yf_, zf), (x0, yf_, zf), (x0, yb, zb), (x1, yb, zb), uv=((0, rows), (abs(x1 - x0) / 4, rows), (abs(x1 - x0) / 4, 0), (0, 0)))
    # front wall, back wall, ends
    strip(mesh, 'concrete', np.array([[x0, zf], [x1, zf]]), y0, y0 + 1.2, 4.0)
    strip(mesh, 'concrete', np.array([[x0, zb], [x1, zb]]), y0, yb, 4.0)
    for x in (x0, x1):
        P = np.array([(x, y0, zf), (x, yf_, zf), (x, yb, zb), (x, y0, zb)])
        mesh.add('concrete', P, np.array([[0, 0], [0, 0.3], [D / 4, 2], [D / 4, 0]]), np.array([[0, 1, 2], [0, 2, 3]]), phys=False)
    mesh.wall((x0, zf), (x1, zf), y0 - 0.3, y0 + 1.5); mesh.wall((x0, zb), (x1, zb), y0 - 0.3, yb)
    mesh.wall((x0, zf), (x0, zb), y0 - 0.3, yb); mesh.wall((x1, zf), (x1, zb), y0 - 0.3, yb)
    if roof:
        ry = yb + 3.5
        flat_quad(mesh, 'metal', min(x0, x1), min(zf, zb) - 2 * facing * 0, max(x0, x1), max(zf, zb), ry, uvk=4.0, phys=False)
        for x in np.linspace(x0 + 2, x1 - 2, max(2, int(abs(x1 - x0) / 25) + 1)):
            box(mesh, x, zb + facing * 0.3, yb, 0.4, 0.4, 3.5, 0.0, 'post', collide=False, top=False)


def tent(mesh, cx, cz, y0, size, mat, yaw=0.0):
    """a pop-up canopy: four legs and a pyramid roof"""
    s = size / 2; c, sn = np.cos(yaw), np.sin(yaw)
    W = lambda lx, lz: (cx + lx * c - lz * sn, cz + lx * sn + lz * c)
    corners = [W(-s, -s), W(s, -s), W(s, s), W(-s, s)]
    eave, peak = y0 + 2.6, y0 + 3.8
    top = (cx, peak, cz)
    for i in range(4):
        a, b = corners[i], corners[(i + 1) % 4]
        mesh.add(mat, np.array([(a[0], eave, a[1]), (b[0], eave, b[1]), top]), np.array([[0, 1], [1, 1], [0.5, 0]]), np.array([[0, 2, 1]]), phys=False)
        strip(mesh, mat, np.array([a, b]), eave - 0.3, eave, size, 0.0, 0.1)          # valance
    for a in corners:
        box(mesh, a[0], a[1], y0, 0.08, 0.08, 2.6, yaw, 'post', collide=False, top=False)


def truck(mesh, cx, cz, y0, yaw, livery):
    """a race transporter: tractor and box trailer"""
    box(mesh, cx, cz, y0 + 0.9, 13.5, 2.55, 3.1, yaw, dict(front=livery, back=livery, left='truck_w', right='truck_w', top='roof'), uvm=(13.5, 3.1))
    c, s = np.cos(yaw), np.sin(yaw)
    tx, tz = cx + 8.6 * c, cz + 8.6 * s
    box(mesh, tx, tz, y0 + 0.9, 3.4, 2.5, 2.9, yaw, dict(front='truck_k', back='truck_k', left=livery, right=livery, top='truck_k'))
    box(mesh, cx + 4.0 * c, cz + 4.0 * s, y0, 17.0, 2.4, 0.9, yaw, 'truck_k', top=False, collide=False)    # chassis, wheels


def pit_complex(mesh, G, y):
    """pit garages along the south side of the pit lane, race control, the grandstand opposite, the pit wall"""
    zf = LY.PIT_Z + 6 + 2                                     # garage fronts: 2 m of apron off the pit lane
    for x0, x1 in ((-600, 120), (160, 880)):
        n = int((x1 - x0) / 12)
        for i in range(n):
            cx = x0 + 6 + 12 * i
            box(mesh, cx, zf + 10, y, 12, 20, 8, 0.0, dict(front='garage', back='block', left=None, right=None, top='roof'),
                uvm=(12, 8), tex_full=('front',), collide=False)
        for (a, b) in (((x0, zf), (x1, zf)), ((x1, zf), (x1, zf + 20)), ((x1, zf + 20), (x0, zf + 20)), ((x0, zf + 20), (x0, zf))):
            mesh.wall(a, b, y - 0.3, y + 8)
        strip(mesh, 'block', np.array([[x0, zf + 20], [x0, zf]]), y, y + 8, 6.0)
        strip(mesh, 'block', np.array([[x1, zf], [x1, zf + 20]]), y, y + 8, 6.0)
        # hospitality windows over the garages, set back
        box(mesh, (x0 + x1) / 2, zf + 14, y + 8, x1 - x0, 12, 3.2, 0.0, dict(front='windows', back='windows', left='block', right='block', top='roof'), uvm=(8.0, 3.2), collide=False)
    # race control: a tower behind the garages near the line
    box(mesh, 240, 272, y, 16, 14, 18, 0.0, dict(front='facade', back='facade', left='facade', right='facade', top='roof'), uvm=(8, 8))
    box(mesh, 240, 272, y + 18, 18, 16, 3.5, 0.0, dict(front='glass', back='glass', left='glass', right='glass', top='roof'), collide=False)
    # pit wall with a catch fence, where the pit lane runs beside the track
    gp, pit = G.roads['gp'], G.roads['pit']
    d, j = cKDTree(gp.P).query(pit.P)
    ok = d > 11.0
    if ok.any():
        ids = np.nonzero(ok)[0][::3]
        mid = (pit.P[ids] + gp.P[j[ids]]) / 2
        yw = np.full(len(mid), y)
        strip(mesh, 'concrete', mid, yw - 0.2, yw + 1.1, 3.0)
        strip(mesh, 'fence', mid, yw + 1.1, yw + 4.0, 3.0, 0.0, 1.0)
        mesh.wall_line(mid, yw - 0.3, yw + 4.0)
    # the main grandstand across the straight, behind a catch fence
    gy = y
    zf_g = 200 - 6 - 11
    grandstand(mesh, -350, 650, zf_g, gy, rows=16, facing=1)
    fence_z = 200 - 6 - 8
    strip(mesh, 'fence', np.array([[-380, fence_z], [680, fence_z]]), gy, gy + 4.5, 3.0)
    mesh.wall((-380, fence_z), (680, fence_z), gy - 0.3, gy + 4.5)


def paddock(mesh, G, y):
    r = LY.PADDOCK
    liveries = ['truck_r', 'truck_b', 'truck_w', 'truck_k']
    canv = ['canvas', 'canvas_r', 'canvas_b', 'canvas_y']
    # transporters in two rows behind the garages, an awning tent beside each
    for row, z in enumerate((300, 352)):
        for i, x in enumerate(np.arange(-560, 860, 56)):
            if 100 < x < 190: continue
            k = (i + row) % 4
            truck(mesh, x, z, y, 0.0, liveries[k])
            tent(mesh, x - 2, z + 6.2, y, 6.0, canv[k])
    # hospitality and workshops on the south side
    building(mesh, 520, 590, y, 70, 18, 8, 0.0, front='windows', side='block', uvm=(8, 3.2))
    for x in (-560, -440, -320):
        building(mesh, x, 590, y, 90, 22, 7, 0.0, front='metal', side='block', uvm=(4, 4))
    building(mesh, -150, 470, y, 40, 16, 6, 0.0, front='facade', side='concrete')
    # tents in the open middle
    for x in np.arange(-100, 400, 14):
        for z in (440, 456):
            tent(mesh, x, z, y, 8.0, canv[int(x) // 14 % 4])
    # parking lines along the paddock road
    for x in np.arange(-640, -560, 3.0):
        flat_quad(mesh, 'paint', x, 400, x + 0.12, 405, y, lift=0.012)


def small_paddock(mesh, r, h, facing_track, label=''):
    """a club-level paddock: a small pit building, a few tents"""
    cx, cz = (r['x0'] + r['x1']) / 2, (r['z0'] + r['z1']) / 2
    w, d = r['x1'] - r['x0'], r['z1'] - r['z0']
    building(mesh, r['x0'] + 30, cz, h, 40, 12, 5, yaw=np.pi / 2, front='garage', side='block', uvm=(12, 5))
    for i in range(4):
        tent(mesh, r['x0'] + 70 + i * 12, r['z0'] + 16, h, 6.0, ['canvas', 'canvas_r', 'canvas_b', 'canvas_y'][i])
    building(mesh, r['x1'] - 20, r['z1'] - 14, h, 24, 14, 4, front='metal', side='block', uvm=(4, 4))


# ---------------------------------------------------------------- drag strip, oval, gate
def drag_strip(mesh, G, rd):
    y = float(rd.y[0])
    x0s = LY.DRAG_START; x1f = x0s + 402.34
    z = LY.DRAG_Z
    # lane lines, start and finish
    for zz in (z - 7.6, z + 7.6):
        flat_quad(mesh, 'paint', LY.DRAG_X0 - 50, zz - 0.08, LY.DRAG_X1, zz + 0.08, y, lift=0.012)
    for xx, mat in ((x0s, 'paint'), (x1f, 'checker')):
        flat_quad(mesh, mat, xx - 0.3, z - 7.8, xx + 0.3, z + 7.8, y, lift=0.013)
    # concrete walls both sides, a divider between the lanes from the start to past the finish
    for zz in (z - 8.6, z + 8.6):
        pts = np.array([[LY.DRAG_X0 - 40, zz], [LY.DRAG_X1 - 40, zz]])
        if zz < z: pts = np.array([[x1f + 120, zz], [LY.DRAG_X1 - 40, zz]])     # open beside the staging area
        strip(mesh, 'concrete', pts, y - 0.2, y + 1.0, 3.0)
        mesh.wall_line(pts, y - 0.3, y + 1.0)
    div = np.array([[x0s - 6, z], [x1f + 250, z]])
    box(mesh, (div[0, 0] + div[1, 0]) / 2, z, y, div[1, 0] - div[0, 0], 0.5, 0.9, 0.0, 'concrete', uvm=(3, 1))
    # the start "tree": a post on the divider with amber, green and red lamps; the timing tower beside
    box(mesh, x0s - 4, z, y + 0.9, 0.3, 0.3, 2.6, 0.0, 'post', collide=False)
    for k, (mat, hy) in enumerate((('lamp_y', 2.9), ('lamp_y', 2.6), ('lamp_y', 2.3), ('lamp_g', 1.9), ('lamp_r', 1.6))):
        box(mesh, x0s - 4, z, y + hy, 0.45, 0.45, 0.22, 0.0, mat, collide=False)
    building(mesh, x0s - 30, z - 24, y, 10, 10, 9, front='facade', side='facade')
    # grandstand along the south side, facing the strip
    grandstand(mesh, x0s - 40, x1f + 60, z + 14, y, rows=8, facing=-1)


def oval_walls(mesh, G, rd):
    n = len(rd.P)
    c = np.array(LY.OVAL_C)
    out_side = np.sign(np.einsum('ij,ij->i', rd.n, rd.P - c))       # +1 where the left normal points away from the centre
    o = out_side * (rd.half + 0.3)
    pts = rd.P + rd.n * o[:, None]
    yb = rd.surface(np.arange(n), o)
    ids = np.r_[np.arange(0, n, 3), 0]
    strip(mesh, 'concrete', pts[ids], yb[ids] - 0.2, yb[ids] + 1.2, 3.0)
    strip(mesh, 'fence', pts[ids], yb[ids] + 1.2, yb[ids] + 5.0, 3.0)
    mesh.wall_line(pts[ids], yb[ids] - 0.3, yb[ids] + 5.0)
    # a stand on the outside of the south straight
    y = float(rd.y[0])
    cx, cz = c
    zf = cz + LY.OVAL_R + rd.half + 14
    grandstand(mesh, cx - 260, cx + 100, zf, y + 1.0, rows=10, facing=-1)


def gate(mesh, G, y_road):
    r = LY.GATE_PAD; h = G.pads['gate'][1]
    building(mesh, r['x1'] + 60, 3650, h, 80, 34, 12, yaw=0.0, front='facade', side='facade', uvm=(8, 8))
    box(mesh, r['x1'] + 60, 3650, h + 12, 82, 36, 0.6, 0.0, 'roof', collide=False)
    # parking bays
    for x in np.arange(r['x0'] + 10, r['x1'] - 10, 3.0):
        for z in (r['z0'] + 30, r['z1'] - 50):
            flat_quad(mesh, 'paint', x, z, x + 0.12, z + 5.5, h, lift=0.012)
    # gatehouse and barrier at the fence
    gx, gz = 12, LY.HALF - 18
    building(mesh, gx, gz, y_road, 6, 4, 3, front='windows', side='concrete', uvm=(6, 3))
    box(mesh, -1, LY.HALF - 14, y_road + 0.9, 8.0, 0.15, 0.15, 0.0, 'lamp_r', collide=False)
    # fuel station by the gate road
    fx, fz, fy = 70, 3300, float(G.surface([40], [3300])[0])
    for dx in (-9, 9):
        for dz in (-5, 5): box(mesh, fx + dx, fz + dz, fy, 0.5, 0.5, 5.0, 0.0, 'concrete', uvm=(1, 1))
    box(mesh, fx, fz, fy + 5.0, 24, 14, 0.8, 0.0, dict(front='lamp_r', back='lamp_r', left='lamp_r', right='lamp_r', top='roof'), collide=False)
    pad = dict(x0=fx - 16, x1=fx + 16, z0=fz - 12, z1=fz + 12)
    return pad


def perimeter_fence(mesh, G):
    H = LY.HALF
    for (a, b) in (((-H, -H), (H, -H)), ((H, -H), (H, H)), ((H, H), (-H, H)), ((-H, H), (-H, -H))):
        n = int(np.hypot(b[0] - a[0], b[1] - a[1]) / 8) + 1
        t = np.linspace(0, 1, n)
        pts = np.c_[a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
        yg = G.surface(pts[:, 0], pts[:, 1])
        strip(mesh, 'fence', pts, yg - 0.1, yg + 2.6, 3.0)
        for p, yy in zip(pts[::2], yg[::2]):
            box(mesh, p[0], p[1], yy, 0.1, 0.1, 2.7, 0.0, 'post', collide=False, top=False)
        mesh.wall_line(pts, yg - 0.5, yg + 2.6)


def marshal_posts(mesh, G, rd, every=700):
    for s in np.arange(150, rd.L - 100, every):
        j = int(s) % len(rd.P)
        p = rd.P[j] + rd.n[j] * (rd.half + 12)
        nm, _ = G.road_at([p[0]], [p[1]], margin=4)
        if nm[0] is not None: continue
        y = float(G.height([p[0]], [p[1]])[0])
        box(mesh, p[0], p[1], y, 2.4, 2.4, 2.6, float(np.arctan2(rd.t[j, 1], rd.t[j, 0])), dict(front='windows', back='metal', left='metal', right='metal', top='roof'), uvm=(2.4, 2.6))


# ---------------------------------------------------------------- trees
def keep_clear(G, X, Z, clear):
    """points at least `clear` metres from every road edge and pad"""
    ok = np.ones(len(X), bool)
    for k, rd in G.roads.items():
        d, _ = G.trees[k].query(np.c_[X, Z], distance_upper_bound=rd.half + rd.verge + clear)
        ok &= ~np.isfinite(d)
    for k, (r, h) in G.pads.items():
        ok &= ~((X > r['x0'] - clear) & (X < r['x1'] + clear) & (Z > r['z0'] - clear) & (Z < r['z1'] + clear))
    return ok


def trees(mesh, G):
    """forests where a smooth noise field is high, thicker toward the fence; lines of trees along the access
    roads; individual trees fade out at 1.3 km"""
    n2 = TR.noise(21)
    def F(x, z): return TR.sample(n2, x, z)
    sp = 18.0
    gx, gz = np.meshgrid(np.arange(-LY.HALF + 20, LY.HALF - 20, sp), np.arange(-LY.HALF + 20, LY.HALF - 20, sp))
    X = gx.ravel() + RNG.uniform(-sp * 0.45, sp * 0.45, gx.size); Z = gz.ravel() + RNG.uniform(-sp * 0.45, sp * 0.45, gx.size)
    f = F(X, Z)
    edge = np.maximum(np.abs(X), np.abs(Z))
    dens = np.clip((f - 0.25) * 2.2, 0, 1) + np.clip((edge - 3500) / 400, 0, 1) * 0.7
    take = RNG.random(len(X)) < dens
    X, Z = X[take], Z[take]
    ok = keep_clear(G, X, Z, 30.0)
    X, Z = X[ok], Z[ok]
    # avoid the inside of the GP's main straight grandstand area and the slalom run-offs
    print(f'trees: {len(X)} in forests')
    roadside = []
    for k in ('gate', 'paddock', 'east', 'west', 'to_drag', 'to_oval', 'to_handling'):
        rd = G.roads[k]
        for s in np.arange(10, rd.L - 10, 18):
            j = int(s)
            for sd in (1, -1):
                if RNG.random() < 0.3: continue
                p = rd.P[j] + rd.n[j] * sd * (rd.half + 11 + RNG.uniform(-1.5, 1.5))
                roadside.append(p)
    roadside = np.array(roadside)
    ok = keep_clear(G, roadside[:, 0], roadside[:, 1], 6.0)
    roadside = roadside[ok]
    # clumps of trees beside the circuits, beyond the run-off (where the noise says so)
    clumps = []
    for k, clear in (('gp', 24.0), ('club', 18.0), ('handling', 14.0)):
        rd = G.roads[k]
        for s in np.arange(5, rd.L - 5, 11):
            j = int(s)
            for sd in (1, -1):
                clumps.append(rd.P[j] + rd.n[j] * sd * (rd.half + rd.verge + clear + RNG.uniform(0, 22)))
    clumps = np.array(clumps)
    f2 = F(np.mod(clumps[:, 0] * 3.1 + 5700, 10400) - 5200, np.mod(clumps[:, 1] * 3.1 + 5200, 10400) - 5200)
    clumps = clumps[(f2 > 0.05) & (RNG.random(len(clumps)) < 0.75)]
    ok = keep_clear(G, clumps[:, 0], clumps[:, 1], 12.0)
    roadside = np.r_[roadside, clumps[ok]]
    X = np.r_[X, roadside[:, 0]]; Z = np.r_[Z, roadside[:, 1]]
    Y = G.height(X, Z) - 0.15
    kind = F(X * 1.7 + 900, Z * 1.7) + 0.4 * (Z < -1500)
    for mat, sel, aspect, hr in (('pine', kind > 0.35, 0.5, (14, 24)), ('tree_a', (kind <= 0.35) & (kind > -0.1), 1.0, (11, 18)),
                                 ('tree_b', kind <= -0.1, 1.0, (9, 15))):
        n = int(sel.sum())
        if not n: continue
        h = RNG.uniform(*hr, n)
        cards(mesh, mat, X[sel], Y[sel], Z[sel], h * aspect, h, RNG.uniform(0, np.pi, n))
    print(f'trees: {len(X)} in all ({len(roadside)} along the roads)')
    # bushes round the paddocks and buildings
    bx, bz = [], []
    for k, (r, h) in G.pads.items():
        per = np.r_[np.c_[np.linspace(r['x0'], r['x1'], 12), np.full(12, r['z1'] + 8)], np.c_[np.full(8, r['x0'] - 8), np.linspace(r['z0'], r['z1'], 8)]]
        bx.extend(per[:, 0]); bz.extend(per[:, 1])
    bx, bz = np.array(bx), np.array(bz)
    ok = keep_clear(G, bx, bz, 3.0)
    bx, bz = bx[ok], bz[ok]
    cards(mesh, 'bush', bx, G.height(bx, bz) - 0.1, bz, np.full(len(bx), 5.0), np.full(len(bx), 2.4), RNG.uniform(0, np.pi, len(bx)), uv=(0, 0, 1, 1))


# ---------------------------------------------------------------- beyond the fence
def far_scenery(mesh, G):
    """tree lines on the hills outside the fence, a ring of high hills, mountains on the horizon"""
    import tin
    # tree lines: rows of wide cards following the ground, from just outside the fence out to 900 m
    for off in np.arange(30, 900, 70):
        for side in range(4):
            Hh = LY.HALF + off
            L = 2 * Hh
            n = int(L / 38)
            t = (np.arange(n) + RNG.uniform(0, 1, n) * 0.5) / n
            a = -Hh + L * t
            if side == 0: X, Z = a, np.full(n, -Hh)
            elif side == 1: X, Z = np.full(n, Hh), a
            elif side == 2: X, Z = -a, np.full(n, Hh)
            else: X, Z = np.full(n, -Hh), -a
            X = X + RNG.uniform(-12, 12, n); Z = Z + RNG.uniform(-12, 12, n)
            ok = tin.inside(X, Z, 60) & keep_clear(G, X, Z, 26.0)  # on the ground, short of its edge, off the roads
            X, Z, n = X[ok], Z[ok], int(ok.sum())
            Y = G.height(X, Z) - 1.0
            yaw = np.full(n, 0.0 if side in (0, 2) else np.pi / 2)
            h = RNG.uniform(16, 24, n)
            row = RNG.integers(0, 4, n)
            for r in range(4):
                sel = row == r
                if sel.any():
                    cards(mesh, 'treeline', X[sel], Y[sel], Z[sel], np.full(sel.sum(), 44.0), h[sel], yaw[sel], uv=(0, r * 0.25, 1, (r + 1) * 0.25), crossed=False)
    # a ring of high wooded hills from the edge of the heightfield out to 10 km
    from scipy.ndimage import gaussian_filter1d
    rings = np.array([tin.RING_R, 5800, 6700, 7800, 9000, 10200])
    pows = [tin.RING_P, 3.0, 2.5, 2.0, 2.0, 2.0]          # rounded square at the ground's edge, circles further out
    ang = tin.RING_A; na = len(ang)
    ex = [tin.edge(r, p) for r, p in zip(rings, pows)]
    rng = np.random.default_rng(5)
    hh = np.zeros((len(rings), na))
    for i, r in enumerate(rings):
        if i == 0: hh[i] = TR.sample(G.H, *ex[0])     # the ground's own edge points
        else:
            base = 160 + 150 * (i / len(rings)) + 110 * np.sin(ang * 3 + i) * (i > 1)
            hh[i] = gaussian_filter1d(base + rng.normal(0, 70, na) * (i > 1), 6, mode='wrap')
    hh[1] = np.maximum(hh[1], hh[0] + 20)
    a2 = np.r_[ang, ang[:1]]
    P = np.zeros((len(rings), na + 1, 3))
    for i, r in enumerate(rings):
        P[i, :, 0] = np.r_[ex[i][0], ex[i][0][:1]]; P[i, :, 2] = np.r_[ex[i][1], ex[i][1][:1]]; P[i, :, 1] = np.r_[hh[i], hh[i, :1]]
    U = np.dstack([P[:, :, 0] / 120, P[:, :, 2] / 120])
    I = grid_tris(len(rings), na + 1)
    mesh.add('far_hill', P.reshape(-1, 3), U.reshape(-1, 2), I[:, [0, 2, 1]], phys=False)
    # mountains on the horizon: big cards, the backdrop's own haze, in a ring at 12-13.5 km
    na2 = 26
    for k in range(na2):
        a = 2 * np.pi * (k + rng.uniform(-0.15, 0.15)) / na2
        r = 12500 + rng.uniform(-700, 700)
        w = 2 * np.pi * r / na2 * 1.35
        hgt = rng.uniform(900, 1500)
        cx, cz = r * np.cos(a), r * np.sin(a)
        tx, tz = -np.sin(a), np.cos(a)
        A = (cx - tx * w / 2, -150, cz - tz * w / 2); B = (cx + tx * w / 2, -150, cz + tz * w / 2)
        u0 = rng.uniform(0, 0.6)
        quad(mesh, 'alps', A, B, (B[0], hgt, B[2]), (A[0], hgt, A[2]), uv=((u0, 1), (u0 + 0.4, 1), (u0 + 0.4, 0), (u0, 0)), split=None)
