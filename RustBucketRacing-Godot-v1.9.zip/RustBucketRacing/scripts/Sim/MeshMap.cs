// Mesh maps (real circuits from a map pack, tools/convert_spa.py): the ground is a triangle soup (road,
// kerbs, gravel, grass) indexed in an 8 m grid; walls are vertical 2D segments with a height range
// (guardrails, tyre walls, fences, buildings) that the car body collides with.
using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Json;

namespace RustBucket.Sim
{
    // compressed per-cell lists: Start[c]..Start[c+1] index into Items
    public sealed class GridLists
    {
        public int[] Start, Items;
    }

    public sealed class MeshTerrain : TerrainBase
    {
        // surface id per triangle (1 tarmac, 2 kerb, 3 gravel, 4 grass); 0 counts as grass
        static readonly Surf[] SURF_NAMES = { Surf.Grass, Surf.Tarmac, Surf.Rumble, Surf.Gravel, Surf.Grass };

        public readonly float[] Tri;   // 9 floats per triangle
        public readonly byte[] SurfId; // per triangle
        readonly float[] nrm;
        public readonly double X0, Z0, MinX, MaxX, MinZ, MaxZ, MinY;
        public readonly int Nx, Nz;
        const double C = 8;
        readonly GridLists g, wg;
        readonly int[] wStamp;
        int wTick;

        public MeshTerrain(float[] tri, byte[] surf, float[] walls)
        {
            Tri = tri; SurfId = surf; WallSeg = walls;
            KerbLift = 0;
            int n = surf.Length;
            double x0 = double.PositiveInfinity, z0 = double.PositiveInfinity, x1 = double.NegativeInfinity, z1 = double.NegativeInfinity, y0 = double.PositiveInfinity;
            for (int i = 0; i < n * 9; i += 3)
            {
                double x = tri[i], y = tri[i + 1], z = tri[i + 2];
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (z < z0) z0 = z; if (z > z1) z1 = z; if (y < y0) y0 = y;
            }
            MinX = x0; MaxX = x1; MinZ = z0; MaxZ = z1; MinY = y0;
            BoundsMinY = y0;
            Floor = y0 - 80; // under everything: what Height() reports off the edge of the map
            X0 = x0; Z0 = z0;
            Nx = (int)Math.Ceiling((x1 - x0) / C) + 1; Nz = (int)Math.Ceiling((z1 - z0) / C) + 1;
            // upward unit normal per triangle
            nrm = new float[n * 3];
            for (int i = 0; i < n; i++)
            {
                int o = i * 9;
                double ux = tri[o + 3] - tri[o], uy = tri[o + 4] - tri[o + 1], uz = tri[o + 5] - tri[o + 2];
                double vx = tri[o + 6] - tri[o], vy = tri[o + 7] - tri[o + 1], vz = tri[o + 8] - tri[o + 2];
                double cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
                double l = Math.Sqrt(cx * cx + cy * cy + cz * cz);
                if (!(l > 0)) l = 1;
                double sg = cy < 0 ? -1 : 1;
                nrm[i * 3] = (float)((cx / l) * sg); nrm[i * 3 + 1] = (float)((cy / l) * sg); nrm[i * 3 + 2] = (float)((cz / l) * sg);
            }
            int ncell = Nx * Nz;
            // ground triangles per cell
            g = Build(n, ncell, (i, add) =>
            {
                int o = i * 9;
                CellSpan(tri[o], tri[o + 3], tri[o + 6], X0, Nx, out int ix0, out int ix1);
                CellSpan(tri[o + 2], tri[o + 5], tri[o + 8], Z0, Nz, out int iz0, out int iz1);
                for (int iz = iz0; iz <= iz1; iz++) for (int ix = ix0; ix <= ix1; ix++) add(iz * Nx + ix);
            });
            int nw = walls != null ? walls.Length / 6 : 0;
            wg = Build(nw, ncell, (i, add) =>
            {
                int o = i * 6;
                CellSpan(walls[o], walls[o + 2], walls[o], X0, Nx, out int ix0, out int ix1);
                CellSpan(walls[o + 1], walls[o + 3], walls[o + 1], Z0, Nz, out int iz0, out int iz1);
                for (int iz = iz0; iz <= iz1; iz++) for (int ix = ix0; ix <= ix1; ix++) add(iz * Nx + ix);
            });
            wStamp = new int[nw]; wTick = 0;
        }

        static void CellSpan(double a, double b, double c, double o, int cnt, out int i0, out int i1)
        {
            i0 = Math.Max(0, (int)Math.Floor((M.Min3(a, b, c) - o) / C));
            i1 = Math.Min(cnt - 1, (int)Math.Floor((M.Max3(a, b, c) - o) / C));
        }

        static GridLists Build(int count, int ncell, Action<int, Action<int>> cells)
        {
            var start = new int[ncell + 1];
            for (int i = 0; i < count; i++) cells(i, (c) => { start[c + 1]++; });
            for (int c = 0; c < ncell; c++) start[c + 1] += start[c];
            var items = new int[start[ncell]];
            var fill = new int[ncell];
            Array.Copy(start, fill, ncell);
            for (int i = 0; i < count; i++) cells(i, (c) => { items[fill[c]++] = i; });
            return new GridLists { Start = start, Items = items };
        }

        // index of the highest ground triangle over (x, z) no higher than yMax, or -1; its height goes in h
        int Top(double x, double z, double yMax, out double h)
        {
            int ix = (int)Math.Floor((x - X0) / C), iz = (int)Math.Floor((z - Z0) / C);
            h = double.NegativeInfinity;
            if (ix < 0 || iz < 0 || ix >= Nx || iz >= Nz) return -1;
            int c = iz * Nx + ix;
            var T = Tri;
            int best = -1; double bh = double.NegativeInfinity;
            for (int k = g.Start[c], e = g.Start[c + 1]; k < e; k++)
            {
                int i = g.Items[k], o = i * 9;
                double ax = T[o], az = T[o + 2];
                double e0x = T[o + 3] - ax, e0z = T[o + 5] - az, e1x = T[o + 6] - ax, e1z = T[o + 8] - az, px = x - ax, pz = z - az;
                double d = e0x * e1z - e1x * e0z;
                if (d > -1e-9 && d < 1e-9) continue;
                double u = (px * e1z - e1x * pz) / d, v = (e0x * pz - px * e0z) / d;
                if (u < -1e-6 || v < -1e-6 || u + v > 1 + 1e-6) continue;
                double hh = T[o + 1] + u * (T[o + 4] - T[o + 1]) + v * (T[o + 7] - T[o + 1]);
                if (hh > bh && hh <= yMax) { bh = hh; best = i; }
            }
            h = bh;
            return best;
        }

        // fine relief the meshes don't carry: kerb ridges, gravel and grass ruts (physics only)
        static double Chatter(int s, double x, double z)
        {
            if (s == 2) return 0.011 * (0.5 - 0.25 * Math.Cos(x * 14.96) - 0.25 * Math.Cos(z * 14.96));
            if (s == 3) return Shapes.Waves(Shapes.GravelFine, x, z) + Shapes.Waves(Shapes.GravelLong, x, z);
            if (s == 4) return Shapes.Waves(Shapes.GrassLong, x, z);
            return 0;
        }

        const double Up = double.PositiveInfinity;
        public override double HeightVis(double x, double z) => Top(x, z, Up, out double h) >= 0 ? h : Floor;
        public override double Height(double x, double z) => HeightBelow(x, z, Up);
        public override V3 Normal(double x, double z) => NormalBelow(x, z, Up);
        public override Surf Surface(double x, double z) => SurfaceBelow(x, z, Up);

        // under rock overhangs (and anything else with ground above ground) a point at height y stands on the
        // highest surface no more than Reach above it
        public override double HeightVisAt(double x, double z, double y, double reach = Reach) => Top(x, z, y + reach, out double h) >= 0 ? h : Floor;
        public override double HeightAt(double x, double z, double y, double reach = Reach) => HeightBelow(x, z, y + reach);
        public override V3 NormalAt(double x, double z, double y, double reach = Reach) => NormalBelow(x, z, y + reach);
        public override Surf SurfaceAt(double x, double z, double y, double reach = Reach) => SurfaceBelow(x, z, y + reach);

        double HeightBelow(double x, double z, double yMax)
        {
            int t = Top(x, z, yMax, out double h);
            return t >= 0 ? h + Chatter(SurfId[t], x, z) : Floor;
        }

        V3 NormalBelow(double x, double z, double yMax)
        {
            int t = Top(x, z, yMax, out _);
            return t >= 0 ? new V3(nrm[t * 3], nrm[t * 3 + 1], nrm[t * 3 + 2]) : V3.UnitY;
        }

        Surf SurfaceBelow(double x, double z, double yMax)
        {
            int t = Top(x, z, yMax, out _);
            return t >= 0 ? SURF_NAMES[SurfId[t]] : Surf.Grass;
        }

        // First t in [0, maxT] where o + d*t meets the ground; -1 if none.
        public override double Raycast(V3 o, V3 d, double maxT)
        {
            int t0 = Top(o.X, o.Z, o.Y + Reach, out double h0);
            if (t0 >= 0 && h0 + Chatter(SurfId[t0], o.X, o.Z) >= o.Y) return 0; // starts under the surface (not under an overhang)
            double ex = o.X + d.X * maxT, ez = o.Z + d.Z * maxT;
            int ix0 = Math.Max(0, (int)Math.Floor((Math.Min(o.X, ex) - X0) / C)), ix1 = Math.Min(Nx - 1, (int)Math.Floor((Math.Max(o.X, ex) - X0) / C));
            int iz0 = Math.Max(0, (int)Math.Floor((Math.Min(o.Z, ez) - Z0) / C)), iz1 = Math.Min(Nz - 1, (int)Math.Floor((Math.Max(o.Z, ez) - Z0) / C));
            var T = Tri;
            double best = double.PositiveInfinity; int bt = -1;
            for (int iz = iz0; iz <= iz1; iz++)
                for (int ix = ix0; ix <= ix1; ix++)
                {
                    int c = iz * Nx + ix;
                    for (int k = g.Start[c], e = g.Start[c + 1]; k < e; k++)
                    {
                        // Moller-Trumbore
                        int i = g.Items[k], b = i * 9;
                        double e1x = T[b + 3] - T[b], e1y = T[b + 4] - T[b + 1], e1z = T[b + 5] - T[b + 2];
                        double e2x = T[b + 6] - T[b], e2y = T[b + 7] - T[b + 1], e2z = T[b + 8] - T[b + 2];
                        double px = d.Y * e2z - d.Z * e2y, py = d.Z * e2x - d.X * e2z, pz = d.X * e2y - d.Y * e2x;
                        double det = e1x * px + e1y * py + e1z * pz;
                        if (det > -1e-12 && det < 1e-12) continue;
                        double inv = 1 / det, sx = o.X - T[b], sy = o.Y - T[b + 1], sz = o.Z - T[b + 2];
                        double u = (sx * px + sy * py + sz * pz) * inv;
                        if (u < -1e-6 || u > 1 + 1e-6) continue;
                        double qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
                        double v = (d.X * qx + d.Y * qy + d.Z * qz) * inv;
                        if (v < -1e-6 || u + v > 1 + 1e-6) continue;
                        double tt = (e2x * qx + e2y * qy + e2z * qz) * inv;
                        if (tt >= 0 && tt < best) { best = tt; bt = i; }
                    }
                }
            if (bt < 0) return -1;
            if (d.Y < -0.3)
            {
                double ch = Chatter(SurfId[bt], o.X + d.X * best, o.Z + d.Z * best);
                if (ch != 0) best = Math.Max(0, best - ch / -d.Y);
            }
            return best <= maxT ? best : -1;
        }

        // wall segments within r of (x, z): their indices land in WNear, returns how many
        public override int WallsNear(double x, double z, double r)
        {
            var W = WallSeg;
            if (W == null || W.Length == 0) return 0;
            int ix0 = Math.Max(0, (int)Math.Floor((x - r - X0) / C)), ix1 = Math.Min(Nx - 1, (int)Math.Floor((x + r - X0) / C));
            int iz0 = Math.Max(0, (int)Math.Floor((z - r - Z0) / C)), iz1 = Math.Min(Nz - 1, (int)Math.Floor((z + r - Z0) / C));
            int tick = ++wTick;
            int n = 0;
            for (int iz = iz0; iz <= iz1; iz++)
                for (int ix = ix0; ix <= ix1; ix++)
                {
                    int c = iz * Nx + ix;
                    for (int k = wg.Start[c], e = wg.Start[c + 1]; k < e; k++)
                    {
                        int i = wg.Items[k];
                        if (wStamp[i] == tick) continue;
                        wStamp[i] = tick;
                        int o = i * 6;
                        double ax = W[o], az = W[o + 1], exx = W[o + 2] - ax, ezz = W[o + 3] - az;
                        double l2 = exx * exx + ezz * ezz;
                        double u = M.Clamp(((x - ax) * exx + (z - az) * ezz) / (l2 != 0 ? l2 : 1), 0, 1);
                        double dx = x - ax - exx * u, dz = z - az - ezz * u;
                        if (dx * dx + dz * dz > r * r) continue;
                        if (n < WNear.Length) WNear[n++] = i;
                    }
                }
            return n;
        }
    }

    // A centreline from points (x, z pairs), resampled to ~1 m: same queries as ArcPath. Closed (a lap) or open
    // (a stage: s runs from 0 at the first point to Len at the last), optionally with the road height.
    public sealed class PolyPath : IPath
    {
        public double Len { get; }
        public readonly double Ds;
        public readonly bool Closed;
        readonly double[] sx, sz, sh, sk, sy;

        public PolyPath(float[] xz, bool closed = true, float[] y = null)
        {
            Closed = closed;
            int m = xz.Length / 2;
            int segs = closed ? m : m - 1;
            var cum = new double[segs + 1];
            for (int i = 0; i < segs; i++) { int j = (i + 1) % m; cum[i + 1] = cum[i] + M.Hypot(xz[j * 2] - xz[i * 2], xz[j * 2 + 1] - xz[i * 2 + 1]); }
            double L = cum[segs];
            int n = Math.Max(2, (int)Math.Round(L, MidpointRounding.AwayFromZero));
            double ds = L / n;
            Len = L; Ds = ds;
            int cnt = closed ? n : n + 1; // an open line keeps a sample at each end
            sx = new double[cnt]; sz = new double[cnt]; sh = new double[cnt]; sk = new double[cnt]; sy = new double[cnt];
            int jj = 0;
            for (int i = 0; i < cnt; i++)
            {
                double s = Math.Min(i * ds, L);
                while (jj < segs - 1 && cum[jj + 1] < s) jj++;
                double span = cum[jj + 1] - cum[jj];
                double f = (s - cum[jj]) / (span != 0 ? span : 1);
                int a = jj, b = (jj + 1) % m;
                sx[i] = xz[a * 2] + (xz[b * 2] - xz[a * 2]) * f; sz[i] = xz[a * 2 + 1] + (xz[b * 2 + 1] - xz[a * 2 + 1]) * f;
                sy[i] = y != null && y.Length == m ? y[a] + (y[b] - y[a]) * f : double.NaN;
            }
            int Idx(int i) => closed ? ((i % cnt) + cnt) % cnt : Math.Clamp(i, 0, cnt - 1);
            for (int i = 0; i < cnt; i++) sh[i] = Math.Atan2(sz[Idx(i + 2)] - sz[Idx(i - 2)], sx[Idx(i + 2)] - sx[Idx(i - 2)]);
            for (int i = 0; i < cnt; i++)
            {
                double dh = M.WrapA(sh[Idx(i + 4)] - sh[Idx(i - 4)]);
                int span = closed ? 8 : Idx(i + 4) - Idx(i - 4);
                sk[i] = dh / (Math.Max(1, span) * ds);
            }
        }

        // sample index and fraction for s (clamped to the ends of an open line)
        void Locate(double s, out int i, out int k, out double f)
        {
            int n = sx.Length;
            if (Closed) s = ((s % Len) + Len) % Len; else s = Math.Clamp(s, 0, Len);
            double fi = s / Ds;
            int i0 = (int)Math.Floor(fi);
            f = fi - i0;
            if (Closed) { i = ((i0 % n) + n) % n; k = (i + 1) % n; }
            else
            {
                if (i0 >= n - 1) { i0 = n - 2; f = 1; }
                i = i0; k = i0 + 1;
            }
        }

        public PathPt At(double s)
        {
            Locate(s, out int i, out int k, out double f);
            return new PathPt
            {
                X = sx[i] + (sx[k] - sx[i]) * f, Z = sz[i] + (sz[k] - sz[i]) * f,
                H = sh[i] + M.WrapA(sh[k] - sh[i]) * f, K = sk[i], Part = 0,
            };
        }

        // road height at s (NaN when the pack has none)
        public double Y(double s)
        {
            Locate(s, out int i, out int k, out double f);
            return sy[i] + (sy[k] - sy[i]) * f;
        }

        public NearRes Nearest(double x, double z, int hint = -1)
        {
            int best = -1; double bd = double.PositiveInfinity;
            NearestScan.Find(sx, sz, x, z, hint, ref best, ref bd);
            return At(best, x, z);
        }

        // Nearest, telling roads apart by height as well: on a hillside of switchbacks the leg above or below can be
        // closer across than the one you're on. y is the height of the ground under you (the car's own height,
        // less about half a metre). Dist is still the distance across.
        public NearRes Nearest(double x, double y, double z, int hint)
        {
            if (double.IsNaN(sy[0]) || !double.IsFinite(y)) return Nearest(x, z, hint);
            int best = -1; double bd = double.PositiveInfinity;
            NearestScan.Find(sx, sy, sz, x, y, z, hint, ref best, ref bd);
            return At(best, x, z);
        }

        NearRes At(int best, double x, double z)
        {
            double h = sh[best], dx = x - sx[best], dz = z - sz[best];
            double along = dx * Math.Cos(h) + dz * Math.Sin(h);
            double S = Closed ? (best * Ds + along + Len) % Len : Math.Clamp(best * Ds + along, 0, Len);
            return new NearRes { I = best, S = S, D = -dx * Math.Sin(h) + dz * Math.Cos(h), Dist = Math.Sqrt(dx * dx + dz * dz) };
        }
    }

    /* ---------------- map pack: 'RBMP' | u32 json length | json | blob ---------------- */

    public sealed class MapMat
    {
        public string Name = "";
        public int Tex = -1;      // image index, -1 = none
        public int Mode;          // 0 opaque, 1 alpha test, 2 blended
        public string Cat = "";   // ground | veg | obj | small | wall
        public int Surf;          // 0 none, 1 tarmac, 2 kerb, 3 gravel, 4 grass
        public double Fade;       // metres, 0 = always drawn
        public bool Shadow;
        public int Layer;         // +1 drawn over the road, -1 under it
        public double Spec;
        public double[] Color = { 1, 1, 1, 1 };
        public int UnderTex = -1; // see-through ground: texture laid under it in world space
        public double UnderK;     // uv per metre
        public bool Fog = true;   // false: a backdrop that carries its own haze
    }

    // one LOD of a draw: an index list over the draw's own vertices (in the order MapWorldView builds them),
    // chosen by the renderer while its error (metres) stays under a pixel or so on screen
    public struct MapLod { public double Size; public int I0, N; }

    // NPhys: the first NPhys indices are ground the car drives on; the rest is only drawn (overhang undersides)
    public struct MapDraw { public int Mat, I0, N, NPhys; public double UOff, VOff, Kq; public MapLod[] Lods; }

    public sealed class MapChunk
    {
        public double[] O = new double[3], Min = new double[3], Max = new double[3];
        public int V0, VN, I0, IN;
        public double Qs;          // position steps per metre (the far backdrop chunk has coarser steps)
        public MapDraw[] Draws;
    }

    // a timed course besides the main circuit: a loop (timed by laps) or a sprint from a start line to a finish line
    public sealed class CourseInfo
    {
        public string Id = "", Name = "";
        public bool Loop, Sprint;
        public double Width = 10, Len;
        public float[] Line, LineY;          // a loop's centreline (x, z pairs) and heights
        public double SX, SZ, FX, FZ;        // a sprint's start and finish line centres
    }

    // a road's centreline: x, y, z every few metres
    public sealed class RoadLine
    {
        public string Id = "";
        public double Half = 3.5;
        public bool Loop;
        public float[] Pts;
    }

    public sealed class SpotInfo
    {
        public string Name = "";
        public double X, Z, Dx, Dz;          // where, and the way the car faces
    }

    public sealed class MapPack
    {
        public string Name = "";
        public double Qs = 64;
        public MapMat[] Materials;
        public MapChunk[] Chunks;
        public byte[] Geo;          // gunzipped: vertices (16 bytes each), then uint16 indices
        public int VLen, ILen;
        public ushort[] Idx, LodIdx;
        public float[] Walls, Line, LineY;
        public bool Loop = true;
        public bool Merge;          // draw with one texture array, materials merged per chunk (MapWorldView)
        public StageInfo Stage;
        public double Width = 11.5;
        public List<(double x, double z)> GridMarks = new List<(double, double)>();
        public string Credit = "";
        // a compound's extras (packs from game 1.9): more timed courses, every road's centreline (resets put the car
        // back on the nearest), the pads beside them, cones, and places to start from
        public List<CourseInfo> Courses = new List<CourseInfo>();
        public List<RoadLine> Roads = new List<RoadLine>();
        public List<(double x0, double z0, double x1, double z1)> Pads = new List<(double, double, double, double)>();
        public List<(double x, double z)> Cones = new List<(double, double)>();
        public List<SpotInfo> Spots = new List<SpotInfo>();
        public string ExtrasError;      // the extras didn't read (the map still loads, without them)
        byte[] buf;
        int blobBase;
        (int off, int len, string type)[] images;

        public int ImageCount => images.Length;
        public byte[] Image(int i)
        {
            var im = images[i];
            var b = new byte[im.len];
            Buffer.BlockCopy(buf, blobBase + im.off, b, 0, im.len);
            return b;
        }

        // vertex k of the chunk-relative buffer: position (int16 x3 from the chunk origin, 1/qs steps),
        // normal (int8 x4, normalised), uv (int16 x2, scaled per draw)
        public short PosQ(int v, int c) => BinaryPrimitives.ReadInt16LittleEndian(new ReadOnlySpan<byte>(Geo, v * 16 + c * 2, 2));
        public sbyte NrmQ(int v, int c) => (sbyte)Geo[v * 16 + 8 + c];
        public short UvQ(int v, int c) => BinaryPrimitives.ReadInt16LittleEndian(new ReadOnlySpan<byte>(Geo, v * 16 + 12 + c * 2, 2));

        static double Num(JsonElement e, string k, double def)
        {
            if (e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number) return v.GetDouble();
            return def;
        }
        static int Int(JsonElement e) => (int)Math.Round(e.GetDouble());
        static string Str(JsonElement e, string k, string def)
        {
            if (e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String) return v.GetString();
            return def;
        }
        static double[] Arr(JsonElement e)
        {
            var o = new double[e.GetArrayLength()];
            int i = 0;
            foreach (var x in e.EnumerateArray()) o[i++] = x.GetDouble();
            return o;
        }
        static float[] Floats(byte[] b, int off, int count)
        {
            var o = new float[count];
            for (int i = 0; i < count; i++) o[i] = BinaryPrimitives.ReadSingleLittleEndian(new ReadOnlySpan<byte>(b, off + i * 4, 4));
            return o;
        }

        static bool Flag(JsonElement e, string k) => e.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.True;

        // the extra map data: arrays sit in the blob as float32 ([offset, bytes, count])
        static void Extras(MapPack pk, JsonElement meta, byte[] buf, int bas)
        {
            float[] Blob(JsonElement e)
            {
                var a = Arr(e);
                if (a.Length < 3 || a[0] < 0 || bas + (long)a[0] + (long)a[2] * 4 > buf.Length) throw new Exception("bad array");
                return Floats(buf, bas + (int)a[0], (int)a[2]);
            }
            bool IsArr(JsonElement e, string k, out JsonElement v) => e.TryGetProperty(k, out v) && v.ValueKind == JsonValueKind.Array;
            if (IsArr(meta, "tracks", out var trs))
                foreach (var t in trs.EnumerateArray())
                {
                    var c = new CourseInfo { Id = Str(t, "id", ""), Name = Str(t, "name", ""), Width = Num(t, "width", 10), Len = Num(t, "len", 0), Loop = Flag(t, "loop"), Sprint = Flag(t, "sprint") };
                    if (c.Id.Length == 0) continue;
                    if (c.Sprint)
                    {
                        if (!IsArr(t, "start", out var s0) || !IsArr(t, "finish", out var f0)) continue;
                        var a = Arr(s0); var b = Arr(f0);
                        c.SX = a[0]; c.SZ = a[1]; c.FX = b[0]; c.FZ = b[1];
                        if (Math.Abs(c.FX - c.SX) + Math.Abs(c.FZ - c.SZ) < 10) continue;
                    }
                    else
                    {
                        if (!c.Loop || !IsArr(t, "line", out var l)) continue;
                        c.Line = Blob(l);
                        if (IsArr(t, "lineY", out var ly)) c.LineY = Blob(ly);
                        if (c.Line.Length < 16 || (c.LineY != null && c.LineY.Length * 2 != c.Line.Length)) continue;
                    }
                    pk.Courses.Add(c);
                }
            if (IsArr(meta, "roads", out var rds))
                foreach (var r in rds.EnumerateArray())
                {
                    if (!IsArr(r, "pts", out var p)) continue;
                    var rl = new RoadLine { Id = Str(r, "id", ""), Half = Num(r, "half", 3.5), Loop = Flag(r, "loop"), Pts = Blob(p) };
                    if (rl.Pts.Length >= 6 && rl.Pts.Length % 3 == 0) pk.Roads.Add(rl);
                }
            if (IsArr(meta, "pads", out var pds))
            {
                var f = Blob(pds);
                for (int i = 0; i + 3 < f.Length; i += 4) pk.Pads.Add((f[i], f[i + 1], f[i + 2], f[i + 3]));
            }
            if (IsArr(meta, "cones", out var cns))
            {
                var f = Blob(cns);
                for (int i = 0; i + 1 < f.Length; i += 2) pk.Cones.Add((f[i], f[i + 1]));
            }
            if (IsArr(meta, "spots", out var sps))
                foreach (var s in sps.EnumerateArray())
                {
                    if (!IsArr(s, "at", out var at)) continue;
                    var a = Arr(at);
                    if (a.Length < 4) continue;
                    double l = Math.Sqrt(a[2] * a[2] + a[3] * a[3]);
                    if (!(l > 1e-6)) continue;
                    pk.Spots.Add(new SpotInfo { Name = Str(s, "name", "Start " + (pk.Spots.Count + 1)), X = a[0], Z = a[1], Dx = a[2] / l, Dz = a[3] / l });
                }
        }

        public static MapPack Load(byte[] buf)
        {
            if (buf.Length < 8 || BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 0, 4)) != 0x504d4252) throw new Exception("not a map pack");
            int jl = (int)BinaryPrimitives.ReadUInt32LittleEndian(new ReadOnlySpan<byte>(buf, 4, 4));
            int bas = 8 + jl;
            var pk = new MapPack { buf = buf, blobBase = bas };
            using (var doc = JsonDocument.Parse(new ReadOnlyMemory<byte>(buf, 8, jl)))
            {
                var h = doc.RootElement;
                pk.Name = Str(h, "name", "map");
                pk.Qs = Num(h, "qs", 64);
                // materials
                var mats = new List<MapMat>();
                foreach (var m in h.GetProperty("materials").EnumerateArray())
                {
                    var mm = new MapMat
                    {
                        Name = Str(m, "name", ""),
                        Mode = (int)Num(m, "mode", 0),
                        Cat = Str(m, "cat", "obj"),
                        Surf = (int)Num(m, "surf", 0),
                        Fade = Num(m, "fade", 0),
                        Layer = (int)Num(m, "layer", 0),
                        Spec = Num(m, "spec", 0.1),
                    };
                    if (m.TryGetProperty("tex", out var tx) && tx.ValueKind == JsonValueKind.Number) mm.Tex = Int(tx);
                    if (m.TryGetProperty("shadow", out var sh)) mm.Shadow = sh.ValueKind == JsonValueKind.True;
                    if (m.TryGetProperty("fog", out var fg)) mm.Fog = fg.ValueKind != JsonValueKind.False;
                    if (m.TryGetProperty("color", out var col) && col.ValueKind == JsonValueKind.Array) mm.Color = Arr(col);
                    if (m.TryGetProperty("under", out var un) && un.ValueKind == JsonValueKind.Array)
                    {
                        var u = Arr(un);
                        mm.UnderTex = (int)u[0]; mm.UnderK = u[1];
                    }
                    mats.Add(mm);
                }
                pk.Materials = mats.ToArray();
                // images
                var ims = new List<(int, int, string)>();
                foreach (var im in h.GetProperty("images").EnumerateArray())
                {
                    var a = im.EnumerateArray();
                    a.MoveNext(); int off = Int(a.Current);
                    a.MoveNext(); int len = Int(a.Current);
                    a.MoveNext(); string type = a.Current.GetString();
                    ims.Add((off, len, type));
                }
                pk.images = ims.ToArray();
                // geometry
                var geo = Arr(h.GetProperty("geo"));
                using (var ms = new MemoryStream(buf, bas + (int)geo[0], (int)geo[1]))
                using (var gz = new GZipStream(ms, CompressionMode.Decompress))
                using (var outMs = new MemoryStream((int)(geo[2] + geo[3])))
                {
                    gz.CopyTo(outMs);
                    pk.Geo = outMs.ToArray();
                }
                pk.VLen = (int)geo[2]; pk.ILen = (int)geo[3];
                int ni = pk.ILen / 2;
                pk.Idx = new ushort[ni];
                for (int i = 0; i < ni; i++) pk.Idx[i] = BinaryPrimitives.ReadUInt16LittleEndian(new ReadOnlySpan<byte>(pk.Geo, pk.VLen + i * 2, 2));
                int nl = geo.Length > 4 ? (int)geo[4] / 2 : 0;
                pk.LodIdx = new ushort[nl];
                for (int i = 0; i < nl; i++) pk.LodIdx[i] = BinaryPrimitives.ReadUInt16LittleEndian(new ReadOnlySpan<byte>(pk.Geo, pk.VLen + pk.ILen + i * 2, 2));
                // chunks
                var chunks = new List<MapChunk>();
                foreach (var c in h.GetProperty("chunks").EnumerateArray())
                {
                    var v = Arr(c.GetProperty("v")); var ii = Arr(c.GetProperty("i"));
                    var ch = new MapChunk { O = Arr(c.GetProperty("o")), Min = Arr(c.GetProperty("min")), Max = Arr(c.GetProperty("max")), V0 = (int)v[0], VN = (int)v[1], I0 = (int)ii[0], IN = (int)ii[1], Qs = Num(c, "qs", pk.Qs) };
                    var draws = new List<MapDraw>();
                    foreach (var d in c.GetProperty("d").EnumerateArray())
                    {
                        var a = d.EnumerateArray();
                        a.MoveNext(); int mat = Int(a.Current);
                        a.MoveNext(); int i0 = Int(a.Current);
                        a.MoveNext(); int n = Int(a.Current);
                        var md = new MapDraw { Mat = mat, I0 = i0, N = n, NPhys = n, UOff = 0, VOff = 0, Kq = 1 };
                        if (a.MoveNext() && a.Current.ValueKind == JsonValueKind.Array)
                        {
                            var uv = Arr(a.Current);
                            md.UOff = uv[0]; md.VOff = uv[1]; md.Kq = uv[2];
                            if (a.MoveNext() && a.Current.ValueKind == JsonValueKind.Number) md.NPhys = Math.Min(n, Int(a.Current));
                            if (a.MoveNext() && a.Current.ValueKind == JsonValueKind.Array)
                            {
                                var lods = new List<MapLod>();
                                foreach (var l in a.Current.EnumerateArray())
                                {
                                    var la = Arr(l);
                                    if ((int)la[1] + (int)la[2] <= pk.LodIdx.Length) lods.Add(new MapLod { Size = la[0], I0 = (int)la[1], N = (int)la[2] });
                                }
                                md.Lods = lods.ToArray();
                            }
                        }
                        draws.Add(md);
                    }
                    ch.Draws = draws.ToArray();
                    chunks.Add(ch);
                }
                pk.Chunks = chunks.ToArray();
                // walls and centreline (float32)
                var wl = Arr(h.GetProperty("walls"));
                pk.Walls = Floats(buf, bas + (int)wl[0], (int)wl[2] * 6);
                var ln = Arr(h.GetProperty("line"));
                pk.Line = Floats(buf, bas + (int)ln[0], (int)ln[2] * 2);
                if (h.TryGetProperty("lineY", out var lyE) && lyE.ValueKind == JsonValueKind.Array)
                {
                    var ly = Arr(lyE);
                    pk.LineY = Floats(buf, bas + (int)ly[0], (int)ly[2]);
                }
                if (h.TryGetProperty("meta", out var meta))
                {
                    pk.Width = Num(meta, "width", 11.5);
                    pk.Credit = Str(meta, "credit", "");
                    if (meta.TryGetProperty("loop", out var lp)) pk.Loop = lp.ValueKind != JsonValueKind.False;
                    if (meta.TryGetProperty("merge", out var mg)) pk.Merge = mg.ValueKind == JsonValueKind.True;
                    if (meta.TryGetProperty("stage", out var st) && st.ValueKind == JsonValueKind.Object)
                    {
                        pk.Stage = new StageInfo { Start = Num(st, "start", 0), Finish = Num(st, "finish", 0) };
                    }
                    if (meta.TryGetProperty("grid", out var grid) && grid.ValueKind == JsonValueKind.Array)
                        foreach (var gm in grid.EnumerateArray()) { var xz = Arr(gm); pk.GridMarks.Add((xz[0], xz[1])); }
                    try { Extras(pk, meta, buf, bas); }
                    catch (Exception e) { pk.ExtrasError = e.Message; pk.Courses.Clear(); pk.Roads.Clear(); pk.Pads.Clear(); pk.Cones.Clear(); pk.Spots.Clear(); }
                }
            }
            return pk;
        }

        // Terrain for a map pack: ground triangles read back from the render chunks, walls, centreline, grid.
        public static MeshTerrain BuildTerrain(MapPack pk)
        {
            var mats = pk.Materials;
            bool Solid(int m) => mats[m].Surf > 0 && mats[m].Mode != 2; // blended edges sit on top of the real surface
            int n = 0;
            foreach (var c in pk.Chunks) foreach (var d in c.Draws) if (Solid(d.Mat)) n += d.NPhys / 3;
            var tri = new float[n * 9];
            var surf = new byte[n];
            int k = 0;
            foreach (var c in pk.Chunks)
                foreach (var d in c.Draws)
                {
                    if (!Solid(d.Mat)) continue;
                    double q = 1 / c.Qs;
                    for (int j = 0; j + 2 < d.NPhys; j += 3, k++)
                    {
                        for (int e = 0; e < 3; e++)
                        {
                            int v = c.V0 + pk.Idx[c.I0 + d.I0 + j + e];
                            tri[k * 9 + e * 3] = (float)(c.O[0] + pk.PosQ(v, 0) * q);
                            tri[k * 9 + e * 3 + 1] = (float)(c.O[1] + pk.PosQ(v, 1) * q);
                            tri[k * 9 + e * 3 + 2] = (float)(c.O[2] + pk.PosQ(v, 2) * q);
                        }
                        surf[k] = (byte)mats[d.Mat].Surf;
                    }
                }
            if (k * 9 < tri.Length) { Array.Resize(ref tri, k * 9); Array.Resize(ref surf, k); }
            var T = new MeshTerrain(tri, surf, pk.Walls);
            var path = new PolyPath(pk.Line, pk.Loop, pk.LineY);
            if (pk.Stage != null)
            {
                // a stage: no grid, the car waits 12 m short of the START line, facing up the road
                var st = pk.Stage;
                var slot = new GridSlot { S = st.Start - 9.4, D = 0 };
                T.Circuit = new Circuit { Path = path, Width = pk.Width, SLine = st.Start, Grid = new List<GridSlot> { slot }, Mesh = true, Name = pk.Name, Stage = st };
                var ps = path.At(slot.S - 2.6);
                T.HasSpawn = true;
                T.SpawnPos = new V3(ps.X, 0, ps.Z);
                T.SpawnYaw = Math.Atan2(-Math.Cos(ps.H), -Math.Sin(ps.H));
                return T;
            }
            // grid slots: the painted boxes behind the start line (front edge 1.5 m ahead of the box centre), pole first
            var grid = new List<GridSlot>();
            foreach (var (x, z) in pk.GridMarks)
            {
                var nr = path.Nearest(x, z);
                double s = nr.S + 1.5;
                if (s > path.Len - 250 && s < path.Len - 0.3) grid.Add(new GridSlot { S = s, D = nr.D });
            }
            grid.Sort((a, b) => b.S.CompareTo(a.S));
            if (grid.Count < 2)
            {
                grid.Clear();
                for (int i = 0; i < 20; i++) grid.Add(new GridSlot { S = path.Len - 7 - 8 * i, D = i % 2 != 0 ? 2.9 : -2.9 });
            }
            T.Circuit = new Circuit { Path = path, Width = pk.Width, SLine = 0, Grid = grid, Mesh = true, Name = pk.Name };
            var g0 = grid[0];
            var p = path.At(g0.S - 2.6);
            T.HasSpawn = true;
            T.SpawnPos = new V3(p.X - Math.Sin(p.H) * g0.D, 0, p.Z + Math.Cos(p.H) * g0.D);
            T.SpawnYaw = Math.Atan2(-Math.Cos(p.H), -Math.Sin(p.H));
            return T;
        }
    }
}
